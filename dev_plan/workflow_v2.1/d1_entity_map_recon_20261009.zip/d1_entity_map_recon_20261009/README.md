# Workflow V2 · D1 Entity Map 实现现状勘察

勘察日期：2026-10-09，时间均按 Asia/Shanghai 表述。远端产出主快照采集时间：2026-10-09 02:29:24。用途：为后续该节点重做提供当前实现、接口与实际样本基线；本文件不是重做方案或上线验收。

## 1. 结论与交付

当前 Entity Map 是 Global Research 中 C4 产出的 `entity_relations` 五字段关系列表，随整个研究 bundle 发布。它提供轻量业务关系上下文，尚未实现独立的规范化实体库、关系图存储或单独版本生命周期。

当前初始化链路的 D1 实际运行 `codex_global_research_v1 / global_research`。其顺序是横向数据准备 → C4 预扫描 → C1/C3 并行 → Observation 归一化 → C5 → C4 enrichment → 汇总与发布。Entity Map 与 Future Nodes 共用两次 C4 turn，enrichment 是最终完整快照，没有独立 C4 finalization。仓库内另一条 `codex_d1_v2 / legacy_document1` 兼容路径仍有 finalization，不能用它替代当前初始化编排的解释。

INTC、BE 的已发布关系已从新加坡远端拉取。分别为 **23 条、30 条**；当前激活 revision 的 `artifacts.document1.run_id` 与所取 D1 一致。两份 D1 均于 2026-09-21 UTC 发布，业务研究 cutoff 也停留在当时，当前 activation 的更新不代表 Entity Map 已刷新至 10 月。

重做前最需要关注的是：关系对象粒度混合、关系类型自由文本、Entity Map 与 Future Nodes 的共用完成条件、完整快照主要依赖提示词，以及 C4 引用作用域未随 bundle 结构行完整表达。最后一项在 INTC 样本中已经存在实际别名映射冲突，详见第 8 节。

| 交付物 | INTC | BE |
| --- | --- | --- |
| 可读 Entity Map，保留五字段原文 | [entity_map.md](INTC/entity_map.md) | [entity_map.md](BE/entity_map.md) |
| Entity Map JSON，原列表的无损抽取 | [entity_map.json](INTC/entity_map.json) | [entity_map.json](BE/entity_map.json) |
| 远端已发布 bundle 原始 JSON | [bundle.raw.json](INTC/bundle.raw.json) | [bundle.raw.json](BE/bundle.raw.json) |
| 预扫描 completion 原始字节 | [c4_pre_scan](INTC/c4_pre_scan.completion.raw.json) | [c4_pre_scan](BE/c4_pre_scan.completion.raw.json) |
| 最终 enrichment completion 原始字节 | [c4_enrichment](INTC/c4_enrichment.completion.raw.json) | [c4_enrichment](BE/c4_enrichment.completion.raw.json) |
| 当前 activation 依据 | [activation](INTC/activation_revision.raw.json) | [activation](BE/activation_revision.raw.json) |

每个 ticker 目录另含 C4 citation manifest、ArtifactRef、冻结输入资源、ingestion/bundle audit 和初始化 D1 节点记录。完整文件来源、大小及 SHA-256 见 [远端采集清单](evidence/remote_capture_manifest.json)；结构分析及校验探针见 [analysis.json](evidence/analysis.json)。C4 的 `report.raw.md` 为 0 字节，符合结构化 C4 的预期，因此阅读关系应使用 JSON 或本次生成的可读投影。

## 2. 勘察依据与版本边界

### 2.1 本地工作区

- cwd：`C:\Users\WEIXUANXIE\Desktop\DoxAgent`。
- 分支：`codex/v1-retirement-cleanup`；HEAD：`f9d1a3f8928d9af1a61a34eb99682b9395a65f5f`。
- 开始勘察时已有 142 条工作区状态记录，含 D2/D3 等未提交改动。本文读取当前工作区实际文件，不将 HEAD 当作所有文件的精确内容版本。
- 项目为 Python 3.11–3.13 / Codex SDK / SQLite 与可选 Postgres repository；测试使用 pytest，静态工具为 Ruff/mypy，前端为独立 `frontend/v2`。本次范围是 D1 Entity Map 与交接边界。

### 2.2 远端

- SSH：`doxagent-sg`，实测身份 `ubuntu@VM-0-15-ubuntu`；仓库 `/home/ubuntu/doxagent`。
- 远端仓库 HEAD：`b0f1caf50060b34483f13020a9d173ef57933afa`，也有未提交修改。
- 实际初始化容器：`doxagent-v2-v2-initialization-1`，镜像 `doxagent-v2:codex-gpt6-research-0.159.3`；Worker 为 `doxagent-v2-codex-worker-1`，镜像 `doxagent-v2:maintenance-worker-20261003`。
- 产出从 `/data/research/research.sqlite3` 与 `/data/workspaces/<run_id>` 读取；激活指针从 `/data/initialization/control.sqlite3` 读取。SQLite 使用 `mode=ro`、`PRAGMA query_only=ON` 和显式读事务；研究库与控制库各自具有事务快照，不宣称跨库原子快照。
- 检查了初始化容器 `/app` 中 12 个相关代码/资源文件。归一化换行后，11 个与本地相同；`codex_runtime/schema.py` 的差异限于本地新增的 D2/D3 节点枚举，EntityRelation、FutureNode 和 GlobalResearchBundle 未变。证据位于 `evidence/runtime_source/` 和 `analysis.json`。
- 两个 ticker、四次 C4 attempt 的冻结 `task.md`、Entity Map skill 和 JSON Schema，均与本地当前对应资源一致。历史产出的提示契约与本次分析基线吻合。

当前初始化进程有效设置为 `gpt-6-luna / max / 1800s`。但这两份历史样本的四次 Worker 请求实际为 **`gpt-5.6-luna / max / 1800s`**，C4 均 `allow_subagents=false`。不能把当前模型配置归因到历史产出。相关请求与当前有效配置见 [remote_worker_settings.json](evidence/remote_worker_settings.json)。

本次没有重新调用研究模型、刷新 ticker、修改生产业务代码或执行部署。关系中的外部业务事实按原文保留，未逐条重新上网核实。平台引用可解析与事实是否正确、是否仍然有效是不同验证维度。

## 3. 编排现状

### 3.1 初始化大编排

`ticker_initialization/catalog.py` 中 D1 和 CDECR 无相互依赖，可并行运行；O2 等待 D1+CDECR，D2 等待 D1+O2，D3 等待 D2+O2，随后进入 O4 和 activation。

```mermaid
flowchart LR
    D1["D1 / Global Research"] --> O2
    CDECR --> O2
    D1 --> D2
    O2 --> D2
    D2 --> D3
    O2 --> D3
    D3 --> O4
    O4 --> Activation
```

初始化 `research_adapter._d1()` 直接创建 `CodexGlobalResearchOrchestrator`，child run ID 为 `<initialization_id>-d1`。`codex_research_lanes_enabled` 在当前环境为 true，但此入口直接选择 Global Research；不应把这个配置字段解释为该入口仍在新旧 D1 间动态选择。

### 3.2 Global Research 内部

```mermaid
flowchart TD
    HC["program_collection / Horizontal Collection"] --> PRE["C4 pre_scan：Entity Map + 初步 Future Nodes"]
    PRE --> C1["C1 基本面；future_nodes 置空"]
    PRE --> C3["C3 行业链；future_nodes 置空"]
    C1 --> N["agent_normalization：C1/C3 Observation"]
    C3 --> N
    N --> C5["C5 市场隐含预期"]
    PRE --> EN["C4 enrichment：完整最终快照"]
    C1 --> EN
    C3 --> EN
    C5 --> EN
    EN --> PUB["assemble / publish GlobalResearchBundle"]
```

| 环节 | 实际输入/行为 | 对 Entity Map 的作用 |
| --- | --- | --- |
| 数据准备 | 收集或恢复 Global Research 横向数据 | 发生在 C4 前；C4 请求没有 `horizontal.json`，不能据调用顺序推断其直接读取横向全集 |
| C4 pre_scan | ticker、company_name、research_brief、base_context；Worker 同时携带统一 cutoff | 构建轻量关系列表并扫描直接未来事项；任务字符串同时要求两者，不是两个独立节点 |
| C1/C3 | 预扫描 `NodeOutput` 的交接副本 | 程序只将 `future_nodes` 数组置空，保留 entity_relations；其余 summary/warnings 等 envelope 字段仍在，非纯关系列表接口 |
| C5 | C1、C3 报告与归一化 Observation，横向市场输入 | 不直接接收独立 `entity_relations` 字段；关系可经 C1/C3 研究内容间接影响它 |
| C4 enrichment | 完整预扫描、C1/C3/C5 报告、归一化 Observation | 提示词要求保留/修正/去重旧关系并补充新关系；同时补充 Future Nodes；返回完整快照 |
| 发布 | 直接取最终 C4 列表存入 bundle | 没有后置关系抽取器、实体归一化器、关系图构建器或独立 map 发布步骤 |

同一个 run 下，C4 预扫描和 enrichment 正常复用 C4 role 的 Codex thread。INTC、BE 的 durable attempt 记录均证明两次 C4 使用同一 thread。已有 attempt 历史的节点重试会启动新 thread，避免旧 attempt 的 Data MCP / Source Capture 作用域混用。

### 3.3 完成、恢复与降级

1. 同 run 已存在 `published` GlobalResearchBundle 时直接返回，不重新生成。
2. 节点可通过已成功 attempt 的 `input_sha256`、ArtifactRef 和输出恢复；input hash 包含上下文、bundle manifest、prompt/skill/schema 等资源。
3. 初始化 `_d1` 配置 `max_attempts=1`；durable 内部 turn 另受初始化 substep 调度控制，不等同于没有任何上层重试机制。
4. `_execute_or_partial()` 将一般节点异常转为失败占位输出，记录 checkpoint/event；lease、capability、不可变 workspace 等完整性异常仍直接抛出。
5. 发布核心门槛是 C1/C3/C5 有报告 ArtifactRef 且报告非空。C4 是可降级上下文：失败不必阻塞整个 D1。
6. **仅当 enrichment 的 entity_relations 与 future_nodes 同时为空，才整体回退 pre_scan。** enrichment 若只有 Future Nodes，最终 Entity Map 可变成空数组；若只返回部分关系，程序直接采用该部分，不自动 union 预扫描。
7. `require_complete_c4_enrichment` 默认为 false，当前 runner 调用未开启；即使开启，其检查也只要求“两类数组至少一类非空”，不验证完整快照。

正常新流程没有 `c4_finalization`。兼容 orchestrator 的额外 finalization、C2、O4-A/B 只用于解释保留代码与历史身份，不是当前初始化运行路径。

## 4. 业务定位与生成逻辑

当前业务目的，是为后续研究提供“目标公司有哪些业务关系、关系具体是什么、关联哪个业务或产品”的事实背景。提示词要求覆盖相关的业务分部、产品/平台、客户、供应商、制造伙伴、竞争者/替代品、商业/技术伙伴，以及明确的监管、地域、技术、基础设施、原料暴露。

Agent 应保持事实中性，不猜测未披露交易对手，不把传闻当关系，不评估财务影响，不排序重要性，不形成 Unit/Gap、投资建议、交易建议或监控规则。覆盖时可以选择与目标实质相关的关系，但没有重要性评分字段。

生成由模型搜索和阅读材料完成，程序负责输入冻结、输出接纳、引用 promotion、恢复与发布。没有固定节点数或关系条数，没有关系类型枚举，没有“每个公司必须生成客户/供应商/竞争者各 N 条”的程序规则。需要何种粒度主要由模型和提示词决定。

Entity Map 与 Future Nodes 的耦合不仅在输出上：预扫描发现关系后可沿一阶客户、供应商、伙伴、监管主体寻找未来事项；enrichment 则在读完 C1/C3/C5 后同时补全两种列表。Future Node 是可观察的未来事项及其时间窗，不能把关系、主题趋势和未来事件混成一类对象。

C4 可使用受 role 能力控制的 Data MCP 和 Source Capture。`data_runtime/policy.py` 的 C4 白名单涉及 SEC、IR、Federal Register、监管、政府合同/支出、公司新闻等；实际可用工具还经过通用排除规则。Worker SDK 具有原生 web search 配置。白名单中的名字不代表每次任务都成功调用或有业务覆盖，两份样本的 Warning 就记录了抓取失败等边界。

## 5. Schema 与字段字典

### 5.1 EntityRelation：每行恰好五个公开字段

| 中文 JSON 字段 | Python / durable 内部名 | 当前业务含义 | 当前限制与歧义 |
| --- | --- | --- | --- |
| 关系主体 | `relation_subject` | 关系起点、发起方或业务所属主体 | 不是 ticker 外键；可写 Intel，也可写 Intel Foundry，没有必须等于目标公司的校验 |
| 关系对象 | `relation_object` | 关系另一端的公司、分部、产品、平台、设施、主体类别或暴露对象 | 非规范化 entity ID；可是一家公司、多家公司合写、产品组合或宽泛主体集合 |
| 关系类型 | `relation_type` | 对该关系的业务标签，例如客户、制造合作、竞争/替代 | 自由字符串；无枚举，可混合多个角色，方向语义也无机器约束 |
| 关系说明 | `relation_description` | 解释关系是什么、为什么成立及必要事实边界 | 自由文本；可嵌入 O 别名、Markdown URL、数量和条件，没有专门证据字段 |
| 关联业务或产品 | `related_business_or_product` | 关系对应的业务范围、产品、技术或应用 | 自由字符串；非产品 ID，不校验与主体/对象是否属于同一体系，可混写多个业务 |

五字段均为必需 `str`；`extra='forbid'`，`populate_by_name=True`，因此既接受中文 alias，也接受内部英文名。Agent wire schema 使用中文 alias；NodeOutput、SQLite bundle 等 canonical 持久化一般 `by_alias=True`，部分 durable/内部交接以英文名序列化，两者语义相同。

EntityRelation 没有独立 `schema_version`、entity/relation ID、ticker/市场/地区身份键、source/source_date、effective_from/effective_to、status、confidence、importance、金额/收入占比、上下游层级或边属性。外围 run/artifact/attempt 存在 ID 与状态，这不与提示词“公开关系行不加 ID/状态机”冲突。

当前字符串没有 `minLength`、空白检查、格式约束或字段间一致性校验；数组没有关系去重或数量约束。第 9 节的探针实测了这些接纳行为。

### 5.2 与 FutureNode 的区别

FutureNode 的五字段为 `时间/time`、`未来事项/future_event`、`与目标公司的关系/relationship_to_target`、`来源/source`、`来源发布日期/source_published_at`，也都是字符串，时间保留源精度，不是强制 ISO date。

Entity Map **没有** FutureNode 的来源与发布日期字段。不能因为两者共用 C4，就假定关系行也携带同等来源/时间结构。关系证据目前只能从文本内引用和外层 attempt citation manifest 追溯。

### 5.3 节点 envelope

| 字段 | 用途/当前行为 |
| --- | --- |
| `status` | 节点自述状态，类型为自由 `str`，不是 attempt 或 bundle 的受限状态枚举 |
| `summary` | 简短摘要，默认空串；C1/C3 关系交接副本仍保留它 |
| `report_markdown` | C4 提示词要求空串，程序仍生成空 report artifact；当前 validator 没有强制 C4 必须为空 |
| `warnings` | 节点提示与恢复/证据诊断，默认空数组 |
| `observation_candidates` | 研究 Observation 候选，默认空数组；不是实体关系本身 |
| `entity_relations` | `list[EntityRelation]`，默认空数组 |
| `future_nodes` | `list[FutureNode]`，默认空数组 |
| `metadata` | 关闭扩展的空对象，未定义业务字段 |

Worker 的 `NODE_OUTPUT_SCHEMA` 由 Pydantic schema 转换为严格 JSON Schema，每个 object 的所有属性都进入 `required`，并禁止额外属性。因此 wire 上要求完整 envelope；本地模型与恢复器仍允许默认值补齐。仓库静态 `prompts/.../schemas/node_output.schema.json` 同时作为 attempt 输入文件提供给 Agent。

### 5.4 接纳层的实际宽容行为

`recover_output()` 逐行接纳关系/Future Nodes/Observation：缺少必需业务字段或类型错误的行隔离到 `audit/ingestion.json`，保留其余可用内容。它不编造缺失关系字段。

`ingest_model()` 会先剥除 `extra_forbidden` 扩展字段再验证。探针中关系行的 `confidence` 被去掉，且没有产生 quarantine 记录。故“严格 schema 不允许扩展”与“接纳器遇到扩展会修整”的层次应分别描述。文本真实内容、主体解析、关系方向、重复事实、过期关系及正文是否支持声明，均不在此处自动验证。

## 6. 文件、持久化与发布边界

每次 C4 attempt 冻结 `input/AGENTS.md`、`task.md`、`task.json`、`context.json`、bundle manifest、skill、schema。`task.json` 当前版本 `codex-d1-attempt-task-v4`，声明 `output/completion.json`；C4 无 progressive draft/progress/observation-candidate sidecar要求。Agent task 与技能输出语言为 zh-CN。

runner 先读 Worker 最终 response 并恢复；若两类结构数组都为空，再尝试读取 workspace 的 `output/completion.json`。这不是逐字段合并：response 已有任意关系或未来事项时，不再用 sidecar 补齐另一类数组。随后写 canonical：

```text
/data/workspaces/<run_id>/
  attempts/<attempt_id>/input/...
  attempts/<attempt_id>/output/completion.json
  attempts/<attempt_id>/audit/{bundle,ingestion,...}.json
  artifacts/c4_pre_scan/<attempt_id>/{report.md,completion.json}
  artifacts/c4_enrichment/<attempt_id>/{report.md,completion.json}
  artifacts/global_research/{global_research_v1.md,citation_manifest.json}
```

GlobalResearchBundle 包含 workflow_version、research_lane、run_id、ticker、status、reports、entity_relations、future_nodes、citation_manifest、handoff、created_at、published_at。bundle 的 published 校验要求 handoff 和 published_at，并不要求 Entity Map 非空。

当前远端 SQLite 为 `codex_runtime_records(record_type,record_key,run_id,workflow_version,research_lane,sort_order,payload_json,updated_at)`，bundle 的 record_type 是 **`bundles`**。Entity Map 嵌在 bundle payload 内，没有单独 entity/edge 表；citation manifest 在 `codex_local_citation_manifests`。

可选 Postgres repository 对应 `doxagent.codex_global_research_bundles`，`entity_relations` / `future_nodes` 为 JSONB 数组，`report_index` 为 JSONB 对象。迁移声明相关 JSON 合计 ≤524288 bytes，并校验 lane/version 和发布状态；没有把每行五字段展开为数据库列。此处是代码/迁移契约核对，未查询云端 Postgres 实际 schema，也不将其视为当前样本的读取来源。

`_publish_references()` 发布并校验 reports/citation 等文件正文。Entity Map 的权威列表随 bundle 保存，不在 Global Research 汇总 Markdown 中；assembler 只拼 C1/C3/C5。节点 completion 保留在 workspace/ArtifactRef repository 中，但不是独立 Entity Map 发布产品。

现行 V2 基础投研读取/下载设计展示 C1/C3/C5 与 Future Nodes；`v2_read/artifacts.py` 和 API 契约没有 Entity Map 页面/下载项。不能通过正常研究 ZIP 期望获得完整 Entity Map；本次通过远端 bundle 与 C4 原始产物独立导出。

## 7. 下游使用与证据交接

| 消费方 | 当前交接形式 | 勘察边界 |
| --- | --- | --- |
| C1/C3 | `c4_pre_scan` envelope；future_nodes 数组置空 | 当前 Global Research 执行路径已确认 |
| C4 enrichment | 完整 pre_scan 与 C1/C3/C5 envelope | `_handoff_output()` 标记上游 Artifact ID；rebinder 导入当前 attempt Observation 并重写引用 |
| O2 | `O2UpstreamContextManifest.entity_relations` 与 future_nodes，含 D1 run/published_at/研究 refs | `research_adapter.py` 明确传递；内部序列化可为英文字段名 |
| D2 | `GlobalResearchInput.entity_relations`，别名统一加 `D1-` 前缀 | 当前本地 D2 输入契约；该前缀没有区分 C4 与汇总 manifest 的 O 命名空间 |
| 本地 D3 v2.1 | 冻结 Global 原始 artifacts，并写 `shared/global/structure.json`，含关系与未来节点 | 本地 v2.1 实现已确认；不是对远端旧 D3 运行过程的重放验收 |
| activation | 保存 `document1.run_id` 指针 | 当前两个 ticker 仍固定指向本次取得的 D1；activation 本身不重新生成 Entity Map |
| V2 基础投研页面 | 未索引为展示项 | 只读呈现范围；不等同于 bundle 中不存在关系 |

attempt 内正式引用形如 `【cite:O2】`。C4 node manifest 锚定 report ArtifactRef，虽然 report 正文为空，promotion 实际扫描的是完整 NodeOutput JSON，所以结构字段里的 O 引用可进入该 manifest。

交接至另一个 D1 attempt 时，`UpstreamObservationRebinder` 根据上游 Artifact ID、其 manifest 和源 Observation 重新导入证据，分配目标 attempt 的 O 别名。证据缺失则降级为 `[upstream evidence unavailable]` 并保留 warning，不伪造已解析来源。

Global Research 汇总 manifest 只聚合 C1/C3/C5，重写这些报告的 O 编号。最终 bundle 的 Entity Map 则直接来自 C4 enrichment，保留 **C4 自己的 O 编号**。两种 manifest 不能互换使用。

## 8. INTC、BE 真实样本及重做关注项

### 8.1 样本身份与规模

| 项目 | INTC | BE |
| --- | --- | --- |
| D1 run_id | `init-intc-738849dbdbb04ae1a39efa0aec69c071-d1` | `init-be-788adefdd31844d98a907468b883176d-d1` |
| 研究 cutoff，北京时间 | 2026-09-22 04:23:27 | 2026-09-21 20:30:11 |
| 发布时间，北京时间 | 2026-09-22 05:40:24 | 2026-09-21 22:14:01 |
| 预扫描 → 最终关系 | 17 → 23 | 25 → 30 |
| 预扫描 → 最终 Future Nodes | 11 → 20 | 19 → 33 |
| C4 预扫描 / enrichment 耗时 | 16.98 / 15.50 分钟 | 12.76 / 19.03 分钟 |
| 最终关系类型标签数 | 22 | 27 |
| 含正式 O 别名的最终关系行 | 23/23 | 2/30 |
| 含直接 URL 的最终关系行 | 0/23 | 30/30 |
| 完全重复行 / 空字段 | 0 / 0 | 0 / 0 |
| 预扫描主体—对象组合在最终缺失 | 0 | 0 |
| C4 pre / enrichment manifest entries | 17 / 25 | 5 / 5 |
| 两个 C4 manifest unresolved | 0 / 0 | 0 / 0 |
| 两个 C4 ingestion quarantine | 0 / 0 | 0 / 0 |
| 当前激活 revision | `runtime-maintain-e738add6dd328ee2e3d98e09-activation` | `runtime-maintain-e5b914877fe8a40a46b494c6-activation` |

entry 数统计完整 NodeOutput，包括 warnings / Future Nodes，不可当作“每条关系证据数量”。`resolved=0` 的缺失数仅指正式 O 引用；BE 直接 URL 不受此项检验覆盖。上述耗时是一次历史 attempt 的墙钟时间，包含 Worker 等待/执行与产物处理，不能直接当作模型纯推理时长、当前模型性能或改造后的预计耗时。

INTC enrichment 新增六个主体—对象组合：Intel 18A/18A-P/14A、Panther Lake、OEM 上市伙伴集合、Foveros/EMIB 技术组合、Lens Technology、Altera。BE 新增五个组合：800V DC 架构、NVIDIA Rubin Ultra/Kyber 生态、MOL/Samsung Heavy Industries、Transwestern/Green Chile/FERC、NERC/FERC 可靠性框架。这里是对产出差异的描述，不是重新认证这些业务关系。

### 8.2 观察与影响

| 关注项 | 已确认的现状 | 对重做的含义/验证边界 |
| --- | --- | --- |
| 实体粒度混合 | INTC 一个对象写 `AMD、Qualcomm、NVIDIA、ARM/RISC-V生态及云厂商自研芯片`，另一个写 EDA 公司集合；BE 包含终端市场、设施、监管框架、未逐名披露供应商网络 | 目前是关系描述行，不是一行一实体。若将来要检索、监控词派生或跨 ticker 归并，需先确定实体类别与拆分规则；未逐名披露集合不等于已识别具体供应商 |
| 多种关系合写 | `公用事业渠道/融资合作`、`业务分部与制造平台` 等自由标签 | 不能把类型直接视为可统计枚举；合作、潜在客户、已部署客户、技术适配也可能落在同一“关系”层 |
| Entity Map / Future Nodes 完成条件耦合 | 两数组任一非空即可避免 pre_scan 回退；enrichment 没有实际全量覆盖校验 | 这是代码级接纳风险，两份现有样本没有发生主体—对象组合丢失；重做应决定是否分别保留/标注两类产出，而非因未来事项成功就推断关系完整 |
| 证据表示不统一 | INTC 使用正式引用，BE 所有行有 URL，但仅两行同时有 O 引用 | 能下载列表不等于能以同一种引用机制追溯每行；URL 的存在也不能替代历史捕获和语义支持检查 |
| C4 与汇总别名冲突 | INTC 关系使用 19 个 O 别名，其中 16 个在汇总 manifest 中存在但 URL 不同，另外 3 个缺失；BE 的 O69/O72 均不在汇总 manifest | 结构行保留 C4 作用域，必须使用 C4 manifest。D2 当前只加 `D1-` 前缀，引用终装器读取 Global 汇总 manifest；输入/映射存在错解风险，未宣称现有 D2 产出已发生业务误引用 |
| 来源/时效不是独立字段 | 关系 row 没有 source/date/effective window；cutoff 只在外围运行契约 | 下游难以单凭 row 判断关系证据时间、关系生效时间或撤销情况；目前是整 run 快照更新，不是逐边时效管理 |
| 关键路径耗时 | C4 pre_scan 先完成再启动 C1/C3；两次 C4 合计约 32 分钟 | Future Node 搜索与关系建设共享前置 turn；后续如调整并行必须先决定 C1/C3 究竟需要多少预先关系上下文；本次未做性能优化 |
| 定义强、自动语义检查弱 | 提示词要求事实中性、去重和完整快照；程序主要做结构与证据作用域处理 | 把提示词约束写进新 schema 不会自动提高事实质量；应以样本 badcase 和具体下游用途确定必要的检查，避免给整个 D1 新增不必要硬阻塞 |

**别名冲突的具体例子：** INTC 第一条 CCPG 关系说明引用 `【cite:O2】`。其 C4 enrichment manifest 的 O2 URL 是 `https://www.intc.com/news-events/press-releases/detail/1776/intel-reports-second-quarter-2026-financial-results`，对应 C4 attempt `init-779e6ae62c4a4337ae79c2940b874cc9`；同 bundle 的汇总 manifest O2 则是 `https://www.sec.gov/Archives/edgar/data/50863/000005086326000077/q126earningsrelease.htm`，对应 C1 attempt `init-609e79a4023544e29f5e06f67b1938ff`。URL 差异和作用域差异可在交付的原始 manifest 与 bundle 中直接复核；完整冲突列表在 `analysis.json`。

### 8.3 后续设计需要先确定的业务问题

以下是前置设计输入，不代表已选择或实施方案：

1. Entity Map 将继续服务轻量研究阅读，还是要承担实体检索、跨 ticker 归并、监控对象生成等机器消费用途？这决定是否需要一行一对象、实体类别或身份键。
2. 什么算“关系”：业务分部、产品隶属、真实客户、潜在客户、技术适配、融资角色、监管暴露是否同层建模？如何保持声明精度？
3. 关系事实和其来源时间应如何表达；下游引用应定位 C4 attempt 还是统一发布证据身份？
4. Entity Map 与 Future Nodes 是否继续共用前置研究和最终完整快照；部分成功时分别采用什么保留与诊断策略？
5. 更新仍按整个 D1 run 冻结，还是需要可独立刷新的 Entity Map；旧关系的修订/撤销如何表示？
6. 优化接受什么可验证改善：减少前置等待、提高有名主体覆盖、消除混合对象、减少证据作用域错误，或更好支持特定下游？现有 23/30 条本身不构成质量目标。

## 9. 本次验证与尚未验证范围

已完成：

- 70 个远端抓取文件逐一核对大小和 SHA-256；存在 canonical ArtifactRef checksum 的 C4 completion/report 同时核对该 hash。
- 两个 ticker 的 JSON 五字段 schema 验证；`entity_map.json == bundle.entity_relations == enrichment.entity_relations`；当前 activation 的 D1 指针匹配。
- pre_scan/final 主体—对象组合比较、空字段/重复行统计、O 引用与 C4 manifest 检查、C4 与汇总 manifest 同编号 URL 比较。
- 12 个初始化容器源文件/资源与本地比较；四次 C4 冻结 prompt/skill/schema 与当前对应文件比较。
- 无模型调用的 schema/validator 探针：确认空字符串、重复行、任意 status、非空 C4 report 仍被接纳，Future-only 可通过 complete flag，额外关系字段可在 ingestion 中被剥除。详情 `analysis.json.acceptance_probes`。
- 运行现有离线测试 `tests/test_codex_document1_workflow.py`、`tests/test_codex_research_lanes.py`、`tests/test_codex_d1_attempt_protocol.py`：**35 passed，29.46s**；唯一 warning 为已有 importlib-metadata 弃用提示。

未进行：逐条关系事实实时核验、全仓库回归、真实模型重跑、完整 D2/D3/O2 引用消费重放、前端浏览器验收或生产部署。因此本次可证明现状契约、远端产出身份、结构与交接风险，不能宣称重做后的质量/性能已验证。

重新校验采集与生成可读投影：

```powershell
uv run --offline python dev_plan/workflow_v2.1/d1_entity_map_recon_20261009/evidence/analyze_capture.py
```

`extract_remote.py` 是本次只读远端查询脚本，输入经 Base64 通过 SSH stdin 送至容器 Python 执行；脚本不创建远端临时文件、不实例化会初始化/迁移 SQLite 的 repository，也不修改源 workspace。原始传输清单保留来源路径及哈希。

## 10. 代码导航

以下行号针对本次本地工作区快照；资源和主体逻辑同时有远端容器文件佐证。

| 内容 | 入口 |
| --- | --- |
| 初始化 D1/CDECR/O2/D2/D3 依赖 | `src/doxagent/ticker_initialization/catalog.py:21` |
| 初始化实际 D1 orchestrator | `src/doxagent/ticker_initialization/research_adapter.py:151` |
| Global Research DAG、投影、回退与发布 | `src/doxagent/workflows/codex_global_research/orchestrator.py:33`、`:76`、`:132`、`:159`、`:168`、`:236` |
| C4 节点清单与 required skill | `prompts/codex_v2/document1/global_research/bundle_manifest.json` |
| C4 业务与 output 约束 | `prompts/codex_v2/document1/agents/c4.md`、`skills/entity-map-and-future-nodes.md` |
| 五字段 EntityRelation / FutureNode | `src/doxagent/codex_runtime/schema.py:356`、`:369` |
| NodeOutput 与严格 wire schema | `src/doxagent/workflows/codex_document1/schema.py:24`、`:50` |
| 冻结输入与 sidecar 路径 | `src/doxagent/workflows/codex_document1/attempt_bundle.py:123`、`:129` |
| sidecar 恢复、citation promotion、validator | `src/doxagent/workflows/codex_document1/node_runner.py:280`、`:322`、`:573` |
| 逐行恢复与扩展字段剥除 | `src/doxagent/workflows/codex_document1/recovery.py:9`；`src/doxagent/codex_runtime/recovery.py:38` |
| hash 恢复、handoff marker、发布 | `src/doxagent/workflows/codex_document1/orchestrator.py:487`、`:642`、`:884` |
| attempt 引用重新导入 | `src/doxagent/workflows/codex_document1/upstream_rebinder.py` |
| SQLite 存储 / Postgres bundle 存取 | `src/doxagent/codex_runtime/repository.py:373`、`:535`、`:1325`、`:1615` |
| Postgres JSONB 迁移契约 | `supabase/migrations/202608200001_codex_research_lanes.sql:53` |
| D2 关系输入与 D1 alias 前缀 | `src/doxagent/workflows/codex_document2/inputs.py:229`、`:358`、`:420` |
| D2 使用 Global 汇总 citation manifest | `src/doxagent/workflows/codex_document2/orchestrator.py:315`；`assembler.py` |
| 本地 D3 v2.1 结构切片 | `src/doxagent/workflows/codex_document3/inputs_v21.py:170` |
| V2 页面研究索引范围 | `src/doxagent/v2_read/artifacts.py:107` |

交付目录中的 `evidence/runtime_source` 是采集时初始化容器源码副本；`INTC/BE/frozen_inputs` 是生成历史样本时冻结的实际 Agent 输入。两者用于将“现在代码怎样运行”和“这些样本在什么契约下生成”分别追溯。
