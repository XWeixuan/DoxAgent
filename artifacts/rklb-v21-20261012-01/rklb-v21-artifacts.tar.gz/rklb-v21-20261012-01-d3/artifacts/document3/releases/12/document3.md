# RKLB Document3 V3

Version: 12 · PARTIAL · publication candidate

As of: 2026-10-12T08:45:17.165493+00:00

Coverage: {"coverage":[{"note":"","policies":["output/work/v21/research/S0001/0000/policy_globalstar_service_capacity.json","output/work/v21/research/S0001/0000/policy_globalstar_supplier_role.json"],"policy_ids":["pol_4e44ff029991497cba8f4cfadb0482d9","pol_9854f7927ff34c3498b23b24fa730069"],"topic":"设备卫星服务扩展与Globalstar平台采购重选"},{"note":"","policies":["output/work/v21/research/S0001/0000/policy_mda_acceptance_and_settlement.json"],"policy_ids":["pol_28b43728c07b4bba854eb285337fc594"],"topic":"MDA补充星座运行验收与分包责任结算"},{"note":"","policies":["output/work/v21/research/S0001/0001/satellite_batch_integration.json","output/work/v21/research/S0001/0001/satellite_contract_scope_economics.json","output/work/v21/research/S0001/0001/satellite_project_payment_timing.json"],"policy_ids":["pol_c7aad42cce9c4af29615e03c65b9a82a","pol_098eab22649f42c0bc2a67e1fee26499","pol_22c6d513247b45fbb68cccc771c61b58"],"topic":"卫星批量制造与载荷地面联调的交付经济性"},{"note":"","policies":["output/work/v21/research/S0001/0002/policy_escapade_deep_space.json"],"policy_ids":["pol_b7cddfb4b18548879167627385c7eaa2"],"topic":"ESCAPADE转移到达与深空平台资格"},{"note":"","policies":["output/work/v21/research/S0003/0003/policy_mars_telecom_1.json","output/work/v21/research/S0003/0003/policy_mars_telecom_2.json"],"policy_ids":["pol_3eaef49824364b10a8ee68e32ad50d75","pol_280599a6a5934c628eec1e24c42b75dd"],"topic":"火星通信采购争议与民用任务采购路线"},{"note":"","policies":["output/work/v21/research/S0001/0004/policy_loxsat_cryogenic_depot.json","output/work/v21/research/S0001/0004/policy_servicing_vs_replacement.json","output/work/v21/research/S0001/0004/policy_robotics_products_reuse.json"],"policy_ids":["pol_df90f00934a14f05afd840d84280b51e","pol_697421694f7e47ba91cf62dc046e15e3","pol_a033730cebd34114af92b8632c8e93d6"],"topic":"补给维修采用与机器人产品从示范到复用"},{"note":"","policies":["output/work/v21/research/OPEN_RESEARCH/0020/policy_001.json"],"policy_ids":["pol_406849b6b1104206a2a77dfa0ae52e45"],"topic":"共享托管与实时数据服务重组空间硬件和运输需求"},{"note":"","policies":["output/work/v21/research/OPEN_RESEARCH/0021/policy_orbital_compute_demand.json","output/work/v21/research/OPEN_RESEARCH/0021/policy_orbital_compute_supplier.json","output/work/v21/research/OPEN_RESEARCH/0021/policy_neutron_compute_fit.json"],"policy_ids":["pol_8dd3e58467114c7d85da4b3b346df73e","pol_408efe3a509d436894b5e576c6e4bddd","pol_dce36b56ada3451d9402ce6c25a60ac1"],"topic":"轨道算力锚定需求与高功率平台工程路线"},{"note":"","policies":["output/work/v21/research/S0003/0005/policy_sda_followon.json","output/work/v21/research/S0003/0005/policy_rslp_option_orders.json","output/work/v21/research/S0003/0005/policy_defense_procurement_scope.json"],"policy_ids":["pol_034055ca72f14cec9734a07e8a80a8c2","pol_4f6a30aa22864e4aaac557adb5135b8a","pol_6b3a97645120456a84fe6f9c73f53487"],"topic":"国防后续批次选项与主承包分工重排"},{"note":"","policies":["output/work/v21/research/S0003/0005/policy_sensor_transport_architecture.json","output/work/v21/research/S0003/0005/policy_commercial_transport_services.json","output/work/v21/research/S0003/0005/policy_sbi_architecture.json"],"policy_ids":["pol_f216afe45488452bbf17aa6ce5067116","pol_d394cc5858f741abb5596d06a7634cc3","pol_b104b61bb0df434898e0f25646abf4fc"],"topic":"作战用途与多轨道架构改变可采购任务"},{"note":"","policies":["output/work/v21/research/OPEN_RESEARCH/0006/policy_flatellite_contract_delivery.json"],"policy_ids":["pol_9e558560114f4412accde22027500be8"],"topic":"Flatellite整包任务运输替换与运营起点"},{"note":"","policies":["output/work/v21/research/S0001/0002/policy_geo_lightning_qualification.json"],"policy_ids":["pol_7cabcf5c481c47ca8f473fb20e7daf91"],"topic":"GEO环境资格与高轨平台重复采用"},{"note":"","policies":["output/work/v21/research/OPEN_RESEARCH/0012/policy_001.json","output/work/v21/research/OPEN_RESEARCH/0012/policy_002.json"],"policy_ids":["pol_952cd80d533c4c5c98dba990f561890c","pol_5a13225302414625a39c1e630d8bb5ca"],"topic":"响应空间的待命库存与持续服务采购"},{"note":"","policies":["output/work/v21/research/S0001/0007/policy_mynaric_supply_acceptance.json"],"policy_ids":["pol_f630ac3286064d6eba35546c78122126"],"topic":"Mynaric有效供给修复与内外客户分配"},{"note":"","policies":["output/work/v21/research/S0001/0007/policy_optical_terminal_qualification.json"],"policy_ids":["pol_f353ba0f80a04fb4b0b16b1cbc09cbea"],"topic":"光终端互操作标准与升级产品采购选择"},{"note":"","policies":["output/work/v21/research/S0001/0008/policy_hydron_demo_execution.json","output/work/v21/research/S0001/0008/policy_european_procurement_access.json"],"policy_ids":["pol_69e96866770246ecad3d1b2ea2f0ba98","pol_9ede3c0656044b359062e7f77f243639"],"topic":"欧洲光网络项目与本地产品采购资格"},{"note":"","policies":["output/work/v21/research/S0001/0009/components_external_supply.json","output/work/v21/research/S0001/0009/starlite_protection_optics.json"],"policy_ids":["pol_81b7537041d745b3b76433b11acaab19","pol_48b14f64d13640f3bf31b2649dcf20be"],"topic":"成熟组件与保护光学的外销换型及定价"},{"note":"","policies":["output/work/v21/research/S0001/0010/imm_apex_adoption.json"],"policy_ids":["pol_a86f7ccf574a4cbbb28c86ddc3734e1d"],"topic":"无锗太阳能换型与材料优势的价值捕获"},{"note":"","policies":["output/work/v21/research/S0001/0010/gauss_propulsion_qualification.json"],"policy_ids":["pol_9ea741ccefdd4510a44071a774f322c5"],"topic":"Gauss机动离轨需求与电推进产品资格"},{"note":"","policies":["output/work/v21/research/OPEN_RESEARCH/0011/policy_001.json","output/work/v21/research/OPEN_RESEARCH/0011/policy_002.json","output/work/v21/research/OPEN_RESEARCH/0011/policy_003.json","output/work/v21/research/OPEN_RESEARCH/0011/policy_004.json"],"policy_ids":["pol_16673a91124b408a84feb6f36ff31887","pol_29e12917215d4820b93c9a9463e60d63","pol_7a27503f34154ccca7534964a91d83f1","pol_5007e725e9e1420dbcf800a3eec0a1b9"],"topic":"空间天气碎片与部署限制重定平台生命周期"},{"note":"","policies":["output/work/v21/research/S0001/0013/policy_sdn_exchange_photon.json"],"policy_ids":["pol_fd9dc7809fa64f44a9a49aa986a874f3"],"topic":"Space Data Network交换系统与Photon多厂商示范"},{"note":"","policies":["output/work/v21/research/S0002/0014/P01.json","output/work/v21/research/S0002/0014/P02.json"],"policy_ids":["pol_590730274b654f6b8cf29cc707235c13","pol_70d382c2b8624d51bad6a0096febe0a2"],"topic":"Electron任务分配与容量价格付款安排"},{"note":"","policies":["output/work/v21/research/S0002/0015/P01.json","output/work/v21/research/S0002/0015/P02.json"],"policy_ids":["pol_b42987762a7a46e29d0acbf2cd0dec41","pol_fca7ae3f549b484c8b9d4eb2cbf4b3fb"],"topic":"SAR用户覆盖采购与可融资部署需求"},{"note":"","policies":["output/work/v21/research/S0002/0014/P03.json"],"policy_ids":["pol_fda99e3596054cfeb8fc4992c173e3d4"],"topic":"Electron集中客户融资与载荷就绪排期"},{"note":"","policies":["output/work/v21/research/S0002/0016/P01.json"],"policy_ids":["pol_4cb8eb9c704b49a79fc3ad1ea9f7911d"],"topic":"端到端运输替代与主权路线的专属服务竞争"},{"note":"","policies":["output/work/v21/research/S0002/0016/P02.json"],"policy_ids":["pol_951b79da694341688ffe783c48d451c7"],"topic":"Electron异常恢复与客户损失分担"},{"note":"","policies":["output/work/v21/research/S0002/0017/P01.json"],"policy_ids":["pol_bbdf3ecc9d4742e99ebb57f518a046ef"],"topic":"亚轨道研制管线与自费测试采购"},{"note":"","policies":["output/work/v21/research/S0002/0018/P01.json"],"policy_ids":["pol_9365bd2c4f074c12bf78de893ba3a27e"],"topic":"回收空射与模型验证重排实体实验需求"},{"note":"","policies":["output/work/v21/research/S0002/0017/P02.json"],"policy_ids":["pol_8e23b0cc4c954f8491de882144dc46dd"],"topic":"HASTE任务接口与有效数据的合同经济性"},{"note":"","policies":["output/work/v21/research/S0002/0019/P01.json"],"policy_ids":["pol_9028431cc66f4880865537d53e19e540"],"topic":"GHOST地理场景激活与盟国移动部署采购"},{"note":"","policies":["output/work/v21/research/S0002/0019/P02.json","output/work/v21/research/S0002/0019/P03.json"],"policy_ids":["pol_4efe1f39c31e47ca8d14ec77aefdf721","pol_ab54c831740046ca8cde61f0bb35365a"],"topic":"共有火箭制造放行与生产连续性"},{"note":"","policies":["output/work/v21/research/S0002/0022/P01.json","output/work/v21/research/S0002/0022/P02.json"],"policy_ids":["pol_b6df6d83a6c3486cbbf48d1e14e6f494","pol_3577c95bdaa44dcfaffe6f7f5cfe9fe0"],"topic":"场地使用权范围资源与跨境许可的有效供给"},{"note":"","policies":["output/work/v21/research/S0002/0023/P01.json"],"policy_ids":["pol_0ae9b330f38549419ba27efb632ac461"],"topic":"Neutron关键系统资格与整箭地面集成路径"},{"note":"","policies":["output/work/v21/research/S0002/0024/P01.json","output/work/v21/research/S0002/0024/P02.json","output/work/v21/research/S0002/0024/P03.json"],"policy_ids":["pol_20e9976a3a91488f90043db71d64f408","pol_3f34d237b8cf4718b82c7d786c706006","pol_7fb6666bcb82416f9d151f58d2b390a2"],"topic":"Neutron实飞学习与复用重复交付经济性"},{"note":"","policies":["output/work/v21/research/S0002/0025/P01.json","output/work/v21/research/S0002/0025/P02.json"],"policy_ids":["pol_17aba69dffbb4844a1fffb7d3f409242","pol_bf49d2d20fa3401caa024ba8d1ac3105"],"topic":"Neutron商业客户批次留存与合同条件"},{"note":"","policies":["output/work/v21/research/S0002/0025/P03.json","output/work/v21/research/S0002/0025/P04.json"],"policy_ids":["pol_285845c90969445c8d939cf7ec33eed7","pol_9badfda07eb14d25bf94bb5e414e13f3"],"topic":"开放中重型运力与星座批次的中型市场竞争"},{"note":"","policies":["output/work/v21/research/S0003/0026/policy_nssl_qualification.json","output/work/v21/research/S0003/0026/policy_nssl_task_allocation.json","output/work/v21/research/S0003/0026/policy_nite_star_task_orders.json"],"policy_ids":["pol_25cbf5e5322d46fab8898720813f5483","pol_36ea33d0052f4b1a85357e02428f57d0","pol_85ef8982dd234f4ab5b0b39586c1f14c"],"topic":"国家安全发射资格门槛与具体任务分配"},{"note":"","policies":["output/work/v21/research/S0002/0027/P01.json"],"policy_ids":["pol_291a39ffaa334b43b2e8b67ce9e2ff8c"],"topic":"再入货运实验与高时效物流的付费用途"},{"note":"","policies":["output/work/v21/research/S0002/0023/P02.json"],"policy_ids":["pol_686e6482e009438abd65ec3fd4db5cdb"],"topic":"Neutron专属投入与战略开发合作"},{"note":"","policies":["output/work/v21/research/S0003/0028/policy_sda_tranche.json","output/work/v21/research/S0003/0028/policy_sda_supplier_gate.json"],"policy_ids":["pol_3e6f1cadc4364c178252d1c04b61ea98","pol_5f3416d50dab402f854bbe3047bfe08d"],"topic":"SDA作战反馈与新批次采购治理门槛"},{"note":"","policies":["output/work/v21/research/S0003/0028/policy_defense_multiyear_funds.json","output/work/v21/research/S0003/0028/policy_defense_contract_flow.json"],"policy_ids":["pol_91570f68a2774b8d9dfb43b4b7a3f654","pol_3c18975020db49aa997fb16816f65b31"],"topic":"国防项目资金可用性与采购年度重排"},{"note":"","policies":["output/work/v21/research/S0003/0029/policy_sbi_prototype_selection.json"],"policy_ids":["pol_1a32673d76f7470b89c0f989aef5eea0"],"topic":"SBI方案筛选与原型资金竞争"},{"note":"","policies":["output/work/v21/research/S0003/0030/policy_defense_supplier_capacity.json"],"policy_ids":["pol_0d25d072c18340208d56868698f4bc83"],"topic":"国防候选供方资本支持与退出整合"},{"note":"","policies":["output/work/v21/research/S0003/0031/policy_commercial_data_capacity.json"],"policy_ids":["pol_91c19e3704274e0bbda6a1ab5e4e8d10"],"topic":"公共商业数据权利与自建服务采购取舍"},{"note":"","policies":["output/work/v21/research/S0003/0032/policy_nasa_science_mission_mix.json"],"policy_ids":["pol_2dddd8ef6b004a969b246238cd10c568"],"topic":"NASA科学探索资金与小型任务采购组合"},{"note":"","policies":["output/work/v21/research/S0003/0031/policy_allied_architecture_access.json"],"policy_ids":["pol_541fe7bc3d264950b6eeeb3e9c8f8ac5"],"topic":"盟国主权架构与跨国产业采购入口"},{"note":"","policies":["output/work/v21/research/S0004/0034/policy-emss-fixed-fee.json"],"policy_ids":["pol_acdfea07ed9a4c719eeb2fe6b3eaf30a"],"topic":"EMSS续约范围固定费与附加服务采购"},{"note":"","policies":["output/work/v21/research/S0001/0033/policy_commercial_station_supplier_entry.json"],"policy_ids":["pol_3a73e769b8ee4311aaea1ed90a621208"],"topic":"商业空间站资金闭合与组件伙伴选择"},{"note":"","policies":["output/work/v21/research/S0003/0030/policy_defense_source_acceptance.json"],"policy_ids":["pol_a6de4da9888840cab6eb5093252449ad"],"topic":"国防材料来源追溯与合格供方接受条件"},{"note":"","policies":["output/work/v21/research/S0004/0035/policy_ntn_direct_operator_access.json"],"policy_ids":["pol_96cb1caf7cf44a04b81aef19d9b2d7b9"],"topic":"NTN Direct运营商开放与付费接入"},{"note":"","policies":["output/work/v21/research/S0004/0035/policy_industrial_iot_oem_adoption.json"],"policy_ids":["pol_173e4dad27c740d7b9a2be974b1b53d4"],"topic":"工业离网连接的OEM配置与运营采用"},{"note":"","policies":["output/work/v21/research/S0004/0036/policy_iridium_recurring_rates_retention.json"],"policy_ids":["pol_fd729b68751f4e3998e0cbc30f869280"],"topic":"Iridium存量服务费率分层与客户留存"},{"note":"","policies":["output/work/v21/research/S0004/0036/policy_iridium_aggregator_channel_control.json"],"policy_ids":["pol_cccb41861c2a4a46bf35ee23a5ba575e"],"topic":"多网络聚合分配与转售渠道控制"},{"note":"","policies":["output/work/v21/research/S0004/0037/policy_consumer_satellite_subscription_choice.json"],"policy_ids":["pol_05d5968f6e3249a1968674901c839623"],"topic":"消费卫星功能内含化与专业独立订阅选择"},{"note":"","policies":["output/work/v21/research/S0004/0037/policy_maritime_safety_companion_service.json","output/work/v21/research/S0004/0037/policy_maritime_remote_ops_control_chain.json"],"policy_ids":["pol_07644a4cb2864a359be5479c57cf8a37","pol_ae0c2c03c04149f3921def537ea334ff"],"topic":"船队安全伴随服务与远程运营独立链配置"},{"note":"","policies":["output/work/v21/research/S0004/0038/policy_independent_pnt_adoption_competition.json"],"policy_ids":["pol_8825ff301dad47f4aae6b88d038cbbf1"],"topic":"独立PNT设计采用与多源授时竞争"},{"note":"","policies":["output/work/v21/research/S0004/0039/policy_government_gateway_engineering_allocation.json"],"policy_ids":["pol_35c0d22ef6c44481b82b61cf9beff6b3"],"topic":"政府网关工程与混合网络支持责任分配"},{"note":"","policies":["output/work/v21/research/S0004/0040/policy_aireon_external_data_contracts.json"],"policy_ids":["pol_25063d5d91c441628c6a41f1e15c465c"],"topic":"Aireon外部空域合同与航空数据分销用途"},{"note":"","policies":["output/work/v21/research/S0004/0040/policy_space_vhf_service_commitments.json"],"policy_ids":["pol_b742e00268b548528032381356cc2396"],"topic":"空间VHF协同开发的采购接受与资本承担"},{"note":"","policies":["output/work/v21/research/S0004/0041/policy_iridium_network_resilience_redundancy.json"],"policy_ids":["pol_2263cbe2680a4b55bf7cbfc9ea4e4251"],"topic":"网络共同依赖与异源韧性采购"},{"note":"","policies":["output/work/v21/research/OPEN_RESEARCH/0042/policy_01.json","output/work/v21/research/OPEN_RESEARCH/0042/policy_02.json","output/work/v21/research/OPEN_RESEARCH/0042/policy_03.json"],"policy_ids":["pol_330f552e0ca24225ae4fb0dfce0bc905","pol_cbb1ecf009cf4ae3b9c403903f6513f7","pol_2d8db7312b0d4985a981300eac2f0570"],"topic":"Iridium网络更新与成熟现金再投资配置"},{"note":"","policies":["output/work/v21/research/S0004/0043/policy_iridium_terminal_supply_access.json"],"policy_ids":["pol_292f456cf72443ce9ef7c999b946cb52"],"topic":"卫星终端模块供给资格与订阅安装能力"},{"note":"自身与他网法律资格分工；终端供给原稿当前仍默认保留，其健康补研/关联编辑未在本次接纳。","policies":["output/work/v21/final/policies/0009/iridium_own_country_operating_rights.json","output/work/v21/final/policies/0009/competing_mobile_country_legal_access.json"],"policy_ids":["pol_c582bceb3ae94c5ebc342ba983c97964","pol_f61acf84f98946118da8e104a2e442f4"],"topic":"国家经营准入与竞争网络频谱许可"},{"note":"保新增有偿共同持续服务及其重要丧失，旧专门合同流失不重复。","policies":["output/work/v21/final/policies/0009/new_joint_external_recurring_service_roles.json"],"policy_ids":["pol_760fbab266f94a7a883018d1ddb2a13e"],"topic":"服务业务整合的客户合同与运营责任"},{"note":"","policies":["output/work/v21/research/S0004/0045/policy_certus_avsafety_acceptance_and_fleet_retrofit.json"],"policy_ids":["pol_89874698a3c34ab69d8f84fd8f0772e7"],"topic":"Certus驾驶舱安全通信接受与机队改装"},{"note":"接纳FCC核心、非FCC独立有效清关和真实窗口分工；未知终止整体净取舍仍gap。","policies":["output/work/v21/final/policies/0009/iridium_core_control_clearance.json","output/work/v21/final/policies/0009/iridium_independent_non_fcc_clearances.json","output/work/v21/final/policies/0009/iridium_substantive_close_window_revision.json"],"policy_ids":["pol_5f42ff5c6c3946b18c62830dbdcaed09","pol_4b3f46d086e34ddbb3f0260409a07f11","pol_ab94c5e54d144a7692be42f855b0ddc7"],"topic":"Iridium控制权审批的范围条件与交割时间"},{"note":"固定优先、普通残余、项目共担、同范围交易价分别覆盖；较小实际权利交换净意义仍有具体缺口。","policies":["output/work/v21/final/policies/0009/other_corporate_fixed_priority_financing.json","output/work/v21/final/policies/0009/ordinary_residual_financing_rights.json","output/work/v21/final/policies/0009/project_cofunding_risk_and_residual_rights.json","output/work/v21/final/policies/0009/iridium_bound_total_consideration_revision.json"],"policy_ids":["pol_bb84df6031a84f16a463b230bbe628ac","pol_e74481d4624a46dc871185b75496cfb5","pol_11e74837b8a54566a4e00849bcf02315","pol_e471e9d810064d34a16b5573c0859efc"],"topic":"新增融资与交易对价的普通股经济权利"},{"note":"贷款成本和一般用途现金改约已接纳；保证/加速组因冻结final缺失负向条件未替换，原保证稿回退保留不表示编辑已完成。","policies":["output/work/v21/final/policies/0009/iridium_retained_loan_net_financing_cost.json","output/work/v21/final/policies/0010/iridium_general_cash_mobility_rights.json","output/work/v21/research/S0005/0048/policy_iridium_guarantee_recourse.json"],"policy_ids":["pol_569adb42d3374ba8aa31fceff384d364","pol_c2e41775c9d34e13976852ebed7168e9","pol_e6de693a7152490b8014306369b102e5"],"topic":"贷款利率保护与集团现金调度权"},{"note":"9/15更新责任为比较点，绑定到期/费用/奖励改约先于付款，价格同一事实另唯一承接。","policies":["output/work/v21/final/policies/0009/iridium_close_waiting_cash_obligations.json"],"policy_ids":["pol_c50ccc9755d9400bb6ce6995bac5ca3b"],"topic":"交易结算与等待期承诺的剩余资金"},{"note":"","policies":["output/work/v21/research/S0005/0049/policy_engineering_portfolio_costs.json"],"policy_ids":["pol_82d6f0e35a5f4a449e2b45b93ef93c7c"],"topic":"跨平台开发组合与工程团队转用的费用负担"},{"note":"","policies":["output/work/v21/research/S0005/0050/policy_acquired_integration.json"],"policy_ids":["pol_dff2bf51451b493ab2e4a02010f99510"],"topic":"已收购业务与区域组织的净整合负担"},{"note":"","policies":["output/work/v21/research/S0005/0050/policy_engineering_talent.json","output/work/v21/research/S0005/0050/policy_digital_engineering.json"],"policy_ids":["pol_9d7730a3e64d47cab7849553ac9b8c2e","pol_36a839d3d8e4466c829a706e6c1755b8"],"topic":"工程人才与数字工作方法的有效投入能力"},{"note":"","policies":["output/work/v21/research/S0005/0051/policy_customer_project_funding.json","output/work/v21/research/S0005/0051/policy_customer_acceptance_settlement.json"],"policy_ids":["pol_43e63d0dfa5041a99007aa224c45695e","pol_6f06c5eb1c3f4c96867ff016c1c07a23"],"topic":"客户项目融资与结算安排的供应商垫资"},{"note":"","policies":["output/work/v21/research/S0005/0051/policy_government_progress_payment_flow.json"],"policy_ids":["pol_e1cc4772b36b47b79362abb2f98860df"],"topic":"政府进度融资与主承包付款流转"},{"note":"","policies":["output/work/v21/research/S0005/0052/policy_supply_inventory_cash_base.json"],"policy_ids":["pol_8b691bf3328e40ae881845774328378b"],"topic":"采购锁料与跨项目库存复用的现金底座"},{"note":"项目可用资金、一般资格与同产品竞争产线分工；德国实际资助、较早真实阶段净责任及资格映射仍未确立。","policies":["output/work/v21/final/policies/0009/regional_bound_project_capital.json","output/work/v21/final/policies/0009/regional_formal_funding_eligibility.json","output/work/v21/final/policies/0009/competing_regional_product_line_financing.json"],"policy_ids":["pol_44311f4a72fe4cf4921eeea46e232883","pol_a5157d180a574b26aec4781d0fe00db5","pol_4bb82e30d8e149568477f71391333098"],"topic":"区域政策资本与合作权益的净自有出资"},{"note":"净固定责任、独立时点价值与承诺用途丧失分别覆盖，不当较长租期为免费节约。","policies":["output/work/v21/final/policies/0009/facility_comparable_use_net_fixed_cost.json","output/work/v21/final/policies/0009/facility_payment_peak_timing_value.json","output/work/v21/final/policies/0009/facility_committed_use_window_loss.json"],"policy_ids":["pol_0a901ce8be854de88ec746ccd2147a1d","pol_f5bbe49e8ddd4e8f915529b2ee2f68fa","pol_04078cfb0cb64f20b4ca506b85d826c3"],"topic":"设施分期共享与租赁替代的投资峰值"},{"note":"方法、公司层面交易属性及最终一般规则保留；联邦正税基/同纳税人和实际可用盾未知不编造。","policies":["output/work/v21/final/policies/0009/federal_r_and_d_actual_method_choice.json","output/work/v21/final/policies/0009/transaction_tax_group_usable_shields.json","output/work/v21/final/policies/0009/binding_general_r_and_d_cash_tax_rules.json"],"policy_ids":["pol_d19919eb69ac442589968961f60ef2fb","pol_7e1006486c184b3f9add9ebb60475469","pol_f9928afb90984286bfddd05da8f17c6a"],"topic":"研发税务选择与交易后现金税安排"},{"note":"直接接纳0045同ID完整稿；精确旧新篮子免费资料不足保留测量gap。","policies":["output/work/v21/supplement/OPEN_EVENT/0045/nasdaq100_target_allocation.json"],"policy_ids":["pol_d4e637fea1f149598f3de8793697fa7e"],"topic":"指数成分审议与股本更新的被动配置"},{"note":"0046两健康同ID稿分别承接经营观点与peer方法；不交易同业财报本身。","policies":["output/work/v21/supplement/OPEN_RESEARCH/0046/policies/sell_side_view_increment.json","output/work/v21/supplement/OPEN_RESEARCH/0046/policies/peer_method_reselection.json"],"policy_ids":["pol_34cc5ee5c377486b9699f26a5796d4fe","pol_237a6b911cc543fbba7f3a0ad2bb5546"],"topic":"卖方覆盖与制造网络运营估值框架重选"},{"note":"领导真实能力接续与董事实质监督分别覆盖，不把普通换名/持续交接自动定向。","policies":["output/work/v21/final/policies/0010/leadership_execution_capability_continuity.json","output/work/v21/supplement/OPEN_RESEARCH/0047/policies/policy_02_board_oversight_rights.json"],"policy_ids":["pol_076f96fcaecc43beb617dc39b4d79e91","pol_1d3e675750b3424184c7d97354c6dad4"],"topic":"创始人接班与董事权安排的执行治理"},{"note":"原重要集中持有与主动重配/低于5%绑定二级供给保回同一身份；首次表格或日差不代真实新增交易。","policies":["output/work/v21/final/policies/0010/active_important_holders_and_public_secondary_supply.json"],"policy_ids":["pol_73b9000457354dc4891bfc62357c20b2"],"topic":"重要持有人持股变化与公开转让安排"},{"note":"资料、关键工作操作和正式授权各保信息，实际受阻/有效复工不等100m或全取证。","policies":["output/work/v21/final/policies/0010/engineering_controlled_information_and_security_authorization.json","output/work/v21/final/policies/0010/own_engineering_workflow_disruption_and_recovery.json","output/work/v21/final/policies/0010/external_engineering_interface_disruption_and_recovery.json"],"policy_ids":["pol_55a92b7861ea4b499719d41bfde1562c","pol_76a6265119934d3a97d21e4d9ed23a19","pol_0491c9181ed6407b961d619afa8a79c5"],"topic":"工程信息安全事件与制造承包授权恢复"},{"note":"output/work/v21/discovery/OPEN_EVENT.late.jsonl#L1由具体任务及一般规则两个对象承接；目标系统当前等级/任务流转仍未映射，未宣称净方向研究完成。","policies":["output/work/v21/final/policies/0010/contract_cmmc_system_qualification_and_access.json","output/work/v21/final/policies/0010/general_cmmc_rules_and_eligible_work_scope.json"],"policy_ids":["pol_2f35e145efc941c7863b62c34452424e","pol_bb3acf092c91452d8bc53da7aba20f71"],"topic":"国防信息安全认证改革与供应链协作边界"},{"note":"","policies":[],"policy_ids":[],"topic":"Globalstar外部服务承诺对RKLB的可寻址增量"},{"note":"","policies":[],"policy_ids":[],"topic":"项目付款与客户资金链的公开比较及现金边界"},{"note":"","policies":[],"policy_ids":[],"topic":"GEO与深空平台资格的最早有效结果"},{"note":"","policies":[],"policy_ids":[],"topic":"在轨服务接口与维修换新的目标净暴露"},{"note":"","policies":[],"policy_ids":[],"topic":"国防架构与商业运输采用的可寻址增量"},{"note":"","policies":[],"policy_ids":[],"topic":"Flatellite替换运输与延迟的净经济变化"},{"note":"","policies":[],"policy_ids":[],"topic":"光终端合格供给与标准资格的公开增量"},{"note":"","policies":[],"policy_ids":[],"topic":"欧洲终端可竞争资格的规则变化"},{"note":"","policies":[],"policy_ids":[],"topic":"组件外销供给与未量化采用的公开增量"},{"note":"","policies":[],"policy_ids":[],"topic":"新品电源推进资格与供给变化的早期入口"},{"note":"","policies":[],"policy_ids":[],"topic":"生命周期与轨道治理事实的独立经济增量"},{"note":"","policies":[],"policy_ids":[],"topic":"Electron任务与可兑现排期的相邻边界"},{"note":"","policies":[],"policy_ids":[],"topic":"SAR服务承诺到新增运输机会的公开比较"},{"note":"","policies":[],"policy_ids":[],"topic":"Electron全链替代运力与资格的早期竞争变化"},{"note":"","policies":[],"policy_ids":[],"topic":"发射服务自身价格责任与非财报成本入口"},{"note":"","policies":[],"policy_ids":[],"topic":"共享中继托管的付费采用与可寻址节点增量"},{"note":"","policies":[],"policy_ids":[],"topic":"轨道算力系统路线与中型适配的早期增量"},{"note":"","policies":[],"policy_ids":[],"topic":"场地窗口资本损害与收费条款的相邻边界"},{"note":"","policies":[],"policy_ids":[],"topic":"Neutron重基线与专属资源决策的公开比较"},{"note":"","policies":[],"policy_ids":[],"topic":"Neutron关键时间与复用资格的最早阶段信息"},{"note":"","policies":[],"policy_ids":[],"topic":"中型第三方窗口与星座批次的相邻变化"},{"note":"","policies":[],"policy_ids":[],"topic":"PWSA生产资金与批次节奏的公开相邻比较"},{"note":"","policies":[],"policy_ids":[],"topic":"国防供方门槛与可竞争任务的增量分配"},{"note":"","policies":[],"policy_ids":[],"topic":"再入货运保障采购与用户路线的早期增量"},{"note":"","policies":[],"policy_ids":[],"topic":"材料来源与跨国产业资格的前生产入口"},{"note":"","policies":[],"policy_ids":[],"topic":"NASA小任务组合与平台池的相邻增减"},{"note":"","policies":[],"policy_ids":[],"topic":"商业站体资金设计与可寻址硬件的早期变化"},{"note":"","policies":[],"policy_ids":[],"topic":"EMSS续约期限费率与收费责任的相邻边界"},{"note":"","policies":[],"policy_ids":[],"topic":"Iridium付费规模资费与工程工作量的相邻边界"},{"note":"","policies":[],"policy_ids":[],"topic":"NTN渠道产品范围与路由分配的早期增量"},{"note":"","policies":[],"policy_ids":[],"topic":"专业连接技术接受与PNT替代的最早可用边界"},{"note":"","policies":[],"policy_ids":[],"topic":"空间VHF标准与可执行资本责任的早期变化"},{"note":"","policies":[],"policy_ids":[],"topic":"Iridium共享路径恢复与正常冗余的相邻信息"},{"note":"","policies":[],"policy_ids":[],"topic":"成熟现金与更新资本的公开比较及配置方向"},{"note":"","policies":[],"policy_ids":[],"topic":"终端供给报价与新增服务安装的净传导"},{"note":"","policies":[],"policy_ids":[],"topic":"Certus后续资格升级与付费改装的相邻入口"},{"note":"必要清关/窗口已实际接纳；一般终止与留款的净取舍未建立。","policies":["output/work/v21/final/policies/0009/iridium_core_control_clearance.json","output/work/v21/final/policies/0009/iridium_independent_non_fcc_clearances.json","output/work/v21/final/policies/0009/iridium_substantive_close_window_revision.json"],"policy_ids":["pol_5f42ff5c6c3946b18c62830dbdcaed09","pol_4b3f46d086e34ddbb3f0260409a07f11","pol_ab94c5e54d144a7692be42f855b0ddc7"],"topic":"交易审批时点与终止资金用途的相邻比较"},{"note":"部分公开绑定权利入口有效；0047一般发行与项目残余交换的较早净主导经济未全建立，不以零新增Policy当题目消失。","policies":["output/work/v21/final/policies/0009/iridium_close_waiting_cash_obligations.json","output/work/v21/final/policies/0009/other_corporate_fixed_priority_financing.json","output/work/v21/final/policies/0009/ordinary_residual_financing_rights.json","output/work/v21/final/policies/0009/project_cofunding_risk_and_residual_rights.json","output/work/v21/final/policies/0009/iridium_bound_total_consideration_revision.json"],"policy_ids":["pol_c50ccc9755d9400bb6ce6995bac5ca3b","pol_bb84df6031a84f16a463b230bbe628ac","pol_e74481d4624a46dc871185b75496cfb5","pol_11e74837b8a54566a4e00849bcf02315","pol_e471e9d810064d34a16b5573c0859efc"],"topic":"融资现金权利与项目剩余的公开相邻比较"},{"note":"现金新ID信息收束原身份；保证/法律状态候选因丢失负向条件不接纳，追索部分保留未完成编辑gap。","policies":["output/work/v21/final/policies/0010/iridium_general_cash_mobility_rights.json"],"policy_ids":["pol_c2e41775c9d34e13976852ebed7168e9"],"topic":"保留贷款现金权限与追索的最早有效变化"},{"note":"","policies":[],"policy_ids":[],"topic":"跨平台开发工作与非财报成本的相邻信息"},{"note":"","policies":[],"policy_ids":[],"topic":"组织与工程方法的公开成本入口"},{"note":"","policies":[],"policy_ids":[],"topic":"锁料义务与库存用途的公开净比较"},{"note":"分对象接纳六范围，旧强金额不是全部最早边界；真实资助角色/较小阶段净交换与规则适用仍未完成。","policies":["output/work/v21/final/policies/0009/facility_comparable_use_net_fixed_cost.json","output/work/v21/final/policies/0009/facility_payment_peak_timing_value.json","output/work/v21/final/policies/0009/facility_committed_use_window_loss.json","output/work/v21/final/policies/0009/regional_bound_project_capital.json","output/work/v21/final/policies/0009/regional_formal_funding_eligibility.json","output/work/v21/final/policies/0009/competing_regional_product_line_financing.json"],"policy_ids":["pol_0a901ce8be854de88ec746ccd2147a1d","pol_f5bbe49e8ddd4e8f915529b2ee2f68fa","pol_04078cfb0cb64f20b4ca506b85d826c3","pol_44311f4a72fe4cf4921eeea46e232883","pol_a5157d180a574b26aec4781d0fe00db5","pol_4bb82e30d8e149568477f71391333098"],"topic":"地区资格与设施资本安排的早期净变化"},{"note":"有效非财报三范围接纳；方法通常不公开、当前零联邦税及交易组/属性可用连接为真实缺口。","policies":["output/work/v21/final/policies/0009/federal_r_and_d_actual_method_choice.json","output/work/v21/final/policies/0009/transaction_tax_group_usable_shields.json","output/work/v21/final/policies/0009/binding_general_r_and_d_cash_tax_rules.json"],"policy_ids":["pol_d19919eb69ac442589968961f60ef2fb","pol_7e1006486c184b3f9add9ebb60475469","pol_f9928afb90984286bfddd05da8f17c6a"],"topic":"研发与交易税务安排的非财报预期入口"},{"note":"0044新ID条件信息合入原C1/C3/C4，原集中持有C2保留，签署/成交/快照一次；较小角色与流量归因未明处留gap。","policies":["output/work/v21/final/policies/0010/active_important_holders_and_public_secondary_supply.json"],"policy_ids":["pol_73b9000457354dc4891bfc62357c20b2"],"topic":"持仓重配与公开供给安排的相邻分量"},{"note":"同价篮子及舍入已解决，完整免费当前index shares/前一可比篮子仍不可得。","policies":["output/work/v21/supplement/OPEN_EVENT/0045/nasdaq100_target_allocation.json"],"policy_ids":["pol_d4e637fea1f149598f3de8793697fa7e"],"topic":"指数目标篮子与方法变化的可公开增量"},{"note":"分别接纳可见观点/方法，不需不存在的首次旧模型；同日完整EV/摊薄分母和RJ原模型仍缺。","policies":["output/work/v21/supplement/OPEN_RESEARCH/0046/policies/sell_side_view_increment.json","output/work/v21/supplement/OPEN_RESEARCH/0046/policies/peer_method_reselection.json"],"policy_ids":["pol_34cc5ee5c377486b9699f26a5796d4fe","pol_237a6b911cc543fbba7f3a0ad2bb5546"],"topic":"卖方观点与同业方法的可见增量"},{"note":"董事健康补研直接接纳；领导正常接续中性与真实权限/相关能力损失区分，特定能力保全未公开部分仍gap。","policies":["output/work/v21/final/policies/0010/leadership_execution_capability_continuity.json","output/work/v21/supplement/OPEN_RESEARCH/0047/policies/policy_02_board_oversight_rights.json"],"policy_ids":["pol_076f96fcaecc43beb617dc39b4d79e91","pol_1d3e675750b3424184c7d97354c6dad4"],"topic":"领导能力接续与独立监督的净治理变化"},{"note":"0048新增ID保独立操作两侧，与原资料/权限协调；较小授权实际范围与私有修复责任仍不可得。","policies":["output/work/v21/final/policies/0010/engineering_controlled_information_and_security_authorization.json","output/work/v21/final/policies/0010/own_engineering_workflow_disruption_and_recovery.json","output/work/v21/final/policies/0010/external_engineering_interface_disruption_and_recovery.json"],"policy_ids":["pol_55a92b7861ea4b499719d41bfde1562c","pol_76a6265119934d3a97d21e4d9ed23a19","pol_0491c9181ed6407b961d619afa8a79c5"],"topic":"工程安全中断与授权恢复的相邻范围"},{"note":"保存具体与一般早期范围，不把加OUTER当研究完成；目标系统资格、任务FCI/CUI数据流及净竞争传导仍未建立。","policies":["output/work/v21/final/policies/0010/contract_cmmc_system_qualification_and_access.json","output/work/v21/final/policies/0010/general_cmmc_rules_and_eligible_work_scope.json"],"policy_ids":["pol_2f35e145efc941c7863b62c34452424e","pol_bb3acf092c91452d8bc53da7aba20f71"],"topic":"CMMC正式门槛与航天协作的早期适用"}],"publish_empty":false,"remaining_gaps":[{"name":"Consolidation尚未完成的候选核读与集合选择","reason":"当前只对下列20组形成明确before/after；其他final候选没有以目录、标题或Result代替完整核读而自动接纳。它们不是已退休，也不表示无价值，相关B原稿默认回退保留；此为执行未完成而非合理零Policy结论。尚未接纳的实际候选路径：\noutput/work/v21/final/policies/0000/commercial_military_transport_service.json\noutput/work/v21/final/policies/0000/customer_acceptance_settlement.json\noutput/work/v21/final/policies/0000/customer_project_funding.json\noutput/work/v21/final/policies/0000/defense_architecture_competitive_increment.json\noutput/work/v21/final/policies/0000/defense_procurement_scope.json\noutput/work/v21/final/policies/0000/escapade_dual_spacecraft_coordination.json\noutput/work/v21/final/policies/0000/escapade_mars_capture.json\noutput/work/v21/final/policies/0000/escapade_transfer.json\noutput/work/v21/final/policies/0000/geo_lightning_production_adoption.json\noutput/work/v21/final/policies/0000/globalstar_supplier_role.json\noutput/work/v21/final/policies/0000/government_project_financing_flow.json\noutput/work/v21/final/policies/0000/haste_paid_task_procurement.json\noutput/work/v21/final/policies/0000/mda_acceptance_settlement.json\noutput/work/v21/final/policies/0000/robotics_flight_product_adoption.json\noutput/work/v21/final/policies/0000/robotics_operational_qualification.json\noutput/work/v21/final/policies/0000/rslp_option_orders.json\noutput/work/v21/final/policies/0000/satellite_batch_integration.json\noutput/work/v21/final/policies/0000/satellite_contract_scope_economics.json\noutput/work/v21/final/policies/0000/satellite_project_payment_timing.json\noutput/work/v21/final/policies/0000/sda_followon_allocations.json\noutput/work/v21/final/policies/0000/sdn_followon_paid_work.json\noutput/work/v21/final/policies/0000/sdn_system_qualification.json\noutput/work/v21/final/policies/0000/sensor_transport_mission_requirements.json\noutput/work/v21/final/policies/0001/components_external_production_position.json\noutput/work/v21/final/policies/0001/components_price_engineering_responsibility.json\noutput/work/v21/final/policies/0001/defense_production_source_acceptance.json\noutput/work/v21/final/policies/0001/electron_other_customers_incremental_deployment.json\noutput/work/v21/final/policies/0001/european_optical_procurement_access.json\noutput/work/v21/final/policies/0001/flatellite_firm_scope.json\noutput/work/v21/final/policies/0001/flatellite_manufacturing_acceptance.json\noutput/work/v21/final/policies/0001/flatellite_neutron_acceptance_path.json\noutput/work/v21/final/policies/0001/flatellite_operational_service.json\noutput/work/v21/final/policies/0001/flatellite_user_window.json\noutput/work/v21/final/policies/0001/gauss_paid_product_adoption.json\noutput/work/v21/final/policies/0001/gauss_platform_qualification.json\noutput/work/v21/final/policies/0001/imm_apex_paid_product_adoption.json\noutput/work/v21/final/policies/0001/imm_apex_platform_qualification.json\noutput/work/v21/final/policies/0001/mynaric_effective_supply.json\noutput/work/v21/final/policies/0001/mynaric_external_production_adoption.json\noutput/work/v21/final/policies/0001/mynaric_internal_flight_set.json\noutput/work/v21/final/policies/0001/optical_terminal_inorbit_interoperability.json\noutput/work/v21/final/policies/0001/optical_terminal_model_qualification.json\noutput/work/v21/final/policies/0001/sar_independent_expansion.json\noutput/work/v21/final/policies/0001/silicon_hybrid_paid_design_supply.json\noutput/work/v21/final/policies/0001/silicon_hybrid_platform_qualification.json\noutput/work/v21/final/policies/0001/solar_legacy_family_production_adoption.json\noutput/work/v21/final/policies/0001/starlite_protection_optics.json\noutput/work/v21/final/policies/0010/iridium_enforced_debt_obligation_status.json\noutput/work/v21/final/policies/0010/iridium_group_guarantee_recourse_scope.json\noutput/work/v21/final/policies/0002/electron_compatible_full_chain_supply.json\noutput/work/v21/final/policies/0002/electron_contract_payment_stages.json\noutput/work/v21/final/policies/0002/electron_customer_task_windows.json\noutput/work/v21/final/policies/0002/electron_firm_tasks.json\noutput/work/v21/final/policies/0002/electron_payload_readiness_restoration.json\noutput/work/v21/final/policies/0002/electron_sovereign_qualification.json\noutput/work/v21/final/policies/0002/funded_responsive_task_assignment.json\noutput/work/v21/final/policies/0002/neutron_commercial_tasks.json\noutput/work/v21/final/policies/0002/neutron_compute_open_opportunity.json\noutput/work/v21/final/policies/0002/neutron_customer_task_preparation.json\noutput/work/v21/final/policies/0002/neutron_development_resources.json\noutput/work/v21/final/policies/0002/neutron_first_customer_delivery.json\noutput/work/v21/final/policies/0002/neutron_repeat_customer_delivery.json\noutput/work/v21/final/policies/0002/paid_readiness_and_orbital_reserve.json\noutput/work/v21/final/policies/0002/project_environmental_compliance.json\noutput/work/v21/final/policies/0002/project_quality_hold_restoration.json\noutput/work/v21/final/policies/0002/shared_design_batch_remediation.json\noutput/work/v21/final/policies/0002/shared_design_risk_exclusion.json\noutput/work/v21/final/policies/0003/electron_operating_window_suspension_recovery.json\noutput/work/v21/final/policies/0003/electron_single_task_delivery_failure.json\noutput/work/v21/final/policies/0003/haste_existing_cost_and_remedy_responsibility.json\noutput/work/v21/final/policies/0003/haste_paid_scope_changes.json\noutput/work/v21/final/policies/0003/kepler_additional_transport_opportunities.json\noutput/work/v21/final/policies/0003/kepler_neutron_capacity_customer_support.json\noutput/work/v21/final/policies/0003/launch_fixed_asset_recovery_liability.json\noutput/work/v21/final/policies/0003/launch_legal_service_authorization.json\noutput/work/v21/final/policies/0003/launch_site_access_rights.json\noutput/work/v21/final/policies/0003/launch_site_customer_window_availability.json\noutput/work/v21/final/policies/0003/neutron_cancellation_cost_protection.json\noutput/work/v21/final/policies/0003/neutron_contract_preflight_cash.json\noutput/work/v21/final/policies/0003/neutron_stage1_actual_recovery.json\noutput/work/v21/final/policies/0003/neutron_stage1_first_reflight.json\noutput/work/v21/final/policies/0003/neutron_stage1_further_life_cycles.json\noutput/work/v21/final/policies/0003/neutron_stage1_postflight_qualification.json\noutput/work/v21/final/policies/0003/orbital_compute_distributed_system_validation.json\noutput/work/v21/final/policies/0003/orbital_compute_funded_adoption.json\noutput/work/v21/final/policies/0004/archimedes_flight_configuration_qualification.json\noutput/work/v21/final/policies/0004/constellation_unallocated_medium_batches.json\noutput/work/v21/final/policies/0004/funded_hypersonic_test_stage_mix.json\noutput/work/v21/final/policies/0004/ghost_campaign_site_executability.json\noutput/work/v21/final/policies/0004/ghost_paid_new_location_deployment.json\noutput/work/v21/final/policies/0004/medium_third_party_effective_windows.json\noutput/work/v21/final/policies/0004/neutron_first_flight_window_risk.json\noutput/work/v21/final/policies/0004/neutron_flight_design_requalification_risk.json\noutput/work/v21/final/policies/0004/neutron_pad_arrival_window_risk.json\noutput/work/v21/final/policies/0004/neutron_tank_flight_configuration_release.json\noutput/work/v21/final/policies/0004/neutron_vehicle_ground_interface_acceptance.json\noutput/work/v21/final/policies/0004/orbital_compute_paid_supplier_roles.json\noutput/work/v21/final/policies/0004/qualified_rocket_input_sources.json\noutput/work/v21/final/policies/0004/rocket_manufacturing_qualified_output.json\noutput/work/v21/final/policies/0005/commercial_station_flight_hardware_roles.json\noutput/work/v21/final/policies/0005/commercial_station_open_supplier_packages.json\noutput/work/v21/final/policies/0005/commercial_station_paid_early_engineering.json\noutput/work/v21/final/policies/0005/commercial_station_paid_role_withdrawal.json\noutput/work/v21/final/policies/0005/commercial_station_product_qualification.json\noutput/work/v21/final/policies/0005/emss_core_comparable_fixed_rates.json\noutput/work/v21/final/policies/0005/emss_core_firm_renewal.json\noutput/work/v21/final/policies/0005/emss_existing_function_scope_transfer.json\noutput/work/v21/final/policies/0005/emss_separately_paid_operating_capabilities.json\noutput/work/v21/final/policies/0005/emss_uncompensated_new_service_duties.json\noutput/work/v21/final/policies/0005/neutron_cargo_critical_support.json\noutput/work/v21/final/policies/0005/neutron_cargo_paid_task_roles.json\noutput/work/v21/final/policies/0005/neutron_cargo_route_admissibility.json\noutput/work/v21/final/policies/0005/neutron_cargo_survival_results.json\noutput/work/v21/final/policies/0005/neutron_first_orbital_flight_results.json\noutput/work/v21/final/policies/0005/neutron_postflight_correction_qualification.json\noutput/work/v21/final/policies/0005/nite_star_awardee_access.json\noutput/work/v21/final/policies/0005/nite_star_funded_target_tasks.json\noutput/work/v21/final/policies/0005/nssl_effective_competitor_supply.json\noutput/work/v21/final/policies/0005/nssl_funded_launch_service_roles.json\noutput/work/v21/final/policies/0005/nssl_neutron_independent_qualification_changes.json\noutput/work/v21/final/policies/0005/pnt_binding_independent_source_requirements.json\noutput/work/v21/final/policies/0005/pnt_existing_paid_role_withdrawal.json\noutput/work/v21/final/policies/0005/pnt_fixed_competing_satellite_production_service.json\noutput/work/v21/final/policies/0005/pnt_fixed_competing_satellite_qualification.json\noutput/work/v21/final/policies/0005/pnt_fixed_fiber_holdover_role_substitution.json\noutput/work/v21/final/policies/0005/pnt_fixed_iridium_architecture_acceptance.json\noutput/work/v21/final/policies/0005/pnt_fixed_iridium_production_deployment.json\noutput/work/v21/final/policies/0005/pnt_iridium_mobile_product_qualification.json\noutput/work/v21/final/policies/0005/pnt_iridium_oem_production_choice.json\noutput/work/v21/final/policies/0005/pnt_mobile_competing_product_adoption.json\noutput/work/v21/final/policies/0005/pnt_mobile_competing_service_qualification.json\noutput/work/v21/final/policies/0006/consumer_phone_satellite_external_alternatives.json\noutput/work/v21/final/policies/0006/defense_supplier_independent_production_maturity.json\noutput/work/v21/final/policies/0006/government_ground_engineering_paid_scope.json\noutput/work/v21/final/policies/0006/industrial_iot_paid_production_adoption.json\noutput/work/v21/final/policies/0006/iridium_actual_wholesale_recurring_rates.json\noutput/work/v21/final/policies/0006/iridium_consumer_paid_product_roles.json\noutput/work/v21/final/policies/0006/iridium_general_paid_scope_retention.json\noutput/work/v21/final/policies/0006/iridium_independent_channel_routing_positions.json\noutput/work/v21/final/policies/0006/iridium_personal_device_subscription_roles.json\noutput/work/v21/final/policies/0006/maritime_paid_companion_services.json\noutput/work/v21/final/policies/0006/ntn_direct_persistent_paid_adoption.json\noutput/work/v21/final/policies/0006/ntn_direct_sellable_eligibility.json\noutput/work/v21/final/policies/0006/pwsa_effective_supplier_pool_transitions.json\noutput/work/v21/final/policies/0006/pwsa_executable_production_scope_tempo.json\noutput/work/v21/final/policies/0006/pwsa_specific_production_funding_rights.json\noutput/work/v21/final/policies/0006/sbi_funded_team_selection_roles.json\noutput/work/v21/final/policies/0006/vodafone_ntn_path_and_timing_risk.json\noutput/work/v21/final/policies/0007/allied_formal_foreign_procurement_access.json\noutput/work/v21/final/policies/0007/allied_pre_rfp_effective_role_qualification.json\noutput/work/v21/final/policies/0007/defense_new_equipment_vs_existing_data_capacity.json\noutput/work/v21/final/policies/0007/idle_nonoperating_asset_binding_cash_release.json\noutput/work/v21/final/policies/0007/iridium_committed_replacement_cash_timing.json\noutput/work/v21/final/policies/0007/iridium_network_stage_external_risk_share.json\noutput/work/v21/final/policies/0007/iridium_paid_network_health_capacity.json\noutput/work/v21/final/policies/0007/nasa_new_independent_small_transport_pool.json\noutput/work/v21/final/policies/0007/nonnetwork_committed_investment_value_support.json\noutput/work/v21/final/policies/0007/nonnetwork_stage_external_cost_risk_share.json\noutput/work/v21/final/policies/0007/photon_funded_new_science_roles.json\noutput/work/v21/final/policies/0007/remote_ship_control_state_production_operation.json\noutput/work/v21/final/policies/0007/remote_ship_mode_link_qualification.json\noutput/work/v21/final/policies/0007/remote_ship_paid_control_state_service.json\noutput/work/v21/final/policies/0007/space_vhf_anc_affirmative_review.json\noutput/work/v21/final/policies/0007/space_vhf_coordinated_trial_permission.json\noutput/work/v21/final/policies/0007/space_vhf_final_operating_standards.json\noutput/work/v21/final/policies/0007/space_vhf_paid_service_anchor_routes.json\noutput/work/v21/final/policies/0007/space_vhf_regional_commercial_access.json\noutput/work/v21/final/policies/0007/space_vhf_stage_cost_risk_sharing.json\noutput/work/v21/final/policies/0008/acquired_organization_continuity_resources.json\noutput/work/v21/final/policies/0008/aireon_ansp_paid_operating_scope.json\noutput/work/v21/final/policies/0008/aireon_commercial_feed_license_scope.json\noutput/work/v21/final/policies/0008/certus_fir_operating_acceptance.json\noutput/work/v21/final/policies/0008/certus_new_paid_safety_service_roles.json\noutput/work/v21/final/policies/0008/certus_safety_installation_and_blockage.json\noutput/work/v21/final/policies/0008/certus_upgraded_system_performance_acceptance.json\noutput/work/v21/final/policies/0008/current_batch_supply_inventory_cash_obligations.json\noutput/work/v21/final/policies/0008/engineering_committed_customer_function_scope.json\noutput/work/v21/final/policies/0008/engineering_core_product_route_withdrawal.json\noutput/work/v21/final/policies/0008/engineering_effective_team_reuse.json\noutput/work/v21/final/policies/0008/engineering_key_role_recurring_compensation.json\noutput/work/v21/final/policies/0008/engineering_key_talent_capability.json\noutput/work/v21/final/policies/0008/engineering_redundant_work_resource_exit.json\noutput/work/v21/final/policies/0008/funded_customer_digital_evidence_workflow.json\noutput/work/v21/final/policies/0008/internal_funded_digital_validation_capability.json\noutput/work/v21/final/policies/0008/local_matching_engineering_labor_competition.json"},{"name":"未接纳补研的正式Topic去向仍待完成","reason":"以下正式Topic的coverage暂未计入未经完整核读的候选，空policies/空note不表示研究已合理关闭。完整选择和具体残余研究缺口尚未完成，不宣称全部134 Topic健康：\nGlobalstar外部服务承诺对RKLB的可寻址增量\n项目付款与客户资金链的公开比较及现金边界\nGEO与深空平台资格的最早有效结果\n在轨服务接口与维修换新的目标净暴露\n国防架构与商业运输采用的可寻址增量\nFlatellite替换运输与延迟的净经济变化\n光终端合格供给与标准资格的公开增量\n欧洲终端可竞争资格的规则变化\n组件外销供给与未量化采用的公开增量\n新品电源推进资格与供给变化的早期入口\n生命周期与轨道治理事实的独立经济增量\nElectron任务与可兑现排期的相邻边界\nSAR服务承诺到新增运输机会的公开比较\nElectron全链替代运力与资格的早期竞争变化\n发射服务自身价格责任与非财报成本入口\n共享中继托管的付费采用与可寻址节点增量\n轨道算力系统路线与中型适配的早期增量\n场地窗口资本损害与收费条款的相邻边界\nNeutron重基线与专属资源决策的公开比较\nNeutron关键时间与复用资格的最早阶段信息\n中型第三方窗口与星座批次的相邻变化\nPWSA生产资金与批次节奏的公开相邻比较\n国防供方门槛与可竞争任务的增量分配\n再入货运保障采购与用户路线的早期增量\n材料来源与跨国产业资格的前生产入口\nNASA小任务组合与平台池的相邻增减\n商业站体资金设计与可寻址硬件的早期变化\nEMSS续约期限费率与收费责任的相邻边界\nIridium付费规模资费与工程工作量的相邻边界\nNTN渠道产品范围与路由分配的早期增量\n专业连接技术接受与PNT替代的最早可用边界\n空间VHF标准与可执行资本责任的早期变化\nIridium共享路径恢复与正常冗余的相邻信息\n成熟现金与更新资本的公开比较及配置方向\n终端供给报价与新增服务安装的净传导\nCertus后续资格升级与付费改装的相邻入口\n跨平台开发工作与非财报成本的相邻信息\n组织与工程方法的公开成本入口\n锁料义务与库存用途的公开净比较"},{"name":"三个宿主标记final edit incomplete的实际失败","reason":"task.missing明确列output/work/v21/final/policies/0002/electron_sovereign_qualification.json、0003/neutron_stage1_postflight_qualification.json、0010/iridium_enforced_debt_obligation_status.json。实际冻结加速稿仅剩恢复C2，原正式执行负向未在该文件；飞后资格仅剩LONG，整级资格损害只在transmission而非Condition；主权稿尚未完整保回原订单稿的有效资格条件来源。当前不能写新Policy或改冻结候选补救。三候选及相应不完整联合替换不当已完成；原保证稿含C3暂回退保留，未采用其删C3版本，故旧保证免责硬组合/100m已付款门槛未修且小额重要正式索偿缺口仍在。"},{"name":"借款人现金、保证责任与近端法律压力","reason":"实体资金分布和真实净可调度量、低于44.3m/100m的重要原受限责任、免责费/替代保证及较短保护净意义仍未全部建立。交割前Iridium义务非RKLB当前法定义务；未发现违约不能推今后没有法律状态入口。保证/加速联合编辑失败见上述，不能因现金修好把该题全关闭。"},{"name":"一般公司融资、项目剩余与交易等待安排的净交换","reason":"当前无闭合期后可用现金/用途、一般发行资源收益及项目收益/追索基线；17.75m、29.3m、100m、183.4m是强尺度不构成任意较小阈值。重要有据绑定改约可比较，普通新增支出/股数或多数权益不独立证明净方向，较早交换的决定性缺项未完成。"},{"name":"Iridium清关时点和终止净取舍","reason":"mid2027没有精确原月日，条件EndDate非公司承诺；小幅窗口变化净意义和一般终止撤回付款/债务保证、既成稀释、真实费用及替代用途的净价值尚未可判，不把整个集团终止天然SHORT或留款天然LONG。"},{"name":"联邦现金税盾的主体与可用性","reason":"方法选择/申报通常保密，当前RKLB联邦零现金税、交易未交割，公开公司纳税组、同年正税基和可利用属性尚未连接。2.5m历史口径不能代未来同纳税人实际基线，DTA不能当现金退款，未有潜在盾不能构造SHORT。"},{"name":"地区资本与设施阶段的真实交换","reason":"Germany仅潜在制造用途，没有已确认厂址/预算/授资。公开控制资格与资金窗口、较小重要固定责任、峰值改善换长租及设施用途固定责任的对应仍有个案未建立；20m/25m不替代比较，Cailabs地面站及EIF基金无具名受益者不填竞争暴露。"},{"name":"领导能力、董事监督和工程安全的具体未公开范围","reason":"正常连续换人与特定重要能力损失的主导分量未全建立；不揣测私人客户/技术归属。较小安全授权实际受阻任务范围/修复责任和有效备用流程未全公开；无重大已记录事实不是截止日从无事件，资料损失不可恢复部分不能被系统复工抹去。"},{"name":"CMMC目标适用资格与竞争传导","reason":"目标法人/系统SPRS有效状态、等级、系统UID及合同/新采购FCI/CUI流转没有公开逐项映射；框架采用和47%政府链暴露不代认证。紧规则可能已合格目标获益，松规则也可能增强对手，泛制度净方向仍未建立。补研SAM查询失败不表示没有招标，不启动第二补研。"},{"name":"主动持有人、指数与卖方的测量来源","reason":"ARK未归因日差不可当主动交易，真实float、较小持有人重要角色/资金意图与披露滞后仍有限；NDX完整当期index shares及旧同价篮子免费来源不足。卖方完整同日EV/净债务/摊薄分母、共识及RJ原模型未取得，不否认可归属的新独立观点，也不编价格影响。"},{"name":"其余累计审查的研究缺口尚未逐题收束","reason":"最新健康review_frozen coverage_notes中保留的Globalstar服务与Iridium消费两段净暴露、项目付款/政府融资、GEO/深空、维修净角色、国防商业容量、Flatellite净替换和窗口、光终端现时供给/SDN时点、成熟组件报价交期、Gauss/Apex/硅阵列内供和锗、生命周期与平台保障、Electron任务窗口/SAR运输、HASTE价格责任/Neutron复飞直接成本、Kepler空间段份额、轨道计算完整系统、场地租金、开发资源队列、PWSA lot资金、供方整合/份额、货运支持、盟国与NASA平台池、站体资金/岗位、EMSS较小期限费率、IoT/批发费率/网关工程、NTN渠道路由、PNT性能/生产范围、VHF阶段资金、现网更新与非网络投入、终端同SKU价格传导、Certus时间、组织数字与采购锁料等具体未决比较仍在。本次未将其全部逐题核读与实际F对应，不能用这份归纳替代剩余Consolidation工作或声称研究已完成。"},{"name":"公司或战略客户调整Neutron专属投入与开发安排","reason":"Rocket Lab可能明确改变Neutron开发预算、团队及产线优先级，或由战略客户提供预付款、能力建设支持和带约束的开发合作。当前系统资格仍在推进、型号剩余预算未单列；9月融资主要服务Iridium交易，不能机械视作Neutron全部可用资金。区别于某项试验通过或失败，资源决策自身可改变维持队伍、完成验证及匹配客户窗口的能力，并可能以较低性能或更慢路径换取现金纪律。待研是新增承诺究竟支持哪段工作、是否挤占成熟发射业务、附带什么交付或排他条件；工程里程碑不应成为观察资本配置事件的前置要求。"},{"name":"公司或战略客户调整Neutron专属投入与开发安排","reason":"Rocket Lab可能明确改变Neutron开发预算、团队及产线优先级，或由战略客户提供预付款、能力建设支持和带约束的开发合作。当前系统资格仍在推进、型号剩余预算未单列；9月融资主要服务Iridium交易，不能机械视作Neutron全部可用资金。区别于某项试验通过或失败，资源决策自身可改变维持队伍、完成验证及匹配客户窗口的能力，并可能以较低性能或更慢路径换取现金纪律。待研是新增承诺究竟支持哪段工作、是否挤占成熟发射业务、附带什么交付或排他条件；工程里程碑不应成为观察资本配置事件的前置要求。"},{"name":"Certus航空安全通信获运行接受与机队改装","reason":"航空驾驶舱安全通信具有区别于Aireon监视和空间VHF的终端、认证与服务采用路径。FAA网站所载Iridium项目更新称首个Certus终端于2025年12月取得TSO，初始飞机STC和运行评估仍在推进，并计划改进通信性能；这些状态不代表cutoff已全部完成。未来航空监管者、航司和Collins等设备伙伴可公布适用飞机认证、空域运行接受、机队改装或评估时程调整，直接扩展或推迟Iridium的专业服务入口，影响RKLB拟收购业务。需研究客舱连接与驾驶舱安全服务的不同责任、旧服务迁移与新增付费、试用转商用及维修安装周期；技术认可本身有信息价值，不要求同时披露网络收入，但不能把评估飞机或免费服务当经常性订阅。"}],"replacements":[{"after":["output/work/v21/final/policies/0009/iridium_own_country_operating_rights.json","output/work/v21/final/policies/0009/competing_mobile_country_legal_access.json"],"before":["pol_c582bceb3ae94c5ebc342ba983c97964"],"reason":"自身实际国家权利与重合用途他网资格分工；保原自身两侧及竞争准入/撤回，不将UAE既有PTT、账单地区或物理覆盖泛化。"},{"after":["output/work/v21/final/policies/0009/federal_r_and_d_actual_method_choice.json","output/work/v21/final/policies/0009/transaction_tax_group_usable_shields.json","output/work/v21/final/policies/0009/binding_general_r_and_d_cash_tax_rules.json"],"before":["pol_d19919eb69ac442589968961f60ef2fb"],"reason":"同ID0043补研基底拆为方法、交易纳税主体及正式一般规则；移除2.5m/全部归零硬边界，保真实同年联邦税基与可用税权；零现金税和未建立纳税组不造税盾。"},{"after":["output/work/v21/final/policies/0009/new_joint_external_recurring_service_roles.json"],"before":["pol_760fbab266f94a7a883018d1ddb2a13e"],"reason":"保真正新增有偿共同持续服务及重要角色损失，排旧合同联名/更名和无偿职责天然LONG，不与旧专门服务合同流失重复。"},{"after":["output/work/v21/final/policies/0009/iridium_core_control_clearance.json","output/work/v21/final/policies/0009/iridium_independent_non_fcc_clearances.json","output/work/v21/final/policies/0009/iridium_substantive_close_window_revision.json"],"before":["pol_5f42ff5c6c3946b18c62830dbdcaed09"],"reason":"原FCC/必要监管阻断与0036新增ID非FCC有效清关、真实交割窗口协调；拒绝/终止和时点各唯一承接，不把EndDate或所有Q3目标当重大延迟。非FCC补研ID为after候选，不作为B的before。"},{"after":["output/work/v21/final/policies/0009/iridium_close_waiting_cash_obligations.json"],"before":["pol_c50ccc9755d9400bb6ce6995bac5ca3b"],"reason":"以9/15更新责任比较其他债务、费用、奖励及等待安排，卖方贷款183.4m只强尺度；总对价同一事实由价格范围承接，新增能力和现金抵销不忽略。"},{"after":["output/work/v21/final/policies/0009/other_corporate_fixed_priority_financing.json","output/work/v21/final/policies/0009/ordinary_residual_financing_rights.json"],"before":["pol_bb84df6031a84f16a463b230bbe628ac"],"reason":"Iridium贷款成本交专门身份，本组保其他固定优先责任及普通股/转换残余交换；17.75m与29.3m旧ATM不作最早硬底线，一般发行不因股数增加天然SHORT。"},{"after":["output/work/v21/final/policies/0009/iridium_retained_loan_net_financing_cost.json"],"before":["pol_569adb42d3374ba8aa31fceff384d364"],"reason":"同一贷款真实利差/评级/保护/再融资由原身份唯一承接；25bp约4.4m年量级为强参照，绑定未来条款及重要较短保护可先成立，原非标准费用结构不按模板改写。"},{"after":["output/work/v21/final/policies/0009/project_cofunding_risk_and_residual_rights.json"],"before":["pol_11e74837b8a54566a4e00849bcf02315"],"reason":"保具名项目真实共担、追索及保留权益，不因100m/多数阈值或项目伙伴名义自动定向；保真实共担撤回及经济权利损害，Neutron同一专属共担不重复。"},{"after":["output/work/v21/final/policies/0009/facility_comparable_use_net_fixed_cost.json","output/work/v21/final/policies/0009/facility_payment_peak_timing_value.json","output/work/v21/final/policies/0009/facility_committed_use_window_loss.json"],"before":["pol_0a901ce8be854de88ec746ccd2147a1d"],"reason":"同目的净固定责任、非免费近端峰值时间价值及承诺用途/窗口损失分别承接，25m为强尺度非共同最低；同一节约不又作时点利好。"},{"after":["output/work/v21/final/policies/0009/regional_bound_project_capital.json","output/work/v21/final/policies/0009/regional_formal_funding_eligibility.json","output/work/v21/final/policies/0009/competing_regional_product_line_financing.json"],"before":["pol_44311f4a72fe4cf4921eeea46e232883"],"reason":"实际项目资本MIDDLE、一般可获资资格OUTER和同产品竞争产线融资MIDDLE分工；20m非最早门槛，有偿融资不当赠款也不先全扣本金抹价值，Cailabs地面站/无具名EIF基金不作飞行终端竞争事实。"},{"after":["output/work/v21/final/policies/0009/iridium_bound_total_consideration_revision.json"],"before":["pol_e471e9d810064d34a16b5573c0859efc"],"reason":"保同一VWAP、股份/奖励及资产债务范围下绑定总价双向改约，100m非最早最低；原公式最终股数不是新经济条款，必要同意状态据实保留。"},{"after":["output/work/v21/final/policies/0010/leadership_execution_capability_continuity.json"],"before":["pol_076f96fcaecc43beb617dc39b4d79e91"],"reason":"普通有效CEO交替不天然LONG，真实新增能力/单点分散及此前CEO/CFO/COO/平台缺口恢复保留；有名代理或董事会代管须按实际权限、相关能力和机制判断，不造当前空档。"},{"after":["output/work/v21/final/policies/0010/iridium_general_cash_mobility_rights.json"],"before":["pol_c2e41775c9d34e13976852ebed7168e9"],"reason":"0038现金新增ID候选C1/C2的信息合入原现金C1/C2，不冒同名条件为同一身份；即时与未来自动生效的一般用途权统一，不在签署/交割/划款重复，44.3m和100m不取硬交集；扫付须同时计债务/利息/风险。"},{"after":["output/work/v21/final/policies/0010/active_important_holders_and_public_secondary_supply.json"],"before":["pol_73b9000457354dc4891bfc62357c20b2"],"reason":"0044新增ID的净重配/分销信息吸收进原C1/C3/C4，原C2重要真实集中持有保留；不按条件名字嫁接身份。ARK强比例、RKLB市场量级及低于5%绑定分销分别可充分，同一承诺/交易/快照一次。"},{"after":["output/work/v21/final/policies/0010/engineering_controlled_information_and_security_authorization.json","output/work/v21/final/policies/0010/own_engineering_workflow_disruption_and_recovery.json","output/work/v21/final/policies/0010/external_engineering_interface_disruption_and_recovery.json"],"before":["pol_55a92b7861ea4b499719d41bfde1562c"],"reason":"保原受控资料与正式授权C1—C3，加入0048新增ID操作中断/复工的真实独立两侧；自有INNER、履约接口MIDDLE，不按攻击者/发布者划层，重要单任务不等100m/全取证。公告重合含义一次，后来实际权限/能力变化仍可独立。"},{"after":["output/work/v21/final/policies/0010/contract_cmmc_system_qualification_and_access.json","output/work/v21/final/policies/0010/general_cmmc_rules_and_eligible_work_scope.json"],"before":["pol_2f35e145efc941c7863b62c34452424e"],"reason":"具体任务/分包MIDDLE与通用正式门槛OUTER分开；保PhaseI及底层保护、FCI短任务/新采购早期资格，不按等级升降机械方向。目标现行系统/任务映射未建立是明确未完成研究，不宣称加OUTER已补齐。"},{"after":["output/work/v21/supplement/OPEN_RESEARCH/0047/policies/policy_02_board_oversight_rights.json"],"before":["pol_1d3e675750b3424184c7d97354c6dad4"],"reason":"直接接纳已健康同ID董事补研；现行lead/六七独立监督非零、实际任职多数非授权席数、实质新增议程权/单项目资本权及自然监督恢复均已完整承接，不制造无变化final副本。"},{"after":["output/work/v21/supplement/OPEN_EVENT/0045/nasdaq100_target_allocation.json"],"before":["pol_d4e637fea1f149598f3de8793697fa7e"],"reason":"直接接纳已健康同IDNDX补研；公告最终目标、同价同规模重建及精确1bp/公开舍入2bp分开，旧0.05pp为强尺度，修FastEntry错误，不把单QQQ或粗AUM当实际买单。"},{"after":["output/work/v21/supplement/OPEN_RESEARCH/0046/policies/sell_side_view_increment.json"],"before":["pol_34cc5ee5c377486b9699f26a5796d4fe"],"reason":"接纳健康同ID卖方观点稿：首次明确推荐/独立风险时间判断可先成立，正常摘要无需私有全年度模型；旧报告重述、PT机械变化排除，同报告净主导观点只一次。"},{"after":["output/work/v21/supplement/OPEN_RESEARCH/0046/policies/peer_method_reselection.json"],"before":["pol_237a6b911cc543fbba7f3a0ad2bb5546"],"reason":"接纳健康同IDpeer方法稿：已上市同行可重新选择/加权，公开方法与RKLB方向足够，不须再等IPO/完整EV桥；经营与peer相反变化按明确净主导结论，不拆相反交易。"}],"summary":"本文件是未完成的Consolidation部分交付，不是已收敛的正式PolicySet/Projection，也不表示可以宣称全部候选已接纳。以125份不变主研究B为起点，20组明确替换接纳33个实际候选，其他B默认保留；publish_empty=false。134正式Topic均列出：主Topic按实际B/所选after的文件定位列去向，未加注的主Topic只表示原稿默认存在，不作健康断言；未获本次接纳的补研Topic空policies/空note是未完成，不是合理零结果，名单进入remaining_gaps。三个宿主incomplete候选不计after；保证组未用删C3范围稿覆盖原稿，原负向还在但未修好。0038现金新ID、0044持有人新ID的信息分别吸收进原身份；0048操作新ID及外部接口分别实际新增。未接纳候选不计最终覆盖、不凭文件存在自动发布。信息截止2026-10-12T08:45:17.165493+00:00，不开第二补研。Late：OPEN_EVENT.late#L1已由本次CMMC两范围承接，适用gap如实保留；S0001.late#L1仍由默认B的S0001/0013 SDN承接，系统/后续阶段编辑尚未接纳；S0002.late#L1及late/1dcb9cd5497207173f1e1f9b.jsonl#L1、late/72a8e1e878c864e3d97e1b5e.jsonl#L1为同一Neutron资源题，默认B S0002/0023/P02保留而完整编辑未接纳；S0004.late#L1及late/3e089623cf30b8957fc17f9b.jsonl#L1为同一Certus题，默认B S0004/0045保留、升级/时点候选未在本次接纳。上述真实late不复制、不重新Planning。"}

## Flatellite整包范围、Neutron运输与运营交付

截至2026-10-12，Rocket Lab披露的SB-AMTI任务把Flatellite设计制造、Neutron发射和在轨运营连为一个政府交付包；公司公告的3.97亿美元是含额外Flatellite选项的潜在总值，不是发射订单或全部刚性收入。空间系统的制造进度、Neutron运输和任务运营是不同实现阶段：公司一般固定价航天器项目可按履约进度确认，但本合同的基础数量、选项金额、单次发射价格、生产验收/付款是否独立于发射、替代运输权责、赔偿与运营起点均未在已核验披露中拆开。因此，Neutron延迟不能自动推断全部卫星制造收入同步消失，也不能把3.97亿美元视为Neutron收入。Neutron仍在资格与开发阶段；2026Q2 10-Q给出的Q4目标是运抵发射台，年末首飞窗口收窄且资格测试仍在继续，合同自身的Flatellite发射与运营窗口未披露。一个明确改用外部火箭的合同变化，即使保留卫星生产和运营，也会削弱Neutron的内部使用与首批客户证明；若额外运输/集成成本由Rocket Lab承担，还会压缩固定价合同回报。反之，Space Force接受制造交付或开始任务运营可以分别降低项目完成风险，不必等全部卫星与火箭链条同时完成。Space Force的SB-AMTI公开采用多供应商/多方案采购，其他厂商另获任务不等于Rocket Lab这份合同已被替换；只把针对Rocket Lab已承诺任务的明确改约视作运输变化。首批Neutron时隙同时连接内部Flatellite履约与外部发射客户：内部使用有助系统任务但不是新增合并口径外部发射收入，外部客户占窗也可能推迟本项目服务起点；公开资料没有单位成本、排期或合同价差，故不从时隙选择本身推断净收益。C5未建立卖方共识或市场隐含首飞/合同兑现日期，以下边界相对于披露的合同与工程状态，不声称超出市场预期。

- C1 / LONG / MIDDLE: Space Force正式行使SB-AMTI中追加Flatellite数量的选项，或以新有资金义务的合同修改增加Flatellite系统工作范围。
  - Reference: 截至2026-10-12，公司公告的3.97亿美元为含选项潜在总值，且明确包含额外Flatellite选项；已核验文件没有披露基础数量、基础/选项金额拆分或选项已行使的事实。C1说明公司一般backlog排除未行使选项，故当前潜在上限不等于已承诺工作量。
  - Boundary: 采购机关的正式选项行使或新资金义务应把此前可选的额外卫星/系统工作变为净新增firm工作；这已提高有约束力的Space Systems项目范围，不需合同潜在总额超过3.97亿美元或另行公布单星价格。只有更新明确保留Neutron运输，才同时计为Neutron任务上修；若新增仅限制造/运营，不把其价值推定为发射贡献。重复报道原授标、仅重述总潜在值、或不增加已承诺范围的预算上限不触发。
- C2 / LONG / MIDDLE: Space Force确认其在Neutron发射前已正式接受一项完成的Flatellite制造交付或实质生产里程碑，作为SB-AMTI合同项下的客户交付，而非仅为Rocket Lab自述制造进度。
  - Reference: 合同公告列出卫星设计/制造、Neutron运输和运营，但没有公开Flatellite制造验收节点、是否可先于发射接受或对应付款条款；截至截止时Neutron仍在资格阶段，未见客户正式接受Flatellite成品/制造交付的披露。公司其他固定价航天器的进度确认方式不能代替本合同条款。
  - Boundary: 客户正式接受一项已完成的Flatellite制造交付，即足以单独降低制造与合同交付风险，即使Neutron发射和其他卫星仍未完成；不要求整包已运营。该接受本身不证明款项已收或该履约义务可独立结算，除非公开文件同时明确付款/结算。一般设计进度、公司内部测试完成或未获客户接受的状态不触发。
- C3 / LONG / MIDDLE: Space Force或Rocket Lab确认至少一颗Flatellite已进入并开始提供SB-AMTI合同约定的实际在轨任务服务，例如向任务用户提供合同数据/目标跟踪能力。
  - Reference: 已披露的合同责任包含在安全设施运营航天器并向Space Force提供数据/跟踪信息；截止时尚无本项目在轨服务开始或运行验收记录，首飞日期与运营起点均未公开。
  - Boundary: 至少一颗Flatellite被确认开始合同任务运营即跨越从开发/部署到实际服务的阶段，能独立验证运营工作已启动；不要求全部星座、持续多年或新订单。单纯发射成功、入轨或未完成的commissioning不等同于合同运营开始，也不能由此推算运营收入金额。
- C4 / SHORT / MIDDLE: Space Force通过合同修改/任务调整，正式削减或取消已承诺的SB-AMTI Flatellite基础制造或运营工作范围；仅未行使选项不算已承诺工作被削减。
  - Reference: 公司披露了现行SB-AMTI设计、制造、Neutron发射和运营合同，潜在总值含选项；已核验材料未提供基础数量或任何基础工作削减/终止通知。由于金额含选项，不能把总额视为不可取消的固定收入。
  - Boundary: 客户正式取消、解除或减少一项此前已承诺的Flatellite制造/运营交付，或把该已承诺系统工作移出Rocket Lab合同，即足以减少已分配的Space Systems任务及后续运营机会；不需等待财务报表确认损失。只是不行使尚未承诺的选项、其他厂商获得独立任务、或仅调整运输方式而保留制造/运营工作，不触发此项；不把3.97亿美元全额记为损失。
- C5 / SHORT / MIDDLE: 一项此前分配给Rocket Lab Neutron的已承诺Flatellite发射任务，被Space Force/项目方或合同修改明确改派到Neutron以外的运载器，而Rocket Lab卫星制造/运营范围仍可保留。
  - Reference: Rocket Lab的SB-AMTI公告明确Flatellite计划由Neutron发射；Neutron仍在资格测试，当前公司目标仅为Q4到台且年末首飞窗口收窄。尚未披露本合同发射数量、价款或已批准替代路线。Space Force另行授予其他供应商SB-AMTI任务本身不表示本合同运输被转移。
  - Boundary: 针对Rocket Lab已承诺Flatellite任务的正式Neutron→替代载具改派，即使整包卫星制造与运营合同仍在，也会减少Neutron的内部任务和早期商业履历，足以单独修订Neutron捕获预期；无须证明整份卫星合同取消或全部制造收入损失。另有供应商独立授标、平行运力预留、研究替代方案或一般Neutron延期但未更改本任务，不触发。
- C6 / SHORT / MIDDLE: SB-AMTI改用外部运载服务后，Rocket Lab被明确要求承担一项合同原补偿之外、不可向客户回收的额外外部运输或重新集成成本。
  - Reference: 已核验公司、Space Force与SEC披露未列Neutron运输分摊、外部运载器报价、合同成本调整、延期赔偿或替代运输费用由谁承担；公司公告的3.97亿美元混合制造、运输与运营且含选项，不能充当替代运费预算。
  - Boundary: 只有公开的合同改约、公司申报或可靠报道明确新增飞行级外部运输/重新集成费用由Rocket Lab自行承担且未获客户变更价款或补偿，才构成新增固定价成本/现金占用并触发SHORT。仅称替代火箭被考虑、由客户直接支付、或未说明Rocket Lab承担额外成本的改运消息，不足以认定成本归属；不以外部发射的毛票价冒充相对Neutron的净成本差。
- C7 / SHORT / MIDDLE: Space Force或Rocket Lab把一项已公开的SB-AMTI Flatellite发射、交付或首个运营窗口正式改到更晚的报告季度，且该变化推迟合同任务的可服务起点。
  - Reference: 截至2026-10-12，Neutron公司目标为2026Q4到Wallops发射台，年末首飞窗口收窄且资格测试未完成；SB-AMTI本身的首发、客户验收及运营时间没有公开。不能把Neutron到台日误作Flatellite发射/运营基线。
  - Boundary: 只有本项目已有公开窗口后，客户/公司明确将已承诺Flatellite发射、交付或首个运营起点从原报告季度移至后续季度/财年，才是独立的时间下修，因任务服务及相应项目进度被推迟；同一季度内的日期移动、仅Neutron通用目标变化而未连到SB-AMTI、或没有可比的既有窗口，不触发。

## 在轨寿命与客户补网资金如何改变 Electron 承诺任务

Electron 的直接商业单位是客户承诺的一次完整发射任务，不是退役卫星数。Synspective 截至 2026-10-01 累计披露 47 项 Electron 发射任务、34 项未飞；新披露的 20 项 2028–2031 campaign 不应再机械加到 34 项未飞数上，也没有逐年任务拆分。H1 2026 对两颗卫星调低寿命估计，分别涉及当前太阳活动造成的轨道高度下降和发电量下降，并非已报废或失效。提前补网只有在客户资本、维护、卫星制造和运力安排可承担时才成为可支付发射；它还会与扩网争资。寿命延长会推迟后续采购但提高服务持续性；寿命估计或损失本身不等于 Rocket Lab 获得新任务。H3 的两次 Synspective 发射服务不同中倾角轨道，是并行采购而非 Electron 任务转移的证据。现有资料没有客户级 Rocket Lab 收入或该 campaign 的逐年排程，因此直接看新增、缩减或转移的 firm mission。

- C1 / LONG / MIDDLE: Synspective 或另一名已有 Electron 客户公开新增一项由客户承担的 firm Electron 发射任务，并将其作为寿命缩短或已发生在轨损失后的替换安排；该任务须超出该客户 cutoff 时已披露的 Electron 承诺，而非只把原任务提前排期。
  - Reference: 截至 2026-10-01，Synspective 披露累计 47 项 Electron 任务、34 项未飞，并宣布 2028–2031 年 20 项 campaign；报道未给出年度拆分或客户级 Rocket Lab 收入。H1 两颗卫星的寿命估计调短，不是实际报废。2 项 H3 发射服务不同轨道，不能视为 Electron 取消或替代。
  - Boundary: 一项超出现有承诺、获得正式客户任务/合同承诺的完整 Electron 发射任务是第一项直接新增运力采购；一次完整发射也是该业务的自然销售单位，强于寿命估计、融资意向、补星计划或原合约内的排程前移。以 Synspective 为例，必须超过 cutoff 的累计 47 项基线，且不得重复计入已公布的 20 项 campaign。
- C2 / SHORT / MIDDLE: Synspective 或另一名 Electron 客户公开取消或转交给其他发射服务商一项已签 Electron 发射任务，并说明更长的预计在轨寿命、较低替换规模或资金/维护约束减少了其替换计划。
  - Reference: 截至 cutoff，Synspective 有 34 项未飞 Electron 任务；寿命估计下调的两颗卫星尚未报告失效、退役或脱轨，20 项 campaign 的年度节拍不公开。并行采购 H3 或预留其他路线本身不代表原 Electron 任务已转移。
  - Boundary: 至少一项完整、已签的 Electron 发射任务从客户承诺中被取消或明确转移，才是直接减少任务量的边界；纯粹在原 2028–2031 campaign 内改期，或只报道较长寿命而未改合同，不足以触发。一个完整 Electron 任务是可观察的采购单位，不能由卫星数换算收入。

## 轨道安全冗余与分批部署如何改变 Neutron 任务数和有效适配

碎片碰撞、空间天气和轨道协调要求可使新星座增加避碰、离轨推进或电源储备、降低同批密度、分散轨道面；这会同时改变单星质量/体积、每批星数、所需发射次数和可用轨道。Neutron 的 13,000 kg 是可复用低轨设计目标，不是已实现性能，也不是所有任务轨道的载荷质量或整流罩体积边界。截止日 Neutron 仍处于资格/测试阶段，仅有 Kepler 一项已知专用 Neutron 任务且不早于 2028 年；Kepler 另行预留的 10 颗约 400 kg 卫星 Falcon 9 运力是并行路线，不是转出 Neutron 订单。客户最终选择更多小批次可增加专用发射任务，但更长寿命或降低星座密度也会减少总星数；协调或许可放宽通常只是恢复既有任务，不等于新增需求。实际客户任务承诺、路线及最终载荷适配比行业吨位或 13 吨名义目标更有意义。

- C1 / LONG / MIDDLE: Neutron 客户公开授予一项新的付费专用 Neutron 发射任务，明确其星座在安全/离轨配置、分散轨道面或较小批次部署后需要这项额外任务；该任务须在已有承诺之外。
  - Reference: 截至 2026-10-12，唯一已知专用 Neutron 客户任务为 Kepler 一项、不早于 2028 年；10 颗约 400 kg 卫星的 Falcon 9 预约与其并行。Neutron 尚未完成资格/首飞，13,000 kg 为可复用低轨设计目标，没有客户最终载荷的质量、体积和其他轨道适配公开值。
  - Boundary: 在 Kepler 现有单项专用任务之外，新增一项由客户公开授予的 Neutron 专用发射任务，是第一次直接增加已采购任务数的边界；更改法规、协调放行、同一任务改期或新增安全硬件而未产生额外 Neutron 任务均不构成新增需求。
- C2 / SHORT / MIDDLE: 一名 Neutron 客户公开取消、转交或撤回一项已承诺的专用 Neutron 任务，并将原因归于改变后的星座寿命/密度安排，或避碰、离轨与推进储备使最终任务载荷不再适配该任务的已约定运力/轨道方案。
  - Reference: 截止日仅有一项已知专用 Neutron 任务（Kepler，不早于 2028 年）；其另行保留的 Falcon 9 容量并非 Neutron 订单取消。Neutron 仍在资格与测试阶段，13 吨目标不等于某一具体轨道、载荷质量及整流罩体积的已验证边界。
  - Boundary: 对现有已约定任务，客户正式撤回、取消或转交其 Neutron 发射承诺，是足以改变已知任务池的首次边界。规格讨论、较低部署密度、增加冗余、平行预订替代路线或名义 13 吨对比都不足以单独命中；如是质量/体积不适配，须由客户/主承包商公开确认其最终载荷与承诺任务方案不相容并据此处置任务。

## 在轨损失的环境归因与共用设计责任如何改变 Rocket Lab 平台风险

一次卫星损失可能来自太阳活动增加大气阻力、碰撞或其他轨道环境，不应仅因失效就归因于供应商共用设计；反过来，若客户或调查机构将原因指向共享平台/组件设计，并对该批次采取返工或资格暂停，影响会从单星扩大到多个交付项目。NASA 对 2024 年风暴的历史记录展示了环境拖曳可使 CIRBE 提前脱轨、ICESat-2 进入安全模式，但这不是 Rocket Lab 客户事故。Rocket Lab 现有暴露横跨整星平台与组件：例如 Globalstar/MDA 既有 17 个定制 Lightning 平台，太阳能产品则用于超过 1,100 颗卫星；这些规模不证明任何单项事故由共同缺陷造成。冻结资料未显示 Rocket Lab 受影响批次的当前共因事件、调查结论或停收验收。

- C1 / LONG / MIDDLE: 针对一项涉及 Rocket Lab 交付平台或组件的在轨事故，客户/主管机构的公开结案将原因归于环境、碎片或其他非 Rocket Lab 共用设计因素，并在同一处置中解除该批已公告的验收/运行暂停，允许原已承诺项目恢复。
  - Reference: 截至 2026-10-12，输入材料没有显示 Rocket Lab 客户的多平台故障调查、相关批次停交或待解除的验收暂停；NASA 2024 年风暴造成的 CIRBE/ICESat-2 影响属于 NASA 任务，不能外推为 Rocket Lab 事故。
  - Boundary: 外部环境归因本身不是利好，必须同时有受影响 Rocket Lab 承诺项目恢复验收、生产或运行的正式处置；纯粹的无责调查结论、媒体对太阳活动/碎片风险的复述，或没有被暂停项目的环境损失不足以解除目标公司风险。
- C2 / SHORT / MIDDLE: 客户、主管机构或独立调查公开确认，某个 Rocket Lab 共用平台/组件设计是已报告故障的根因，并对采用该设计的多颗已交付或已签约产品实施批次性返工、停用或重新资格审查。
  - Reference: 本轮没有证据证明 Rocket Lab 现有平台或组件存在这种共同缺陷。Rocket Lab 既有平台和组件用于多个任务，但已公开规模仅表明潜在复制暴露，不构成共因失效证据。
  - Boundary: 一项有明确根因归属、且整改/暂停覆盖同一共享设计的多颗已交付或已承诺产品的调查处置，构成从孤立环境损失跨到系统性合同与交付风险的边界；单星损失、未归因事故或只称环境恶劣都不足以触发。

## 电源、推进与在轨安全余量如何转成 Rocket Lab 组件订单

在轨电源、寿命保障、避碰和离轨储备会影响太阳能/储能、推进系统及整星设计，但运行业务调整或更长任务寿命也可能不新增硬件。Rocket Lab 太阳能产品已用于超过 1,100 颗卫星，但该口径不是全部 IMM-β Apex；Apex 于 2026-09-08 完成首次在轨发射、31.5% 初始效率及相对传统方案降低 40% 电池质量的设计数据，不等于卫星总质量或寿命提升，也不代表所有客户已完成资格确认。Gauss 电推进产品已发射，公开的生产线设计能力超过每年 200 台不是实际产出或订单。硬件升级可能让 Rocket Lab 获取新增太阳能/推进订单；若客户选软件/轨道操作、延长既有寿命或转用其他供应商，安全要求变化不一定转成 Rocket Lab 销售。真正边界是客户有资金的生产设计选型或既有采购被撤换，不是规格讨论、工厂能力或产品发布。

- C1 / LONG / MIDDLE: 一名卫星客户/主承包商公开授予资金已落实的卫星生产项目，并在项目的在轨电源、寿命、避碰或离轨配置调整中正式选用 Rocket Lab 太阳能系统或 Gauss 推进产品。
  - Reference: 截止日，Rocket Lab 太阳能产品累计用于超过 1,100 颗卫星；IMM-β Apex 于 2026-09-08 首次发射但客户资格/订单不能由首飞推定。Gauss 已发射，产线设计能力超过 200 台/年，但实际产量、客户节拍和已获订单没有公开确认。
  - Boundary: 客户/主承包商明确把 Rocket Lab 产品选入一个有资金的生产批次并公开授予/确认供应安排，是第一次将新增安全或寿命规格转为 Rocket Lab 可捕获交付；产品发布、规格研究、技术演示、行业采购需求或标称产能都不够。无需报道披露内部单价或完整全星座份额。
- C2 / SHORT / MIDDLE: 一个已资金落实且先前公开选用/订购 Rocket Lab 太阳能或推进产品的卫星批次，因客户改用软件/轨道操作、延长既有寿命、调整安全储备或改选其他供应商而正式撤销或替换该产品采购。
  - Reference: 现有太阳能产品已有广泛在轨使用，Apex 与 Gauss 的新产品客户采购状态不能以首飞或产线能力代替；公开资料没有每个客户的订单量。新项目选择其他技术但从未承诺 Rocket Lab 产品，不是既有订单撤销。
  - Boundary: 对已公开选型或已订购的有资金生产批次，客户正式宣布去掉/替换 Rocket Lab 的产品，构成实际供应捕获减少的边界；仅采用软件操作、寿命延长的行业观点，或没有先前 Rocket Lab 选型的竞争产品发布，都不足以命中。

## 快速响应任务的单次采购与 Rocket Lab 任务分配

VICTUS HAZE 是目前已知的一次具名响应任务采购：Rocket Lab 提供 Pioneer/Puma 航天器、Electron 发射及运营，通知至发射为 16 小时 42 分，航天器调试为 37 小时 36 分；True Anomaly 的 Jackal/Mosaic 随后完成的是同一任务的追踪、重规划阶段，不是第二份合同或已披露的长期合资服务。额外的、独立付费任务若直接分配给 Rocket Lab，会把一次履历变成至少一次复购，并可能带来 Launch Services 的发射工作和/或 Space Systems 的航天器、初始化与运营工作；具体传导取决于合同范围，整包服务和仅承运并非相同收入构成。任务执行还依赖已准备的航天器、火箭、人员、许可窗口及对向目标，保持待命会占库存、团队工时与商业发射窗口，临机任务可能替代而非叠加普通排程。公司 2026Q2 Launch Services 收入为 44.6 百万美元、六次发射中含两次 HASTE；每次任务 9.1 百万美元是组合指标，不是响应任务价格或其利润，不能据此估算新订单收益。已披露采购决定本身是现实观察入口，不要求同条新闻再披露净发射增量、调用率、收入或毛利。

- C1 / LONG / OUTER: 政府或盟国采购者公开授予或签署一项独立于 VICTUS HAZE、具名且有资金义务的响应任务，并明确把至少一项付费任务责任分配给 Rocket Lab（可为 Electron 临机发射、响应航天器/储备平台交付，或任务运营；也可公开说明其在联合体中的具体责任）。
  - Reference: 截至 2026-10-12，可确认的 Rocket Lab 响应任务履历是 2026 年 VICTUS HAZE 这一项；通知至发射 16 小时 42 分、航天器调试 37 小时 36 分。Rocket Lab 与 True Anomaly 的后续阶段公告描述同一演示的不同任务角色。未见 Rocket Lab 已获后续具名响应任务或持续待命订单；政府的 CASR 兵推是危机能力框架讨论，不是 Rocket Lab 数量或合同基线。
  - Boundary: 一项完整、独立、已获资金义务的后续响应任务就足以把当前单次演示基线改为重复采购，并增加 Rocket Lab 的具名可履约工作；不要求先积累多个客户、等待实际发射、披露合同金额或证明净新增 Electron 次数。单纯框架资格、演习、未获资助的选中、HAZE 任务阶段更新或一般 HASTE 合同不越界。
- C2 / SHORT / OUTER: 采购者公开取消、终止或把一项此前已授予 Rocket Lab 的具名未来响应任务之完整付费工作范围改派给其他供应商或另一任务架构，且明确该项 Rocket Lab 任务不再执行。
  - Reference: 目前 HAZE 已经完成，且尚无可确认的 Rocket Lab 后续具名响应订单，因此截至本基线没有可被取消的新增任务存量。若之后公开授予一项具名响应任务，它的资金义务及 Rocket Lab 角色构成可比较的新基线。
  - Boundary: 撤销或转走一项已授予的完整 Rocket Lab 未来任务，足以逆转该任务订单的增量预期；不要求消息同时量化收入或净发射缺口。任务改期但仍保留 Rocket Lab 责任、单纯未行使从未计入已承诺基线的选项、或 Impulse 等供应商获得一项没有明确取代 Rocket Lab 任务的独立合同，均未达到此边界。

## 持续待命与在轨储备的有偿准备状态

本主题真正的增量不是更快一次发射，而是谁承担维持随时可用能力的固定成本。若客户只在调用时付款、但要求 Rocket Lab 预留火箭、卫星、人员和许可窗口，低调用率会把库存占款、值守团队和放弃普通商业窗口的机会成本留给供应商；调用较频繁时，共用准备资源才可能摊薄。明确的待命费、优先容量或可用性合同则把一部分闲置风险交给买方，同时为服务水平、快速初始化和任务成功责任设定义务。另一条路线是预置在轨卫星或物资：可减少紧急时临时造星/运输，但把支出前移到部署，并增加持续初始化、维护和对向资产协同；它可能补充初次发射和平台工作，也可能减少将来临机 Electron 次数。HAZE 证明一次准备体系曾可执行，并非持续服务市场。Impulse 2026-08-13 获 SSC 2,800 万美元合同，为 VICTUS SALO 2/3 提供两艘 Mira 航天器，说明买方已为在轨机动付费；但没有证据表明它夺走任何 Rocket Lab/Electron 任务。CASR 2025 年兵推揭示危机与平时容量差异、目标包括预先谈妥商业增援合同，仍未建立 Rocket Lab 的常备采购量。当前没有公开的 Rocket Lab 待命费、调用率、库存单位成本或被放弃窗口价值，不能由合同总额推算利润；只需新闻明确买方为 Rocket Lab 的何种可用性付款，无须同时披露最终净发射增量。

- C1 / LONG / OUTER: 政府或盟国采购者公开授予 Rocket Lab 一项有资金义务的合同/任务订单，其明确购买的是一个可识别服务期或窗口内的地面准备状态（例如待命火箭、响应人员、快速初始化支持或优先保留的发射容量），并说明付款包含为可用性保留资源的对价，而不只是成功调用或发射后才付款。
  - Reference: 截至 2026-10-12，Rocket Lab 的直接响应履历限于完成的 VICTUS HAZE 任务；未见公开的付费待命期、预留窗口、待命库存数量或常备调用率。HAZE 的 24 小时通知要求与 16 小时 42 分实际发射证明曾有准备状态，但不证明买方为持续闲置能力付费。
  - Boundary: 首个直接授予 Rocket Lab、以可用性本身为付费交付的完整合同服务期，就把收入机制从一次任务或调用后付费推进到买方承担一部分准备成本；无需限定一年、多份合同、最低调用次数或披露待命费数额。若合同仅按实际调用付款而没有为保留状态付费，仍由 Policy 001 的单次任务条件判断。
- C2 / LONG / OUTER: 政府或盟国采购者公开签订有资金义务的 Rocket Lab 服务合同，明确由 Rocket Lab 提供并维持可调用的预部署轨道储备（如航天器、物资或机动能力），并承担一个可识别服务期内的初始化、维护、运营或响应可用性责任。
  - Reference: 当前确有 SSC 购买的在轨机动路线：Impulse 获 2,800 万美元合同，提供 VICTUS SALO 2/3 的两艘 Mira；但该合同是 Impulse 的独立工作，没有证据显示它取代 Rocket Lab 任务。Rocket Lab 尚无已披露的持续轨道储备可用性合同，HAZE 是一次性协同示范。
  - Boundary: 第一项公开、获资助并把持续储备运行责任直接交给 Rocket Lab 的服务承诺，会形成新的空间系统/运营可用性业务，即使储备减少后续突发发射次数也不要求同一消息证明净发射增量。仅有第三方预部署、未获资助的研究或 Rocket Lab 一次性交付/发射储备平台而无任何持续准备义务，不越过此可用性边界；一次性付费任务可由 Policy 001 覆盖。
- C3 / SHORT / OUTER: 买方公开撤销、终止或把一项此前已授予 Rocket Lab 的付费待命服务期、保留容量或持续轨道储备运营责任，整体改由其他供应商或明确不同的共享/预置架构承担，并说明 Rocket Lab 的该项承诺不再履行。
  - Reference: 当前没有公开的 Rocket Lab 待命合同或轨道储备服务合同可供削减；Impulse 的 VICTUS SALO 2/3 是另一个已采购架构，但并未被证明替换 Rocket Lab 的某项既有合同。未来若 Rocket Lab 获得上述付费可用性合同，该合同的服务期与责任范围成为可比较基线。
  - Boundary: 撤销或转走一项已签付费容量/完整服务期，直接使 Rocket Lab 不再收取该项准备服务对价，已足以确认其增量持续服务预期回撤；不要求公布调用率、机会成本金额或最终少发几枚 Electron。服务期内调用不足但固定费仍保留不构成下修；未获 Rocket Lab 合同的对手独立授标，也不构成此条件。

## 托管与实时光中继的付费需求如何转成空间段增减

Kepler 的第一批 T1 已于 2026-08-24 宣布完成调试并提供商业光中继服务，客户包括商业与政府任务；因此当前比较不是“光通信从概念走向首次使用”。公司 2025 年公布的 T1 方案为 10 颗约 300 kg 卫星、每星至少 4 个光终端；2026 年称分布式算力已在 10 颗星上运行 40 个 NVIDIA 模组。其 2025 年托管服务资料给出的单次任务设计包络约为载荷 120 kg、寿命末期平均载荷功率至少 400 W（受地方时影响）、接入网络最高约 2.2 Gbps、每日下传超过 20 TB、端到端延迟低于 750 ms；这些是 Kepler 对特定服务配置的供应商规格，不是当前网络的实测占用率、链路余量或全网吞吐量。T2 的最高 100 Gbps 也是公司披露的未来能力目标，不等同每颗卫星、每轨道窗口的保证容量。特定轨道面/时段能否交付，仍取决于星地可见性、星间链路路由、光地面站、服务调度与备援；已公开的 10 多个光学地面站、IP 网格和在轨计算可提高现网吸收能力，但没有公开各时段已占链路、剩余载荷位、功率/热裕度或客户 SLA 的履约数据，不能从用户数或原始数据量一比一推算所需卫星数。

托管把用户从自建整星转为租用平台、计算与中继能力，降低每个用户的独立平台及集成门槛；多个载荷、传感器和工作负载聚集到一颗宿主星上，也会提高该星的电源、热控、存储、光终端和集成复杂度。边缘筛选能压缩回传数据量，却增加在轨处理负载，并可能让更多任务选择实时协同、跨星分发和更短响应时间；净空间段需求取决于特定时间窗的链路和载荷资源是否先被用满，而不是单一“数据增长”指标。反过来，买方改善地面出口、重用既有星间/地面路由或自建中继，可能先替代共享网络需求；敏感用户改租隔离平台/本地直下传则减少多租户但可能增加独立卫星、平台和运输。仅因用户改选公共或自有系统，无法判定 Rocket Lab 净获益方向。

已知扩容基线包含多个 2028 年发射计划：Kepler 只公开了一次不早于 2028 年的 Neutron 专属任务；另在 2026-09-14 为 10 颗约 400 kg 的 T2 卫星安排了 2028 年中期 SpaceX Falcon 9/Portal-Maverick 运输。该并行配置说明新增网络能力不会自动归 Neutron，也不能把 T2 批次线性换成 Rocket Lab 的平台、光终端或发射订单。2025 年 Axiom 已购买两台在轨计算载荷；ESA 于 2026-04-14 授予 Kepler 一项 1,860 万欧元 HydRON Element 3 合同以托管多个欧洲伙伴载荷；NorthStar 与 Kepler 于 2026-08-27 公布传感器托管协议和扩大 SDA 网络的长期框架，但未披露传感器数量、服务容量、期限或价格。Kepler 的商业运行和已有项目已成立，尚无公开全网利用率或融资闭合数据。新增付费的持续服务承诺可以在后续卫星采购之前提高网络商业化和新容量的融资可信度；新增节点批次则更直接改变平台/运输市场，但二者均不证明 Rocket Lab 是 Kepler 的平台或光终端供应商，也不证明 Mynaric 获得份额。现有 Neutron 单次预订仅作基线，不在此重做其合同谈判。

- C1 / LONG / OUTER: Kepler 公布一项新增、可执行且有付款义务或专项资金支持的用户服务/容量合同，明确由遥感、政府或空间运营客户在多期或持续服务期限内购买实时光中继、在轨处理接入或 hosted-payload 容量；该合同增加已知客户承诺或付费保留的服务量，而不是未定价合作框架、免费试点、一次性演示或既有任务的例行运行更新。
  - Reference: 截至 cutoff，Kepler 于 2026-08-24 声称 T1 已商业运营，服务商业及政府客户；2025-04-07 公布 Axiom 购买两台首批在轨计算载荷并可追加；2026-04-14 获 ESA 1,860 万欧元 HydRON Element 3 合同、将托管多个欧洲伙伴载荷；2026-08-27 与 NorthStar 签托管协议及长期扩展 SDA 传感器的合作框架。公开材料没有全网利用率、按轨道窗口分配的链路余量、长期用户服务合约的完整金额/期长或每客户容量，Kepler 所称客户增长不能替代这些数据。
  - Boundary: 一项新增的、明示持续/多期或有明确保留容量的付费用户承诺即可越过现有“已有商业运行与若干托管/政府项目，但常态付费容量规模不清”的基线；不必等待该客户或 Kepler 公开新卫星采购、Rocket Lab 订单或季度收入。未定价的战略合作、需求意向、非持续演示和仅宣布能力可用仍在基线内。
- C2 / LONG / MIDDLE: Kepler 公开下达或融资落实一项超出已公布 T2 扩容的、独立新增的中继/托管卫星节点批次或相应空间段采购，并说明它将新增在轨中继、托管或覆盖能力；这须是实际批准/采购/生产安排，而非愿景、待融资计划，亦非仅为现有批次更换发射提供方。
  - Reference: 截至 2026-10-12，Kepler 公开计划 2028 年多批次扩容；已明确的一项是一次不早于 2028 年的 Neutron 专属发射，另一项是 10 颗约 400 kg T2 卫星经 Portal/Maverick 安排于 2028 年中由 Falcon 9 运送。尚未披露 Neutron 任务所含星数、每批实际服务容量、轨道窗占用或扩容融资明细；两种运输路线并存，不能把已计划的 T2/Neutron 事项再算成额外需求。
  - Boundary: 一次独立于上述已公布计划的新增、已批准并有资金/采购承诺支撑的空间段批次，且对外明确增加在轨容量，即首次把后续扩容从“客户增长的计划理由”推进为可执行的新增硬件采购，足以提高卫星平台及发射市场的机会预期。不要求运营者披露未公开的逐轨道链路裕度或单星利润，也不把该行业批次等同 Rocket Lab 已获订单、终端份额或 Neutron 份额。
- C3 / SHORT / MIDDLE: Kepler 明确取消或永久缩减一项此前已公布的未来中继/托管卫星节点批次或其空间段采购数量，理由指向客户承诺/付费使用不足、现有网络或地面路由足以承接需求，或扩建资金无法落实；单纯推迟窗口、调整轨道、替换发射提供方而仍保留卫星批次不属于该事实。
  - Reference: 当前基线仍为 T1 商业运行及至少一项已明确的 2028 T2 十星 Falcon 9 容量安排、Kepler 另有一次 Neutron 专属任务计划；多客户、托管与实时数据承诺的规模和 Kepler 可用资金没有公开核实。未见截至 cutoff 对上述已知网络扩容的正式削减；未披露也不能视为零需求。
  - Boundary: 一项已宣布的未来节点批次被正式撤销，或其卫星/托管能力数量被明确下调且不能仅靠换运载器或换档期恢复，即表明某段此前预期的空间段和未来运输需求不再按原规模建设；不需再等待收入确认。仅有个别客户转向自有平台/本地地面出口而 Kepler 仍执行批次，不触发，因为该用户可能另外形成平台与发射采购需求；也不将 Neutron 既有单次合同的单独谈判或改期作为本条件。

## Neutron 对轨道算力部署的批次适配

Neutron 是与平台/组件供货分开的发射服务传导。公开设计能力约为 13,000 kg 至 LEO，较高轨道能力更低；管理层给出的每飞行约 5,000万–5,500万美元价格框架不是已成交价。以完整 13 吨设计载荷简单相除约为 3,850–4,230 美元/kg，仅作满载量级比较，非报价或所有轨道的实运价；管理层另给约 8,000 万美元年固定运营负担框架，早期计划飞行数是管理计划而非计算客户订单。能够单独发射、重复采购或升级的模块批次，若连同平台结构、供电/阵列、电力电子、散热器、屏蔽、通信、冗余与部署结构后仍适配单次质量和买方预算，可能构成中型运输路线；只核算 GPU 会误判。Google 的设计研究把低于约 200 美元/kg 的 2030 年代发射假设用于特定大型系统成本比较，不是当前市场运价或所有空间边缘工作负载的门槛。若集中式不可拆分平台必须依赖该价位并选用超重型，行业总市场可以变大而 Neutron 不在其运力/成本类别。Neutron 截止时仍以 2026 年第四季度到发射台为目标，首飞窗口收窄且资格测试继续，因此技术设计与客户发射收入也需分开。

- C1 / LONG / MIDDLE: 具名算力部署的客户/运营者以有资金支持的合同或正式系统任务分配，向 Rocket Lab 购买一项 Neutron 发射，用于投放一批可独立部署的轨道算力模块；公开任务规格显示其完整 LEO 发射批次处于 Neutron 约 13,000 kg 的设计能力内（高轨按实际较低能力判断）。
  - Reference: 当前 Neutron 公开的可重复使用 LEO 设计能力约 13 吨；管理层价格框架约为每飞行 5,000万–5,500 万美元，年固定运营成本框架约 8,000 万美元。若假设满载 13 吨，票面价的简单平均仅约 3,850–4,230 美元/kg，不能视为实际单位报价；模块越轻，整次专属飞行的票价占比越高。截止时尚无轨道算力专属 Neutron 订单，Neutron 尚未首飞，Q4 2026 到台为目标而非已实现里程碑。
  - Boundary: 具名项目的有资金支持 Neutron 发射授标/合同本身，加上完整可发射模块批次落在相应设计运力内，即足够确认 Neutron 已捕获该类需求；不需等火箭发射成功、服务开始或第二次订单。公开的模块质量、系统接口和付费选择优于 GPU 重量或‘兼容’说法；单次订单只证明该批发射收入与适配，不证明长期飞行频率、成熟毛利或固定成本已被吸收。
- C2 / SHORT / MIDDLE: 一项具名且有资金支持的规模部署，正式确定其不可拆分的完整 LEO 生产批次超过 Neutron 的约 13 吨设计运力，并以低于约 200 美元/kg 的超低发射成本作为成立条件、锁定超重型专属运载路线而不保留可独立部署的中型模块批次。
  - Reference: Neutron 的名义 LEO 运力和每飞行价格如上；满载简单平均约 3,850–4,230 美元/kg。Google Suncatcher 研究对 2030 年代低于约 200 美元/kg 的假设，是特定大型系统比较情景，不是已获得的商业报价、当前运价或边缘处理所需价格。当前没有具名算力客户以此模式订购超重型部署，也没有已获算力任务 Neutron 订单。
  - Boundary: 只有当正式获资助/签约的生产部署同时锁定超出 Neutron 的完整批次、明确以该低价作为商业成立条件并选用超重型专属路线时，才足以判定该部署的 Neutron 参与窗口关闭；单篇白皮书、2030 年代模型、仅有较重总星座质量或未资金化的超重型设想不够。该 SHORT 限于大型集中式算力部署的 Neutron 发射机会，不否定可由 Rocket Lab 单独争取的平台、电源、光学或机器人供货。

## 轨道算力的付费采用与高功率部署

对 Rocket Lab 的可传导变量不是泛 AI 投资或卫星上搭载 GPU，而是运营者能否把轨道处理变成有付费用户的持续任务，并由此提高平台、供电、通信及运输的采购概率。GAO 区分了较接近实际用途的空间原生边缘处理与仍未证明规模经济的大型轨道数据中心；后者必须计入阵列与电力电子、散热器、辐射防护、通信、故障冗余、全寿命更新和实际利用率，而不只是芯片质量。工程质量或地面 AI 资本支出本身不能证明需求。付费运营工作负载或续约容量是从演示走向市场的较早可观测事实，即使当时尚未公布 Rocket Lab 订单，也会提高产生平台及组件采购的概率；因系统全成本或地面替代而停止扩容则压低大型专用平台的机会，但不等于所有边缘处理消失，也不直接量化为 Rocket Lab 收入、发射次数或利润。

- C1 / LONG / MIDDLE: 命名的轨道算力运营者宣布新的独立付费用户为其真实任务数据购买在轨处理，或既有用户签下继续/重复购买的容量服务；亦包括买方或机构为超出单次技术验证的重复运营模块部署明确承诺资金。事件须显示买方/资助方承担运营用途的经济承诺，而非仅由开发者自费测试其自有设备。
  - Reference: 截至 2026-10-12，Starcloud-1 搭载 H100 并演示过在轨运行/训练小模型，属于技术示范；Google 的两颗 Suncatcher 原型已于 2026-10-01 发射并开始收集 TPU 辐射、热环境数据，后续短距高速激光链路测试仍属研究计划。Starcloud-2 对 2027 年商业任务的描述尚未给出具名终端服务买方。2026-09-30 Firefly 将 Starcloud 列为 Elytra SC-1L 的商业载荷客户，计划在不早于 2028 年的月球轨道任务中处理 Firefly Solux 影像；这是已存在、金额未披露的一次托管能力示范，不等于重复容量或独立数据中心服务订单。
  - Boundary: 越过当前单次 Firefly/Starcloud 托管示范即可：一名新的独立付费用户购买实际运行任务的在轨处理，或该既有示范转为有合同/资金支持的重复服务，就足以确认买方承诺。无需披露金额、等待飞行/收入确认、完成大型云训练迁移，或在同一消息中披露 Rocket Lab 供应合同；单纯白皮书、研发拨款、开发者自费演示或没有付费用户的计划仍不足。
- C2 / SHORT / MIDDLE: 具名运营者或资助方正式终止已有付费容量安排或有资金支持的高功率运营扩容，并将原因归于完整平台的电源/热控/辐射/维修约束、实际利用率或相对地面服务的总成本，因而取消该专用规模化路线。
  - Reference: 当前只有一次已披露的 Firefly/Starcloud 商业载荷示范，没有公开的重复算力容量购买、持续服务用户或获资助的高功率生产星座。GAO 指出大型轨道数据中心的电力、冷却、通信、抗辐射及在轨维护经济性尚未验证；空间原生边缘处理仍是不同的、较早成熟的用途。
  - Boundary: 对一个已明确付费/获资助的运营扩容计划，正式取消或转回地面并明确归因于上述全系统约束，即足以降低大型专用平台的可融资机会；不必等到损失已体现在财务报表。单次测试延期、某一原型故障后继续下一轮、或只把集中式改为可行的边缘/模块方案，不满足该边界。该 SHORT 只针对被放弃的规模化高功率路线，不否定仍在进行的边缘处理需求。

## Rocket Lab 在轨算力平台与组件的供应位置

这一观察范围衡量的是 Rocket Lab 能否从行业采用中实际捕获供货，而不是把潜在市场规模直接归给公司。它已有航天器平台/系统集成、电源与太阳能产品、Mynaric 光学通信终端以及 Motiv 机器人能力；这些分别服务平台承载、供电、链路和未来维修/换件，不是一个可以互换的‘算力订单’。Rocket Lab 于 2026 年公布面向空间数据中心的先进硅太阳能阵列设计，但规格或目标用途不是客户定点、合格产品或已签采购。Google 的近距高速激光链路需求也不能自动视为 Mynaric 某款终端合格；机器人只在买方实际采用可换模块/在轨维修时有关。任何一个产品族的具名、有资金支持的采购/设计角色，都能独立改善相应供应位置；它不能证明其他产品族同时中标、形成规模或产生某一具体利润。

- C1 / LONG / MIDDLE: 一项具名且有资金支持的轨道算力项目，正式授予 Rocket Lab 或其相关产品线一项付费的平台/总线、项目所需高功率阵列或电源、功能匹配的光通信终端，或在轨换件/维修机器人硬件供货、设计或资格合同。具名范围中的任一单项供货角色即可成立，不能外推到其余产品线。
  - Reference: 截至截止时点，Rocket Lab 已发布面向轨道数据中心的先进硅太阳能阵列设计；其太阳能和平台产品有既有航天器客户基础。公司于 2026 年 4 月纳入 Mynaric 光终端业务，Motiv 机器人臂的 NASA/ Astro Digital 飞行演示则仍为计划于 2027 年末开展的技术验证。现有材料没有确立 Rocket Lab 在 Suncatcher、Starcloud 或 Firefly/Starcloud 项目中的算力专属平台、阵列、光终端或机器人订单。产品公告、一般资格能力、公司收购或未具名合作均不能作为专属供应基线。
  - Boundary: 具名客户/主承包方/资助机构公开确认一份有资金支持的合同、采购或付费资格/设计工作，并明确 Rocket Lab 与具体产品/系统的角色，即为足够的最早边界；不要求产品先完成在轨飞行或等待后续收入披露。非约束性合作备忘录、产品规格新闻、未说明链路匹配的‘光通信’引用、或通用机器人演示不够。授标只更新被点名的那一项业务，不推导其它供应份额。

## Iridium NTN Direct 的付费商业采用与渠道扩张

Iridium 的标准化 NTN Direct 可把低成本卫星消息接入运营商兼容终端和现有 SIM/漫游渠道，改变现有商业 IoT 服务的可达范围；截至本任务截止日，已披露的是 Deutsche Telekom IoT 漫游整合、与 Toyota 的语音消息演示及 2026 年后段商业开放目标，而不是付费车队量产。Iridium 2026Q2 商业 IoT 约 209.1 万计费用户、约 4,707 万美元季度服务收入，用户增长快于收入且 ARPU 同比下降：新增覆盖只有在付费激活和批发/套餐收益进入 Iridium 时才增加服务现金，不能把兼容设备数当收入，也不能把 NTN 接入当现网局部余量充足或新增卫星订单。交易仍待交割，Rocket Lab 对这部分服务现金的暴露有条件性。

- C1 / LONG / MIDDLE: Iridium 或具名运营商/OEM 宣布 NTN Direct 已向一个有明确设备/客户范围的商业群体提供可付费服务，并确认存在运营商批发费、按用量付费或终端客户订阅等有偿路径及首批实际开放时间；消息超出技术测试或合作意向。
  - Reference: 当前基线是渐进商业化：DT IoT 已完成漫游整合，Toyota 仅完成演示，Iridium 目标为 2026 年后段/第四季度提供商业服务；尚无公开付费客户群规模、批发价或活跃用户路径。既有 IoT 有约 209.1 万用户和约 4,707 万美元季度收入，但 ARPU 下行，故不能以用户增长本身年化现金。
  - Boundary: 有偿商业服务已向界定的客户/设备群开放、且至少一种结算路径确认，即足以把当前演示/计划修订为实际商业化采用；无需等待财报确认大量用户或收入。仅重述第四季度商业开放目标、宣布演示、兼容终端或未定价测试都属于普通进展，不跨越边界。
- C2 / SHORT / MIDDLE: Iridium 正式撤销 NTN Direct 的首次商业服务开放，或将整个商业化计划（而非单一地区的排期）置于无替代日期的暂停状态，并停止目前已整合的主要运营商/OEM 商业导入。
  - Reference: 公司已公开目标于 2026 年后段引入服务，合作方和芯片/设备集成正进行测试；基线是逐步导入，不是立即全面消费级采用。尚无付费用户或现成的收入基线。
  - Boundary: 计划本身的延后或单一地区/设备批次小幅移期不足以证明市场路径失效；撤销首次商业开放或对所有现有商业导入作无期限暂停则取消了近端付费入口，改变实现概率与时间，足以压低对新增 IoT 服务现金的判断。

## Iridium 容量优先级、星座健康与更新资金周期

Iridium 以现有约 66 颗在役星座支持约 1.613 亿美元的季度服务收入（商业约 1.337 亿、政府约 2,763 万美元）；EMSS 固定年费约 1.105 亿美元，提供不同于按用量计费的服务现金基座；原合同至 2026 年 9 月，可选延长六个月，但截止日前未确认已行使或完成新约。标准化 NTN 可先复用现有 L-band 网络，但材料没有局部余量或最新备用星健康清单；17.5 年是会计使用寿命，不是实际寿命/健康证明。管理层交易模型已有 2031—2035 年升级支出，且 2031 年无杠杆 FCF 为负 2,100 万美元；该模型不是更新后的公开指引或市场共识。由此，局部拥塞、健康驱动提前替换、健康证据支持的延后更新，以及外部托管/共同建设的资金分担，是不同的现金时点和容量状态。自制/自发射可以改变成本但合并口径不产生第二份外部收入；外部托管费亦须同初期节省相抵。

- C1 / SHORT / MIDDLE: Iridium 以卫星健康恶化或备用能力显著减少为由，宣布并承诺执行一项针对实质星座群组的替换采购/发射计划，且首个实质现金投入或发射批次移至 2031 年之前（2027—2030），而非只研究下一代方案。
  - Reference: 截至截止日没有公开的局部余量或备用星健康清单；17.5 年会计寿命不能作健康数据。内部交易模型列示 2031—2035 升级周期，2031 年无杠杆 FCF 转负；这只是当时模型，不是对投资者的当前承诺。
  - Boundary: 首个已承诺的实质替换阶段若由 2031—2035 提前到 2027—2030，并由健康/备用耗损而非软件能力试验或新功能扩展驱动，已将资本支出移入此前成熟现金累积期并缩短该模型中的低更新负担窗口；单颗卫星异常、常规维护或没有资金/时间安排的研究不够。
- C2 / SHORT / MIDDLE: Iridium 或主要服务渠道因某些已识别地区/时段的持续容量拥塞，限制既有付费商业服务的可用性、暂停已售服务群的新激活，或将原有客户群持续降级至较低优先级；消息明确是网络容量约束，而非例行灾害优先规则或自愿的高价优先选项。
  - Reference: 现网软件可承接部分 NTN 接入，但局部容量余量未测量，且没有截止日前公开的区域拥塞或存量服务受限事实。服务收入基座是经常性收入，商业服务约 1.337 亿美元/季度，政府服务约 2,763 万美元/季度；不能把网络新用途直接推成服务扩张。
  - Boundary: 新增/测试流量被工程排队仍属普通运行；对已售付费服务的持续限制或停开新激活，明确表明容量优先级已改变真实客户服务/收入范围，足以修订现网吸收增长的判断。限制只影响新产品候选而不触及既有付费范围的消息不足。
- C3 / LONG / MIDDLE: Iridium 发布针对主要在轨群组的实际健康/备用状态，并据此正式将内部模型所列的首个实质星座替换阶段移出 2031—2035 窗口，同时说明当前商业及政府服务容量仍可按已售范围提供。
  - Reference: 内部模型包括 2031—2035 更新投入；目前 17.5 年会计寿命既不能证明卫星健康也不能证明替换可无限延后，且不存在公开健康清单来支持延后结论。
  - Boundary: 必须同时出现相关星群的运行/备用健康证据与正式资金/日期安排，将第一阶段实质替换移至 2035 年以后；这使此前预期的更新支出越过一个完整模型周期。单纯延长折旧寿命、重复称星座表现良好或未宣布新支出，不构成更新计划的实际延后。
- C4 / LONG / MIDDLE: Iridium 签署一项为明确替换/扩容阶段提供托管容量、客户预付款或共同建设资金的约束性合同，说明外部方直接承担至少一个已定义部署阶段的建设/发射现金或预付服务费，并公开首个运营期持续服务费用；Iridium/Rocket Lab 对该阶段的净现金投入低于外部承担额，且保留足以服务既有客户的容量权利。
  - Reference: 目前没有披露的客户预付款、托管容量或共同建设条款可用来抵减内部模型中的更新投入；自有制造/发射是交易后潜在选择，不等同无成本融资。外部费用、贷款与服务现金负担仍未闭合。
  - Boundary: 外部承担/预付需覆盖一个明确部署阶段的资本或服务现金，且合同公开的首个运营期持续费用低于该阶段收到的预付款/外部投入，因而产生可计量净现金减负；非约束 MoU、普通供应商合同、未披露外部承担金额、等额或更高的长期服务费，以及集团内供货都不跨越边界。这样可识别现金责任真正转移，而不要求未来新闻重建完整全寿命模型。

## 交易后成熟现金的非网络配置与集团资金余量

成熟 Iridium 服务现金并不等于 Rocket Lab 可自由调度的现金：2026H1 Iridium 独立 CFO 为 1.85762 亿美元、capex 为 5,179 万美元，算术 CFO-capex 为 1.33971 亿美元且同比下降；这是交割前标的量级，不是集团资金或交易后预测。Rocket Lab 自身 2026H1 简单 FCF 为 -1.87519 亿美元；9 月 ATM 毛额 19.44 亿美元、发行 2,930 万股用于拟议收购现金对价，原 36 亿美元过桥已取消。交易目标为 2027 年中，Iridium 17.75 亿美元定期贷款可在交割后保留，Rocket Lab USA 将提供担保；Aireon 7 月收购对价约 3.667 亿美元（约半数现金、半数为一年后到期的无息卖方贷款），其既有债务与 Rocket Lab 交易费用仍需在来源/用途中单独调节；交割后的债务与网络再投资也会吸收现金。CFO 已含历史现金利息与税，不可再次扣除；内部制造/发射的集团采购必须抵销。新的现金并购或平台资本支出会与持续的网络更新/运营资金竞争；非核心资产变现或外部出资只有扣除交易成本、债务、失去的持续现金流及服务费后才增加可用余量。

- C1 / SHORT / INNER: Iridium 收购完成后，Rocket Lab 承诺一项新的现金收购或早期新平台投资，未来六个月的增量公司现金/新增债务使用额至少为 1.33971 亿美元，来源为交易后可调度现金或公司债务而非预付客户/共同出资；且披露的资产尚无同期已签约外部现金流来覆盖该增量。
  - Reference: 截至截止日 9 月 ATM 已完成并安排用于 Iridium 现金对价；若交易未完成或有超额资金，公司称资金可转用于未来增长/潜在收购及营运资金。Iridium H1 独立简单 FCF 为 1.33971 亿美元，但交割前 Rocket Lab 无权使用且两公司 H1 简单 FCF 机械合计仍为负；内部网络更新模型另有多年投入。
  - Boundary: 新增已承诺净现金用途达到 Iridium 一个已观测半年简单 FCF（1.33971 亿美元）即足以吸收一个成熟服务现金量级，并增加对研发、网络更新和营运现金的竞争；该金额只作为尺度，不是交割后的可用余额/预测。小额或无约束意向、由客户/合作方实际承担的支出，或有同期已签约现金回款可覆盖的项目不足。此 Condition 判断短期资金弹性，不将投资本身判为负 NPV。
- C2 / LONG / INNER: Iridium 收购完成后，Rocket Lab 完成对一项明确非核心、非经营性或无实质持续服务现金贡献资产的第三方出售，披露扣除税费、交易费用及需清偿债务后的净现金至少为 1.33971 亿美元，并明确款项留在集团用于偿还债务或现有已承诺网络/成长计划，而不是转作另一项并购。
  - Reference: 目前没有公开资产出售及可计量出售收入；交割资金仍需覆盖交易、债务担保、营运资金和网络资本周期。Iridium H1 简单 FCF 1.33971 亿美元只是独立经营量级，不是交易后可自由调度现金。
  - Boundary: 只在有约束力的交易产生扣除债务与费用后的现金净额至少达到一个 Iridium 实际半年简单 FCF 尺度、且被留存/用于减债或已承诺项目时，才构成一笔足以改变流动性来源的独立现金来源。出售核心服务、网络容量或可观 recurring cash 的业务不算正向现金释放；报价、意向或未说明净 proceeds 的出售不足。

## Globalstar设备卫星服务范围与网络资金承诺

Globalstar的设备卫星服务、批发容量安排与网络建设共同决定远期平台需求的规模和持续性，但终端设备数量不会按比例转成卫星订单。当前Apple卫星服务已覆盖iPhone 14及后续型号、Apple Watch Ultra 3等设备，可提供紧急服务、消息和位置功能；Amazon与Apple已公布继续支持现有及计划中的Globalstar星座并协作未来服务。Globalstar已承诺扩展网络，C-3超过50颗卫星已向MDA采购，客户预付和SPE安排支撑建设。服务扩至新的大规模终端平台或地区、并伴随新增Globalstar容量/资金承诺，才把现有建设范围外的服务机会变成新的持续网络负荷。反向的服务承诺收缩或实际重大里程碑付款会减少项目资金余量。即使扩展真实，也先经过现网容量、地面设施和频谱利用；它不自动给Rocket Lab带来新平台合同，供应份额由另一个Policy判断。

- C1 / LONG / MIDDLE: Apple、Amazon/Globalstar或新的Globalstar D2D客户公开宣布一项有约束力的服务/容量安排，把Globalstar支持的消息或位置服务扩至当前已披露的iPhone和Apple Watch Ultra 3生态之外的另一个大规模终端平台或主要市场地区，并明确该新增范围将由Globalstar网络承载，且带来新增的长期容量、服务义务或预付资金。
  - Reference: 截至2026-10-12，Globalstar服务已通过Apple覆盖iPhone 14及后续型号及Apple Watch Ultra 3，既有功能包括紧急服务、消息与位置；2026-04 Amazon/Apple协议已公开继续支持当前及计划中的Globalstar星座并合作未来卫星服务。Globalstar的Extended MSS Network及Apple服务预付款安排已在建，2026-04公开将High Power Infrastructure Prepayment上限提高约4.68亿美元至约15.8亿美元。Globalstar已另向MDA采购超过50颗C-3卫星，C-3卫星采购价披露为7.75亿美元；因此，现有Apple支持设备、既定Amazon-Apple安排和已采购C-3不是新增信息。
  - Boundary: 最低充分边界是一次公开、可识别的新增大规模设备平台或主要地区服务义务，并由Globalstar网络承接且有新增长期容量/预付承诺；这会把网络机会推进到已知设备与既定C-3建设之外，扩大持续使用和未来建网资金支持。单个已支持型号的例行换代、已公告服务的继续履行、只提Amazon Leo未来D2D而未说明使用Globalstar网络，均未跨过边界；无需同时公布Rocket Lab订单或卫星数量。
- C2 / SHORT / MIDDLE: Globalstar与Apple、Amazon或其他主要容量客户公开签署或执行一项有约束力的修改，实质撤销/减少既有卫星服务、预付或容量承诺，并明确因此削减或推迟当前C-3卫星或地面网络建设范围；或者Globalstar公开确认因C-3运营里程碑未达而实际触发向客户支付接近截至2026Q2披露的剩余约9,700万美元最高付款额。
  - Reference: Globalstar 2026Q2披露的当前基线包括Apple扩展服务与预付款安排、超过50颗MDA C-3卫星以及继续建设全球地面设施。同期披露在部分C-3运营里程碑未达时，Globalstar对Apple的潜在付款最高额约9,700万美元，因已达成的里程碑从原约1.10亿美元上限下降；截至本次cutoff，这只是或有金额，不是已发生支付。Rocket Lab没有已披露的C-3平台份额。
  - Boundary: 一次实际服务/容量承诺撤回且建设计划随之削减，或接近当前约9,700万美元上限的里程碑现金支付，已使现有建设融资/服务范围发生可识别下修；约9,700万美元相当于C-3卫星采购价7.75亿美元的约八分之一，足以影响后续网络资金余量。仅有合同风险披露、未触发付款、一般建设延后而无客户承诺变化，或Amazon交易仍在审批，均不足以单独判为该方向。

## Globalstar补充与第三代星座的平台供应角色

平台设计与供应分配决定Globalstar的星座投资有多少转成Rocket Lab的Space Systems工作。当前Rocket Lab已通过MDA为Globalstar供应17个定制Lightning卫星平台，名义合同价值1.43亿美元；MDA负责主承包、载荷开发及最终整星集成测试，Rocket Lab不是Globalstar该批卫星的发射商。这个已确定的17平台角色不能继承到第三代：Globalstar另向MDA购买超过50颗C-3卫星，Rocket Lab截至cutoff没有公开的C-3平台授标。新增多星制造批次可使现有设计、制造线和客户资格形成后续工作；持续运行/控制支持也可把收入责任延伸到硬件之外。反之，当前公开基线已是C-3没有Rocket Lab合同，所以只见MDA或Amazon选择其他方案并不能证明Rocket Lab失去一项既有订单。控制权变化可能改写谁作采购决定，但不改变老合同，也不能单凭Rocket Lab拟收购Iridium推断买方会要求中立第二来源。

- C1 / LONG / MIDDLE: MDA、Globalstar或（若交易交割后）Amazon公开宣布有约束力的合同/选项行使，新增Rocket Lab作为Globalstar卫星总线的多星生产供应商，包括为超过50颗的C-3批次分配实际生产批次、在原17平台采购以外增加多星制造，或向Rocket Lab增加持续的星座运营/控制中心工作范围。
  - Reference: 截至2026-10-12，Rocket Lab在原MDA主承包合同中制造17个平台，合同名义价值1.43亿美元；原公告包含额外航天器及运营控制中心等选项，但期权不等于已行使。Globalstar的C-3为超过50颗卫星，Globalstar SEC披露该卫星采购价7.75亿美元且由MDA承接；当前材料没有Rocket Lab C-3生产合同或份额。Globalstar与Amazon交易仍预计2027年交割，MDA仍是当前C-3主承包商。
  - Boundary: 首次公开的、已签约或已行使的多星生产批次，或覆盖星座且持续的运营/控制职责，足以把Rocket Lab从17个平台的既有工作扩展到新一轮直接合同范围；这是从C-3零已披露份额出发的业务捕获变化，不要求公开精确收入、最终星数或实际验收。单纯列入候选、技术可行性研究、设计复用意向、转让控制权、或者MDA采购C-3但未分配Rocket Lab工作，均低于边界。

## Globalstar补充星座17个平台的运行验收、返工与结算

Rocket Lab的17个平台分包由MDA作为主承包交付整星；平台制造完成、客户服务验收、收入按成本进度确认、开票收款及延期赔偿是不同节点。首批8颗在轨且初始接触、发电正常，仍处于调试，约占17颗合同的47%，不能等同服务验收或款项结清。批次通过Globalstar服务验收会验证一个近半批次的总线/系统接口，并降低剩余工作交付的不确定性；若出现共因平台缺陷或重复返修，固定价成本会侵蚀项目利润。Globalstar对MDA的延期索赔属于上游整星责任；Rocket Lab自己的MDA合同也单独允许MDA提出延期赔偿，同时Rocket Lab可向部分供应商追偿。上游争议只有在Rocket Lab实际被追偿/扣款、或Rocket Lab责任被释放时才改变其净责任；即便供应商最终偿付，先行现金扣留也可能造成阶段性缺口。

- C1 / LONG / MIDDLE: Globalstar或MDA公开确认首批8个由Rocket Lab制造的平台已完成调试并通过面向服务的验收/进入Globalstar运行服务，而不是仅报告在轨、接触、发电或仍在commissioning。
  - Reference: Rocket Lab在2026-08-16报告首批8个平台已入轨、全部接触正常并发电，调试刚开始；Globalstar披露其中首批此前在4月交付、经过维修后7月重新交付。C1与公司SEC披露指出项目收入按成本投入进度确认，硬件完成、客户验收、开票及回款并不相同。截至2026-10-12，可用资料没有确立这8颗已经完成服务验收。
  - Boundary: 正式确认8个平台已从调试进入客户认可的运行服务，是首批近半数(8/17)合同单位跨过目前未完成的验收状态；该信号足以提高既有批次交付/整星集成可靠性预期，并可能推进对应结算。仅再公布入轨、开始调试或设备状态正常不够，也不推断17颗全验收、索赔结清或全额回款。
- C2 / LONG / MIDDLE: Rocket Lab与MDA公开签署有约束力的结算/合同修改，明确释放Rocket Lab在原17平台合同下的延期赔偿责任及相关扣款/付款争议，并确认没有仍被扣留的对应合同款项。
  - Reference: Globalstar 2026Q2披露其对MDA享有交付延迟赔偿权，且仍在讨论；Rocket Lab 2026Q2 10-Q另披露MDA作为其客户可能依合同索赔，同时Rocket Lab可对导致延迟的部分供应商追偿。两份文件没有披露与Rocket Lab有关的最终净金额、已支付赔偿或双方放弃权利。
  - Boundary: 只有MDA-Rocket Lab之间可执行的全责释放/抵扣结清才把Rocket Lab一侧风险从未定变为已解除；Globalstar与MDA上游单独和解、Rocket Lab平台入轨、或赔偿权仍存在的改期均不消除该风险。无需等公司季度利润或现金流确认。
- C3 / SHORT / MIDDLE: MDA或Rocket Lab公开指出一个新确认的Rocket Lab平台/总线共因缺陷，导致原17平台中多颗需要再次返修、改造或重新资格，或因此拒绝首批8颗的服务验收；这必须超出已知的首批维修并明确落在Rocket Lab供货平台责任，而非仅载荷、运输或地面环节。
  - Reference: 已知首批有4月交付后维修、7月重新交付；截至8月16日，已入轨的8颗初始健康状态正常但刚开始commissioning，故这次已披露维修本身不是未来新增损失，平台故障原因也未被公开确立。固定价总线合同的新增返工、再测试或重资格可能由供应方承担，而MDA仍负责最终整星/载荷集成。
  - Boundary: 一项新披露的共因总线问题影响多颗在制/在轨单位或使首批8颗被拒绝验收，已越过正常commissioning和已修复初始交付的基线，并将成本或时间风险扩展到一个批次；一颗卫星普通异常、未归因于Rocket Lab的平台之外故障、或重述已知维修不够。
- C4 / SHORT / MIDDLE: MDA或Rocket Lab公开披露，在原17平台合同下Rocket Lab已被要求支付、已被扣留或最终承担不少于1,000万美元的约定损害赔偿/责任扣款；若披露的是最终净损失，则必须说明已扣除可执行且近期可收取的供应商追偿。
  - Reference: Rocket Lab 2026Q2 Form 10-Q披露其17平台MDA合同部分交付日期较原计划晚，MDA可能提出约定损害赔偿，Rocket Lab也可向部分供应商追偿；公司称净赔偿金额仍无法确定。Globalstar另有针对MDA的上游索赔权，但并未披露该责任已传给Rocket Lab。现行合同名义价值为1.43亿美元，不等于剩余可确认收入。
  - Boundary: 不少于1,000万美元的实际扣留、到期支付或扣除可执行追偿后的最终损失，相当于原名义合同约7%，且约为2026Q2 Space Systems整段季度毛利的15%（分部含多个Unit，仅作量级参照）；这种规模足以明显改变固定价项目的利润/现金风险。小额未定索赔、Globalstar单独向MDA索赔、尚未实际扣款的讨论，或8颗入轨，均未跨过边界。若达到该金额但供应商已同时现金偿付、没有现金时差或净损失，则此SHORT条件不满足。

## 多批次航天器制造的接口验证与合格交付节拍

Rocket Lab同时履行MDA/Globalstar商业Lightning、SDA T2TL-Beta与TRKT3两批各18颗，并新增SSC GEO及SB-AMTI/Flatellite整包任务；这些项目分享工艺、工程和测试资源，但轨道、载荷和验收要求并不相同。T2的链路不是单一光终端：Rocket Lab统筹CesiumAstro的Vireo射频载荷、SEAKR的SDR/加密系统、Collins波形、Redwire天线/射频硬件、Parsons NOVA地面系统以及Mynaric光终端；TRKT3另含Phoenix红外载荷与StarLite保护传感器。目标系统的射频/载荷、无线电与波形、天线/光链路、平台和地面运行须联合验证，某个单件合格不等于端到端功能可验收。固定价批量项目中，已验证设计及测试程序复用可减少重复非经常工程和多轮测试并提高合格输出；共用设计缺陷或接口重开则把返工扩散到一批卫星，消耗共享工程/测试时间。2026Q2披露只给Space Systems合计收入、毛利，且长期资产、设施和设备跨业务共用，不可拆成这些项目利润或用厂房面积推断产能。SDA制造、合同履约和收入确认可以先于在轨部署；TRKT3 FY2029计划与2027—2028制造/交付观察期分开，不能等发射才确认制造节拍。

- C1 / LONG / MIDDLE: Rocket Lab、SDA/客户或直接承担接口的供应商公开确认：某个曾约束具名批次的载荷—平台—无线电/天线—地面系统接口已通过系统级联合验证，并获客户作为生产配置接受；该同一验证流程或配置可直接复用于该批其余卫星，而非只通过一个器件的实验室测试。若披露指出它解除原有关键测试瓶颈并使批次验收恢复或快于最近已公布计划，亦满足该事实边界。
  - Reference: 截止2026-10-12，MDA/Globalstar既有Lightning合同为17个平台，首批8颗已在2026年8月发射入轨；这不是17颗全部完成客户验收。T2TL-Beta为18颗，2025-07完成CDR并进入全面生产，合同公开为$515m firm-fixed-price；TRKT3为18颗，2026-05通过SRR，2029年计划发射/交付，仍处于与T2不同的系统开发阶段。T2的子系统供应链和TRKT3的Phoenix/StarLite各有接口，不可互相代用。SSC新GEO明确两颗、Flatellite是含Neutron运输和运营接口的整包任务，均增加异质工程负荷。可用资料未给出各项目已验收批量节拍、测试线吞吐或项目级毛利；“未披露”不表示产能为零。公司披露的Space Systems分部数及共用设施不能分摊到单项目。T3计划发射时间晚于制造履约窗口，验收/制造消息按其自己的节点比较。
  - Boundary: 最早充分边界是一个真实系统级接口从待验证/阻塞转为客户接受且可在多个剩余单元复用，明确减少批次重复集成或复验工作；不必等18颗全数发射、任务运营或收入全部确认。普通设计审查、单个终端台架测试、测试线挂牌投用、只称“按计划推进”或孤立的一颗验收均不足以证明合格产出可复制。
- C2 / SHORT / MIDDLE: Rocket Lab、项目客户/主承包商或可信的直接参与方确认，T2/T3或其他具名批次的共用设计、载荷/无线电/地面接口在集成试验中失败或被改动，导致同一生产配置需为整批重开系统级资格，或必须对一批中的多个卫星返工/重复联合验证，并因此将已公布的验收、交付或下一关键测试节点推后。单颗可局部修复且不改变该批测试/验收计划的异常不构成此Condition。
  - Reference: 截止2026-10-12，T2的CDR已通过、T3的SRR已通过，二者各18颗且处于不同后续资格路径；T2当前公开的是2027发射前交付安排，T3公开的制造/交付计划与FY2029发射窗口分开。系统工程包括多个相互依赖的载荷、无线电、天线/光链路、平台与地面系统。公司未公开项目级一次通过率、返工成本和稳定验收节拍，因此不从财报或Space Systems分部毛利推算项目损失；公司确认分部设施与设备有共用。
  - Boundary: 一项共用接口/设计导致批次层面的复验或多星返工，并改变当前公开的该项目验收/交付进度，即足以说明原有合格节拍受到实质扰动；无需等最终违约、所有单星均失败或合并财报确认损失。局部单件问题、无批次影响的常规调试以及与Rocket Lab供货无直接关系的其他主承包商故障不够。若同一变更另有客户付费补偿，应在成本风险Policy中判断其缓冲，不因此消除技术节拍的负面信息。

## 卫星批量合同的工程范围与成本风险分担

合同形式决定规模化能否变成项目毛利。T2是公开的firm-fixed-price卫星项目；Rocket Lab的10-Q说明，长期航天器合同可按成本投入进度确认收入，估计完工成本修订、交付延迟或合同受阻会改变跨期盈利，预计合同总亏损在首次估计时确认。重复设计和量产可摊薄非经常工程、提高固定制造费用吸收；但客户可通过集中采购压低重复批次报价，亦可要求把新的工程、载荷适配、复验或支持范围继续包在原固定价里。后一情形即使合同额/数量提高，也可能把成本增量留在供应商；有明确的变更单、追加价或成本补偿才会转移新范围风险。T3公布的公司$816m与SDA的$805m潜在值口径尚未调节，且可能含基础/选项差异，不可当单星价格或毛利基线；GEO、Flatellite和商业项目也只有在具体条款公开时才按其实际合同类型判断。公司Q2 Space Systems合计毛利及Q3综合毛利指导不是这些项目的损益，不作分摊或财报催化。

- C1 / LONG / MIDDLE: 具名卫星制造合同的客户/采购方正式批准一项新增的批次级设计、集成或复验范围，并以独立定价的变更单或可报销成本条款支付该新增工作，或将该增量工作明确移出原固定价并由客户承担。披露必须指向新增工程/测试范围的实际资金或成本风险归属，而不只是提高合同上限、增加尚未行使的选项或宣布更多卫星。
  - Reference: 截止日可确认T2的18颗合同为$515m firm-fixed price（公司2024年披露含base、激励与选项），T2于2025年完成CDR；一般10-Q口径为固定价航天器建造可按成本投入进度确认，完工成本上调会压低全项目毛利，但没有T2/T3/GEO/Flatellite的公开项目级成本或毛利桥。TRKT3也是18颗；公司公布潜在合同值$816m，而SDA另公布$805m且基础/选项拆分未调节，故不将这个差额、单星均值或可能的选项当作同口径利润锚。非T2合同只在公告说明其价格类型后适用。标准化节省可能被客户议价取得，批量增加本身不是改善毛利的当前预期。
  - Boundary: 已签的独立变更单/可报销约定直接覆盖新增工程或跨单位复验，而不是只扩大名义上限；在固定价原范围外为增量工作建立资金/风险承担，即能降低未补偿成本风险，足以构成LONG，不需要等该期收入或整项目利润在财报中确认。若价格只增加而新增成本责任仍由Rocket Lab承担，或补偿只是未经行使的上限，则未越界。
- C2 / SHORT / MIDDLE: 具名项目客户/采购方正式增加或改变适用于多个卫星/全批共同设计的接口、软件、载荷集成、资格试验或工程支持要求，但公布的合同修订仍把该工作留在原固定价/固定费内、没有相应补偿，或明确否决供应商的变更单/成本回收；此外，已公布的同口径重复批次价格下调而新增项目级工程义务仍留给Rocket Lab且无独立NRE付款，也满足此事实条件。
  - Reference: T2已是18颗firm-fixed-price合同，CDR已通过；公开资料未提供本批工程工时、项目成本余额和批次验收/单价拆分。TRKT3有另一组18颗及其自己的资格路径，但披露的潜在合同价值口径存在未调节差异，不能套用T2单星基准；其他新GEO和Flatellite的项目级范围/成本也不得从合同总值推算。公司2026Q2披露的Space Systems业务增长、毛利和合并营运资本均不是本Unit或单项目结果。
  - Boundary: 最低充分边界是一项公开、正式的项目变更把新或持续的多单位工程/资格责任留在原有固定价而不加价/成本补偿，或明确记录同等范围下单价下降而NRE仍由公司承担；一项批次级义务即可压缩该项目全期毛利预期，不必等待亏损合同、整批延期或财报报出实际超支。例行设计推进、报价尚未中标或更大采购量但价格/工作责任未知，都不够。

## 卫星制造合同付款节点与项目占款时点

单项目的成本投入、验收/开票权利、客户实际付款和收入确认并非一个日期。Rocket Lab 2026Q2 10-Q说明长期合同可以按履约进度确认收入，成本投入法按已发生成本相对预计完工总成本衡量进度；合同应收、未开票合同资产与客户预收合同负债分别呈现时间差。因此制造收入可能先于发射，合同预付款能降低项目在材料、工程和集成阶段的自筹占用，但不等同已完成履约、项目毛利改善或全公司可用现金。相反，批量验收/开票里程碑推迟会延长已投入成本到收款之间的间隔。只研究已具名项目自身付款条款；客户股权/融资工具、Rocket Lab融资以及供应链垫资传递属于公司现金专题，不从本条件外推。

- C1 / LONG / MIDDLE: 某具名Rocket Lab卫星制造合同的正式客户修订，增加一笔在长交期采购/生产启动或设计/制造阶段即可到期的实质性客户预付款/进度付款，并公开说明它取代或提前了原先在批次验收、交付或更晚阶段才应付的款项。付款权利直接对应正在履约的同一批卫星，不是另一个融资工具或未行使合同选项。
  - Reference: 截止2026Q2，Rocket Lab合并报表列示合同资产$94.245m及合同负债$351.193m，半年内新增的客户预收/已开票净额$206.284m还混有并购承接余额；这些均不是单一卫星项目余额。SEC披露收入确认、合同开票和收款因里程碑而错时，但T2/T3、MDA-Lightning、GEO与Flatellite的个别付款计划未在本批材料中给出。T2有18颗fixed-price履约工作，T3最终制造交付计划与FY2029发射时段不同；制造履约/成本支出可早于部署。项目级旧付款时点是未披露而非零或不存在。
  - Boundary: 以同一具名项目明示的旧新合同付款节点比较；一笔本属该批生产/工程、在大额制造支出之前到期的预付款或阶段款，从验收后移到生产/设计阶段，即减少项目已投入成本的未回收期间，足以支持LONG现金时点修订。仅提高合同总额、宣布授标或形成可开票应收但仍无付款时点变化不够；也不据此宣称项目毛利增加。
- C2 / SHORT / MIDDLE: 客户/采购方正式将具名卫星项目中一笔原在设计、长交期采购、制造进度或阶段验收时支付的实质性款项，推迟到整批系统验收、最终交付或更后续里程碑，或扩大验收保留款并延长到期日，从而要求Rocket Lab先承担多单元工程/制造成本。
  - Reference: 项目层面的预付款和账期不是公开常规基线：公司2026Q2汇总合同负债含收购承接及不同业务，不能推导各航天器合同付款来源或现金覆盖率。长期项目可按投入法确认收入而付款按合同里程碑另行执行；T3 FY2029发射安排不能视作T3制造项目要等到2029才取得收入或收款。只有同一项目公开的既有和新节点可以校准资金回收时间。
  - Boundary: 一项正式修订把原先较早的项目款项推迟到批次制造完成/系统验收以后，或新增覆盖多单元成本的保留款，即使合同总额和项目订单不变，也延长该项目的现金占用；不需等合并现金流披露或客户违约。若仅账单日期移动但约定现金到期时间与实际承担成本顺序不变，或未说明该款项属于同一项目，则不足。

## ESCAPADE双航天器的深空机动与火星轨道运行能力

Rocket Lab为ESCAPADE设计、制造两艘高Δv Explorer级深空航天器，并提供调试运行；Blue与Gold于2026年2月已在日地L2完成调试，NASA报告两星处于运行状态，已完成早期轨道修正。此前2025年12月一星在轨道修正时出现低推力、随后延迟；NASA于2026年1月报告已完成该星第二次修正，但公开资料未给出故障归因，因此它是已恢复的运行背景而不是已确认的Rocket Lab设计故障。NASA计划于2026年11月进行地球引力助推/跨火星注入，2027年9月到达火星并进入捕获轨道，之后降低并同步两星轨道，目标是在2028年进入科学运行轨道；这些日期与状态均为计划，不是已实现结果。实际跨火星机动首先验证高Δv推进、导航和深空长航时控制；火星轨道插入再验证长程飞行及目标轨道捕获；双星同步则增加轨道协调、任务指令与双平台持续运行的证据。由于本次只有两艘航天器，某个关键系统故障对后续资格与保障成本的信号强，但不能外推为公司全部平台的故障率。可靠运行可降低未来深空项目的资格成本及客户风险评估，不等于新增合同或收入。Blue Origin New Glenn负责发射，UC Berkeley领导科学运行，NASA及合作方负责仪器/科学；平台健康、科学数据结果和外部运输表现必须分开归因。

- C1 / LONG / MIDDLE: 公开任务更新确认Blue或Gold至少一艘实际完成计划中的地球引力助推/跨火星注入，且完成后仍可控并进入面向火星的转移轨迹。仅宣布已排期、准备点火或更新预计日期不算。
  - Reference: 截至本任务cutoff，两星已在L2完成调试并执行早期轨道修正；NASA仍将2026年11月地球助推/跨火星注入列为计划，尚无该阶段的实际完成记录。NASA于2025年12月披露一星早期轨道修正低推力、于2026年1月确认后续修正完成，但没有公开故障归属。
  - Boundary: 至少一艘航天器真实完成跨火星注入并继续保持计划轨迹，已将任务从地球附近运行推进至深空转移，直接验证高Δv推进与深空导航/控制，是从计划走向资格证据的最早有意义变化。对单艘平台能力形成判断不必等同日有新授标，也不需等到全程科学结果；两星都成功会加强重复性证据，但不是该单星能力条件的必要要件。
- C2 / LONG / MIDDLE: 任务方确认Blue或Gold实际到达火星并完成火星轨道插入、进入预定捕获轨道，且航天器仍具备任务控制能力；只报道计划到达或接近火星不算。
  - Reference: NASA目前计划于2027年9月到达；官方任务路线包括每艘航天器进行火星轨道插入、先进入大型捕获轨道，再逐步调整轨道。跨火星巡航和火星捕获均尚未完成。
  - Boundary: 至少一艘平台在长航程后真实进入火星捕获轨道，第一次证明航天器能够完成深空巡航至目标行星轨道的关键转换；与完成TMI相比，这是新的独立环境与任务阶段证据。无需等到整段科学任务或具体科学发现，也不能以科学数据质量替代航天器健康。
- C3 / LONG / MIDDLE: NASA/UC Berkeley确认Blue与Gold均完成计划中的火星轨道降低和协调/同步，转入任务设计的近匹配或协调科学轨道，且两星仍正常执行指令。
  - Reference: NASA现有计划是在到达后先降低并协调两星轨道，避开2027年末太阳合期间的通信中断风险，随后在2028年中前后使两星进入近匹配科学轨道；科学运行目标为2028年春/年内。两星当前尚未到达火星。
  - Boundary: 实际双星轨道协调状态本身即跨过从两艘独立可控航天器到可配合执行任务的门槛，证明Rocket Lab设计平台支持了较复杂的多航天器深空运行。达到计划轨道即可成立，不要求等完全部科学任务或证明某一科学发现。
- C4 / SHORT / MIDDLE: NASA、UC Berkeley、Rocket Lab或任务运营方报告推进、供电、姿态/导航、热控、通信、飞行软件等航天器平台系统发生故障，导致Blue或Gold错过/无法继续一项关键跨火星或火星轨道阶段，且公开状态显示无法通过正常修正恢复该阶段；若事件被归因于New Glenn、地面指令、外部运输或单独科学仪器，则不属于本Condition。
  - Reference: 双星各自承载深空运行风险；2025年末曾报告一星低推力和修正延后，随后第二次修正成功，NASA当时称两星除此之外运行正常且无长期影响，但没有公布原因。故单次短时异常或已恢复的延迟不是新的平台故障基线。
  - Boundary: 一艘平台因已披露的平台系统问题失去计划关键阶段且不存在可行任务恢复路径，已足以直接提高Rocket Lab设计/保障责任、客户对深空平台的风险评估以及修复或重新资格投入预期；不必等待合同取消、财务结果或另一份故障确认。故障只局限于一星时，不外推为所有型号失效；若公开材料显示设计共因，才相应扩大复用风险。

## Lightning-GEO高轨资格、客户验收与跨任务复用

Rocket Lab于2026年5月宣布获Space Systems Command（SSC）9000万美元合同，为两颗GEO空间域感知卫星提供设计、制造、集成及commissioning后的最长五年在轨运行；卫星搭载其Heimdall光学载荷，并由Lightning总线改制，明确需适配GEO热、辐射、推进及定点保持要求。这是公司首个GEO卫星生产项目；此前Heimdall载荷原型项目不等于整星总线已经完成GEO在轨资格。Lightning在LEO项目的生产和设计经验可复用部分组件、供应链与工程流程，但高轨热/辐射寿命、推进剂和站位维持仍需要新设计/测试，不能把LEO资格视作GEO资格。2026年8月，Viasat公开选择Rocket Lab为一颗PTS-G通信卫星提供GEO版Lightning总线，说明已有SSC空间域感知以外的另一类客户/任务采用；该项目由Viasat作主承包，双频X/Ka载荷所需的高功率架构与Heimdall光学载荷不同，Rocket Lab被选为平台总线供应方；不能据此算成Rocket Lab的SDA项目或其长期卫星/网络运营收入。公开资料未量化LEO与GEO间可复用模块比例、GEO辐射寿命门槛或单星工程成本，不能以Lightning同名推定系统级资格已经转移。公司Q2资料另概述三颗GEO卫星、跨两份合同、总值超过1.6亿美元，但未给出各颗/合同的金额与成本分配；不要按低轨平均单价外推GEO利润。少量高要求平台的非经常工程、资格测试、制造整合与多年运行占用的资源可能大于其数量占比；是否成功复用、客户验收及运营责任边界才是估值风险所在。

- C1 / LONG / MIDDLE: SSC或任务执行方确认至少一颗Rocket Lab Lightning-GEO卫星完成实际GEO轨道commissioning，平台在热控、供电、姿态/推进和定点保持等总线功能正常，并获客户验收或开始执行Heimdall空间域感知任务。
  - Reference: 当前公开基线是SSC两颗、9000万美元的GEO合同，Lightning已声明为适配热、辐射、推进和定点保持的配置，Rocket Lab承担设计制造、Heimdall集成和commissioning后最长五年在轨运营；公开资料未建立这些新型总线已完成GEO在轨验收。此前两颗Heimdall载荷原型不是Lightning-GEO平台的飞行资格。Viasat在2026年8月已公开另选Rocket Lab提供一颗PTS-G GEO总线，但不证明该总线已飞行或被客户验收。
  - Boundary: 至少一颗平台实际进入GEO并由客户验收开始预定运行，已把热/辐射环境适配、推进和长期轨道保持从设计目标转为真实在轨证据，是本项目最早有意义的高轨资格跨越。无需等两颗都完成或五年运营期结束；完整五年是合约范围，不是获得资格的必要等待。只有传感器数据好而总线健康未知，或只有上线/发射新闻，不足以成立。
- C2 / LONG / MIDDLE: 在当前已公开的SSC两颗Heimdall卫星及Viasat一颗PTS-G卫星之外，另一具名客户/独立项目给Rocket Lab授予或签署有资金支持的GEO平台生产工作，明确选用Lightning-GEO或相同平台的具体GEO改型；不包括未落实的需求意向、框架入围、单独载荷原型或已知合同内的第二份报道。
  - Reference: Rocket Lab于2026年5月公布SSC两颗Heimdall GEO卫星，8月Viasat公布其选用Rocket Lab为PTS-G一颗GEO卫星提供总线；Rocket Lab Q2资料另将GEO组合概述为三颗/两份合同，但未公开将每一颗与客户/合同逐项对表。由此可确认有不同任务的采用，但运营资格仍未完成，也不能把公司总值拆成单星经济性。
  - Boundary: 一份新增且有资金的独立生产选型足以把当前两类已知任务扩展到新的任务/客户，说明GEO适配设计的采用面扩大；不需将它定义为大规模星座，也无需先等上星或五年服务完结。门槛仅是实际平台总线被选入具体生产工作，而非抽象的GEO采购计划或仅获入围资格。
- C3 / SHORT / MIDDLE: Rocket Lab或客户披露Lightning-GEO总线在必要热/辐射/推进/定点保持等环境资格或在轨commissioning中未能达到任务要求，并因此被要求实质性重新设计/重复资格测试、显著改期，或客户拒绝/暂停该卫星总线验收；仅Heimdall或Viasat载荷单件故障、New Glenn/其他运载器问题或可在例行范围内修正的小问题不算。
  - Reference: 当前平台仍处于改型生产与客户任务执行路径；SSC的范围包括整星、Heimdall集成和多年运行，Viasat是另一任务但公布使用GEO版Lightning总线。GEO配置明确加入热、辐射、推进和定点保持要求，且行业低轨Lightning交付不证明这些新增条件已经通过。
  - Boundary: 一次影响总线本体并造成实质重新资格、重新设计或客户验收/运行延误的公开结果，已足以显示最关键的GEO复用假设仍需额外固定工程和测试资源，并提高当前两类客户路径的履约风险；不必等合同取消或另一个任务失败。普通测试调整或有效载荷单独问题不改变本Condition，因为它不能说明总线环境资格失败。

## 低温液氧储存转移与轨道推进剂库成熟度

LOXSAT是Eta Space在NASA Tipping Point支持下开展的微重力低温流体管理示范；Rocket Lab提供Photon航天器平台和Electron发射，并公开将其定位为自有Cryo-Dock低地球轨道推进剂库设计的输入。其关键价值不是一次NASA示范合同本身，而是液氧能否在轨受控储存、管理压力并实际转移：若可行，会降低低温推进剂库及相关平台/任务的技术不确定性，支持Rocket Lab未来提供此类平台和任务能力的可能性。低温液氧的热控、蒸发、压力和接口要求与肼、氙推进剂或一般机器人维修不同，不能把一种流体试验外推为通用补给资格。成功也不等于已有客户、商业推进剂库或重复运营收入。

- C1 / LONG / MIDDLE: NASA或Eta Space公开LOXSAT在微重力飞行试验中完成受控液氧储存并实际执行液氧转移，且报告满足该演示的核心储存/压力管理与转移目标。
  - Reference: 截至2026-10-12，NASA称LOXSAT载荷已集成到Rocket Lab Photon，计划进行约九个月、覆盖11项低温流体管理技术的LEO示范，原公布发射窗口为不早于2026-07-17；NASA TechPort于2026-08-07仍列为Active Technology Project。Rocket Lab官方任务页仍列2026年发射、具体时间TBC，并称Cryo-Dock低温推进剂库的目标运行年份为2030；本次截止输入未确认已完成飞行试验。
  - Boundary: 有受控液氧储存和真实的在轨液氧转移结果，已验证推进剂库的核心流体功能，足以提高Cryo-Dock相关技术路径的可行性；仅发射、载荷开机、返回一般遥测或完成不涉及转移的个别技术试验尚不足。无需等11项技术全部完成、商业客户签约或收入确认。
- C2 / SHORT / MIDDLE: NASA或Eta Space报告LOXSAT未能完成可用的微重力液氧转移，或任务在核心储存/转移试验前终止，因而没有形成可用的在轨低温流体管理演示结果。
  - Reference: 基线仍是NASA支持的九个月、11项技术计划，载荷已集成而非已验证；Rocket Lab公开的Cryo-Dock目标依赖在轨低温流体管理能力，但目前没有本轮材料证明该技术已运行或已有商业库运营合同。
  - Boundary: 正式结果表明核心液氧储存或转移无法实现，或任务在转移试验前终止，直接削弱低温推进剂库所需的关键技术路径。单纯改期、尚未发布结果或某个非核心传感/辅助技术表现不佳，不等同核心试验失败。

## 机器人臂与专用机构从示范走向多任务采用

Rocket Lab Robotics（原Motiv）把多自由度机器人臂、执行器、驱动电子和精密机构纳入组件产品线；过去的火星Perseverance/CADRE经验和2026年NASA任务显示其工程能力已不是未验证样机。当前最具辨识度的在轨臂位置是NASA的Fly Foundational Robots (FFR)：Rocket Lab供臂，Astro Digital负责飞行试验平台，NASA执行任务软件，计划在2027年末展示模块移动与工具操作。2026年10月NASA又选出三个可操纵载荷团队，计划在2028年初与FFR平台会合；这是机器人任务生态扩展，不是Rocket Lab对三个载荷的合同。EMILIA-3D则由Rocket Lab公开称提供专用单轴仪器云台，其相机扫描机制与FFR多功能臂不是同一产品。多功能臂可完成抓取、模块更换和外部操作，但软件、对接/任务接口、平台及飞行测试责任彼此分开且定制工程昂贵；对相机扫描等窄任务，专用云台/机构可能以更低复杂度取得采用。新增具名飞行任务的产品选择或一次成功的在轨模块操作可分别提升工程复用与后续采购可信度，但单次示范不等于成熟维修服务，公共平台运作/客载操作收入也不自动属于Rocket Lab。

- C1 / LONG / MIDDLE: FFR在轨报告Rocket Lab Robotics供货的机械臂成功执行计划中的模块移动/安装操作，完成至少一次任务所需的模块级机械操作，而非仅将机器人臂送入轨道或运行控制软件。
  - Reference: NASA当前公布FFR将于2027年末发射，在LEO部署和操作商业机器人臂；计划任务包括在轨搬运/重新定位Orbital Replacement Unit，NASA作为首位Guest Roboticist另行部署并执行软件任务。Rocket Lab供臂、Astro Digital承担飞行测试、NASA执行软件是不同角色。NASA于2026-10-02选出三个载荷团队、每队最高50万美元以开发飞行载荷，计划2028年初搭乘将与FFR会合的轨道航天器演示；该计划尚未构成已执行的第三方操作。
  - Boundary: 公开确认一次计划中的真实在轨模块操作完成，就把当前“已采购但待飞的示范计划”转为机械臂通过关键微重力操作验证，足以提升机械臂在后续维修/装配任务中的资格可信度。不要求三支载荷全部成功、完成商业维修、NASA软件运行所有任务或确认新增采购；单纯发射、展开机械臂或代码测试不够。
- C2 / LONG / MIDDLE: 一个不同于已披露FFR、NASA机器人载荷挑战和EMILIA-3D安排的新具名飞行任务，以有资金支持的采购/合同选用Rocket Lab Robotics的机器人臂、执行器/驱动电子或专用精密机构作为任务硬件。
  - Reference: 截至2026-10-12，FFR机器人臂已有NASA示范采购但在轨验证仍是计划；NASA三支机器人操纵载荷团队取得的是载荷开发奖励/潜在在轨演示机会，并非Rocket Lab的硬件订单。Rocket Lab公开称为NASA所选EMILIA-3D月面科学载荷开发单轴云台；NASA称该载荷之后才会分配至具体CLPS送月任务。既有火星和CADRE履历支持产品能力，但并不等于当前在轨服务或外部新任务的重复采购。
  - Boundary: 一个新的、具名且有资金支持的任务对Rocket Lab某种机器人/机构产品作出明确飞行硬件选择，已足以显示能力可在当前FFR与EMILIA-3D之外被另一个项目采用；无需等硬件发射、重复订单或商业维修市场成熟。一般能力宣传、NASA挑战奖励给其他载荷方、现有FFR/EMILIA-3D排程推进及未授标的伙伴讨论不够。
- C3 / SHORT / MIDDLE: NASA或FFR飞行试验方取消/移除Rocket Lab Robotics供货的机械臂在FFR的在轨模块操作任务，或报告该机械臂未能完成核心模块操作且结束本次验证，导致当前计划的在轨机器人演示不能实现。
  - Reference: 当前具名在轨机械臂任务是计划于2027年末开展的FFR测试，NASA三支付费载荷团队的预计飞行又依赖FFR会合平台；机械臂关键操作尚未在该任务中实际完成。Rocket Lab在其他行星任务/机构产品的履历仍存在，因此风险限于FFR在轨资格和机器人臂的后续服务采用路径，不代表整个组件产品线失效。
  - Boundary: 正式终止/移除硬件或核心模块操作失败并结束该次验证，会直接取消当前最重要的在轨臂资格路径和其后的已选载荷操作机会。Astro Digital发射窗口普通改期、FFR日期从2027年末推后、单个访客载荷不参试，或仍有可恢复的测试异常，不足以触发SHORT。

## 卫星在轨服务采购与整体换新的业主选择

业主比较的是保留仍可工作的载荷/服务并支付在轨维护成本，还是购置并发射替代星。GEO通信卫星若只是推进剂耗尽、有效载荷仍有价值，服务可延长运营收入；Northrop Grumman报告Intelsat的MEV-1和MEV-2分别签订五年寿命延长服务，并称五年延寿可推迟最高约5亿美元的新星支出，证明高价值GEO存在真实付费方。相反，低成本、快速更新的LEO资产可能把新能力、低价批量替换置于复杂维修之前，服务市场不随卫星数量线性增长。服务方案还新添服务飞行器、机械臂、推进剂/物流及运行责任；延寿能减少同等覆盖的换星需求，也会创造服务平台和物流任务。Rocket Lab目前有机器人产品、Photon和LOXSAT/Cryo-Dock示范暴露，但没有已确认的在轨商业维修运营角色，不能把ClearSpace、Northrop、Starfish或NASA项目的运营收入归给Rocket Lab。ESA Phoenix正在成熟可适配既有GEO星的服务飞行器，SSC挑战寻求LEO/GEO重复补给和维护，NASA SSPICY与RSGS则是不同类型的技术示范；它们不等同于业主已经购买常态服务。未来若业主为新星纳入标准接口，流体种类、机器人任务板、对接接口和操作责任仍需分别定义，LOXSAT液氧试验不能证明其他推进剂或机器人接口兼容。

- C1 / LONG / MIDDLE: 卫星所有者或公共采购者为一颗仍具任务能力的具名卫星授出/签订实际在轨补给、检查、维修或延寿任务，并公开确认Rocket Lab或Rocket Lab Robotics承担服务航天器、平台、机器人硬件或任务运行中的具名供货/运营角色。
  - Reference: Northrop/Intelsat已有MEV-1及MEV-2的付费GEO寿命延长实例，但该服务由Northrop提供。ESA于2026-09-22签署的是ClearSpace Phoenix的设计与成熟合同，目标为发展欧洲重复商用服务，不是已披露的卫星业主运营订单。SSC于2026-05-20宣布In-Domain Orbital Logistics Challenge拟采取多阶段公开征集；NASA SSPICY已于2026-10-01发射，但任务是检查最多四个失效LEO物体且不接触/对接；NASA支持的DARPA/Northrop RSGS于2026-07-21发射，仍是机器人服务示范。所给截止材料未确认Rocket Lab获得实际在轨服务任务或运营责任。
  - Boundary: 一项针对具名、仍具使用价值资产的已资助运营服务合同，并明确Rocket Lab在该任务中的硬件/平台/操作职责，即从技术示范/采购探索转为客户为服务付费且目标有角色。单个合同足以形成增量，不等第二颗卫星、任务飞行完成、服务收入确认或成熟市场；研究合同、概念、挑战入围和未具名接口计划不足。
- C2 / LONG / MIDDLE: 卫星所有者或公共任务采购者在有资金支持的卫星批次/舰队设计或采购规范中，正式要求跨供应商可用的补给、模块更换或机器人维护接口，并明确未来的资产运营者/付费者及相应服务使用路径。
  - Reference: 当前已证实的有针对性设计仍主要是示范或单个服务系统：NASA FFR公布四个任务接口和在轨模块操作演示；ESA Phoenix采用服务飞行器适配既有、原本未为维修设计的GEO卫星。SSC挑战把流体兼容、储存、接口与全寿命成本列为待成熟方案，尚非已获批的舰队设计规范。所给材料没有确认某个业主已把供应商中立的服务/补给接口写进受资助的卫星采购批次。
  - Boundary: 正式采购/设计承诺把可识别、可互操作的服务接口纳入一类拟建卫星，并说明谁将为维护/补给使用或付费，即使运营服务商尚未选定，也已把原型用接口转为可重复服务资产的设计要求，降低未来逐星定制门槛。单个非约束性研究、技术挑战、供应商自述标准或只测试一个演示平台的接口不够；不要求实际维修订单或全部舰队入轨。
- C3 / SHORT / MIDDLE: 一名业主取消此前已资助、针对仍可工作的高价值GEO资产的服务/寿命延长采购，并将该资产的更新需求改为由Rocket Lab以外供应商承接的整体替换卫星采购。
  - Reference: 已付费GEO延寿实例说明高价值资产可以购买服务，但新一代维修/补给仍是有限市场。对于低成本、快速更新的LEO星，按期换新本来就是已知替代路线，不是本政策的新增负面事件；服务和替换各自对Rocket Lab平台、机器人及发射业务可能不同向。
  - Boundary: 只有此前已具资金的高价值GEO服务路径被业主实际撤销，且同一资产改由非Rocket Lab供应商整体换新，才表明最可能服务化的客户选择取消了该产品机会。一般研究、技术延期、LEO例行换代、尚未决定的替代方案或由Rocket Lab中标的新造星，不足以单独支持该SHORT。

## Mynaric光终端合格供给、批次验收与外部客户分配

Rocket Lab于2026-04-14完成Mynaric收购；Rocket Lab在2026Q2申报的收购后Mynaric相关收入为1,319.5万美元、营业亏损为1,324.5万美元。这是单季并表贡献，不能当成持续产品毛利或证明亏损全由制造返工造成，但说明合格产出和订单履约对本产品经营有分量，且当前没有拆出良率、返工率或客户毛利。Mynaric于2025-06称累计交付超过100台CONDOR Mk3终端并制造超过150个光学头，二者分母不同；一套完整flight set已交付，证明业务并非从样机起步，却不替代2026年收购后的当前批次验收。Rocket Lab为SDA T2TL-Beta的约1,500万美元终端订单原定2025—2026年交付，现已因收购内部化；Rocket Lab还称Mynaric终端用于其T2/T3整星合同。内部供货可减少外购、保住整星关键路径，但不得记成新增合并外销。2026-09管理重组把完成既有backlog与扩产列为职责，是计划，不是有效供给已恢复。完整终端的齐套、系统测试与客户验收把原料/光学头/在制品转成可交付产品，能减少返工和库存占用、支持客户收款与留存；一次完整客户批次比厂房面积或光学头数量更接近现金与交期。外部客户的产品销售及未来续批与内部项目的采购替代经济不同。更高有效供给能提高固定成本吸收，但新产能若无客户合格订单，也可能只增加固定成本；外部客户改由竞争性第二来源主供则可在订单需求不变时降低Mynaric的供货份额。

- C1 / LONG / MIDDLE: Mynaric、Rocket Lab或具名客户/主承包商公开确认，一套完整CONDOR Mk3/Mk3.1合同批次或flight set已通过所需系统测试并获客户验收交付，而非只发出光学头、样机或实验室测试件。
  - Reference: 2025-06 Mynaric公布累计交付超过100台Mk3、制造超过150个光学头及首套完整Tranche 1 launch set，但这些是截至2025年的历史履历。Mynaric在2024年公布的Rocket Lab T2TL-Beta约1,500万美元订单原计划于2025—2026年交付；其完成度在本轮冻结材料中没有确认。Rocket Lab于2026-09-24仍将履行backlog、扩产列为新管理层工作；2026Q2收购后财务披露列Mynaric相关收入1,319.5万美元、营业亏损1,324.5万美元，但无当期终端验收率或客户级利润拆分。
  - Boundary: 一套客户定义的完整终端批次通过系统测试并被客户验收，已把当前“历史有交付、收购后履约状态与合格节拍未公开”的现实转成新的可交付产品证据；考虑单季收入/营业亏损规模及终端制造成本和库存转化，单个完整批次足以提高供给恢复与客户留存可信度，不必等多个季度、全backlog交付、收入增长或毛利转正。只宣布扩产、通过单项PAT测试、发出光学头或仅装入Rocket Lab内部卫星，不跨过外部客户验收边界。
- C2 / LONG / MIDDLE: 一个具名外部卫星主承包商/运营者为新近有资金支持的终端批次，明确把Mynaric从第二来源提升为主要供货者，或将其选为该批次的主要/独家终端供应商。
  - Reference: Mynaric历史上供应Rocket Lab的T2TL-Beta订单，Rocket Lab称其也是其他SDA合同供应商；收购完成后原采购链部分内部化。公开材料没有给出当前外部客户的具名供货份额，也未确认某个外部主承包已把Mynaric第二来源提升为主供。
  - Boundary: 单个具名、已资助批次中主供位置由客户正式分配，已将市场机会从“有产品和既有合同/供应关系”改为外部客户实际给出主要采购份额，能改善订单可见性、客户留存和有效产能吸收。无需等交付、完整backlog或公司确认营收；新增候选名单、技术交流、非约束性合作或只获备用资格不够。
- C3 / SHORT / MIDDLE: Rocket Lab、Mynaric或具名客户/主承包商确认，一项仍有效的具名光终端合同批次因关键输入短缺、低良率、返工或测试未齐套而被推迟至其此前公开交付窗口之后，客户验收也相应未完成。
  - Reference: 具名T2TL-Beta订单曾公开的交付区间为2025—2026年；后续收购及管理重组建立了扩产、订单履行计划，但没有公开的当前批次合格率或完成进度。Rocket Lab 2026Q2披露Mynaric相关收入1,319.5万美元和营业亏损1,324.5万美元，不应将其年化或解释成制造问题的单一因果，但显示延迟、库存和成本对该业务并非可忽略。
  - Boundary: 对仍然有效的一项具名订单，因产出/测试不足被确认跨出其原先披露窗口，意味着当前供给不能按客户已知排程转成可接受产品，收入确认、现金回收和客户信任至少在该批次后移；一个批次延期已足以改变近端履约预期，不要求整家公司订单取消或公开精确库存余额。客户主动正常重排发射而终端已按时验收、无原因的计划性扩产、以及尚未公布结果都不触发。
- C4 / SHORT / MIDDLE: 一个具名外部主承包商将原已分配给Mynaric的有资金支持终端批次改由竞争性第二来源担任主供，并确认该批量或供货责任从Mynaric转出。
  - Reference: 并购使Mynaric原先独立的约1,500万美元T2TL-Beta采购链部分内部化；其他外部终端供应的数量、价格与批次份额并未在材料中披露。因此，抽象的第二来源资格与真实订单再分配不是同一状态，不能把竞争者的一般能力或一份新合同当作Mynaric已丢单。
  - Boundary: 客户把既有已资助批次中的主要供货责任明确从Mynaric转到竞争性第二来源，已直接修订目标产品的外部采用份额、交付负载和客户留存；一个项目批次即可成立，不要求披露被转移的终端数量或金额。仅增加备用供应商、跨新项目选用不同供应商、或因新卫星规格不同而增加供应商不构成对原供货位置的下修。

## 光通信终端标准版本、互操作资格与代际采用

光终端不是只凭标称速率进入卫星网络：同代终端需在物理层、同步/编码和相互指向捕获跟踪（PAT）上互通，实验室波形、地面PAT、航天器集成和在轨端到端链路分别降低不同风险。SDA v3.2于2025-03定稿并作为Tranche 3标准记录，含v3.1增量要求且SDA说明3.2与同一3.*版本可互通；v4.0引入面向未来MEO Missile Track Custody连接的长程波形，并只预期少量T3终端采用。Mynaric现有Mk3.1产品页称其满足v3.1，另有10/100Gbps选项，但产品页/规格不等于特定任务已通过系统资格或飞行互通。Rocket Lab已将Mynaric终端纳入其T2/T3卫星集成项目，给出既有设计位置；相关整星合同是Rocket Lab主承包工作，收购后内部终端供货不应计作新增外销。ESA已为Mynaric在HydRON E2/E3采购示范工作；另一个Kepler牵头的E3多供应商验证列出TESAT、MBRYONICS、Astrolight等终端伙伴，说明互操作场景是多厂商竞争，非目标产品独占。标准开放可扩大可投标的节点/网络，但也降低单一来源锁定和价格溢价；更高速率可减少链路/终端数量，也可能抬高单台配置或打开新用途，因此不能把Gbps、卫星数或整网合同金额线性换算成Mynaric销量。真正修订产品可服务范围的是具名项目的型号资格和选择，或目标终端与独立厂商终端完成真实在轨链路；排除产品的标准/专有接口选择则降低适用范围。Kepler的商业光中继服务证明应用存在，不证明它采购Mynaric终端。

- C1 / LONG / MIDDLE: 一个有资金支持的新卫星批次/光通信网络采购，公开选定具名Mynaric终端型号作为该批次主要终端，并确认该型号满足采购所需的SDA OCT、ESA ESTOL或其他明确互操作规范。
  - Reference: SDA v3.2已成为T3标准记录，v4.0针对未来长程/MEO波形；Mynaric Mk3.1目前公开产品资料称满足v3.1，但不能由此推断所有v3.2/v4.0或网络验收均已通过。Mynaric已有Rocket Lab的T2/T3内部集成及ESA HydRON E2/E3付费示范，尚没有这些材料确认其Mk3.1被另一个新具名采购批次列为主要终端。
  - Boundary: 在一个新近获资助的真实批次中，客户同时选定目标型号并指明其适用接口资格，足以把可供/示范能力推进为某一外部项目的有资金产品采用，打开该批次需求并验证代际产品选型。一个批次即可改变当前设计位置；不必等待发射、全星座部署、产品收入确认或全行业采用。仅公布SDA标准、Mynaric规格、RFQ邀请或未经授标的合作不足。
- C2 / LONG / MIDDLE: 公开任务结果确认一台Mynaric光终端与独立第三方厂商终端在轨完成完整PAT、建链及真实任务数据传输，且结果发生在有资金支持的网络/飞行任务中。
  - Reference: SDA和ESA的接口标准说明实验室波形、系统PAT和在轨运行不是同一验证层次。ESA已为HydRON授予Mynaric示范终端工作，且另有Kepler牵头的多供应商在轨演示计划；截至本轮截止，未见材料确认Mynaric终端已与第三方产品完成在轨端到端传输。已有产品资料的互通声明、Rocket Lab自有平台设计和Kepler商业网络服务都不能替代目标终端的飞行证据。
  - Boundary: 一条可归属于Mynaric终端的真实异厂商在轨数据链，已跨过仅有规格/实验室波形/PAT验证的主要整系统风险，对同一标准网络中的后续应用资格有独立价值；不要求整套HydRON/星座投入常态商业服务、Mynaric获得新订单或重复飞行。仅发射、产品展开、单端PAT演示、地面连通或第三方终端间成功不够。
- C3 / SHORT / MIDDLE: 一个已资助且此前以开放、跨厂商光终端为设计基础的具名网络批次，公开确认Mk3.1/后续型号未通过该批次必需的标准或端到端资格，或采购方转用不兼容专有接口，并因此把目标产品排除、将该批次主供转给其他终端。
  - Reference: Mk3.1产品页目前宣称SDA v3.1合规；SDA已定稿v3.2并称其作为T3标准记录，v4.0针对少量高长程需求，故不能仅因标准有新版本就假定目标被淘汰。目标已有的Rocket Lab T2/T3整星集成以及ESA HydRON示范构成现有产品位置；Kepler E3列有多家外部终端厂商，证明竞争选择现实存在，但不证明Mynaric已在所有这些项目被选。
  - Boundary: 在一个具名、有资金支持且实际要求目标产品可进入的网络批次中，采购方因明确标准/整机互操作不合格或改用封闭接口而取消目标产品资格，并为该批次改选其他产品，已直接关闭目标在该项近期市场的可服务入口。单个相关批次足够形成负向修订；不必等待Rocket Lab公布收入损失或整条产业线退出。标准草案、普通竞争者中标其他批次、开放标准允许多供方、厂商尚未公开新测试结果或与目标版本无关的兼容问题不足。

## 欧洲光终端采购资格与本地制造工作份额

Rocket Lab于2026年4月收购Mynaric全部股份并取得控制，Mynaric仍以慕尼黑为总部且已有制造能力；Rocket Lab Germany于2026年8月宣布成立，母公司将德国扩产表述为未来可能性，并未证明新增工厂或有效产能已投用。德国政府曾批准收购，但一次外资审查不是对所有未来敏感项目的采购许可。欧洲市场规则也不能混成一条：ESA按各计划的参与国、国家授权资金和工业回报安排竞争与工作地点；HydRON Element 3参与国包括德国，而2026年ESA为IRIS²低轨服务概念开的另一轮预运营征集只向其Element 3参与国开放且名单不同，金额上限为每合同150万欧元、内容是方案成熟而非光终端量产，且后续实施轮仍另行招标。EU Secure Connectivity Regulation第22条只在有必要时对该计划采购适用安全、完整性和韧性参与条件；另一个EuroQCI资助征集曾对第三国控制设严格限制，这证明特定安全调用可设门槛，不证明ESA、欧盟或全部欧洲商用采购一概排除美资控制企业。该Regulation对超过1,000万欧元合同还要求至少30%合同价值通过竞争分包给主投标人集团外企业，可能形成供应链入口，但不保证终端份额。经济变量因此是每一项有资金的采购如何认证主体、安排原产地/实际工作地点并分配终端批次；本地子公司或‘主权’宣传、进入参与国名单、欧洲网络总预算都不能代替具名生产工作包。若项目明确采购部署批次并选择Mynaric，才将地域能力转成产品订单；严格控制或本地工业条款若在具名采购中排除其产品，则会收窄相关机会。

- C1 / LONG / MIDDLE: ESA、欧盟/成员国主管机构或具名欧洲系统主承包方正式授予并落实一项超出已公布HydRON演示范围的部署/后续光终端生产批次，明确由Mynaric或Rocket Lab Germany承担终端供应或制造。
  - Reference: 现有可核实欧洲直接项目入口是HydRON E2/E3的开发与示范终端工作；未见超出这些演示范围、供部署/重复生产的Mynaric终端批次。Rocket Lab Germany公告只称未来可能扩大德国制造，Mynaric已有的慕尼黑产地和参与国资格本身不等于订单。
  - Boundary: 一项已签/已授予且有资金保障的生产或部署工作包明确点名Mynaric/Rocket Lab Germany为终端供应者即可；限定为真实终端生产供货而不是服务概念、资格名单、征求建议、入围或单次演示，不另要求公开利润率、最终收入或多个项目。
- C2 / SHORT / MIDDLE: 一项已资助、包含实际光终端采购的欧洲安全/主权部署招标，明确对相关终端供应实体及其受控关联方实施不得由第三国控制的强制资格限制，且主管方据此正式认定Rocket Lab控制的Mynaric不具资格或排除其终端工作包，无法通过获准豁免、缓解安排或合格本地关联实体参与。
  - Reference: Rocket Lab持有Mynaric全部股份并取得控制，属于美国母公司控制的德国企业；德国曾批准该次收购，且ESA HydRON已有Mynaric项目角色。现有EU法规将安全参与条件限定为必要时适用，具体安全资助调用才可明确引入控制门槛；当前无证据表明这一门槛已普遍施加于Mynaric的欧洲终端业务。
  - Boundary: 在一个有已落实资金且包含部署终端采购的具名项目中，规则被正式应用并导致该实体失去相应供应资格/工作包，即越界；不要求证明整个欧洲市场被关闭。一般安全政策、法律提案、同一规则用于非光终端领域，或存在可行豁免/替代本地实体时不够。
- C3 / SHORT / MIDDLE: 具名欧洲部署项目的采购方/系统主承包方公开确认，依据有约束力的国家原产地、生产地点或工业回报/工作份额条件，将原已授予Mynaric/Rocket Lab Germany的主要终端生产批次转交其他国家或供应商，并实质移走该公司承担的生产范围。
  - Reference: ESA按成员国贡献和实际工作地点执行工业回报，部分计划可设置特定地域约束；HydRON Element 3将德国列为参与国，但不同EU相关ESA征集可能有不同国家名单。当前没有已披露的欧洲大规模终端生产工作份额或产地转移，未获新批次本身不能按丢单处理。
  - Boundary: 一次公开的、有资金支持的部署批次中，目标公司原有的主要制造工作因明确地域条款被正式转出即可构成有意义的捕获下修；一般产业政策目标、他国企业参与、多供应商名单或新增伙伴分得增量而Mynaric原有工作保留，不足以触发。

## HydRON终端交付、在轨验证与服务示范

截至本轮，Mynaric已有两个有别于普通商业终端订单的ESA项目入口：HydRON Element 2中为地面与空间段提供终端，Element 3则把终端放入用户段演示系统，面向海事、航空等服务概念。ESA给出的HydRON-DS计划是2027年发射、2028—2029年在轨演示；E2另有跨轨道网络与后续在轨验证安排。当前状态是已承接的开发/示范工作，不是大规模运营网络的终端重复采购；ESA将未来商业利用放在成功完成在轨演示之后。因而，真实在轨跨轨链路或用户服务演示会减少终端、接口和多方集成的技术风险，并提高Mynaric进入后续项目的可信度，但不能据此推算未披露的产量、订单额或商业化收入。相反，若现有具名终端工作包因资格或交付失败被正式取消或转给他方，会直接撤销既有项目位置。终端到货、实验室测试、项目一般进度及高带宽愿景均不等于系统在轨验证。

- C1 / LONG / MIDDLE: ESA或HydRON系统主承包方确认Element 2的在轨演示已通过装有Mynaric终端的LEO采集器，在另一轨道层或相连地面段之间完成跨轨光链路并实际传输任务数据。
  - Reference: ESA已公开Mynaric为HydRON Element 2提供空间与地面段光终端；该工作属于多轨道网络开发和演示。现有公开计划仍处于建设阶段，E2的发射与验证安排在未来，尚无Mynaric终端参与跨轨道任务数据传输的在轨结果。
  - Boundary: 首次官方确认的、经过Mynaric终端并完成跨轨/相连地面段数据转发的在轨运行即可越界；不要求全网商用、Tbps容量、重复使用或新增订单。单星发射、地面PAT/波形测试或仅有终端在轨而无链路数据不够。
- C2 / LONG / MIDDLE: ESA或Element 3系统/服务伙伴确认HydRON Element 3在轨演示使用Mynaric终端完成从网络核心到具名用户段的端到端光通信服务试验。
  - Reference: ESA于2026年3月确认Mynaric将向Element 3 Demonstration System提供终端，以验证未来商业及机构任务的服务概念；ESA公布的HydRON-DS基准计划为2027年发射、2028—2029年在轨演示。当前是终端合同和演示系统开发状态，尚非真实用户段服务结果。
  - Boundary: 一个在轨服务演示完成且有官方结果说明Mynaric终端承担了端到端链路中的实际传输，就足以把当前状态从开发计划推进到服务环境验证；不需等待长期商业运营、收入确认或更多用户。仅交付终端、演示系统发射或不含目标终端的用户试验不够。
- C3 / SHORT / MIDDLE: ESA、HydRON系统主承包方或Mynaric公开确认，原已授予Mynaric的具名Element 2或Element 3终端工作包因产品资格、验收或交付失败被取消、实质削减或改由其他供应商承担。
  - Reference: Mynaric在E2和E3均有已公开的终端项目角色，但项目仍处建设/演示阶段；没有证据表明其终端工作包已被撤回。整体任务延期或计划更新可能由多方接口、发射或资金造成，不能自动归因于该产品。
  - Boundary: 出现一次针对Mynaric已授予终端范围的正式撤销、削减或供应商替换，并明确与产品资格/验收/交付有关，即足以反转已知项目位置；不要求等到整个HydRON取消。只有整体日程变化、单纯延期或一般风险提示不够。

## 成熟航天组件的外部采购位置、定价与工程分担

Rocket Lab 将反作用轮、普通星敏、分离/部署系统、无线电及飞控/地面软件作为可独立供货的组件组合，也可将其放入面向外部客户的整星包。客户的标准配置、批量续采、接口资格、合格交付和可用替代供应共同决定外部组件位能否转换成可履约合同；一个竞争主承包商赢得更多卫星，只有其明确采用 Rocket Lab 组件时才扩大本公司的组件机会。当前公开履历证明这些产品已有外部市场和飞行用途，但不能替代当期客户量价：2021年轮系新线曾公布每年最高2,000件的设计供给及未具名星座订单，2022年两份分离系统合同合计1,400万美元、超过80套Lightband并涉及Lockheed Martin及一名未具名客户，2023年12 Nms轮系产品处于生产并计划用于未具名大型星座；这些都是历史订单/生产状态，不是2026当前合格输出。2025年加拿大航天局约99.9951万加元的轮系研发资助是有付款的产品开发，不是批量销售。现行目录和2026年新品公告说明产品继续销售，但未披露产品级在手订单、可用合格产能、良率、报价或交期。较高采购量可能提高重复制造价值，也可能由集中采购压价；买方自研或经验证的兼容替代能降低换厂门槛，若RKLB承担新增资格工程却无单独补偿，量增不必然提升净价值。内部航天器用自有零件不形成新增合并外销，整星合同金额不能拆成组件单价或毛利。RKLB于2026年6月签署收购Iridium协议、9月已获Iridium股东批准并完成融资，但交易仍待监管等条件、预计2027年年中交割；在交割前双方仍是独立公司。网络运营后客户可能偏好中立供应商，也可能更愿意采购整包方案，目前没有公开的客户换源或加单证据，故只把客户实际采购、配置或条款变化作为观察，不把交易公告或未来整星获奖本身当作触发。

- C1 / LONG / MIDDLE: 外部星座运营者或卫星主承包商公布新的已授予经费/已签约多星生产批次或续批，并明确把一项 Rocket Lab 成熟组件列入该批次的标准配置或重复供货；该零件须属于反作用轮、普通星敏、分离/部署系统、无线电或飞控/地面软件，并用于非 Rocket Lab 自有卫星。公告若给出星数、部件数或交付节奏则沿用其口径；若只表明该组件是该批次的标准件，不要求推算每星数量或单价。
  - Reference: 截至2026-10-12，Rocket Lab仍公开销售上述成熟组件，具备长期飞行履历和过往外部合同；但已知批量订单主要是2021—2023年的历史资料。2021年每年2,000件是轮系产线设计能力而非当期产出；2022年超过80套Lightband、总合同1,400万美元是两个旧合同的合计口径；2023年12 Nms轮系的未具名星座安排没有公开当前批次数。当前资料未给出任何主要产品家族的客户级有效订单、重复量、价格或合格交期，默认只沿用产品继续销售、既有客户/产品组合可能延续，不把未披露的数量视作零。
  - Boundary: 一项公开可识别、已签约或获经费支持的外部多星生产批次把具体 Rocket Lab 组件列为标准供货，已从目录/资历或单次演示跨到直接外部生产分配，是足以修订该产品客户池与未来供货位置的最早现实信号；不必等到发货或收入确认。单次样件、验证飞行、公司自有卫星、外部整星获奖但没有部件选型，都尚未越界。合同总价若包含整星/其他系统，不可换算成该零件价格或利润。
- C2 / LONG / MIDDLE: Rocket Lab 与具名外部客户签署并公开一项生产批次合同修订或续约，明确提高同一成熟组件、同规格且同范围的已承诺批次单价/合同对价，或为该批次新增的客户专属资格/工程工作另列并落实支付；批次供货承诺没有同时被缩减。
  - Reference: 当前没有按产品披露的生效客户报价、可比合同单价、订单总量、单位成本或工程工时。2021年公开的10 mNms RW-0.01资料列有每件20,000美元、抗辐射筛选另加2,000美元，但这是旧版目录价而非当前接受价；2025年加拿大航天局约99.9951万加元的25 Nms轮系研发资助证明专项工程可以获付费，却不是当前批量采购或各产品的成本基线。
  - Boundary: 对同一产品、已承诺生产批次，具有法律/采购效力的公告直接给出旧新同口径对价，或明确把新增客户特定资格/工程纳入有对价的合同范围，已改变该批次可捕获的外部价值；不需等季度利润证明。未接受的报价、旧目录价的简单更新、无批次的研发愿景或未单独补偿的工作说明都不够。此条件确认对价而非盈利率，成本和利润率仍未知。
- C3 / SHORT / MIDDLE: 一个公开已选用 Rocket Lab 组件、且已有已签约/获经费的外部多星生产批次，之后由该客户或主承包商正式把该部件位改为兼容的其他合格供应商或客户自研自制，或修订批次/合同而取消 Rocket Lab 的该组件供货，同时卫星批次本身仍继续。
  - Reference: 产品目录、飞行履历和旧订单说明 Rocket Lab 曾进入多种外部用途，但目前没有逐客户组件份额或活跃批次清单；不能假定某一家过往客户仍在采购，也不把未具名市场份额设为零。因而要以新消息中可核验的既有标准件/已承诺批次为同项目比较锚。
  - Boundary: 同一具名客户/批次的正式供应商或配置变更若移除 Rocket Lab 已获得的生产部件位，且卫星项目继续，等价供应将从其可服务外销量中直接挤出；这是首次出现的真实替代/内制而非一般竞争风险，不需等到订单实际交付或财报确认。仅有供应商评估、第二来源测试、平台竞争者赢标或新产品发布不够。
- C4 / SHORT / MIDDLE: 对一个已公开定量和签约的外部组件生产批次，客户与 Rocket Lab 公布生效的同产品、同规格、同数量/交付范围合同修订，下调已接受的组件对价，或把新增资格/定制工程义务纳入原固定对价而未另行支付。
  - Reference: 当前没有可与未来比较的产品级有效报价、价格序列、在手订单条款或直接履约成本；旧轮系目录价不替代客户合同价。可用的当前现实仅是产品仍在售、历史上有大批次合同和外部设计采用，且费用/研发负担无法分解到单一组件。
  - Boundary: 具约束力的订单修订若在已承诺的多星组件批次上直接降低对价，或明确增加同一固定价合同下未付费的客户特定工程范围，即减少这项外部供货的收入/补偿基础或扩大持续工程负担；无需先证明公司整体利润下滑。只有公开报价下调但无接受合同、未披露原新可比范围、常规规格变化或普通资格测试，不构成足够边界。

## StarLite保护光学的外部配置、威胁要求与主承包捕获

StarLite是独立于Phoenix导弹预警/跟踪载荷的空间保护传感器，保护需求和每个平台配置决定该部件是否存在；已认证接口、辐射/任务环境资格、主承包商是否自研或改选供应商决定Rocket Lab能否获得外部份额。Rocket Lab的18颗TRKT3自有卫星采用StarLite，而2025-12-19公司又称其他TRKT3主承包商也采用，构成真实但未量化的商用部件位置；客户身份、颗数、对价、交付完成状态均未披露。公司同时提及的约10亿美元潜在捕获包含自有18颗卫星的约8.16亿美元整包合同以及多类可能子系统，不是StarLite签约额，也不能除以星数反推单价。2026年新增同类对手卫星授标会扩大潜在可服务平台池，但只有保护要求保留且平台采购方选用StarLite才增加该产品需求；对手赢下整星既可能扩大组件市场，也可能在与Rocket Lab竞争后转为自研/换源。任何保护规范缩小、替代传感器资格完成或客户角色冲突都可降低这一外部机会，不需要等待RKLB整星项目结果。现有采用声明不等于按批交付或可确认收入。

- C1 / LONG / MIDDLE: 外部卫星主承包商或采购方正式发布一份新批次/合同配置或对既有采用的扩展，明确将 Rocket Lab StarLite 列为已获经费的外部卫星生产配置，并给出可识别的生产批次、星数或交付节奏；该批次超出当前仅知“其他TRKT3主承包商采用”的未具名、未量化范围。
  - Reference: 截至2026-10-12，Rocket Lab的18颗TRKT3主承包卫星装有StarLite；公司另披露StarLite已被其他TRKT3 prime采用，但未识别客户、外部颗数、生产时间、订单金额或交付完成。全项目约10亿美元捕获估算涉及多类潜在组件和整星合同，不能用作StarLite基数。政府采购材料显示同用途的外部主承包订单仍在扩展，但当前没有已公布的StarLite外部批次数量/单价。
  - Boundary: 新的具名外部生产配置或旧披露中未量化采用的首个已资助批次数量/节奏，一旦明确到可识别的组件生产范围，即把“被其他prime采用”的设计位置转成具体、可持续生产的外部供应机会；不需等待首颗卫星交付、系统收入确认或额外主承包商再确认。只重复报道原有采用声明、仅公布竞争者卫星授标、把保护传感器作为可选评估或未说明StarLite的威胁需求，都不够。
- C2 / SHORT / OUTER: 有权采购方/系统设计基线正式修改一个已获经费的外部卫星批次保护要求，明确取消或显著缩减原本承担保护传感器配置的卫星范围，导致该批次不再要求该类传感器。
  - Reference: 目前其他TRKT3 prime已公开采用StarLite，表明该类外部平台存在保护传感器位置；但威胁要求与每星配置不是所有卫星相同，未公开的总数量不能推为全系列每颗都有。当前没有政府/客户公布取消该功能的决定。
  - Boundary: 对已获经费并设有保护传感器配置的具体批次，正式采购/技术基线把其从标准需求中移除或缩到失去相应生产范围，直接减小可服务部件池，不必等Rocket Lab披露销售损失。一般威胁评估、草案讨论或尚无对应已资助生产批次的需求变化不够。
- C3 / SHORT / MIDDLE: 一个公开已选择 StarLite 的外部主承包生产批次，在既有保护需求不变时，正式把相应产品配置切换为已获资格的其他供应商传感器或主承包商自研方案，或修订合同而取消该批次中的 Rocket Lab StarLite 供货。
  - Reference: 公开基线是Rocket Lab已被其他TRKT3 prime采用，虽客户和数量隐去，但并非单纯技术可选项；缺少可核实客户级供货量、资格条件和价格。对手获得更多卫星任务本身并不等于供应商切换，也不证明原有订单受损。
  - Boundary: 同一已选择/承诺的外部批次正式改用合格替代件或主承包自研，会直接撤掉StarLite的原供货位置；它是可核验的竞争捕获损失，即使对手整星总量扩大也成立。只公布替代产品研发、资格测试或与RKLB竞争的主承包商获奖而不改该部件配置，均未达到边界。

## Gauss电推进在卫星机动、寿命维持与离轨配置中的采用

Gauss不是一个可以由“卫星数量或离轨规则”直接换算的产品机会。Rocket Lab于2026年4月14日发布由Hall推进器、PPU与推进剂管理组件组成的Gauss，宣传较化学推进更高比冲、磁屏蔽降低侵蚀并延长寿命，公布的产线设计能力为每年超过200台；这不是客户资格、交付或产线利用率。电推进可用较少推进剂提供较高总冲量，适合长时间轨道维持与反复机动，但相对化学系统推力低、点火时间长，并占用卫星电源；NASA小卫星参考把系统级电推进概括为低推力/高比冲，并说明同一冲量可能需要数百至数千小时，化学系统则通常以秒至分钟完成。Gauss本身的功率、推力、寿命、每星台数及经客户验证数据没有公开，因此用客户系统级资格和重复生产选型而非臆造性能门槛判断。现有Hall系统已在星座中广泛使用，Busek等供货和其他电推进/化学路线构成真实竞争；低轨自然阻力、拖曳装置也可支持部分退役任务。FCC已实施的规则要求低于2,000公里且计划不受控再入的卫星在任务结束后不迟于五年处置，但未指定必须使用推进器；规则可提高每星设计约束，也可能抬高整星部署成本或由被动方案满足，不能作为Gauss销售触发。外售是外部组件收入；Rocket Lab自有卫星采用只可能形成真实可避免采购成本的净节省，不能计作外销，且目前没有自有星内供量或替代成本披露。

- C1 / LONG / MIDDLE: 具名卫星运营方、星座采购方或整星主承包商公布Gauss系统已适配/通过其对应卫星平台资格，并被选入某一重复生产卫星机型的标准电推进配置，且有生产批次采购、供货授予或明确的运营星座量产部署。
  - Reference: 截至2026-04-14，Rocket Lab已推出Gauss，称其为自研Hall推进器、PPU和推进剂管理系统，并称具备每年超过200台的产线设计能力及较高比冲/寿命设计；该数量是设计值而非交付量。当前D2未列出具名客户资格、客户订单、验收交付、每星配置或具体功率/寿命数据。NASA资料显示Hall电推进有成熟在轨使用但同类替代者存在；当前合理基线是Gauss为新增供货选项、客户逐项选型，非已成为通用标准。
  - Boundary: 一个具名、投入重复制造的卫星平台将Gauss定为标准系统并形成正式生产采购/供货位置，即证明客户已在该平台接受其推力、功率、寿命和集成取舍，并把设计产能接到实际可服务需求；无需等待全部批次交付、在轨全寿命或公司确认收入。单星技术演示、一般客户兴趣、公司产线设计值或法规更新不够。
- C2 / SHORT / MIDDLE: 具名重复生产平台在Gauss资格测试中确认推进性能、寿命、功耗/电源接口或系统可靠性不能满足已公开的该机型要求，客户因此中止Gauss资格、取消其生产供货或暂停该平台采用。
  - Reference: Gauss官方发布仅提供定性技术卖点，没有披露具体瓦数、推力、总冲量、寿命测试值或在轨使用；公司称产线已建立，但没有公开客户测试/验收。当前预期是按平台适配推进，并非Gauss已在客户量产星上被证明或已发生性能失格。
  - Boundary: 客户或公司将问题明确归因于Gauss系统本身，且该问题令一个具名重复生产平台的资格或生产配置实际暂停/取消，已足以改变新品在该客户的可交付路径；不要求等到整条产品线的收入或利润公布。可修复且未造成资格/采购变化的单项测试问题、一般性关于电推进功率的讨论或无具体Gauss对象的风险，不足。
- C3 / SHORT / MIDDLE: 一项具名运营星座或主承包商公开其多星生产平台的最终推进系统选择，并确认该方案曾将Gauss列入候选/资格范围，却最终将重复批次授予另一Hall/电推进、化学推进或被动离轨系统且排除Gauss。
  - Reference: 机动、寿命维持及离轨需求可以由多种系统满足；NASA指出化学路线适用于较快/高推力机动，被动拖曳可应对部分低轨离轨，且已有多家Hall推进供应商。Gauss在当前文件中没有具名投标/候选项目，故只有公开可辨的Gauss候选和最终排除才能同当前产品机会比较。FCC五年离轨规则已是现行背景而非新催化，且不规定必须用Hall推进。
  - Boundary: 单一具名重复生产平台在明确评估Gauss后，将后续标准批次确定给替代路线且不含Gauss，已表明目标产品失去该批次的供货位置，无需等全部卫星入轨或客户透露供应商利润。其他客户独立采用替代路线、单纯提高离轨要求、被动/化学选项存在或行业总星数下降，不足以证明Gauss在可服务项目中丢失份额。

## IMM Apex无锗太阳电池的客户采用与价值捕获

Rocket Lab的太阳能组件价值取决于电池在外部卫星产品中的供货选择、可交付成本与实际良率，而非只看电池参数。公司2026年9月8日发布IMM Apex：无锗基底、31.5%寿命初期效率、相对传统产品低40%电池质量，且声明为机械/电气接口兼容的替换品；这些是单体规格，不代表整星同比减重、寿命发电增量或已获客户配置。公司此前IMM技术的在轨履历和超过1,100颗卫星使用Rocket Lab太阳能产品也不等于Apex采用。USGS记录2025年高纯锗金属价格由1月约3,150美元/公斤升至10月约5,380美元/公斤，并记载中国锗出口许可与对美限制，说明规避锗有供应与采购成本选择价值；但Rocket Lab的锗成本占比、其他输入、Apex良率、实际交期、单价和客户分配均未公开，故不能把原料价格涨幅直接换算成公司毛利。Drop-in接口可降低客户换型门槛；通过资格并列为重复生产配置才把供货选项转成可捕获份额。竞价可能把技术节省传给客户；丢失重复批次说明份额转移，不能仅凭竞争价格推断单台毛利。

- C1 / LONG / MIDDLE: 具名卫星业主、整星主承包商或阵列集成商公布IMM Apex已通过其相关产品/平台资格，并被选为一项投入生产的星座或卫星机型后续重复批次的标准电池供货配置；需是可形成重复生产采购的客户选型，而非一次性技术演示。
  - Reference: 截至2026-09-08，Rocket Lab已宣布IMM Apex生产发布并称可供货、可替换传统锗基产品；其公告称IMM技术有十年以上测试资格、制造达到multi-100-kW量级，但没有披露客户名、Apex适用平台资格、客户验收批次、订单或实际出货功率。公司称超过1,100颗在轨卫星使用的是Rocket Lab太阳能产品总体，不能当作Apex装机。当前比较基线是新品可供客户评估、采用仍按项目发生，尚无公开的重复生产客户选择。
  - Boundary: 一项具名生产卫星/星座的标准配置与重复批次供货选择，或相应生产采购授予，即足以把“可供货产品”推进为确定的客户产品位置并支持后续批次需求预期；不必等待多批交付或在轨寿命数据。单纯发布、客户接触、兼容宣传、非生产演示或既有IMM技术履历仍不足。该边界确认供货机会/份额，不宣称公司已实现特定毛利。
- C2 / SHORT / MIDDLE: 具名客户或Rocket Lab披露Apex在一个计划重复生产的卫星机型中出现产品特定耐久、环境或制造验收失败，并因此暂停/否决该机型的资格或撤回其Apex生产配置、批次采购。
  - Reference: 截至cutoff，Apex刚于2026-09-08生产发布；Rocket Lab称其兼容传统接口，且IMM技术家族有既往资格与在轨履历，但D2和公开发布未列Apex客户级资格、耐久结果或接受出货。当前新品产品资格风险仍属待客户验证，未见具名生产批次因Apex失败而取消。
  - Boundary: 首次由客户或公司明确指向Apex本身的资格/耐久/量产验收问题，并使一个具名重复生产平台暂停、否决或取消其Apex配置，即已将当前“可供货”基线改为真实的产品适用或交期障碍。单一实验室异常若已修复、未影响生产资格，或对既有IMM技术的泛化质疑，不足以触发。
- C3 / SHORT / MIDDLE: 在一个具名的重复生产卫星平台中，客户公开说明Apex是已入围或已具资格的候选，却将后续标准电池批次最终授予其他电池供应商并排除Apex；若披露更低竞价/交期为理由，可直接识别节省或供货优势被客户转移。
  - Reference: Apex虽是可立即订购的无锗替代品，现有材料没有公开客户级价格、竞价结果、Apex订单、相关旧报价或Solar产品收入。USGS的锗现货价格和出口限制只说明原料风险，不能建立Rocket Lab单位成本；当前未确认Apex已获得任何具名标准份额。
  - Boundary: 一项已公开Apex候选/资格的重复生产采购最终排除Apex并确认替代供应商取得该标准批次，足以证明该项目的产品份额流向竞争者；无需看到整星收入或公司毛利修订。一般市场价格下跌、未具名报价或与Apex无关的供应商选型均不足。若客户明确低价获选，结论是客户获得议价节省，不据此量化RKLB margin。

## Space Data Network交换系统与Photon多厂商示范

SSC于2026年5月为Space Data Network Backbone（SDN-B）向SpaceX授予22.9亿美元固定价OTA交付订单，目标是在2027年底前交付可全面运行的原型；这构成已知核心网络采购，不是Rocket Lab订单。SSC于8月另以多供应商集成安排，每家分别获得1,000万美元、履期6—9个月的互连原型合同，以及200万美元、履期6个月的OTA以播种Space Exchange Point（SEP）卫星的开发/部署；Rocket Lab是五家之一。Rocket Lab称其两项协议合计1,200万美元，并计划2027年以自建Photon进行在轨示范。SEP被SSC定义为轨道路由节点，可让不同网络及政府卫星系统直接接入SDN-B；因此本题的经济观察是接口系统、网络路由和系统集成位置能否从开发/示范扩展为可复用接入或持续采购，而不只是某款光终端通过部件标准。已接受的跨厂商在轨互通结果会降低整体入网技术风险并提高Rocket Lab参与后续接口/节点采购的可信度；新的持续运营或部署订单则直接增加目标的采购捕获。反之，示范失败、显著推迟或正式转向封闭单一供方，会削弱这条新入口。当前1,200万美元是原型/种子阶段，不是骨干星座主合同；SpaceX作为SDN-B核心供应方已是基线，不能单凭该授标判定多供应商入口已关闭。Rocket Lab现有SDA T2TL-Beta运输层合同为另一个已分配项目（18颗、4.89亿美元基础金额）；太空军2040架构文件分别呈现SDN与PWSA Transport Layer，但截止时没有资料确认SDN将取代该既有合同，或两条采购线的未来供应商份额。故将两者作为相关但独立的采购基线，不把未经披露的替代/互补关系计为当前收入变化。

- C1 / LONG / MIDDLE: SSC/USSF公布并接受Rocket Lab自建Photon的在轨示范结果，确认该任务已按SDN多供应商互连目标，在SDN-B数据传输链中实现与至少一套非Rocket Lab供方系统的跨厂商互通。
  - Reference: 截至2026-10-12，Rocket Lab已获得两项合计1,200万美元的SDN开发/示范协议，并表示计划2027年用自建Photon进行在轨示范；SSC说明五家供应商各自获得互连原型合同及SEP播种开发OTA。SSC也已授予SpaceX独立的SDN-B核心网络订单。上述是已承接工作与公开计划，尚无已被SSC接受的Rocket Lab在轨互通结果；部件规格、实验室连接、发射成功或Rocket Lab自身预告均未证明网络级接入已实现。
  - Boundary: 当SSC/USSF确认Photon完成并接受一项真实在轨的跨厂商SDN互连/数据传输时，Rocket Lab的角色就从获资助开发和计划示范推进到经政府评估的系统级互通路径，主要技术准入不确定性已发生变化；这可以单独提高其后续网络接口/SEP竞争位置，无需再等骨干主合同、多个采购批次或已实现收入。仅有光终端的型号资格、单端链路或成功入轨仍不足。
- C2 / LONG / INNER: SSC/USSF或SDN核心承包方公开授予Rocket Lab一项新的、有资金义务的后续工作，明确采购可部署/持续运行的SDN交换节点、SEP路由或SDN系统集成/运营；该工作须超出当前1,000万美元互连原型合同及200万美元SEP种子OTA所覆盖的开发与示范，不只是原合同里程碑或技术延续。
  - Reference: 截至cutoff，Rocket Lab的已知SDN工作合计1,200万美元，由互连原型合同及SEP开发/播种OTA组成；SSC公告称这些开发安排面向未来多供应商集成和SEP部署，但未确认Rocket Lab取得原型阶段之后的持续网络服务、规模化节点或后续生产工作。SpaceX的22.9亿美元SDN-B核心订单不属于Rocket Lab的捕获。
  - Boundary: 一项新的、资金已落实且职责落在可部署网络节点或持续集成/运营的Rocket Lab工作，即足以证明采购者开始把该供应商从原型/种子任务推进到后续网络服务或硬件采购；一台节点或一项有资金的运营工作即可改变当前基线，不需等整张骨干星座建成、公布未披露的全计划金额或确认长期毛利。仅继续完成现有研发交付、公布不限额框架或无资金合作备忘录不足。
- C3 / SHORT / MIDDLE: Rocket Lab或SSC/USSF正式更新Rocket Lab所计划的Photon在轨示范，使其不再预计于2027年完成、而改至2028年或以后；在2027年内的月份或窗口微调不属于该条件。
  - Reference: Rocket Lab于2026年8月公开表示预计在2027年实施Photon在轨示范；SSC的SDN-B核心网络原型目标同样指向2027年底。当前未披露Rocket Lab演示的具体月份、已发生延期或替代验证路径。
  - Boundary: 正式把演示移出整个2027日历年，至少将关键互通验证窗口推至下一年度，改变了Rocket Lab与核心网络原型同步评估的现有时间预期，并延后其验证/后续采购入口。因没有确切月份，年内小幅改期或仍预计2027年完成不足以构成有分量的边界。
- C4 / SHORT / MIDDLE: SSC/USSF公开报告Photon示范未能建立计划中的跨厂商SDN互通/数据传输，或正式拒收该结果为满足SDN互操作要求。
  - Reference: 截至2026-10-12，跨厂商互通仍是待验证的原型目标，Rocket Lab只披露拟用Photon进行2027年在轨示范；目前没有报告该系统已失败或被政府拒收。
  - Boundary: 政府确认实际在轨示范无法按SDN接口完成互通、或拒绝将其视为符合系统目标，足以否定当前路线中最重要的技术接入证据，并降低Rocket Lab获得后续SEP/系统集成工作的可能性；无需再看到一个完全取消公司全部SDN业务的决定。组件级测试、一般计划风险、未经证实的传闻或单纯未发布结果不足。
- C5 / SHORT / MIDDLE: SSC/USSF正式取消Rocket Lab的SEP/多供应商接入工作，或把SDN后续网络接入改为封闭的单一垂直供方路线并明确不再保留Rocket Lab已获资助的Photon/SEP路径。
  - Reference: SSC已选择五家供应商开展多厂商互连与SEP开发，并公开称开放接口用于降低单一来源依赖；另有SpaceX承担核心骨干网的已知授标。当前基线是核心网与外缘多供应商开发并存，尚无正式取消Rocket Lab工作或关闭SEP接入的证据。
  - Boundary: 采购方明确终止Rocket Lab当前SEP/互连位置，或以专有单一供方架构取代开放接入且排除Rocket Lab相关路径，即关闭本Policy对应的未来系统入口，可独立下修其后续SDN价值捕获。SpaceX继续作为SDN-B核心供应方、但保留多厂商接口/SEP的既定安排，或其他厂商赢得一个不排斥Rocket Lab的子项，均不足。

## 商业低轨空间站建设中的Rocket Lab组件供货位置

NASA于2026年10月9日发布商业空间站最终RFP，采用多授标IDIQ支持设计、开发、认证与服务：至少两家承包商先进入早期开发，最终设计、试验、认证和服务再由竞争任务单分配。NASA明确要求运营商提出可行经济方案并准备投资、发展其他客户，因此公共支持只是需求锚，不保证所有候选站体建成，也不替运营商决定供应商。Axiom于2026年6月完成超过5.25亿美元融资，但资金面向人类航天、宇航服和空间站等多项业务，并非专属站体拨款；其站体已选用Thales Alenia Space建造模块、Redwire提供太阳能阵列，且2026年10月Redwire获第二模块阵列后续合同。Axiom称首模块正在最终组装、计划2028年发射，第二模块计划在首模块后不到一年发射；计划可能随工程与资金调整，但不代表Rocket Lab承担了任何站体工作。Starlab公开了MDA Space的外部机器人与机器人任务运营角色，并与Redwire建立硬件及工程合作。这些安排说明组件商可通过运营商/主承包商进入站体，但资金到位、NASA授予站体开发合同、设计改版或竞争者获选均不等于Rocket Lab取得工作。Rocket Lab有太阳能、电源、机器人和航天器组件能力；其Gateway太阳能供货是经Maxar承包的月球政府项目，FFR机械臂为NASA专项示范，二者均不能代替商业低轨站体供货履历。对当前尚无公开具名站体供货位置的基线，最直接的正向变化是Rocket Lab取得某一商业低轨空间站明确、付费的飞行硬件或系统集成范围；无需等整站交付、认证或收入兑现。空间站运输需求也不是Electron常规载荷机会。

- C1 / LONG / MIDDLE: NASA、商业低轨空间站运营商或其具名总承包商公开确认，已向Rocket Lab授予一项有偿且有约束力的具体合同或分包，要求其交付、测试或集成将进入某一具名空间站飞行设计/制造配置的硬件或子系统（如太阳能/电源、机器人、平台组件或任务系统）。一般供应商登记、非约束合作备忘录、仅有NASA运营商/早期开发授标、未下达任务单的框架合同或不涉及具名站体飞行配置的研究服务不满足。
  - Reference: 截至2026-10-12 08:45 UTC，NASA于10月9日发布最终RFP，投标截止12月8日、授标预期为2027年春；NASA拟以多授标ID/IQ让至少两家进入早期开发，后续再竞争最终设计、认证与服务任务单。Axiom于6月公布超过5.25亿美元融资，涵盖空间站、人类航天和宇航服等项目；Axiom已公布Thales Alenia Space的模块制造角色和Redwire的首模块太阳能阵列合同，且Redwire于10月5日获第二模块阵列后续合同。Axiom称首模块处于最终组装、计划2028年发射，第二模块计划在首模块后不到一年发射。Starlab已公布MDA Space的外部机器人/任务运营角色，并与Redwire开展硬件与集成合作。Rocket Lab的太阳能、机器人和其他航天组件能力及历史Gateway月球空间站太阳能项目提供产品关联，但截至本截止点，现有材料没有显示其获得Axiom、Starlab或其他商业低轨站体的具名供货范围；FFR为独立NASA示范。
  - Boundary: 一项已授予且有资金支持、对象为具名商业低轨空间站飞行配置的Rocket Lab硬件/子系统或系统集成工作，已足以使公司从当前没有公开站体供货位置的状态转为有偿站体供应商，并带来真实项目工作与站体资格/后续复用路径；不要求合同金额公开、连续多次采购、NASA最终服务任务单、整站认证、首飞或后续季度收入。只有站体运营商/开发商获NASA奖项、融资、另一个伙伴获选或非约束性技术合作，仍只改变机会而未形成Rocket Lab的直接价值捕获。

## Electron专属任务的新增、流失与客户替代

Electron订单把客户部署需求转为Rocket Lab的专属发射任务；新增firm批次扩大可服务任务池，客户取消或把已分配任务转给其他运载器则减少Rocket Lab可执行工作。多年批次能提高未来排程可见度，但任务数不等于同期发射、收入或利润，跨年改期也不等于丢单。Synspective在2026-10-01披露总合同47次、其中34次未飞且新增20次计划在2028–2031年发射；这20次包含在34次内，不能相加。NASA选定的PolSIR两次和TSIS-2一次专属Electron任务是既有任务基线，不是新增催化。iQPS于2026-07-30曾披露11颗卫星计划由Electron发射，之后至少两项任务已发射，当前未飞余额无法据此精确更新。

- C1 / LONG / OUTER: Rocket Lab或客户公布一项已签、非选择权的新增专属Electron发射合同，且新增任务不少于5次。
  - Reference: 截至2026-10-12，Synspective总计47次合同发射、34次未飞，其中2026-10-01公布的20次新批次已包含在34次中；NASA的两次PolSIR与一次TSIS-2专属任务也已入基线。iQPS在2026-07-30报告的11颗Electron任务是日期快照，之后至少两次发射已完成，不能把11当作当前未飞余额。只计与这些已披露任务不同的新增firm任务。
  - Boundary: 新增至少5次firm专属任务，相当于Synspective新20次批次的四分之一，足以实质扩大已知多年Electron任务池；授权资格、未行使选项和单纯改期不跨此边界。
- C2 / SHORT / OUTER: Synspective明确取消或转由非Electron运载器执行至少5次原已分配给Electron的未飞任务。
  - Reference: Synspective于2026-10-01公布47次合同总量、34次未飞，内含20次新批次；这是本条件的最新可比披露。只比较从Electron任务池明确移除的任务。
  - Boundary: 至少5次被明确取消或转运，相当于已报告34次未飞量的约15%、新20次批次的四分之一；仅在Electron航次间或年份内重新排期仍属时间变化，不是需求流失。
- C3 / SHORT / OUTER: iQPS明确说明至少3颗此前已分配给Electron的卫星改由其他运载器承担，且指明是原有Electron任务而非新增的替代路线任务。
  - Reference: iQPS于2026-07-30披露11颗卫星计划由Electron发射；其后有任务发射，因此11只是历史已宣布任务清单，不能视作当前未飞余额。2026-09-14另行签署的三颗卫星H3搭载协议和2026-09-10面向2029年后的MaiaSpace基础协议均未说明其替代既有Electron任务。
  - Boundary: 至少3颗原Electron任务被明确转走，约为7月披露11颗清单的27%，且达到后来单独签署的三颗H3批次规模；若只是新增H3任务、框架协议或没有明确同一卫星曾属Electron，则不跨边界。

## Electron专属发射合同的收款时点

专属任务的付款里程碑决定Rocket Lab在制造、整合与发射前要垫付多少客户项目现金；预付款越早，越能覆盖火箭制造的直接投入并降低营运资金占用，尾款后移则使相同任务量带来更长的现金风险。管理层对典型商业Electron合同的描述为签约约10%、开始造箭前约60%、发射前约90%，其余约10%在发射后支付；这是通常做法而非每份合同保证。该现金机制可单独改变合同经济性，但没有足够公开的同任务Electron当前价格、折扣、复杂任务工程费和标准化接口成本，不能由Launch板块混合收入/成本推算专属发射价格或标准化利润。

- C1 / LONG / MIDDLE: Rocket Lab公开一项至少5次firm专属Electron任务的合同或修订，约定不少于合同费用的90%在火箭制造开始前支付。
  - Reference: 管理层披露的典型商业Electron合同付款进度为签约约10%、火箭制造开始前约60%、发射前约90%、发射后约10%；其为通常条款而非每笔合同的已知精确条款。
  - Boundary: 至少5次firm任务的费用中90%在开工前收取，比典型约60%节点提前30个百分点，并覆盖Synspective 20次新批次的四分之一；这一现金提前量可显著降低同等任务批次的制造垫资，而仅到发射前90%不构成改善。
- C2 / SHORT / MIDDLE: Rocket Lab公开一项至少5次firm专属Electron任务的新合同或修订，其中至少40%的合同费用仅在发射后到期支付。
  - Reference: 管理层给出的典型商业合同是在发射前支付约90%，发射后约10%；当前没有已公开、可逐项对应的Synspective、iQPS或NASA任务付款条款。
  - Boundary: 至少40%费用推迟到发射后，比典型约10%增加至少30个百分点，并覆盖不少于5次任务；这显著把同一批次的现金回收移出制造与发射阶段。若只是尾款支付期限延长但发射后比例未达到该水平，不足以独立越界。

## 既有Electron客户资金与载荷就绪对发射排期的影响

已签Electron任务仍依赖客户为卫星制造、发射筹资，以及航天器和仪器按期交付；可证实的资金到账降低履约资金约束，而载荷/仪器的公开准备进度或排期跨年会改变近端任务兑现时点。延期会移动窗口、现金里程碑和相关发射活动，不等于订单取消；若合同和卫星仍然存在，长期任务需求可以保留。Synspective的20次2028–2031新批次是34次未飞中的一部分，其¥20bn融资在截至时点仅有计划借款信息；iQPS已有较强融资基线；NASA的三项具名任务则分别依赖PolSIR或TSIS-2载荷及航天器链。没有公布按年份的客户任务/可填补窗口清单，故不能仅凭竞争客户或替代运载器安排推算Rocket Lab窗口已被填补。

- C1 / LONG / OUTER: Synspective确认已实际提取至少¥9.97bn的¥20bn卫星制造/发射定期贷款。
  - Reference: Synspective于2026-09-17披露¥20bn无担保银团定期贷款及拟于2026-09-30借款，资金用途为卫星制造与发射；借款日期是计划，不是已确认到账。截至2026-06-30现金及存款¥16.21bn，2026H1卫星/固定资产现金购置¥9.97bn。
  - Boundary: 实际到账至少¥9.97bn，约为贷款额度的一半、且等于此前半年度的卫星与固定资产现金购置额，足以显著改善该客户为既有批次生产和发射筹资的可用性；额度、签约或原计划日期本身不构成到账，也不证明卫星已就绪或产生新订单。
- C2 / SHORT / OUTER: Synspective或Rocket Lab正式更新排期，将至少5次已宣布的Synspective新Electron任务从原定2028–2031窗口移至2032年或之后。
  - Reference: Synspective于2026-10-01宣布20次新Electron任务预定在2028–2031年安排发射，四年内年度分布并未披露；这20次属于总计34次未飞任务的一部分。
  - Boundary: 至少5次、即该20次批次四分之一被移出原有四年窗口，会明显延后这组已签工作兑现；仍在原窗口内的年份调换可能影响近端节奏，但在未披露逐年分布时不能由总量推算。移出窗口说明时点风险，不单独证明取消或需求丢失。
- C3 / SHORT / OUTER: NASA或任务承包方公开确认PolSIR或TSIS-2中任一具名专属Electron任务从2027年计划延期至2028年或之后。
  - Reference: 截至截止时点NASA的任务页面将PolSIR安排在2027年后段，将TSIS-2安排在2027年；Rocket Lab已获两次PolSIR及一次TSIS-2 Electron专属任务选择。NASA的VADR上限不是Rocket Lab的任务合同价值。
  - Boundary: 任一具名任务跨入下一日历年，即使只是一项，也使既有三项2027任务基线中三分之一至少延后一整年，足以单独改变近端排期预期；这仍是时间移动，不作为任务取消或收入损失的证明。

## SAR终端采购与多年数据服务承诺

政府、保险、通信和灾害管理用户购买的是及时可行动的观测、分析和特定地区/路径的数据优先权，而非卫星本身。Synspective已签的日本防卫省星座项目是现实的多年度采购：Tri-Sat主合同为¥283.1bn（含税），Synspective与Mitsubishi Electric/Tri-Sat的数据获取服务分包为¥105.6bn（含税），期限至2031-03-31；这证明公共采购可支撑持续SAR数据服务，但金额不是Synspective的发射采购或单个卫星成本。DOCOMO/NTT DATA/Synspective灾害影像协议把影像用于基站损害与修复道路评估，并通过真实灾害和持续验证改善工作流；公告未列最低采购量、价格或专属容量。OMNIA则让多用户购买区域/路径优先权、共享余量并可按需加购。新的 firm 数据承诺能改善Synspective收入可见度和建设资金来源；若在既有网络内完成，先增加的是服务收入而非卫星或Electron任务。

- C1 / LONG / OUTER: Synspective或明确披露的项目公司签署一项新增的多年期SAR影像/观测服务采购合同，具有最低购买量或保证的重复优先观测权，且公开披露归属Synspective影像服务范围的合同金额不少于¥26.4bn（含税）。
  - Reference: 截至2026-10-12，已执行的日本防卫省项目中，Synspective影像获取服务分包金额为¥105.6bn（含税），期限为2026-02-19至2031-03-31；防卫省与Tri-Sat的¥283.1bn是主项目总额，不能全部计作Synspective合同。NTT DOCOMO、NTT DATA和Synspective于2026-08-28签署灾害影像使用协议，但未披露最低采购量、服务价格或新容量需求。
  - Boundary: 新增承诺达到现有Synspective大型五年数据服务分包金额的四分之一（¥26.4bn），且保证多年重复购买/优先获取，已足以显著提高该客户的服务收入和为卫星建设筹资的可见度；该条件只更新用户采购质量，不等于新增卫星、发射或Rocket Lab订单。现有MoD项目续行或新闻复述不算新增。
- C2 / SHORT / OUTER: Tri-Sat、Mitsubishi Electric、Synspective或日本防卫省正式披露，对Synspective影像获取服务分包的终止或范围缩减至少达到原签约金额/保证服务范围的25%。
  - Reference: Synspective在2026-02-20披露其在MoD星座项目中承担影像获取服务的分包金额为¥105.6bn（含税），项目期限至2031-03-31。MoD/Tri-Sat主合同的¥283.1bn不是可用于替代Synspective分包基线的金额。
  - Boundary: 至少四分之一的Synspective分包价值或保证服务范围被正式移除，按已披露金额相当于¥26.4bn，足以实质削弱多年度付费需求和项目回收基础；单次灾害任务未发生、短期任务调整或合作关系未续报不等于该边界。此为客户数据采购下修，不直接证明既签Electron发射任务取消。

## SAR共享容量与新增专用卫星的部署强度

Synspective OMNIA计划让多家用户分别持有特定地区/路径的观测优先权、共享余量并按需加购；这降低用户各自建设整套星座的门槛，也可能让现有卫星在新用户间更充分使用，从而减少每个用户对应的新增卫星。与此同时，Synspective宣布OMNIA将建设一套独立于在建StriX网络的新星座，并负责技术更新与补网：只有地域重访/优先保障需求超过已有网络余量且有 firm 买方承诺时，平台采用才会转为新增卫星制造和运输。现有比较面是StriX 30+颗建设规划以及已签20次Electron任务（2028—2031）；这20次已包含在Synspective披露的47次累计任务/34次未飞内，不能再与OMNIA相加。Synspective另有2027年两颗StriX中倾角H3任务并由日本Space Strategy Fund支持；它说明主权路线与轨道分工可并行，不证明Electron旧单被转移，也不应把中倾角H3需求计为Electron机会。

- C1 / LONG / OUTER: 政府或企业买方通过Synspective/已披露项目公司签署或授出一项有预算支持的多年最低容量采购，明确要求建设独立于现有StriX规划及已签20次Electron批次之外的新SAR卫星/星座；新增卫星用于Electron适配轨道，且未被公开分配给H3或其他运载器。
  - Reference: 2026-09-15 OMNIA公告表示将在现有StriX之外建设一套新星座，并允许用户购买特定区域/路径优先观测权或按需加购；公告没有客户名单、最低采购量、预算、卫星数量、时间表或发射服务。2026-10-01另已签20次Electron发射任务，窗口为2028—2031，累计47次合同中34次未飞；该批次不是OMNIA新增订单。2026-09-18的两颗H3任务明确为2027年中倾角轨道，另由日本公共资金支持。
  - Boundary: 新增且有资金支撑的买方容量承诺明确需要一套/一批额外卫星，且不在现有20次发射或已指定H3任务内，首次证明数据服务采购要求超过现有已规划资产。对既有Electron大客户而言，这实质提高未来适配Electron的任务池和多年运输概率，足以早于火箭订单更新预期；不把该买方合同计作Rocket Lab已获发射任务，也不把单颗卫星机械换算为一次Electron。
- C2 / SHORT / MIDDLE: Synspective正式撤回或无限期取消其为OMNIA宣布的独立新星座建设，并确认不再为该独立容量采购新增卫星。
  - Reference: Synspective于2026-09-15明确表示，OMNIA将建设一套独立于在建StriX系列的新增星座；但该计划尚无公布买方、最低采购、资金闭合、星数、时限或新增发射合同。现有20次Electron合同和其他既有任务仍是独立基线。
  - Boundary: 正式撤销独立新星座并停止对应新增卫星采购，移除的是现有StriX/已签Electron任务之外唯一明确的额外资产扩容方案；共享容量仍可带来数据服务采用，但每单位用户需求的新增卫星和运输强度下修。只改分期或更新未来时间表、暂时使用余量、或未披露项目进度不构成撤销。

## Electron适配任务的端到端运输路线分配

Electron专属发射让客户直接获得目标轨道、相位和日期的安排控制；可替代方案必须按完整交付链比较。Falcon 9 rideshare公开的约$350,000/50kg SSO入口价、约每四个月一次的SSO机会，不等于Electron整次专属任务的全链报价：共乘主任务决定出发轨道与时间，OTV末端转移还带来推进剂、时间、接口、集成、保险和交付风险。Impulse的Mira rideshare已飞行并交付过客户载荷，说明末端运输是实际路线，但不代表所有Electron目标轨道均可替代；LEO Express 3的推进剂异常也说明部署成功不等于所有机动能力已验证。Caravan/Helios的后续服务计划和NSSL首个资格准入订单尚非当前可用的重复替代运力。日本SSF资助的Synspective项目以国内发射为默认采购路径，海外路线须因国内服务不能满足轨道、排期、容量等非价格要求而获准；但SSF支持卫星星座建设并非自动指定H3。Synspective已签的20次Electron SSO任务（2028—2031）与2027年另签的两颗H3中倾角任务是不同轨道和批次，后者不能被算作Electron订单转移。因而路线入口、预约开放、卫星建造补贴、项目计划或技术路线宣传只改变选择背景；对Rocket Lab更直接的增量是该批次外新增的Electron付费任务，负面变化则是具体适配任务确已转给替代路线或因有约束力的主权采购条件失去投标资格。

- C1 / LONG / MIDDLE: 客户或政府采购方与Rocket Lab签署或正式授予一项新的、任务明确且有偿的Electron轨道发射服务合同，且该任务不在Synspective已披露的20次2028—2031年Electron SSO批次内。
  - Reference: 截至2026-10-12，Synspective在2026-10-01披露20次新的Electron SSO发射任务，排期范围为2028—2031；其累计47次Electron任务中有34次尚未飞行，这些已签任务构成既有承诺而不是未来新订单。Synspective另有两颗StriX卫星签约H3于2027年发射至中倾角轨道，以及2025年签约的两颗Falcon 9共乘任务；这些均是路线不同的独立任务。
  - Boundary: 一项超出现有20次批次、具名且有约束力的新增Electron任务，已直接增加售出的专属发射服务和客户承诺，足以使未来任务需求预期上修。意向、可选任务、框架容量、预约开放或卫星建设资助不构成发射授标；不要求任务已发射，也不把同一已签任务跨年排期视为新增。
- C2 / SHORT / MIDDLE: 客户或采购方正式取消一项已签约或已公开指定给Electron的具名轨道任务，并明确将该任务改配给另一发射服务或端到端运输路线。
  - Reference: Synspective已公开的20次Electron SSO任务是现有长期需求基线；其2027年H3中倾角任务和Falcon 9共乘任务为并行订单，不是该Electron批次的取消或改配。Rocket Lab合同可能具有各自的窗口和补救条款，公开材料没有给出该20次批次的逐项取消或重飞责任。
  - Boundary: 同一具名任务从Electron合同/明确分配中实际撤出并转给替代路线，直接削减已获或明确规划的Electron需求，足以构成路线份额下修。只改窗口但仍由Electron执行、评估其他供应商、增设第二供应商但不减少Electron任务，或另签轨道/批次不同的H3与共乘合同均不满足。
- C3 / SHORT / OUTER: 新的、有约束力的国内采购或运输资助条件被正式适用于一项具名且已出资的Electron适配任务，并明确排除海外发射服务，使Electron失去该任务的资格。
  - Reference: JAXA的SSF首期执行指引以日本国内发射为默认，并可在国内发射方不能满足排期、轨道、运力等非价格要求时批准海外发射；该规则并不等于所有SSF资金自动买H3。Synspective已经签署的两颗H3任务为2027年中倾角，不能替代其另签的20次太阳同步Electron批次。
  - Boundary: 正式条件必须明确落到一项有资金支持且轨道、任务窗口与Electron能力相适配的具体任务，并实际取消海外路线资格；这样会从可竞争任务池移除Electron，即使尚未形成既有Rocket Lab收入也改变路线竞争预期。一般主权政策表态、仅资助卫星制造、仍允许在国内能力不满足要求时申请海外豁免，或国内路线尚不能交付而外部运输仍可获准，均未跨过边界。

## Electron任务履约、恢复与客户风险承担

Electron未能把客户载荷送入合同目标轨道，会使具体任务失去交付价值，并可能触发合同折让、服务补偿、客户延后/改配或声誉与保险成本变化；这些后果按任务和合同而异，不能把卫星损失或全部补星费用自动归给Rocket Lab。若根因跨批次，或许可/公司暂停影响后续Electron发射，影响从单次任务履约扩展为供给窗口与多项任务兑现；具体是某型号、发射场还是更广范围，决定受影响供给。反过来，已有暂停被适用许可机构解除、纠正措施已实施并可恢复发射，会在完整调查结案或下一次飞行之前重开供给窗口，但不等于全部根因已消除。监管范围按发射地点分别识别：Mahia的LC-1受新西兰发射/场地许可监管并有FAA适用职责；Wallops的LC-2适用美国FAA许可和场地/范围要求，不能把一次许可结论普遍延伸到所有场址。客户保险自留和贷款条件改变现金风险，不等于物理可靠性变化：Synspective九星保单的首次损失由客户自留、以后损失才承保，公告未识别这九星的具体发射服务商；自留可能减弱客户补星支付能力，也可能令其更重视恢复覆盖。Rocket Lab披露不同任务合同可能要求放弃利润、减款或提供替代产品/服务，也称通常不为补救行动和延误取消导致的损失投保；公开资料未给出Synspective逐项重飞条款。因此只有具体Electron任务的已发生失利、实际运营暂停/恢复，或客户资金/风险规则确实改变其具名任务资格/分配时，才将其作为业务方向信号。

- C1 / SHORT / INNER: Rocket Lab或负责调查的机构确认一次Electron任务未能将客户载荷送入该任务合同或公布目标轨道，或未能完成约定部署。
  - Reference: 截至2026-10-12，没有新的Electron发射失利被当前材料记录；2023年9月一次任务失利后，Electron已经按纠正措施获准恢复飞行，该历史问题已属于已知运行基线。2026年Q2有四次Electron轨道任务，未构成新的异常。Rocket Lab年报披露任务合同可能有放弃利润、减款或替代产品/服务等不同补救条款，但未公开逐项客户重飞责任。
  - Boundary: 一次新的、公开确认的任务交付失败即足以使该客户任务的可靠性与补救预期下修；不要求同时证明全型号根因、停飞或客户取消后续合同。未影响目标部署的可修复异常、调查启动、天气延期或一般遥测问题不等同载荷交付失败，也不能据此假定Rocket Lab承担全部卫星资产损失。
- C2 / SHORT / MIDDLE: Electron异常或质量问题导致公司或适用许可机构公开暂停受影响型号/场址的后续发射，且该暂停实际阻止已排定或已签约的Electron任务窗口按原计划执行。
  - Reference: FAA对美国许可活动负责发射事故调查和许可；在新西兰发射还须遵守新西兰发射与场地许可条件。FAA可以在完整调查结束前、纠正措施和公共安全风险得到充分处理后允许恢复飞行；一次异常不自动代表全车队停飞。Rocket Lab当前没有公开的Electron跨批次故障或在途停飞作为基线。
  - Boundary: 官方或公司确认的操作暂停已经影响一项具体可执行窗口，表明受影响范围超出单次异常并使服务供给/客户交付时间受限；需按受影响型号、发射场和任务判断，不要求泛化为所有Electron设施停运。仅调查、检查、纠正措施制定或暂未公布下一窗口但尚未宣布暂停，不足以单独越界。
- C3 / LONG / MIDDLE: 先前实际限制Electron发射的暂停被相关场址/活动所需的许可机构解除，或Rocket Lab正式确认完成纠正措施并恢复受影响Electron任务的发射安排。
  - Reference: 若新异常造成运营暂停，直接受影响的是该场址/型号的可执行发射窗口；调查报告可能仍未完成。FAA的公开规则允许在纠正措施实施且公共安全足够缓解后、调查结案前恢复飞行。Mahia须满足适用于新西兰发射的许可条件和相关FAA职责；Wallops等美国场址按其FAA及范围要求处理，不要求所有地点接受相同双重许可。
  - Boundary: 对受影响范围实际解除飞行限制并重新开放任务安排，已恢复暂停期间被占住的供给能力，足以令交付窗口风险回落；不需要等完整调查报告、全部客户确认留存或下一次发射成功。若此前没有影响运行的暂停，单纯发布调查更新、宣布纠正行动或完成检查不触发本条件。

## HASTE研制测试管线与可付费任务采购

HASTE的业务量由具体技术问题、实验载荷就绪、任务轨迹/窗口和采购资金共同形成，不由“高超音速关注度”或项目预算上限直接决定。Rocket Lab已披露的MACH-TB 2.0 HASTE工作来自TRMC推动、NSWC Crane协作、Kratos牵头的Task Area 1：Rocket Lab披露自己将执行四年20次HASTE任务、合同约1.90亿美元；Kratos的1.45十亿美元是五年Task Area 1全选项上限，不是Rocket Lab金额，也没有逐年飞行分布。Anduril另以自有资金签约三次HASTE、约3,000万美元，显示私人开发者可以不等政府直接授令而购买试飞，但其产品优先级和资本时钟与公共项目不同。RSLP已授予Rocket Lab 12次亚轨道基础任务及最多六次选项，潜在总值2.66亿美元；选项未行使前不等于确定任务，采购公告也没有给出全部逐次型号/载荷分配。Rocket Lab的RSLP任务页识别HASTE为车辆，但不足以把所有选项、时间和任务组合成同一HASTE交付计划。HASTE提供可定制的速度、释放高度、姿态与载荷分离状态，最多约700kg，适用的测试环境是其价值基础。可复用Talon-A已有十余次成功高超音速飞行，可回收试件对需要回收的实验有价值；但空射回收、火箭释放条件、载荷包络与测量任务不同，只有同一测试点的技术要求确实匹配才会分流。DARPA CyPhER Forge仍是以实验飞机验证数字孪生/AI测试代理的研发项目，理论上可减少部分实体试验点，却不是已经被采购机构接受的高超音速试验替代路线。研发进入鉴定阶段也可能产生新的系统联合测试；一次成功试验不能证明武器已部署，亦不能单独证明HASTE需求消失。

- C1 / LONG / MIDDLE: 客户、政府采购机构或承担采购的主承包方正式签署或授予一项额外的有资金约束力的HASTE飞行任务，或公开行使原未确定的任务选项并明确将新增飞行分配给Rocket Lab HASTE。
  - Reference: 截至2026-10-12，已披露的确定HASTE飞行合同包括MACH-TB 2.0下四年20次、约1.90亿美元，以及Anduril三次、约3,000万美元且由Anduril自有资本资助的任务。另有Rocket Lab的RSLP协议：12次基础亚轨道任务和最多六次选项，约2.66亿美元为含选项潜在总值；公司的任务页把RSLP与HASTE关联，但没有给出全部任务的载荷、型号、逐次窗口或选项行使状况。MACH-TB 2.0的1.45十亿美元是Kratos Task Area 1全选项上限，不能计为Rocket Lab合同或发射收入。上述采购年度分布也未披露。
  - Boundary: 一项超出现有确定HASTE范围的具名、有偿新增任务，或一项被正式行使且明确归属HASTE的选项，已经增加Rocket Lab的可支付飞行任务，不必等到实际发射或武器系统完成鉴定。一般项目预算增加、预告/意向、仅给RSLP未行使选项、总额含全部选项的框架上限、没有明确HASTE分配的RSLP任务，以及原有20次任务的排期变更均不跨过边界；新增任务数只更新任务管线，不直接等于当期收入或利润。
- C2 / SHORT / MIDDLE: 客户、项目采购方或主承包方正式减少、终止或改配一项已签约并仍未执行的具名HASTE飞行任务，使其转由另一平台/试验方法完成或从合同范围中移除，且没有由有偿新增HASTE范围替代。
  - Reference: MACH-TB 2.0和Anduril已经签署的HASTE任务构成当前可确认的多年需求基线；RSLP基础任务与最多六次选项是另一采购链。Rocket Lab在2026年10-Q称发射服务合同通常允许客户预先通知后按约定支付终止费，但未披露上述各HASTE合同的逐项取消费、补偿额、重飞义务或任务费用；未行使选项不在公司backlog定义内。
  - Boundary: 一项已经签署且仍有待执行的HASTE任务实际从付费范围中撤出，而不是推迟窗口、载荷暂未就绪或更换测试构型但仍保留已资助任务，意味着该任务的未来HASTE服务工作减少。若公开的终止费/变更价款或等额替代工作保留了原有服务经济性，则不按全额工作损失处理；反之，不能假设终止费等同于被取消的后续任务贡献。仅仅宣布Talon-A、地面测试或模型测试可用，或某个系统试验成功/进入鉴定，不证明具体HASTE任务被取消。

## HASTE任务范围、验收与合同成本风险

HASTE提供的是经集成的火箭飞行、载荷分离与定制释放条件；客户取得的实验数据还取决于载荷、传感器、测量和试验目标是否匹配。应区分火箭是否完成任务、客户是否取得可用测试结果、武器系统是否通过后续鉴定或进入部署，三者不是一个验收事件。DIU在Cassowary Vex公布了HASTE任务采集的推进系统/飞行器遥测和实时轨迹数据，并称其用于与模拟飞行模型比较；这说明有效数据可能由客户/试验机构描述，但一次数据回传不等同于武器已具备作战能力。合同经济时钟又不同于飞行时钟：Rocket Lab的2026Q2披露称六次Electron任务中两次为HASTE，相关收入按履约进度确认且有部分在此前季度已确认；Launch Services总收入44.6百万美元及其他发射收入中5.7百万美元的合同终止/研究收入均混有其他项目，不能分拆为HASTE单位价格或HASTE毛利。MACH-TB 20次/1.90亿美元与Anduril三次/3,000万美元只是捆绑合同，不是标准单次报价；RSLP潜在总值也不能除以18次作为每次HASTE价格。公司10-Q称长期合同通常固定价格，超时收入一般按已发生成本占预计总成本的投入法确认，预计总成本修订或预期亏损会改变当期确认；合同通常允许客户提前通知并支付约定终止费，但未公开这些HASTE合同逐项的准备费、付款里程碑、变更单价、数据验收、终止补偿或免费重飞责任。重复同接口可降低集成工作，但客户折扣或更高数据保证也可能把节省让给买方或带来额外成本。只有明确有偿变更、客户承担责任，或Rocket Lab明确吸收额外成本时，才能把接口/结果消息传到公司回报。

- C1 / LONG / MIDDLE: 客户或采购主承包方与Rocket Lab公开签署一项付费HASTE合同变更，明确为新增轨迹、载荷/测量接口、任务准备或实验范围支付额外价款/费用，而非仅要求将变更并入原固定价范围。
  - Reference: 截至2026-10-12，MACH-TB 2.0的20次HASTE合同与Anduril的三次合同分别披露了批次总值，但没有任务级费用、成本、准备费或接口/轨迹变更机制。RSLP协议披露基础任务和选项总额，却没有逐项任务接受、服务价格或数据保证。2026Q2 HASTE收入按投入进度确认且部分在此前季度确认，不能由飞行日反推本期已确认收入。
  - Boundary: 公开的合同修改已经把额外工作转为新的付费范围，而非由Rocket Lab在原固定价承诺内免费吸收，提升了相关项目的可收费工作和成本回收。若额外费用金额不足以判断净利润，结论只涉及新增付费范围/成本回收，不推定毛利改善；仅有接口变更、工作量增加、客户预告或同接口再次飞行而无新价款不满足。
- C2 / LONG / INNER: Rocket Lab公开披露一项具名HASTE固定价合同在复用标准接口/测量方案后，下调预计完成成本或合同亏损估计，且合同对价未同步下调。
  - Reference: 公司披露HASTE采用投入法时，合同价与预计完工成本共同决定履约进度和预计项目贡献；合同成本估计需要管理层判断，预计合同亏损在首次估计时确认。公开材料没有逐任务HASTE毛利或可对照的标准接口节省额。
  - Boundary: 同一具名固定价HASTE合同的预计剩余成本/预期亏损真实下修，同时合同对价保持，意味着标准化或返工减少形成的成本节省没有被降价抵消，直接改善剩余合同贡献。相同接口再飞、完成一次成功发射、一般性称赞标准化或综合发射部门成本变化，都不足以证明公司留住了节省。
- C3 / SHORT / MIDDLE: 针对一项具体HASTE试验，客户/采购方确认未获得合同约定的试验结果，并明确要求Rocket Lab承担无新增费用的重飞、退款、抵扣或其他补偿；或Rocket Lab确认该补救义务由其承担。
  - Reference: HASTE可为载荷设计速度、释放高度、姿态和分离条件；是否获得有效实验数据还受客户载荷和测量链影响。DIU公开的Cassowary Vex报告区分了任务发射与遥测/轨迹数据用途。现有MACH-TB、Anduril及RSLP公开材料未披露结果验收或Rocket Lab免费重飞条款；公司披露不同合同的终止与补救安排会不同。
  - Boundary: 须由客户、采购方或Rocket Lab公开确认：所约定的测试结果未实现，且补救责任实际落到Rocket Lab且没有新增有偿任务范围。这样既有新增履约成本/延后资源占用又没有对应费用，足以压低该任务的预期贡献。实验载荷未得到预期数据但原因、服务责任或费用归属未公开，HASTE已成功释放载荷而测试本身未通过，或客户自费安排了另一次测试，均不能直接视为Rocket Lab无偿重飞责任。
- C4 / SHORT / INNER: Rocket Lab在公开财报或合同更新中披露一项具名HASTE固定价合同的预计完工成本上修，已经降低该合同的预计剩余贡献/毛利，或确认预期合同亏损；未获补偿的任务或接口返工是可识别的影响因素。
  - Reference: 截至2026Q2，公司将HASTE纳入Launch Services收入，披露其履约进度和混合发射收入，但未披露HASTE分项毛利、逐项目EAC、标准准备费或返工金额。公司10-Q说明固定价合同在成本预计超过对价时，于首次估计亏损的期间确认合同损失。
  - Boundary: 具名HASTE固定价合同的预计完工成本上修已经压低剩余合同贡献，或进入预期亏损，直接下修项目经济性；不必等待累计成本超过全部对价或项目实际亏损结账。一般部门毛利回落、综合收入确认变化、单次任务延期、估算小幅波动而未影响合同贡献，或没有项目归属的公司整体成本上升，不能套用到HASTE。

## 高超音速验证方法与实体飞行试验组合

高超音速研发是否继续需要亚轨道火箭飞行，不由“模型更快”或“同为Mach 5+”直接决定，而取决于具体测试点的环境、持续时间、释放/轨迹、载荷与测量目标，以及验收方是否允许另一种路径替代。Rocket Lab称HASTE是Electron的亚轨道变型，载荷能力最高约700 kg，可按火箭任务配置向air-breathing、glide、ballistic及再入测试载荷提供超过7.5 km/s的部署速度；2026年3月披露的MACH-TB 2.0批次为4年20次HASTE、合同约1.90亿美元，算术均分不是年度节拍或单次价格。Anduril另签3次自费任务；RSLP有12次基础亚轨道任务和最多6次选项，但不能把每项都视为HASTE。另一条真实路径已非纯概念：Stratolaunch称Talon-A已超过10次高超音速飞行并重复回收，TRMC于2026年授予其MACH-TB 2.0 Task 3一项9,080万美元、两年内多次空射能力测试合同；同一MACH-TB体系同时存在Rocket Lab的20次HASTE安排，说明当前是任务分工/组合竞争，未证明火箭测试已被替代。Stratolaunch于2026年9月购入777并计划2027年完成改装，35%容量提升是公司对未来载机组合的描述，不是截止时已投入的试飞供给。DARPA CyPhER Forge招标目标是数字孪生与AI测试代理把开发型系统所需测试点降低一个数量级，但其三阶段30个月计划仍以实验飞机飞行作为主要演示/验证环境；“测试点”不等于火箭飞行数，也不是已被采购/鉴定机构接受的高超音速豁免。若低成本、可回收早期测试确实满足同一已定义包络，或模型输出正式替代原需实飞的验证，采购者减少实体火箭测试量会压低可捕获需求；若较快的筛选让更多构型进入终端联合鉴定，且新增计划仍保留火箭才可实现的速度/轨迹/测量阶段，则项目层面的实体火箭测试需求可扩大。足以改判断的是具名项目的正式测试计划、验证/验收口径或有资金支持的测试阶段增减，而非平台宣称、Mach标签、模拟软件里程碑或一次成功飞行。

- C1 / LONG / MIDDLE: 一个具名高超音速武器/飞行器研发计划的采购方、试验主管机构或主承包商公开发布正式的测试计划修订、具资金支持的采购/任务公告或被资助的项目阶段，将模型、地面试验或可回收空射用作早期筛选后，明确保留并新增一个独立、与HASTE可服务的高速度亚轨道测试环境相容的火箭实体飞行测试campaign/阶段，用于更高能量包络、终端集成或联合鉴定；该新增火箭阶段不只是把当前已资助的HASTE任务改期或改名。
  - Reference: 截至2026-10-12 08:45 UTC，已具名的HASTE需求包括MACH-TB 2.0四年20次、约1.90亿美元，及Anduril三次自费任务；RSLP为12次基础任务加最多6次选项，不能全部视作HASTE或全部已行使。Stratolaunch已获MACH-TB 2.0 Task 3的9,080万美元、多次空射测试合同，且MACH-TB体系中该空射路线与HASTE批次同时存在；Talon-A已有重复飞行/回收记录。新购777预计2027年改装。DARPA CyPhER Forge仍为研发招标/预期示范，目标减测试点并在实验飞机上飞行验证，尚非高超音速试验验收制度变更。已公开资料未提供HASTE逐年排期、各类环境可互换比例或测试机构今后应保留的火箭试验数量。
  - Boundary: 一项新的、独立于已披露HASTE任务分配的正式火箭亚轨道飞行测试campaign已经被具名项目计划/资金公告纳入，并对应筛选后仍需实飞、且测试计划所述轨迹/速度环境落在HASTE公开任务能力范围内的阶段；这足以把回收空射/模型方法与一条新增、可被HASTE服务类型捕获的实体测试路径连接起来，无需同一消息宣布Rocket Lab获单。仅发布研发目标、招标数字孪生、展示一次飞行、宣布更低测试成本或新增一项空射合同而未增加火箭阶段，均不足；既有合同下测试次序调整也不构成新增需求。
- C2 / SHORT / MIDDLE: 具名高超音速测试计划的采购方、验证机构或主承包商正式修订资助/测试要求，明确以可回收空射平台完成原计划由HASTE可服务的火箭亚轨道飞行承担的同一测试目标或测试包络，并因此删除、缩减或不再资助原计划中的火箭飞行阶段。
  - Reference: 截止时已有HASTE多年度任务和空射平台多次实际飞行及MACH-TB Task 3空射合同并行；因此空射供给成熟、9,080万美元合同或未来载机容量增加本身并不能证明火箭测试被分流。HASTE的亚轨道火箭释放与Talon-A的空射、返回/回收提供不同任务环境；公开材料未建立这些平台在所有高度、持续时间、轨迹、载荷或测量上的等效性。777改装预计在2027年完成，当前不能算新增有效飞行容量。
  - Boundary: 至少一个原本已列入正式资助/计划的火箭亚轨道测试阶段被明确改配或删减，且验证机构接受空射回收路线满足同一规定测试目标；该项目已从并行路线转为真实替代，直接减少一项具名项目中可由HASTE型服务承担的实体测试机会。此处观察的是未来项目/预算组合的上游变化，不把它解释为某份已签HASTE合同的合同取消损失；若公开了Rocket Lab具体合同削减，应由既有任务合同Policy另外判定。新空射飞机、一般性“成本更低”宣传、同一MACH-TB下新增空射任务，若没有原火箭试验量被取消/缩减及同目标验收说明，不越界；不推断其他程序或已签HASTE合同一并取消。
- C3 / SHORT / MIDDLE: 对具名高超音速研发系统负责的试验/鉴定机构或采购方公开接受数字孪生、AI自适应测试等模型证据作为此前要求的实体火箭测试之替代，并据此修订该系统已批准或已资助的测试计划，删除或缩减相应的、HASTE可服务环境范围内的亚轨道火箭飞行阶段。
  - Reference: DARPA CyPhER Forge 2026年招标计划通过数字孪生和AI测试代理把开发系统的测试点目标降低一个数量级，但其30个月三阶段方案以仪表化实验飞机进行飞行验证，项目本身既未证明技术达标，也未证明其他高超音速项目的主管机构接受该方法替代火箭试飞。HASTE现有20次任务等已有采购是基线，模型计划并未公开减少这些任务。
  - Boundary: 正式测试/验收文件把一个原有、单独资助或列入项目计划的亚轨道火箭飞行阶段改为接受模型/自适应测试结果，并相应撤销或缩减该火箭测试任务，即达到有意义的替代边界；这是计划/验收制度对未来实体测试需求的上游修订，不推断已签HASTE任务的收入取消或终止费影响。要求的是项目层面少了至少一个火箭实飞阶段，而不是试验数据点减少十倍、地面模拟增加、试验代理演示成功或一般研发技术采用；若模型只优化飞行选点而终端火箭验证仍在计划中，不跨边界。

## GHOST部署地点就绪、campaign兑现与付费移动需求

Rocket Lab于2026-08-10宣布GHOST将把Electron/HASTE、地面支持和范围控制装入集装箱，首个地点为AAC运营的Pacific Spaceport Complex-Alaska（PSCA），拟建两台，目标2027年首次阿拉斯加亚轨道运营任务。该公告是计划，不是场地验收、任务许可、载荷适配或客户campaign。FAA现有PSCA站点运营许可由AAC持有；站点运营许可与Rocket Lab具体运载器/任务的发射授权、适用场地范围、载荷审查、测量与空海域支持并非一回事。地理部署的增量价值在于让此前不可执行的航迹、落区、窗口或主权客户集合变得可服务，而非增加两台就等于产能翻倍；任务仍受合格运载器、兼容载荷、范围仪器和本地许可约束。单个获批campaign可以验证某一地点和任务的可执行性，但不能代表跨境部署已可复制、重复需求已形成或设施投资已回收。现有材料没有披露移动部署费、当地改造/公共范围的付款分工、单次campaign利润或闲置成本，不能从技术可移动性推导正回报。

- C1 / LONG / MIDDLE: Rocket Lab、AAC/PSCA、适用监管者或客户公开确认：首个Kodiak GHOST/LC-4 campaign已成为具名、进入可执行发射窗口的HASTE任务（可以是运营首秀或客户任务，不预设付款方）；完成该任务适用的场地/运载器授权，range测量与跟踪、空海域及安全支持已可用，且载荷已集成并适配HASTE公开能力。
  - Reference: 截止2026-10-12，Rocket Lab只公布PSCA/Kodiak为GHOST首个地点、计划两台并以2027年亚轨道任务作为运营首秀；尚无已公布的首个具名载荷、任务窗口或LC-4完整运行授权/范围支持验收。AAC现有FAA站点运营许可不等于Rocket Lab该车辆/载荷/轨迹已获任务授权。
  - Boundary: 适用授权、范围测量/窗口与已集成兼容载荷共同进入一个具名的运营首秀/客户campaign，是从设施投资和公司目标转为真实可执行场景的最早公开充分边界；它提高2027新地点交付概率，不需等实际发射成功。若该首秀由Rocket Lab自费演示而非第三方付费任务，它只降低技术/场地风险，不表示已获新客户、收入或设施回报。只有站点许可、地面设备到场、一般发射窗口或未明确地点/车辆/任务的合同选项不够。
- C2 / LONG / MIDDLE: 一国政府/盟国采购者或其他具名客户公开向Rocket Lab授予或签署有资金约束力的第二地点移动部署合同，合同范围明确包括GHOST部署及一项Electron轨道或HASTE亚轨道campaign，并由场地主体/当地范围方确认该地点和所需任务支持已进入实施。
  - Reference: 现有唯一公开的GHOST地点是Kodiak；公司称国际主权轨道/亚轨道需求为目标，但截至cutoff没有公布第二部署地点、付费当地campaign或公开的移动部署合同价/费用分摊。海外Electron订单和既有HASTE采购是独立路线，不能自动归给GHOST。
  - Boundary: 一份明确付费、指定新地点并实际购买移动部署及发射/试验campaign的合同，首次证明除Kodiak计划以外的客户愿为新地理场景承担采购责任，足以扩大可服务客户/轨迹集合；无需合同披露全部价格、毛利或后续重复次数。仅意向书、主权能力倡议、公共范围建设拨款、无地点/车辆范围的框架合同，或一般Electron订单而没有GHOST部署承诺均不足。该合同不等于已证明可持续利用率或所有本地费用由客户承担。
- C3 / SHORT / MIDDLE: 主管监管者、场地主体或范围运营者正式拒绝、撤回或实质限制一项已公布且有资金支持的GHOST campaign所必需的场地/运载器授权、range测量/安全或空海域支持；Rocket Lab或客户确认因此取消该campaign，或将其移出此前公布的执行窗口。
  - Reference: 公司将Kodiak首个GHOST亚轨道运营任务定在2027年；新地理部署另依场地许可、兼容车辆/载荷、范围测量和任务窗口。当前资料未证明这些条件均已为LC-4或其他海外地点完成。
  - Boundary: 一项直接作用于具名campaign的授权/范围阻断并导致取消或错过已公布窗口，会下修地点激活与可用需求实现概率；其判断基于明确的项目窗口变化，而非把建设过程未披露当作失败。一般审批流程、仍在原窗口内的准备工作、可替代日期的日常天气改期，或与GHOST无关的许可变动不满足。

## 跨型号制造节拍、质量放行与共享资源

Rocket Lab披露的2026H1 Electron系列制造11枚、执行12次，以及2025全年制造24枚、执行21次，分别是期间流量，不能用差额倒算库存或最大年产能；2026-06-30 Launch Services backlog 940.2百万美元也跨型号、跨履约时点。制造/发动机/结构/整合/测试分布于Long Beach、Auckland、Middle River、Stennis和Wallops，长期资产、设备及部分工程资源共用而型号仍有专属工序。公司称直接人工和制造间接费用占重要成本，提高合格生产率是成本吸收的关键杠杆。设备到位、名义台数或初件完成并不等于可交付硬件；重复质量放行、库存可用和复产能力才把生产活动转成多个型号的可执行供给。Neutron资格工作与HASTE集成若占用共同团队/测试资源，可能先挤动具名成熟任务而非令需求消失；关键厂区、公用服务或设备停用也可限制某条合格产线。新增产出释放后瓶颈可转至客户载荷、任务集成或范围窗口，不能把发射场机会数当作制造供给。

- C1 / LONG / INNER: Rocket Lab公开确认一项此前受限的火箭制造/检验/测试工序或合格备用线已完成生产资格，且多批次飞行硬件通过该工序的质量放行；公司同时确认其缩短了相对原工序的放行周期、恢复了受阻供给或提高了可持续合格产出节拍。
  - Reference: 截至cutoff，2026H1制造11枚、执行12次，2025全年制造24枚、执行21次；库存余额、型号分项、重复放行周期和持续合格产能未公开。公司称提高产率有助吸收人工/制造间接费用，但现有披露并未量化自动化、质量学习或专用团队贡献。
  - Boundary: 经生产资格后的重复飞行硬件放行并有公司明确的放行周期/持续节拍改善或受阻产出恢复，首次把设备或人员投入转化为可交付的合格供给，且支持成本吸收预期。首件/原型、设备安装、招聘、未飞行的部件、单季制造数与发射数差额或发射场容量描述都不足以证明可持续合格产出；无需等待完整年度产量增长。
- C2 / SHORT / INNER: Rocket Lab或具名项目办公室公开说明Neutron资格、HASTE集成或其他高优先级项目已经占用共享制造/工程/检验/测试资源，并因此将一项有资金支持的成熟火箭硬件放行、客户交付或既定发射窗口移出原已公布安排。
  - Reference: Electron/HASTE持续执行、Neutron资格及开发同时进行，部分工程、资产和测试资源共享但另有型号专属工序；现有材料未确认具体资源已发生挤占，也不提供各型号可用库存。上半年生产与任务计数不能证明有或没有缓冲。
  - Boundary: 对一个具名承诺的硬件/任务窗口，公开归因于共享资源从成熟业务转向Neutron资格或HASTE集成且被移出既定窗口，已经确认跨型号机会成本；不必等公司整体制造量或总发射数下降。仅两个项目同时推进、普通工程里程碑调整、或延期归因于客户载荷而非共享资源，不满足。
- C3 / SHORT / INNER: Rocket Lab、设施运营方或公用服务方确认某一关键火箭制造/整合/资格测试场地、设备或必要公用服务发生持续性中断或质量隔离，且Rocket Lab确认一批已计划的飞行硬件不能按原安排放行或具名任务交付窗口被推后。
  - Reference: 公司在年报中披露部分工序和制造集中、并不维持备份制造设施/作业的风险；截至2026-10-12未见已发生的火箭生产场地/公用服务中断。缓冲库存可能吸收短时停机，故不把风险披露本身计成当期停产。
  - Boundary: 关键作业停用或质量隔离已传到一批具体飞行硬件无法放行/客户任务窗口后移，足以改变实际供给和工序恢复预期；无需发生全公司产量下滑或多型号同时停产。只报故障但未影响生产/测试的短时事件、通用天气、或厂区修复计划不跨边界。

## 关键外购火箭输入、可替代资格与供给成本

Rocket Lab高度垂直整合，但其年报说明仍从外部采购部分单一/有限来源的材料、组件、子系统和设备；风险类别包括化学品、复合材料、电子/机电/机械件、稀土及子组件。公司称对单一来源尤其长交期件持有额外缓冲，且当前认为多数来源总体充足；本轮没有证据证明某一具名供应商正在短缺。缓冲可吸收短时延迟，供应持续中断超过覆盖或质量召回使已到货批次不可放行时，关键小件也可能卡住特定型号整箭。更换来源只有通过工程/质量验证并进入飞行生产放行，才形成可替代供给；新采购单、送样或实验室通过不能替代已认证硬件。保持交付但涨价是另一条路径：在固定价订单且不能获得客户价格调整/成本补偿时，增加预计材料成本会压缩项目贡献；若可转嫁或仅适用于未来新合同，则不等于产出中断。公司未披露各输入的型号映射、库存覆盖天数或成本转嫁比例，不能推断任何特定供应商/型号已短缺。

- C1 / LONG / MIDDLE: Rocket Lab公开确认一种此前单一/有限来源且用于某一在产Electron、HASTE或Neutron飞行硬件的关键输入，已完成第二来源或替代材料的生产/飞行资格认证，并已有使用该来源的硬件通过质量放行、可用于实际任务。
  - Reference: 2025年10-K披露部分投入和服务为单一来源，长交期件由额外缓冲库存管理；公司同时称大多数原料/组件来源总体充足。当前没有已确认的具名供应方短缺、具体部件库存或量化替代认证时间。
  - Boundary: 新来源已通过生产/飞行资格且其硬件能够进入当前型号的可放行任务库存，足以降低一个关键输入的单点供应暴露，而无需假设已发生短缺或证明全部型号都已双供。仅有采购、供应商入围、台架样件、工程验证或尚未完成批准的替代设计不代表可替代产出。
- C2 / SHORT / OUTER: 供应商或主管机关公开对一项Rocket Lab确认用于当前某型号飞行硬件的单一/有限来源关键输入实施停供、产品退出、出口限制或质量召回/隔离，且Rocket Lab确认受影响的在制/已制飞行硬件无法按当前资格放行或没有在相关任务窗口前可用的合格替代，导致至少一个具名批次/交付安排受阻。
  - Reference: 年报称单一来源情形以缓冲库存应对长交期，当前材料认为供应来源总体充足并未确认具名短缺；不同输入只适用某些型号或工序，影响不应扩展至未受影响的火箭和合同。
  - Boundary: 外部停供/召回/出口措施已经使一个具名型号的飞行硬件批次无法按原资格放行或推迟其交付，说明缓冲不足以消除该次事件的生产影响；单一批次/客户窗口的受阻已具独立供给意义，不必等全公司制造或发射数下滑。若有已获批替代品或可用缓冲仍完全覆盖计划，或只是泛行业传闻，则不跨界。
- C3 / SHORT / INNER: Rocket Lab公开确认某关键外购材料/组件涨价适用于现有固定价火箭生产或发射合同，并且没有客户调价、变更单或其他补偿抵消；公司对该具名合同提高预计完工成本/下调剩余贡献，或确认因此形成预期合同亏损。
  - Reference: 公司年报明确原材料价格上涨可能影响固定价业务；未披露逐供应商/型号的采购价格、具体固定价合同承受比例或本轮已发生的材料成本上修。只增加货币成本而持续供应，与不能取得部件导致的产量风险不同。
  - Boundary: 非转嫁输入涨价已进入具名固定价合同的预计成本/亏损并压低剩余贡献，足以修订公司可留存的合同经济性；不要求材料停供或全公司毛利下降。供应商报价提高但交货未受限、尚未进入既有订单、客户接受价格调整或成本被另一项补偿覆盖，都不满足。

## 可用发射场地权与公共范围排期资源

Rocket Lab交付的是受场地权、适用轨迹和公共范围支持约束的发射服务；有火箭、有产线不等于在客户要求的地点、轨道和窗口可以发射。公司披露的LC-1 Mahia租约截至2027-11-30，并有三项各三年的续租选择；两座pad和每年最多120次launch opportunity是场地/许可上限，不是实际吞吐或制造产能。Wallops的LC-2许可上限为每年8次，LC-3在建、为Neutron服务且当前许可上限为每年2次并待进一步评估；其轨道与客户需求不能与Mahia任意互换。海空域关闭、测量跟踪、军方/科研优先窗口和天气会推迟可用slot；若改期越过完整的兼容发射季且没有可保留客户窗口的替代地点，实际履约机会才改变。极端天气毁坏pad或独有范围设施则另有修复资本和长期停用风险。固定租金、范围费用和建造融资也会改变单位经济，但目前披露没有可按场地拆分的旧费率基线，不从一般涨费表态推造数值阈值。2026年Vandenberg SLC-9征询要求私人供方融资、设计、建造和运营，且不是火箭服务采购或场地授予；获得可执行使用权会是新接入选择，但不等于建成、获发射许可或获得任务。新场地/公共范围资源不增加火箭制造能力；已有政府采购条件和Electron任务路线分配另见既有路线Policy。

- C1 / LONG / MIDDLE: Rocket Lab或其受控实体与政府/场地主体签署或获得正式生效的发射场用地、经营/使用权或范围接入协议，协议明确允许Rocket Lab以其具体运载器类别从该地点申请或预约至少一种与公司已披露任务能力相容的轨迹窗口；新国内场地 outgrant 只有在赋予Rocket Lab自身发射服务使用权，而非仅替政府建设/运维设施时适用。
  - Reference: 截至2026-10-12，Rocket Lab披露的LC-1租约至2027-11-30并有三项三年续租选择；LC-2、LC-3的权利期限分别至2028-09-28和2034-02-15，服务能力、轨迹和当前建设状态各异。120/8/2是各自的许可或机会数量上限，不是可互换的实飞产量。Vandenberg SLC-9在2026年6月仍是询求业界融资、设计、建设和运营的RFI；材料未证明Rocket Lab获选或得到outgrant。
  - Boundary: 具约束力的场地/范围接入权本身使Rocket Lab可实际控制或预约一个新的兼容地点/窗口，从“可能开放”变成有权进入的市场选项；不必等到建成或首飞才上修接入选择。仅入围、RFI、获准研究、建设计划、公共场地政策目标，或只替他方建设却无Rocket Lab发射使用权的合同都不够。新权利仍受建造融资、环境评估和独立发射/安全许可约束，故此边界确认接入权而非即刻可飞容量或已获客户订单。
- C2 / SHORT / MIDDLE: 场地主体、监管者或范围运营者正式终止、拒绝续签/行使续租选择，或实质缩减Rocket Lab在一处在用场地的发射使用权/轨迹窗口，令该地点所服务的已公开任务类型或客户窗口失去可用接入，且现有其他已获权场地不能保留同一任务所需轨迹与窗口。
  - Reference: LC-1当前租期虽截至2027-11-30，但公司披露三项各三年的续租选择；Wallops LC-2/LC-3亦有各自访问期限。故租约日期本身不是关停信号，且一地pad或许可上限不能推导其他地点可替代。
  - Boundary: 当有权主体的正式决定实际消除一项现有场地权利/窗口，且该任务类别无法用Rocket Lab现有、同轨迹且能保留客户窗口的地点接续时，Rocket Lab可服务任务集合即缩小。只讨论费用或续租、尚可行使的续租选择到期日、短暂停场、或已有合适替代slot的改派均未跨过边界。
- C3 / SHORT / MIDDLE: range/空海域/测量跟踪/军事或科研优先排期，或持续天气条件，令Rocket Lab一项已排定并公开可识别的付费/政府客户发射任务错过其下一完整兼容发射季；Rocket Lab、客户、场地主体或有权range运营者明确该延误不能通过另一现有场地/slot保留原任务所需窗口。
  - Reference: LC-1、LC-2和LC-3的许可额度与轨迹用途不同，当前披露没有显示所有场地均满载，也没有公开的可替代slot总表。因此，一般天气概率、单日延期或平均等待不构成供应紧张的证据；实际任务日程与其目标轨道/客户窗口是可直接比较的基线。
  - Boundary: 一项具名任务被移出下一完整兼容发射季且没有现存替代slot，已经把客户交付推迟至少一个适用的发射季，显示公共range/窗口而非火箭制造在限制履约。仅天气预报、季内改期、没有实际任务排期的范围优先级表态或可保留客户窗口的转场不足；不要求再等到合同取消或财务结果确认。
- C4 / SHORT / MIDDLE: 极端天气或其他自然灾害造成Rocket Lab在用发射场、pad或其不可替代的range测量/安全设施出现经运营方或公司确认的实体损毁，并使受影响的兼容发射活动至少停用一个完整发射季。
  - Reference: 场地接入和实体设施是长期固定资源；天气导致短时窗口变化与设施毁损后的修复/资本损失不同。公司公开的场地许可上限不说明设施替换成本、保险回收或剩余pad是否能执行相同任务。
  - Boundary: 实际资产损毁并跨过一个完整兼容发射季仍无法支持发射，足以证明从临时天气延误转为持续的范围供给/资本恢复问题；普通恶劣天气、无资产影响的临时停场或当季内修复均不触发。该判断不推定未披露的损失金额或保险责任。

## 跨境与任务级许可决定的合法可服务集合

运载器能飞、站点有权使用，并不表示所有客户载荷、技术转移、国家来源或轨迹都已合法获准。FAA Part 450为许可范围和组合运营提供了较大灵活性，Electron完成转换不等于Neutron、其他地点、配置或客户载荷自动获批；发射运营许可、站点许可、载荷审查及出口/技术转移权限各有不同主管路径。美国—新西兰技术保障安排支持特定跨境活动，但不是所有技术、国家和任务的通行许可；新西兰法律另设运载器、设施和载荷的许可/批准，部长可按国家利益、安全与国际义务审查具体申请。新西兰并未把安全载荷一概禁止，判断是个案性的。一次正式授权可首次打开此前不能合法服务的载荷/车型/地点组合；相反，最终拒绝、撤销或新限制可让一个已有可服务的任务类别消失。新闻中的一般国家安全表态、既存双边安排或Part 450制度本身都不代表具体项目已获准；应看正式决定覆盖的主体、车辆、地点、载荷类别、跨境环节和生效时间。

- C1 / LONG / MIDDLE: 有管辖权的监管者正式签发、修改或确认一项适用于Rocket Lab的运营/站点/载荷/出口或跨境许可，使一项此前未获授权的具名车辆—地点—轨迹配置，或有明确边界的客户载荷/国家类别，首次进入Rocket Lab可合法提供发射服务的范围。
  - Reference: 截至2026-10-12，Electron已完成Part 450转换，但Part 450本身不自动批准每个站点、车型配置、载荷或出口。美国与新西兰的技术保障安排只覆盖其约定范围；新西兰OSHAA对运载器、设施与载荷设有各自许可/批准。现有材料没有证明Neutron或任意GHOST任务在任何地点已获全面许可，也没有披露一项普遍适用的载荷/跨境许可。
  - Boundary: 最终、具约束力的许可决定明确扩大原本未获授权的Rocket Lab服务范围，即打开一个具体的车辆/地点/轨迹或客户载荷类别合法入口；这改变可寻址且合规的任务集合，不必等到新客户授标或首次飞行。已有许可重述、行政流程提速、一般双边合作或只允许既有已许可Electron配置的常规续期不构成新增。
- C2 / SHORT / MIDDLE: 有管辖权的监管者作出已生效的拒绝、撤销或实质附款/限制，令Rocket Lab一项目前合法可服务的车辆—地点—轨迹组合或一类有边界的客户载荷/跨境任务不再可执行；对于单一任务许可，决定直接使已公开的Rocket Lab客户Campaign无法使用任何已持有的等效许可路线。
  - Reference: 现有许可不是全球统一许可：站点、运载器、载荷审查与技术转移分开，跨境安排及客户/国家限制按具体适用范围判断。新西兰国家利益审查可逐案处理，但安全载荷并非天然不准；一般讨论或被拒的其他主体申请不改变Rocket Lab当前权限。
  - Boundary: 正式生效的决定确实从现有合法服务集合中移除一个重复/明确的客户类别，或直接阻断一项已公开任务且没有Rocket Lab已持有的等效合法路线，足以降低该市场的可服务性。一般政策言论、仍在审理中的申请、对其他供应商的限制、未落到Rocket Lab车辆/地点/任务范围的出口担忧或可由现有许可路线完成的改派均不足。

## Neutron关键系统资格与整箭地面集成路径

Neutron仍处于开发和资格阶段。2026年1月21日一级贮箱静液压试验破裂；公司随后将首飞目标调整到2026年第四季度。到2026年8月，公司仍称大型结构至组件的资格试验、Archimedes发动机测试和首飞硬件集成在推进，并把一级贮箱送达Wallops发射台的目标放在第四季度，同时称年末首飞窗口正在收窄。送达发射台只是物流节点，不等于整箭地面接口验证、发射许可或首飞。贮箱复验、发动机资格和整级/整箭地面接口处于不同的风险门：任一代表性通过可移除其对应的关键路径不确定性，但子系统通过不等于整箭合格；若故障只是局部工装或制造缺陷，返工可能局限于单个组件，若涉及材料、结构或发动机接口设计则既有验证可能失效并需重新资格，显著延长工时、占用测试资源并增加项目现金需求。即使飞行硬件成熟，地面系统、加注和发射操作也可能成为新的关键路径。因此应分别观察资格结果、重新设计范围、到台与首飞两个时间节点，而不必等完整实飞才识别风险。公开披露没有给出剩余Neutron专属预算；公司总研发费用还包含收购业务、人员和其他项目，不能从总额推算本项目剩余成本或首飞经济性。

- C1 / LONG / MIDDLE: Rocket Lab确认替换或修复后的首飞构型一级贮箱完成规定的压力及相关资格复验，并获准用于后续首飞硬件集成。
  - Reference: 2026年1月21日一级贮箱静液压试验破裂；截至2026年8月，公司仍将一级贮箱资格和送台准备列为进行中的关键工作，并以2026年第四季度送达Wallops发射台为目标。公开材料尚未确认受影响贮箱的资格闭环。
  - Boundary: 公司明确报告代表首飞构型的贮箱已通过其规定复验并获准集成；仅有新贮箱制造、抵达设施或单次非资格性试压不越界。该节点足以降低贮箱这一已发生故障对开发路径的风险，但不代表整级或整箭已合格。
- C2 / LONG / MIDDLE: Rocket Lab宣布Archimedes飞行构型发动机资格测试活动完成，并确认发动机进入首飞构型整级集成。
  - Reference: 截至2026年8月，公司描述Archimedes测试仍在推进；发动机进展与整箭成熟是不同门槛，尚无公开的资格活动完成声明。
  - Boundary: 以公司确认相关飞行构型资格活动结束并放行整级集成为边界；一次点火、热试车或中间测试成功本身不足。完成发动机资格是独立的关键路径风险下降，不宣告贮箱、整箭、地面系统或飞行已经合格。
- C3 / LONG / MIDDLE: 首飞代表性整级/整箭与Wallops地面系统完成公司计划的端到端集成接口测试或发射演练，并被宣布通过、转入后续发射处理。
  - Reference: 2026年8月的公开基线是首飞硬件集成/准备进行中、资格测试仍在推进；没有已披露的首飞构型整箭及发射台接口端到端验收通过。
  - Boundary: 公司报告有代表性的车辆—发射台地面接口测试/演练完整通过并放行后续发射处理即可越界；只完成设备安装、单项检查或整级静态测试不等于地面接口闭环。该信号能证明关键地面集成路径前进，无需等首飞，但不等于飞行验证、发射许可或全部任务准备就绪。
- C4 / SHORT / MIDDLE: Rocket Lab或可信的正式披露确认Neutron贮箱/一级结构或发动机—箭体接口的材料、结构或设计缺陷要求改变飞行设计并对受影响关键硬件重新进行资格验证。
  - Reference: 一级贮箱已发生试验破裂，资格工作仍在推进；截至截止日，所映射的公开材料未将问题定性为需要整车层面材料/结构/接口重新设计，也未报告受影响资格工作已闭环。
  - Boundary: 越界需要明确的设计层面纠正以及由此产生的关键件重新资格/已完成验证失效；单一工装、制造批次或试验设备的局部修复，若不改变飞行设计或推翻已完成验证，不足以触发。重大重新设计会延长资格路径并增加项目执行和资金压力，即使公司尚未正式移动首飞日期也已是独立风险信号。
- C5 / SHORT / MIDDLE: 公司将一级贮箱/首飞硬件送达Wallops发射台的公开目标从2026年第四季度正式移至2027年或更晚，或明确表示无法在该季度送台。
  - Reference: 2026年8月10-Q披露一级贮箱生产与2026年第四季度送达Wallops发射台目标对齐；该表述是目标而非已确定的具体日期。
  - Boundary: 正式目标跨出2026年第四季度即越界；仍维持Q4目标但窗口变窄、单项测试延期而未改目标，不足以触发。送台延后直接推迟整箭地面集成的可用时间，且不应与实际首飞日期混为一谈。
- C6 / SHORT / MIDDLE: 公司因Neutron技术资格或地面操作关键路径，正式确认2026年内首次飞行已不可行或将首飞窗口移至2027年，即使送台目标尚未变更。
  - Reference: 2026年2月公司将首飞目标调整为2026年第四季度；2026年8月披露年末首飞窗口正在收窄，并称时点取决于一级资格及后续关键测试。尚未披露首飞具体日期，窗口收窄本身已是基线而不是窗口取消。
  - Boundary: 明确撤销2026年首飞窗口、把首次飞行安排到2027年或说明2026年首飞已不可实现，且原因是技术资格/地面集成或操作准备，即越界。仅重复‘窗口收窄’或保留Q4目标不越界；此条件与Q4送台目标分别校准，因为到台并不代表能够在年内飞行。

## Neutron专属投入、战略开发合作与现金约束

Neutron的长期价值需从开发与资格投入走到可交付的中型发射能力，但公司未单列项目剩余预算、专属团队/产线资源、剩余资本开支或客户共担金额。2026年第二季度总研发费用为8,243万美元、上半年为1.629亿美元，增长来自Neutron进展以及收购业务研发、增员和航天器原型等多项因素，不能当成Neutron单项目成本；9月ATM融资公告说明净款项用于Iridium收购现金支付，也不能当成Neutron项目跑道。已披露的发射合同和含Neutron发射的系统合同证明有任务需求，但不是客户已支付剩余资格/产能建设成本的证据。若客户或政府合作方签署有约束力、款项明确用于Neutron资格或专属能力建设的成本分担，Rocket Lab承担的开发现金风险下降，且关键路径获得支持，即使工程节点尚未通过也有独立信息价值。相反，正式削减Neutron专属预算、关键团队或专用产线/测试工作，会压缩资格与交付能力；外部资助撤回亦会把原定由合作方承担的关键开发成本重新压回公司。较慢的分阶段开发或降低首飞性能可能降低峰值现金需求，但延长周期也可能增加持续人员/测试支出，降低性能还可能损害任务适配；只有公开的项目级成本下降且仍保持已披露客户承诺时，才可视为现金纪律改善，不能仅凭‘更便宜’推断为利好。当前材料不足以给出剩余跑道、最低融资额或可承受的性能下降比例，因此不以合并现金、全公司研发或发射标价设项目阈值。

- C1 / LONG / MIDDLE: 战略客户、政府或项目合作方签署/修订有约束力的协议，承诺将新增款项或明确成本份额用于具名Neutron资格、首飞能力建设或专属产能工作，而非仅购买未来某次发射。
  - Reference: 截至2026年10月12日，所映射公开材料未确认客户为Neutron剩余资格或专属产能建设提供项目级共担资金。公开的多次Neutron发射订单、Kepler任务和含Neutron发射的航天器合同属于任务/服务安排，未披露为开发费用承担；9月ATM净款用于Iridium收购。
  - Boundary: 当公开的绑定承诺明确把新增资金/风险分担分配给一项可识别的Neutron研发、资格或专属能力工作包，即足以改变公司承担的开发现金风险；普通发射服务订金、一次任务订单、尚未签约的意向或未指向Neutron开发的总额合同不越界。工程测试通过不是触发前提。
- C2 / LONG / INNER: Rocket Lab正式批准Neutron分阶段/首飞构型重基线（可包括降低初始性能或延后部分能力），并披露该调整相较原批准方案实质降低剩余Neutron专属研发或资本需求，同时维持已公开Neutron客户任务承诺。
  - Reference: 目前Neutron公开设计目标包括可复用构型及约13,000公斤低地球轨道运载能力，但仍属设计目标、未由飞行验证；公司没有披露剩余项目预算、计划成本对比或客户逐任务性能要求，也未公开将首飞重基线为较低性能/分阶段方案。
  - Boundary: 需有公司正式采纳的方案变更，并明确说明项目级剩余现金/资本需求实质下降且已公开客户任务仍由该构型满足；仅宣布放慢节奏、降低纸面性能、或削减工作但没有现金需求改善依据，不足以判断为LONG。该条件承认更可负担路径的潜在价值，但不要求任何工程里程碑先通过。
- C3 / SHORT / INNER: Rocket Lab正式削减/暂停已承诺的Neutron专属关键资格预算、核心测试团队或专用产线工作，并明确将具名资格、首飞硬件或能力建设任务因此延期、取消或缩减。
  - Reference: 2026年第二季度公司仍报告Neutron开发及硬件集成在推进，但没有公开Neutron独立预算、团队规模或专用产线拨款，因此不能用总研发增长或单次招聘变化建立项目资源基线。
  - Boundary: 公司层面披露一项具体、已承诺的Neutron关键路径资源被削减且具名工作包随之延期/取消/缩减，即越界；全公司降本、未分项研发变动、普通员工变动或跨型号调度不单独触发。项目专属资源决策自身就改变完成资格工作的能力，不需要等工程失败或到台目标移动。
- C4 / SHORT / MIDDLE: 已公开承担Neutron开发/产能建设成本的战略合作方正式取消或实质削减该承诺，且由此使已具名的资格/能力建设工作失去资金或将相应成本重新转回Rocket Lab。
  - Reference: 截至截止日没有映射材料确认此类Neutron专属开发共担承诺，因此并未假定存在未披露的合作资金。若未来建立并公开此承诺，其后正式撤回应相对该新基线评估。
  - Boundary: 公开确认已承诺的项目级款项/成本份额撤回或实质缩减，并明确让一个关键Neutron工作包失去支持或增加Rocket Lab承担的剩余资金，即越界；普通客户取消或推迟发射服务、没有项目开发资金条款的订单变化不属于此条件。
- C5 / SHORT / INNER: 公司因首飞构型/性能重基线确认某项已公开签约的Neutron任务无法由新方案履约，并因此取消、改签到其他运载器或延期该任务。
  - Reference: Neutron公开客户安排包括未来发射任务，但若干任务的具体载荷性能需求、详细窗口和履约条款并未披露；约13,000公斤LEO仍是未飞行验证的设计目标。
  - Boundary: 越界需要公开的能力/范围下调与一项已签约Neutron任务的取消、改签或延期之间存在明确联系；单纯设计性能调整、未披露任务需求的推测，或与Neutron构型无关的客户选择不触发。若现金节省以失去已签约任务/交付机会为代价，降低成本本身不能掩盖商业化能力受损。

## Neutron首飞结果与飞行异常恢复

截至2026年10月12日，Neutron仍没有实飞入轨履历。公司8月10日的10-Q将一级贮箱送达Wallops发射台的目标放在2026年第四季度，同时说年末首飞窗口收窄、实际时点依赖一级资格和其他关键测试；这不是一个确定的发射日。第一枚完整飞行器的实际轨道投送会首次在飞行环境中检验多级推进、分离、制导及整箭运行，提供比地面资格更直接的设计证据；一次首飞未达目标也不自动意味着项目终止，遥测、回收的数据和故障隔离仍可改变下一轮试验的风险边界。若故障可局部修复并恢复后续飞行准备，影响与跨级结构/推进设计返工不同。反之，进入预定轨道也只证明该次飞行目标，不证明完整性能包线、长期可靠性、客户验收或高频运营。Neutron已经进入NSSL Phase 3 Lane 1，但美国太空军明确将首个成功发射作为竞标具体发射任务订单的门槛；满足门槛扩大可竞标范围，不等于获标或商业现金收入。此范围聚焦实飞结果和飞行后技术恢复，不重复另项Neutron预飞资格/到台日程研究，也不将首飞成功与未来经济复飞绑成同一确认链。

- C1 / LONG / MIDDLE: Neutron首次完整飞行完成公司在发射前公布的主要飞行目标，并将规定的试验载荷/飞行器投入预定轨道（若该次任务有载荷部署目标，则按公布目标完成部署）。
  - Reference: 截至2026年10月12日没有Neutron轨道飞行；公司最新正式进度仍是2026年第四季度送台目标、年末首飞窗口收窄且日期未确定。可复用性能和约13吨LEO运力仍是设计目标，不是飞行验证结果。
  - Boundary: 达到飞行前公开的主要轨道任务目标即越界；无需首飞同时验证全部性能、寿命、重复飞行或客户服务。若只有升空但未达到公布的主要轨道投送目标，不触发此正向条件。 按公开的NSSL规则，首飞成功还会跨过Neutron竞标Lane 1具体任务的飞行门槛，但不会自动产生任何任务授标。
- C2 / SHORT / MIDDLE: Neutron首个完整飞行因火箭/飞行器异常未达到飞行前公布的主要轨道任务目标，或车辆/任务载荷损失使首飞任务失败。
  - Reference: 首飞尚未发生，当前正式基线没有已知轨道任务结果；公司披露的Q4节点是发射台交付目标而非一次飞行成功保证。
  - Boundary: 实际飞行未达到事前公布的主要任务目标或发生车辆级任务损失即越界，无需等待公司完成根因调查；发射前取消、天气/场地导致的未起飞、或未影响主要目标的次要异常不单独触发。该失败信号不预断项目最终成败，后续异常恢复另有独立边界。
- C3 / LONG / MIDDLE: 首飞后出现的异常被公司隔离为局部可修复问题，纠正措施通过受影响系统的必要复验，并恢复下一飞行构型的集成/发射准备，且无需重做其他主要级段的设计资格。
  - Reference: 截至cutoff没有飞行异常或异常关闭记录；项目只有预飞测试及资格工作，尚无实飞故障范围、机体检查和恢复节奏的证据。
  - Boundary: 公司公开说明故障范围局部、修正已验证并且下一飞行准备恢复，即足以支持异常可控的正向更新；仅公布‘仍在调查’或宣布了未经复验的拟议修正不越界。即使首飞未完成全部目标，此闭环也能单独收窄后续返工/资格风险，但不抹去该次失败。
- C4 / SHORT / MIDDLE: 首飞后公开的调查结果显示异常来自飞行构型的共因设计/结构/推进问题，要求对多个主要级段或系统重新设计，或推翻先前视为已完成的主要资格并重新开展系统级验证。
  - Reference: 截至cutoff尚无首飞，因此没有飞行验证后的故障范围；预飞状态不能证明飞行条件下不存在共因设计问题。
  - Boundary: 需有公司或正式调查明确指向广泛设计更改及主要系统重新资格这一实际工作范围；仅一次可更换部件故障、遥测数据不足或尚未定因不越界。若真实发生，这会使飞行一次成功与否之外的系统成熟度和剩余投入预期重新下修。

## Neutron客户任务接受与重复商业交付

Neutron现有订单是商业化的需求锚，不等于服务已经交付。公开安排包括Kepler一项不早于2028年的专属任务、保密客户的五次Neutron及三次Electron多发射合同，以及Neutron作为SB-AMTI卫星—发射—运营整包中的一环；合同总额、选项和发射价并未完整拆分。Kepler为2028年下一批卫星另行锁定Falcon 9容量，显示客户有多路线部署，不能把一次Neutron预订推成排他需求，也不能把另一路线安排误判为Neutron合同取消。首个真正的客户任务完成并被客户/机构接受，是从预订到可交付服务的跃迁；另一次独立客户任务成功，则说明交付开始重复而非只完成一次演示。重复任务更有利于吸收固定运营负担，但仍不等于正的单次现金贡献。管理层在2026年5月给出的每次约5000万—5500万美元销售价格、约8000万美元年度固定成本，以及2027三次/2028五次节拍仅是商业框架；按该节拍粗分固定负担约每飞行2700万/1600万美元，尚未扣除第二级、一级新造或翻修、回收、发射与任务执行等变动现金，也不是目前的正式节拍指引。首个客户任务或第二次重复交付都无需等待完整财报利润证明，但也不能据此宣布高频运营或盈利拐点。

- C1 / LONG / INNER: Rocket Lab确认一项已签Neutron客户任务的飞行硬件/载荷已进入LC-3或发射活动现场，并开始针对该任务的载荷集成或正式发射处理。
  - Reference: 截至2026年10月12日，公开资料显示Kepler、保密客户及SB-AMTI有Neutron任务安排，但尚未显示某项客户任务的载荷已在Neutron发射设施进入任务特定集成/发射处理。订舱或卫星生产计划不等同飞行硬件准备。
  - Boundary: 具名或可验证的签约任务载荷已在LC-3/发射活动现场并开始任务特定集成/正式处理，即提供了从订单到可执行发射的现实推进；客户继续预订、签约、宣布星座扩张或仅给出未来窗口不越界。此状态可在Neutron首飞成功/最终客户验收之前发生，不等待两者。
- C2 / LONG / INNER: 一项已签约的Neutron客户/政府任务实际由Neutron飞行，达到合同或任务公开的主要轨道投送目标，并由客户/任务机构确认交付或任务完成。
  - Reference: 截至2026年10月12日，Neutron尚无实际客户任务交付。Kepler的一次专属任务不早于2028年；保密客户及SB-AMTI体现已签采用，但未形成Neutron飞行交付、任务验收或单次发射收入数据。
  - Boundary: 首次完成可识别的签约客户/政府任务，并出现客户或任务机构接受/任务完成的公开证据，即越界；订单、发射窗口、初步选定、测试飞行或公司仅称发射成功但未完成已披露的任务目标不足。该交付证明客户开始使用Neutron服务，不证明回款金额、单次利润或后续复购。
- C3 / LONG / INNER: 在首项客户任务之后，Rocket Lab再完成至少一项独立签约的Neutron客户/政府任务，且载荷达到其主要任务目标并获客户/任务机构验收。
  - Reference: 当前没有已完成Neutron客户任务，历史安排只有预订及合同；管理层早期年度飞行数是框架而非实际交付基线。
  - Boundary: 除首项客户交付外，再有第二项独立的签约客户任务成功交付并验收，即足以形成重复服务证据；不设必须在某个旧管理层年度节拍内完成的次数要求，也不要求两次使用同一枚一级。重复交付提升产品履约/固定负担吸收的可置信度，但不单独证实高频率或正单位现金。
- C4 / SHORT / MIDDLE: Neutron飞行数据或已验证能力不足以满足某项已签客户任务的载荷/轨道/飞行要求，导致客户正式取消该项Neutron任务、改签替代运载器或不再承诺其已签窗口。
  - Reference: Kepler、保密多发射客户及SB-AMTI构成当前已公开的Neutron采用锚，但任务性能细项与各任务取消权并未完整披露；Kepler另有Falcon 9路线仅表明多供应商安排，尚非Neutron任务取消。
  - Boundary: 需有具体已签Neutron任务的取消、改签或失去约定窗口，并由公司/客户明确关联到飞行表现或车辆能力未满足任务要求；一般窗口重排、客户正常多供应商安排、未行使选项或单纯测试延期不触发。此事件会直接损失一项已承诺的产品交付机会，不需等单次利润披露。

## Neutron一级回收、翻修复飞与单位现金回报

Neutron的设计目标是让一级在大西洋海上平台受控着陆、回收后返回LC-3，并把Hungry Hippo整流罩留在一级上；截至cutoff这些仍是设计和运营方案，不是实飞记录。一级回收成功只证明返回和回收环节有初步可行性，拆检后能否检查放行、翻修、重新资格及复飞才证明循环可运行；单次成功回收并不自动省钱。一次复飞还没有确定寿命，一级能用多少个周期、发动机/复合材料结构的损耗、海上回收船与平台/运输、检验翻修工时、备份箭库存、二级耗材与客户节拍共同决定每年实际可交付次数和现金占用。管理层2026年5月给出的约5000万—5500万美元单次售价、约8000万美元年度固定运营负担和少量初期任务框架，显示节拍对固定成本吸收敏感：仅把8000万美元固定负担除以三次或五次，约为每次2700万美元或1600万美元，仍没有扣除任何变动飞行/回收/翻修成本，也不是已实现利润或当前正式产能计划。因而回收、复飞和连续交付可依次提供有价值的阶段证据，但只有实际净节约数据才证明复用改善单位现金；无需以整家公司盈利或完整毛利披露作为识别前述阶段的前提。

- C1 / LONG / MIDDLE: 在公司已公开计划进行一级回收的Neutron飞行中，一级按计划完成海上受控着陆并被回收平台实际接收/打捞，且硬件可供飞后检查。
  - Reference: 截至2026年10月12日没有Neutron飞行、一级着陆/回收、拆检或周转记录；公司公开的是海上着陆与Return On Investment平台回收方案。
  - Boundary: 实际一级安全着陆、被回收并进入检查即可作为回收链首次通过的正向证据；仅公布平台、着陆计划、尝试落海或未确认是否收回不越界。此状态不等于飞行成功、拆检放行、可复飞或净成本节约；如果飞行任务本身失败，独立首飞结果规则仍可同时反映。
- C2 / SHORT / MIDDLE: 一次Neutron任务明确计划尝试一级回收，但一级未能完成受控着陆/未被平台接收，或返回硬件因结构、热防护、推进等重大损伤而无法进入可评估的翻修状态。
  - Reference: 一级海上着陆与回收只是计划中的复用路径，尚无Neutron回收履历；不假设首次飞行一定会执行回收尝试。
  - Boundary: 只有在公司明确宣布该次任务的一级回收目标而回收失败或回收硬件无法检查时才越界；若某次飞行按设计选择消耗式/不尝试着陆，不据此记为回收失败。回收系统失效直接打击复用路径，即使该飞行的上面级或轨道任务另有部分成功。
- C3 / LONG / MIDDLE: 一枚已飞过的Neutron一级完成实际飞后检查、翻修与必要重新资格后，再次被用于后续Neutron飞行并按该次任务要求完成飞行。
  - Reference: 目前没有任何Neutron一级实飞、检查放行或复飞履历；设计目标是重复使用一级，而不是已证明一级可重复飞。
  - Boundary: 同一枚之前飞过的一级完成一个完整的检查/翻修/资格放行/再次飞行循环即可越界；不要求再飞任务为客户商业单，也不等于该一级已达到设计寿命或飞行成本低于新造一级。仅回收、拆检或公布翻修计划不足。
- C4 / LONG / MIDDLE: 至少一枚Neutron一级在首次复飞后又完成第二个回收—检查/翻修—复飞周期（累计至少三次飞行），并获准继续服役。
  - Reference: 目前没有Neutron飞行循环；一次未来复飞将只能证明一次复用，不能标定一级实际可用寿命。
  - Boundary: 同一枚一级完成两次独立复飞循环并再次通过后飞放行即越界，给出超出一次性演示的寿命/周转证据；不要求其达到设计最大复用次数或宣称全面高频运营。
- C5 / SHORT / MIDDLE: 一级已成功回收，但飞后检查确认主结构、发动机或关键复用系统需重大替换/返工，导致该枚一级不能在已承诺的下一次Neutron任务前完成重新资格，或公司明确决定不能按计划复用该枚一级。
  - Reference: 无实飞回收、寿命或翻修工时数据，当前只有公司设计目标；公开资料没有可用于判定正常翻修的时间/成本基线。
  - Boundary: 公司确认需要重大主结构/推进/关键系统维修或更换，并使原定复飞窗口失效/该一级退出计划复用，才越界；例行拆检、小件更换或没有影响复飞的维护不触发。此结果表明落海回收本身不能等同于可用复用周转。
- C6 / LONG / INNER: 公司首次披露实际Neutron复飞成本比较，确认在计入海上回收、返回、检查和翻修后，使用已飞过的一级使同类任务的单次现金成本低于新造一级执行任务。
  - Reference: 管理层曾给出单次价格和年度固定负担估计，但没有披露Neutron实际一级寿命、回收/翻修成本、变动成本或复飞后的单位现金节省；设计可复用和实际复飞都不能代填成本验证。
  - Boundary: 公司基于实际飞行/翻修数据确认净一级成本节省为正即越界，无需披露整家公司毛利或完整利润表；只报告回收成功、再次飞行、设计寿命或预测性成本目标不足以证明净节省。该条件直指复用的现金经济性，不与前述技术性回收/复飞信号互相替代。

## Neutron商业客户批次签约与留存

截至2026年10月12日，Neutron仍处开发阶段，尚无实际商业发射收入。公开可识别的商业基线是Kepler一项不早于2028年的专属任务，以及保密客户五项Neutron专属任务（2026—2029年基准）；SB-AMTI总额含卫星、发射、运营和选项，不能算作发射收入或并入商业任务数。早期已知的六个专属商业飞行使新增或失去一项任务都足以改变小型初始任务组合，但订单只表示已签安排，不等于已交付、已收款或有正毛利。Rocket Lab的10-Q说明backlog基于可执行协议并排除未行使选项，且发射服务合同通常有提前通知和指定终止费；Neutron客户的具体取消费、批次价格和延误权仍未公开。Neutron管理层约5000万—5500万美元/次和约8000万美元年固定负担只是框架，不能作为已成交价格或现金成本。

- C1 / LONG / MIDDLE: Rocket Lab或商业客户确认已签署一项Neutron发射协议或修订，净增加至少一项有目标年份/窗口的专属商业飞行，且明确它不是既有任务重新披露、合同选项或已计入现有批次的替代。
  - Reference: 截至cutoff，公开可识别的firm商业专属任务为Kepler一项（不早于2028年）及保密客户五项（基准2026—2029年）；合同具体价格、窗口与取消费未披露，完整公司订单簿可能还含其他未具名项目。
  - Boundary: 在公开可识别的六项基础上新增一项firm飞行并带有目标时段，即增加约六分之一已知商业任务数，足以改善Neutron早期任务池的可执行需求预期；普通意向、未行使选项、无净增量的批次拆分或单纯发射窗口讨论不越界。该信号不证明预付款、客户验收、飞行成功或利润。
- C2 / SHORT / MIDDLE: Rocket Lab、客户或正式文件确认至少一项当前firm Neutron商业专属任务被取消、从Neutron转签至其他运载器，或从已签任务数量中删除。
  - Reference: 当前公开资料有一项Kepler Neutron专属任务和五项保密客户Neutron专属任务；另一路线已存在但不构成Neutron任务取消。合同层面的提前终止权与费用通常存在，Neutron具体费率未知。
  - Boundary: 已签任务真实从Neutron任务池移除一项即越界；它相当于公开可识别六项的约六分之一。仅把Kepler的十颗T2卫星安排在Falcon 9、将同一firm Neutron任务改期而不撤销，或客户仍保留Neutron并行任务不触发。若有终止费，需在实际条款中评估其补偿，不把gross任务数损失直接当同额收入损失。

## Neutron客户现金承担、取消权与固定价重谈

商业任务数与单项合同现金质量是两个不同变量。Rocket Lab 2026Q2文件称长期发射服务合同通常按固定价格签订，backlog排除未行使选项，合同通常含提前通知及指定终止费；但Kepler与保密Neutron客户的单项成交价、预付款、取消费、客户延期/融资选择均未披露。同期公司报告有三项商业多发射协议可由客户选择融资某些里程碑付款，利息在首飞后才起算，之后按9.5%—12.6%利率分12个季度偿还；报告未识别这些协议对应的客户或火箭型号，因此不能推定已适用于Neutron。Neutron早期若能收到非退款、飞前专属资金，或相同任务范围的实际合同价格提高，可减轻研发/执行现金由Rocket Lab承担的程度；反之延期收款、放宽撤销保护或同范围价格下调会削弱任务现金价值，固定价格下成本上升还可能形成合同损失。管理层约8000万美元年固定负担仅作规模参照：2000万美元为约四分之一年度框架，足以使单项现金时点值得重估；约5000万—5500万美元ASP不是已签Neutron单价，不能用来替代实际对比。

- C1 / LONG / MIDDLE: 一项firm Neutron商业发射合同明确规定并实际收到至少2000万美元的不可退还、Neutron任务专属预付款或飞前里程碑付款。
  - Reference: 截至cutoff，没有公开的Neutron专属客户预付款金额或支付日；Rocket Lab的总合同负债/客户预付款为跨业务汇总，不能归到Neutron。管理层年度固定运营负担约8000万美元仅是估计框架。
  - Boundary: 实际收到至少2000万美元且不可退款、用于Neutron任务的飞前现金，相当于约四分之一管理层年度固定负担框架，直接缓解首飞前由公司垫付的现金需求；可退还预付、只签约但未收款、或金额低于该边界的普通里程碑不触发。它不是收入确认、飞行成功或单位利润证明。
- C2 / LONG / MIDDLE: 一项已签Neutron商业发射批次在飞行数量、载荷/轨道配置和其他服务范围未增加的情况下，通过正式修订把firm合同总价净提高至少2000万美元。
  - Reference: 当前Neutron专属合同成交价格和付款义务未披露；保密客户称定价与公司平均售价相符，但没有提供可用的每次价格。已知管理层的每飞行价格框架不是交易价格。
  - Boundary: 同一数量与范围下的公开旧价—新价显示合同总额至少上调2000万美元，约为管理层年度固定负担框架的四分之一；这代表净提高已签运输收入而非额外任务量，足以单独改变该批次现金预期。若价格上调同时购买新增任务、重载配置或其他服务，须先按范围区分，不以gross金额当单位贡献。
- C3 / SHORT / MIDDLE: 已签Neutron商业客户实际选择融资至少2000万美元的原定飞前里程碑付款，使该笔现金改在首次Neutron飞行后才偿付。
  - Reference: 2026Q2文件显示Rocket Lab的三项商业多发射协议允许客户选择融资某些里程碑，利息在相关初始飞行日期通过后才开始，并按客户利率分12季回收；披露未说明是否涉及Neutron，当前Neutron客户选择未知。
  - Boundary: 只有公司明确把至少2000万美元付款延期归属到Neutron firm任务，且实际现金从飞前移至首次飞行之后，才越界；这种短期垫资超过年度固定负担框架的四分之一，显著改变首飞前现金风险。适用融资利率和之后回收不会消除飞前现金延期；其他客户、其他型号、一般应收款增长或公司汇总合同负债均不触发。
- C4 / SHORT / MIDDLE: 一项已签Neutron商业发射批次在飞行数量、载荷/轨道配置和其他服务范围未变的情况下，通过正式修订把firm合同总价净下调至少2000万美元。
  - Reference: 没有Neutron逐任务成交价或同一合同的价格修订记录；公司历史发射合同曾出现低于执行成本的固定价格并后来修订或终止，但该旧合同不是Neutron价格基线。
  - Boundary: 同范围正式修订显示净减少至少2000万美元，等于管理层年度固定负担框架约四分之一，并直接压低已签批次的合同现金价值；小额配置调价、减少任务数量或改签其他产品应分别按任务池计算，不可伪装成同一单价变动。此结果不要求先证明全年利润下降。
- C5 / SHORT / MIDDLE: 一项firm Neutron商业任务的新合同或修订允许客户在Rocket Lab已开始该任务的专属硬件生产/发射活动后单方取消，且条款明确不补偿已发生或不可撤销的Neutron专属费用。
  - Reference: SEC披露发射服务合同通常有提前通知和指定终止费，但没有公开Kepler或保密Neutron合同的具体取消窗口、终止费或首飞前成本赔偿。
  - Boundary: 客户获得在Neutron专属生产或launch campaign开始后撤销firm飞行且不赔付任务专属已承诺支出，等于把取消成本转给Rocket Lab；若协议仍保留足以覆盖专属费用的取消费、或只允许在工作开始前改期，则不越界。没有直接合同披露，不推断当前条款宽松。
- C6 / SHORT / INNER: Rocket Lab正式披露一项Neutron商业发射合同需要确认至少2000万美元的合同损失准备，原因是预计履行该项firm固定价任务的成本超过合同价。
  - Reference: 没有Neutron逐合同预计成本、毛利或损失准备披露；2025年10-K曾具体说明历史商业发射协议固定价格低于执行成本并确认损失准备，证明公司有在合同成本预期触发时公开确认的披露路径，但不是Neutron当前损失。
  - Boundary: Neutron专属firm合同的已确认损失准备达到至少2000万美元，约为管理层年度固定负担框架四分之一，说明固定订单价格不足以覆盖可预见履行成本；一般研发增长、未量化的成本压力、其他Space Systems合同损失或汇总合同负债不触发。无需等任务发射或完整分部财报。

## Neutron市场可用第三方窗口与竞争运力

Neutron的设计目标是可复用配置向LEO运送至约13吨，但截至cutoff没有实飞或商业交付，设计运力也不等于对所有轨道都能载到13吨。替代供应有两种不同状态：Falcon 9 Transporter等低价拼车正在飞行，SpaceX于2026年10月1日的Transporter-18官方任务携带130个载荷；但多家小卫星公司向SpaceNews报告，未来2028—2029的部分Transporter预约已不可用，这只是客户报道，并非SpaceX公开宣布退出整个Falcon商业发射市场。Amazon Leo则已将100余次部署任务分配给五种运载器，另有新重型任务和发射设施投入；这证明星座买方有真实发射需求，也说明这些大型运力多数已被长期预订而非开放给Neutron争取。小型拼车、提供商自用的Starlink任务以及Amazon已经预约的发射不能自动视为Neutron同轨道/同载荷可替代窗口。只有可供第三方预订的重复运力、其发射窗口和客户所需质量/轨道/任务服务相匹配时，供应约束或供给扩张才改变Neutron的未来竞争位置。

- C1 / LONG / OUTER: 一个现有商业运载器运营者公开暂停或关闭一整年度的第三方专属/多吨级发射预约，且具名星座运营者公开确认至少一项已融资、轨道与质量适配Neutron商业服务的计划任务因没有可比商业窗口而推迟或未能安排。
  - Reference: 截至cutoff，SpaceX Transporter正常飞行且10月1日任务运送130个载荷；客户报道称部分2028—2029 rideshare预约已无法取得，但公司未正式宣布Falcon整体退出。Amazon Leo已在Ariane 6、Falcon 9、Vulcan、New Glenn等处预订100余次任务；其运力大多是自有星座已分配，不是第三方开放窗口。Neutron首个客户锚在2028年以后，首飞日期仍未确定。
  - Boundary: 一整年度同级商业窗口对第三方关闭，并且至少一个有融资/载荷准备的可比星座任务因此无法按原计划排上，说明供应紧约束已从低价小卫星拼车扩展至可由Neutron未来争取的中型/专属任务；一次发射延迟、单个Transporter预约不足、政府或自用任务占用但没有公开受影响买方，都不足以改变中型市场预期。此事增加潜在稀缺性，不代表Neutron已能接单。
- C2 / SHORT / MIDDLE: 一家先前尚未对外提供相关运力的商业运载器完成重复商业飞行，公开开放同等质量/轨道的第三方预约，并签署至少两项未来专属星座任务，形成可与Neutron争夺的重复外部发射服务。
  - Reference: 当前Neutron只有约13吨LEO的设计目标；New Glenn、Vulcan和Ariane 6的重型能力仍主要对应已预订的大型任务，Amazon Leo在2026年公告中称其100余次发射跨五种运载器。Starship等自用运力或尚未向第三方开窗的名义容量不属于当前可竞争供给。
  - Boundary: 必须看到已重复飞行、明确对第三方开放、且实际签下至少两项后续专属商业任务，三项合起来显示稳定新供给已进入Neutron可比的2028年后窗口；仅建成新发射台、首飞成功、公开设计吨数、Starlink自用任务或Amazon原已锁定的订单均不触发。新服务未必一定低价，也不证明Rocket Lab已有合同丢失，但增加同级买方可选供给并降低Neutron稀缺溢价。

## 大型星座部署配置与中型任务数量

星座的服务容量、覆盖与补网寿命先决定需要建多少颗卫星；卫星质量/体积、一次可部署数量、轨道面与替换周期再决定实际付费发射次数。Amazon Leo已从Atlas V每次27颗优化到29颗，Ariane 6在性能升级后由32颗提高到36颗，且未来重型发射可带更多卫星；这可减少同一目标卫星数的任务数，但Amazon同时已签100余次部署任务、计划20次以上年度发射并扩大服务，所以“更多卫星/每箭”不能自动推导总发射市场下修。相反，单星长寿命、吞吐提升或重型批量若让运营者明确删除未来发射，也会压低专属中型任务数量；更频繁的小批更新、轨道专属部署则可增加可争取的发射窗口。Neutron约13吨LEO的可复用设计能服务部分而非全部轨道和载荷。Kepler既签一项专属Neutron任务，也把十颗约400公斤T2星安排在2028年Falcon 9任务上，说明不同批次/轨道配置可并行，不代表Neutron合同取消。关键看运营者是否改变可付费的任务数与未分配的部署批次，而非只看用户增长、星座宣传或每次载荷数量。

- C1 / LONG / MIDDLE: 一个已有大规模商业星座的运营者正式修订部署方案，采用较短更新周期或多次较小的专属轨道批次，并为Neutron可服务的质量/轨道范围新增至少两项尚未分配、进入公开招标或可由新供应商竞标的商业发射任务。
  - Reference: 已知Kepler有一项不早于2028年的Neutron专属任务，同时十颗约400公斤T2星另行安排在2028年Falcon 9任务，说明批次路线可以并存；Amazon Leo现已将100余次任务锁给五家提供商，且有每箭携星数提升，不能把已分配的重型任务重新算作Neutron可得市场。当前没有统一的中型商业星座年度任务数量共识。
  - Boundary: 一个星座配置改变实际增加至少两项、质量/轨道适配且仍开放竞标的专属任务，约相当于当前公开六项Neutron商业专属飞行基线的三分之一，足以扩大初期可争取的独立市场；只改设计、提出未来用户增长、同一卫星数改用更少重型批次，或新任务已全数授予其他供应商，不触发。无需要求Rocket Lab赢得订单，订单捕获仍由商业合同Policy单独判断。
- C2 / SHORT / MIDDLE: 一个具有多次未来发射计划的商业星座公开确认，因更高单星容量/寿命或重型批量部署而从同一服务目标的未执行部署计划中永久删除至少两项Neutron可服务范围内的付费专属任务，且不是把任务换给另一发射商。
  - Reference: Amazon Leo已经提升单次部署数（如Ariane 6由32颗至36颗），但公司仍称计划年内20多次发射并在2026年新增多家提供商/任务；目前没有证据显示这些效率提升导致总体或适配中型任务数实际下修。
  - Boundary: 运营者明确表示同一服务/星座目标下至少两项未来商业任务被免除，且并非重新分配到Falcon、Vulcan、New Glenn或其他提供商，才说明单星效率、寿命或超重型批次实际压缩了可争取的中型任务池；每箭多带几颗但总部署计划不变或任务改签其他火箭不越界。两项相当于当前已知Neutron商业任务数约三分之一，足以让早期任务密度下修。

## Neutron再入货运验证与高时效物流任务采用

截至2026-10-12，Neutron在非星座物流上的唯一具名采用锚，是Rocket Lab于2025-05公布的AFRL/REGAL再入货物存活实验发射合同；公告称任务不早于2026，但并未给出当前执行日、价格或飞行结果。它验证的是一个货物再入实验，不是常态点对点货运订单。AFRL最初把Rocket Cargo定位为评估商业火箭租赁服务、比较配送速度和成本的研发/试验项目，目标场景是快速恢复任务能力、特种空运和人道救灾；USTRANSCOM也曾与Rocket Lab签CRADA探索Neutron、Electron、Photon货运/轨道货仓，并非采购承诺。价值取决于用户从决定调拨到收到可用货物的总时间和中断损失，而非单独的弹道飞行时间：货物集成、发射准备与许可、空域协调、再入落区安全、回收卸载、目的地许可及末端运输都可能吃掉时效优势。USTRANSCOM的2026-2029 INSTRUCT项目把与现有供应链、政府指挥系统、快速发射许可、空域和条约流程的整合列为关键工作；传统空运和前置库存则能在一些场景直接满足早期需求。轨道预置既可能先需要一项火箭部署，也可能减少之后临机发射，只有看清Neutron是否被选作该部署及其对应哪项任务才可判断方向。FY27 P2D预算申请继续支持分析、SBIR和初始参考任务，并考虑多类服务/支援；AFRL在2026年向Geneva Technologies授予的Rocket Cargo架构/需求研究合同也不是Neutron发射订单。故预算、研究合同或“全球数小时”宣传本身不能记为Rocket Lab订单。Neutron约13吨LEO是设计目标，不是再入货物有效载荷；管理层常规发射价框架也不是点对点货运成交价。一个真实存活结果能提高该路线可行概率；任务级付费采购会更直接增加服务采用；明确取消或将同一急件任务改派给空运、库存或其他供应商则降低Neutron的可捕获机会。

- C1 / LONG / INNER: AFRL/REGAL或其他任务主管公开报告：由Neutron发射并返回的货物再入实验完成了其明确的存活目标，且货物或试验载荷以可用状态回收。
  - Reference: 截至cutoff，Rocket Lab已公告一项AFRL/REGAL Neutron货物存活实验发射合同，任务目标是演示再入能力；公开资料未建立其已飞行、载荷存活结果或当前确定日期。Neutron尚无成熟的点对点货运服务履历。
  - Boundary: 一次任务实际达到存活实验的核心目标，会把Neutron运送并返回可用货物从设计/合同目标推进到实测能力，直接提高后续付费物流任务的可行概率；不要求同一公告再同时披露已签复购、全程门到门时长或单位利润。它只证明该载荷/任务条件下的再入存活，不证明所有货物、落点、许可或常态周转已经解决。一般首飞成功、Neutron一级回收或实验尚未公布结果均不触发。
- C2 / LONG / MIDDLE: AFRL/REGAL、P2D、USTRANSCOM或其他具名买方为一项新的、已获资金支持且明确归属Neutron的货运/再入任务作出任务级采购承诺：可为追加的Neutron货物存活实验/重复飞行或实际货物运输订单；也可为明确分配给某一Neutron任务的关键货物、再入存活、回收、装卸或地面集成保障物资/服务的新增有偿采购，但采购文件必须写明Neutron被选作该任务火箭段并形成新的具体交付。若订单是部署在轨货仓，须指明由Neutron执行该部署。
  - Reference: 当前公开的Neutron货运采用只有一项2025年公布的AFRL/REGAL货物存活实验发射合同；公告未给当前飞行结果、具体执行日或货运服务价格。冻结材料与截止前公开来源没有确立后续重复实验、实际货物运输订单或明确指向Neutron任务的新增关键物资/保障采购。P2D预算和REGAL架构/需求研究属于项目研发，不等同Rocket Lab任务授予；常规Neutron发射价格框架不能直接替代货运价格。
  - Boundary: 一项新增且有资金、范围与交付义务的Neutron任务承诺，会把当前单次实验扩大为一笔可执行的增量飞行/任务收入机会，或通过任务专用关键物资采购表明具名用户已选Neutron路线并实质推进该任务；无须等实验完全成功、第二个客户、重复飞行或收入确认。这个边界证明的是单项付费使用/任务实施概率改善，不证明常态服务或门到门经济性。未行使选项、IDIQ总上限、通用研究合同、一般库存/关键物资采购、物资订单未明确Neutron为该任务选定火箭段，或没有Neutron任务分配的在轨仓概念均不足。
- C3 / SHORT / INNER: AFRL/REGAL或其他任务主管公开报告：Neutron承担的货物再入存活实验未达到其明确的核心存活目标，货物/试验载荷未能以可用状态回收。
  - Reference: 公开任务的核心用途就是演示货物再入存活；截至cutoff尚无实验结果。Neutron尚未形成可重复的点对点货运履历，现有机会仍处于研发和验证阶段。
  - Boundary: 核心存活目标失败直接否定该次实验要验证的关键交付环节，降低近端付费任务的成功概率，因此无需再等买方正式取消整个Rocket Cargo项目才构成不利更新。只报告测试未完成、数据不确定、因其他未说明原因改期，或在核心存活目标已达成后的非关键异常，不等同于该条件。
- C4 / SHORT / MIDDLE: 具名物流买方或主管机构正式取消、终止或移除一项已计划/已授予的Neutron货物再入任务，并将同一项急件需求改由前置/多地库存、航空运输、其他供应商或其他已选方案满足，或明确放弃该项任务。
  - Reference: 目前公开的是一项AFRL/REGAL实验合同，不是常态货运服务；没有公开证据显示某一运营需求已被Neutron独占。DoD本来就以空运、海运及预置库存分担不同物流场景，预算中的多模式探索也不代表任一具体Neutron任务已被替代。
  - Boundary: 同一具名货物需求的正式撤销/改派，说明Neutron失去一项原定或已授予的物流任务，且替代路线的采购或任务选择已进入现实安排；该单一任务级选择即可下修Neutron的早期非星座用途，不需等待公司确认收入损失。其他场景增加库存、常规空运采购或对轨道仓的研究若没有取代Neutron的同一任务，不触发。若前置轨道货仓的首发部署仍明确由Neutron承接，则不是本条件所说的替代。

## NASA火星通信网络授标异议的重开与结束

NASA将火星通信需求从研究和征求方案推进为一项固定价、单一高性能火星通信轨道器采购：2026年9月1日选择Blue Origin，合同潜在最高金额约7亿美元，Blue负责设计、开发、集成、发射和运营，航天器须于2028年12月31日前交付，目标2030年投入火星运行。金额是采购上限/潜在值，不是Rocket Lab订单；NASA公开说明的本次架构为一颗高性能通信航天器，不是已授予的多星座采购。它覆盖未来与当前火星任务，单个选择足以影响RKLB进入一项具名深空航天器整包任务的机会。RKLB已被排除在现有授标之外，GAO对B-424825.1的处置只有在实质恢复其方案的评估或竞争资格时才改变这项机会；暂停履约本身仅移动Blue项目的进度和不确定性。NASA对其候选方案的公开资料显示，RKLB以Explorer平台和ESCAPADE履历为支撑，称MTO可由Neutron或其他中大型火箭发射；Blue称方案基于Blue Ring，采用混合推进并可携带可部署UHF中继星。上述为投标方公开的方案主张，并非NASA的比较评分或GAO认定。国会法条确实对本项7亿美元固定价采购规定了申请人范围（FY2024/25获NASA火星样本返回商业设计研究资金并曾提出独立发射火星通信轨道器等），但RKLB有关资格误用与技术卷评估错误的指控仍只是其主张；GAO称在案件未决时不公开诉讼文件。公司2025年约47%收入来自美国政府及其主承包/分包链（不是NASA份额），说明政府采购事件可触及重要业务，但不能将整个MTO上限换算成RKLB预期收入。GAO依法在100日内处理且可建议纠正采购；可能措施包括重新评估、改写招标/重开投标或重新授标，具体救济取决于案情与NASA实施。GAO支持异议、NASA采取纠正措施、采购重开、Rocket Lab恢复竞标、Rocket Lab最终中标是连续但互不等同的状态；2026年12月21日是该案程序期限而非胜诉或授标日期。

- C1 / LONG / OUTER: NASA或GAO公开的正式处置将本次80GSFC26R0011采购重新带回竞争：Rocket Lab的火星通信轨道器方案被明确恢复为符合资格、重新纳入评估，或NASA重开/重新发布招标且Rocket Lab可依据新条款参与。仅有案件受理、暂停执行、承诺调查、GAO指出程序问题但未改变RKLB的竞标地位，均不是此事实。
  - Reference: 截至2026-10-12，NASA于9月1日已选择Blue Origin承担单颗高性能火星通信轨道器的固定价合同，最高潜在金额约7亿美元，交付目标为2028-12-31；Rocket Lab未获该授标。GAO官方案卷记载B-424825.1于9月11日提交、目前仍未结案，案卷列12月21日为处理期限。Rocket Lab在9月11日公开提出资格与技术卷异议；NASA于9月15日公开表示案件解决前暂停履约（新闻报道引述NASA）。程序仍开放，但截至cutoff没有公开决定恢复Rocket Lab的竞标资格；GAO的100日处理期限是程序时限，不是重新授标的预期。
  - Boundary: 第一条足够的信息是NASA/GAO正式确认当前采购将重新评估Rocket Lab方案，或NASA公布一份实际可投的重开/重新发布招标，使Rocket Lab的合格方案重新回到竞争中。对单颗、最高潜在金额约7亿美元的独立深空航天器合同，恢复真实竞标机会已足以改写现有“竞争失败、Blue独家获选”状态；不必再等待RKLB最终赢标、开工或确认收入。单纯程序暂停或GAO决定将在某日发布，未跨越这一边界。
- C2 / SHORT / OUTER: B-424825.1通过GAO最终否决结案，或以撤回/程序性结案结束且无NASA纠正措施恢复Rocket Lab方案的竞争地位；原Blue Origin授标因该异议未被替代，故本次火星通信轨道器采购对RKLB的竞标路径关闭。
  - Reference: 现有比较点不是RKLB已有合同收入，而是：NASA在9月1日授标Blue，RKLB因9月11日向GAO提起异议而仍有一条非零但不确定的恢复竞标路径；该路径涉及本次约7亿美元最高潜在金额的单星固定价任务。GAO案卷截至10月12日仍开放，12月21日只是案卷期限。GAO否决实质争点会结束当前程序，原NASA授标仍是Blue；撤回/程序性dismissal则可能伴随纠正措施，也可能不改变原授标，因此只有结案且未恢复RKLB竞争资格的结果才适用此边界。
  - Boundary: GAO最终否决实质异议，或案件以撤回/程序性结案结束且没有NASA纠正措施恢复RKLB方案资格时，当前投标机会已关闭；对一项固定价上限约7亿美元的独立任务，这足以消除异议期间保留的直接竞标路径，即使尚未到交付日或Blue仍有未来执行风险。仅仅未及时看到新闻、12月21日到期或伴随竞争重开的dismissal不够。此判断只涉及本次合同的机会损失，不推导NASA所有深空采购下降。

## NASA独立火星通信任务由架构研究转入新增采购

本次国会拨款和NASA选择把一颗火星通信轨道器作为NASA Mars Telecommunications Network的首个独立固定价采购，Blue Origin已有该项单星合同。NASA此前另以一项竞争采购聘请Rocket Lab进行“火星端到端通信服务架构”研究；USAspending记录显示其义务额为390,936美元、执行期2026年2月23日至5月24日、18份报价且全公开竞争。该研究可证明NASA实际购买过商业通信架构设计，也证明RKLB已有此类研究合同入口，但它是短期小额研究，不是卫星/星座/运营合同，更不证明服务路线已经扩展。未来若NASA把研究以外的第二项火星中继航天器或端到端商业通信服务另行设为有资金、有交付范围的竞争采购，需求池将从现有单颗Blue航天器和一次小额研究转向新的独立商业任务机会。要有独立工作范围而非Blue现合同内的能力/选项调整，并且采购条款为RKLB提供可参与的实质平台、系统或运营工作，才构成对Rocket Lab可竞争机会的扩展。NASA的一般“支持未来任务”、预算方向、ESCAPADE履历或研究完成都不足以证明新增付费购买已成立。

- C1 / LONG / OUTER: NASA公开发出或正式列入资金执行的单独竞争采购，要求在当前Blue Origin首颗火星通信轨道器及RKLB已做的390,936美元架构研究之外，采购另一颗/一组火星通信中继航天器或一项有交付和运行范围的端到端商业火星通信服务；该采购允许RKLB按条款竞争，或允许其在有实质平台/系统/运营工作的位置参与。
  - Reference: 截至2026-10-12，国会FY2025特别拨款规定约7亿美元用于在FY2026前签订一份竞争性固定价高性能火星通信轨道器合同；NASA于9月1日选择Blue承担一颗轨道器，预计不迟于2028年交付。NASA的最终RFP及授标公告将此描述为一个通信航天器合同/基础能力。另一个独立的Rocket Lab研究合同80GSFC26C0008金额为390,936美元，执行期2月23日至5月24日并有18份报价；这是研究工作而非商业系统交付。NASA将通信能力用于未来火星任务，但截至cutoff没有公开确认其已另行出资采购第二颗火星中继器或新端到端服务的RFP。
  - Boundary: NASA正式发布一项有实际资金与独立交付范围的后续竞标（另一颗火星通信/中继航天器或长期端到端商业通信服务），且招标条件让Rocket Lab能够竞争其平台、系统或运营部分，即足以证明当前单颗Blue合同以外出现第二条可寻址的商业任务采购。无需等任务授标或RKLB获选；仅研究资助、服务架构论文、未拨款的预算请求、Blue现有合同内的可选工作或NASA称Mars通信很重要都没有改变实际采购池。

## 国防数据运输采用商业网络服务的付费路径

T2TL-Beta的18颗卫星是政府采购自有数据运输能力；另一路是购买商业网络的任务数据运输服务。Rocket Lab于2026年加入Space Data Network Backbone consortium，披露已获两项合计1,200万美元的交付订单，证明它进入实际联通/互操作采购链，但订单规模和目标仍属有限的开发/示范工作，并不代表军方已改为长期购买商业容量。用户复用既有容量可以增加服务使用而不带来新设备；外包也可替代一部分政府自有卫星工作。只有在正式作战网络中采用可付费的持续运输服务，并把Rocket Lab/其已命名团队纳入实际订单，才打开目标的新增服务捕获，避免把“军方支持商业能力”、加入联盟或伙伴网络扩大直接当作Rocket Lab订单。

- C1 / LONG / OUTER: USSF/SSC/DoD以正式采购或任务订单，把商业卫星数据运输从一次开发/互操作演示转为有运营用户及持续服务范围的付费军事任务，并将Rocket Lab或公开列名含Rocket Lab的团队/consortium供应商列为实际获选承包方。
  - Reference: 2026-08-18，公司称Rocket Lab加入Space Data Network Consortium并获两项合计1,200万美元的SDN Backbone交付订单；这些订单及未来Photon互操作演示证明采购入口，但未证明多年度运行中付费的数据容量已经转由商业供应商提供。SDA T2TL-Beta仍有18颗政府自有运输卫星合同。新服务既可能补充，也可能部分替代政府硬件采购，不能按同一美元额推算卫星数。
  - Boundary: 一项公开、已授予且承担实际军用数据运输运营/容量交付的商业服务订单，若把Rocket Lab列为服务履约方，即足以打开重复服务采购和后续容量工作的直接路径；不用等运营满一个周期或再增发卫星。若只批准服务概念、发布可申请的联盟名额、给研究/互操作样机资金或订单与Rocket Lab无关，不够。

## 国防卫星任务的整包或分段采购如何决定Rocket Lab责任深度

政府买的是可验收的任务范围，不是卫星数量或标称合同总值。Rocket Lab在T2TL-Beta与TRKT3已被指定为直接卫星主承包商并承担设计、制造及运营；2026年Space Force的两颗GEO任务则显示另一种做法：Rocket Lab作为主承包商提供设计、制造、集成及多年运营，发射由政府提供运载器。PTS-G又展示Viasat为全任务prime、Rocket Lab提供卫星平台的供应链分工。由此，独立竞争卫星平台/系统集成 lot 可让Rocket Lab在无需同时承诺运载器的情况下争取可交付工作；若已签的运营或集成范围被拆给其他承包商，单位数量即使不变，其直接价值链也变浅。整包任务可集中接口协调、增添主承包职责，但同时把系统和跨供应商时序风险集中，合同总额更大不等于Rocket Lab可得收入或更高利润。SB-AMTI中Neutron替代运输的具体窗口和成本由另一Topic深化，本条不借用该合同来设置边界。

- C1 / LONG / OUTER: DoD/USSF/SDA/SSC为一项新的、有明确任务和资金的卫星生产采购发布最终 solicitation，将空间飞行器平台/系统集成作为可单独投标或授标的主要工作包，与运载器或长期运营责任分开，且允许已有航天器主承包能力的Rocket Lab按独立主承包方案竞争。
  - Reference: Rocket Lab已直接承担18颗T2TL-Beta和18颗TRKT3空间飞行器的设计、制造、集成/运营；SSC的两颗Heimdall/GEO卫星是独立的Rocket Lab主合同，含政府提供的发射；在PTS-G，Viasat为prime而Rocket Lab获得卫星bus工作。以上说明系统工作可在政府合同中单独采购，且公司实际有prime和sub两种角色。某任务的发射/运行工具可另由政府或其他供应商承接，不能假定必须由Neutron整包。
  - Boundary: 最终招标文件首次为一项有任务、资金和交付范围的生产型卫星系统采购设立独立空间飞行器/集成竞争包，并允许Rocket Lab类别的航天器承包商不捆绑未合格的发射系统直接投标，已经扩大其真实可争取的主承包路径；不必等source selection或后续收入。泛化“未来可能模块化”、仅技术研究、框架上限、无具体采购包的RFI不够。
- C2 / SHORT / OUTER: SDA/USSF正式修改Rocket Lab当前直接卫星主合同，把原已分配给Rocket Lab的系统集成或在轨运营工作转给另一承包商，而原18颗空间飞行器数量仍保留。
  - Reference: T2TL-Beta及TRKT3当前直接合同都包括设计/制造以外的交付或运营责任；这些责任是Rocket Lab已进入主承包链的实际工作，而不是通用发展机会。
  - Boundary: 政府公开的合同修改或正式职责分工显示已签的集成/运营交付件从Rocket Lab范围移除并落到其他承包商，即使卫星数量未减也足以修订其价值链深度。单纯对新任务采用分项采购不是已有工作损失；如果Rocket Lab继续承担原集成与运营任务，也不因竞争者负责发射而触发。

## RSLP可选试验发射任务的实际呼叫

2026年7月公布的Space Force RSLP协议给Rocket Lab提供12次基础亚轨道任务，另最多6次选项，合同潜在金额约2.66亿美元。实际行使选项会把一个额外的政府试验/响应发射任务转成Rocket Lab的直接服务采购；六项全部行使相对12次基础是最多50%的任务数量增量，数量杠杆显著不同于TRKT3约1,000万美元、约1.2%基础的选项。任务分布受测试载荷就绪、用户要求、火箭和发射窗口共同影响，协议的上限不是已下达的18次任务，亦不能从合同类型推断每次均是HASTE或同一载荷。正式订单即改变任务储备，无需等发射成功；反向只有删减既有基础任务才减少已经承诺的直接机会，单纯不行使未购买的选项不是损失。

- C1 / LONG / OUTER: USSF/SSC通过正式选择或任务订单，实际行使Rocket Lab 2026年RSLP协议中一项或多项可选追加任务，并将至少一次新的具体飞行任务加入Rocket Lab的付费履约范围。
  - Reference: 截至2026-10-12，Rocket Lab披露RSLP协议为12次基础任务并最多追加6次选项，总潜在值约2.66亿美元；六次只是上限，任务窗口、载荷准备和具体任务安排仍属后续决定。因各任务的载荷和使命可能不同，不从协议总值平均反推出单次价格或任务均为HASTE。
  - Boundary: 一份官方任务订单或合同修改首次把一项可选飞行列为Rocket Lab新的 firm 任务，即超出12次基础而增加一项真实发射服务订单；无需等飞行、验收或收入确认。仅有最多18次的潜在合同总值、备用选项、泛称未来测试需求或未行使剩余选项都不够。
- C2 / SHORT / OUTER: USSF/SSC正式修改或终止Rocket Lab RSLP协议，取消或削减12次基础任务中的一项或多项已签服务范围。
  - Reference: 当前有12次已签基础任务以及最多6次尚未承诺的选项任务；只有基础任务构成可计入当前直接任务范围的对照。
  - Boundary: 政府正式删减一项或多项基础飞行、或终止基础履约范围，就直接减少已签任务量；不需要等到实际发射窗口或财报确认。六项未来选项未行使或到期，不属于撤销12次基础，不能单独作为Short。

## 天基拦截器从集成演示进入实际防御架构的路径

天基拦截和天基传感是不同的采购层。USSF于2026年建立SBI计划，目标是在2028年前后将演示能力集成进Golden Dome架构；Rocket Lab于5月称它与Raytheon被选中演示先进能力。7月公布的奖项制要求企业先投入并按里程碑竞争资金，且APL协调体系架构；因此现有公司位置是合作演示入口，没有公开独立份额、生产卫星数或长期采购值。SBI是否成为被采用的作战层，决定该入口有无后续的重复研制、拦截星生产与运营工作；如果区域防护以地面拦截为主、太空拦截只留一次性演示，Rocket Lab可分配的远期拦截机会会低于被纳入实际部署架构的路径。CBO约1.2万亿美元是依据总统目标设定的假想国家导弹防御系统成本估算，CBO说明DoD的objective architecture尚未公开；该模型不是政府已批准采购额或Rocket Lab可获市场。个人原型评分、里程碑拨款和技术成果不在本Policy，另由原型竞争Topic处理。

- C1 / LONG / OUTER: DoD/USSF公开采纳的Golden Dome目标架构或实施计划，将SBI列为2028年前后集成演示之外的实际部署层，明确存在从演示转向后续作战能力/系统部署的正式路线。
  - Reference: 当前已知状态是USSF公开设定演示与Golden Dome架构集成目标，Rocket Lab与Raytheon合作演示由公司于2026-05-07披露；官方7月资料说明SBI采用企业前置投入、里程碑竞争和APL架构协调的奖项模式。尚未公开经采纳的目标架构、生产批次、团队份额或后续经费规模。总统行政目标与测试规划已知，不能视为SBI全星座部署的默认预测。
  - Boundary: 正式Objective Architecture或项目实施方案第一次把SBI从2028演示提升为计划在作战系统中部署/进入下一阶段的能力层，就会提高现有SBI合作团队获得系统后续工作的现实概率；无需等到RKLB新订单、量产卫星或全系统投入。单纯重复政策目标、现有演示目标或CBO假想模型不够。
- C2 / SHORT / OUTER: DoD/USSF最终批准的防御架构明确规定，SBI只做研发/2028集成演示，不进入该架构的后续作战部署阶段，或者将SBI层从objective architecture中移除并由地面拦截等其他已选能力承担该范围。
  - Reference: SBI当前唯一清楚的Rocket Lab入口是与Raytheon参加能力演示；除演示外没有已披露的Rocket Lab系统订单。官方材料没有证明长期空间拦截器已取得已授权的重复采购数量，CBO的Notional规模不得用作默认预测。
  - Boundary: 当正式架构第一次公开将后演示的SBI部署路线排除，或明确把空间拦截限制为一次演示而无后续fielding层，现有合作带来的远期生产机会即被显著削弱；不必等2028演示结束才承认。若只把首阶段保护集中在重点区域、但保留SBI作为后续部署选择，或只是继续企业里程碑竞争，则仍未跨过负向边界。

## SDA导弹感知与数据运输卫星的后续批次分配

Rocket Lab已有两项可区分的SDA直接卫星工作：T2TL-Beta为18颗数据运输卫星，Rocket Lab披露基础金额4.89亿美元、另有2,600万美元激励及选项；TRKT3为18颗导弹预警、跟踪及防御卫星，公司8-K披露8.06亿美元基础与1,000万美元选项。两者的空间飞行器交付与运营是已分配的直接工作，不是未来任务清单。SDA原TRKT3 72颗由四家各18颗取得，2026年新增的36颗AMDT3又由L3Harris与Sierra Space承接，且变型任务不同；所以需求或总星数上升，不能自动推成Rocket Lab续单。若政府再给Rocket Lab明确的空间飞行器数量、单独卫星任务或因他家延误而实际移交的第二来源任务，新的可执行生产量会改变其在当前18颗基数上的采购捕获。反之，正式删减该基础数量或在同类型竞标中明确未获一整项任务，直接削弱未来国防采购量。TRKT3约1,000万美元的选项仅约占其基础的1.2%，若只涉及激励或未新增卫星，不与新增一批等同；RSLP六个任务选项相对12次基础的数量杠杆不同，另在专门条件中处理。合同价值、上限、实际义务和收入确认也不互相替代。

- C1 / LONG / OUTER: SDA/USSF以签署的合同授标、任务订单或合同修改，向Rocket Lab或公开确认由Rocket Lab承担飞行器交付的团队，新增其现有T2TL-Beta或Tracking Layer基础数量以外的卫星生产任务；包括一项实际授予的同类第二来源数量（例如另一承包商延误后转交），或行使明确增加空间飞行器数量的合同选项。
  - Reference: 截至2026-10-12，Rocket Lab直接承担T2TL-Beta 18颗、TRKT3 18颗。Rocket Lab披露T2TL-Beta为4.89亿美元基础、另有2,600万美元激励及选项；TRKT3公司8-K为8.06亿美元基础和1,000万美元选项。SDA另公布原TRKT3 72颗由四家各得18颗；2026-07-13新增36颗AMDT3由L3Harris与Sierra Space各得18颗，尚不能视作Rocket Lab原18颗的减项或增项。SDA按阶段重复采购是已建立路径，然而后续供应商、数量和合同类型仍需实际选择。
  - Boundary: 一份正式合同文件或政府授标公告首次明确给Rocket Lab新增至少一个实际的卫星生产数量或独立交付任务，即已增加其直接采购量；不用等卫星发射、验收或收入确认。只行使不增加飞行器数量的激励款、表态将研究下一代、发布没有新任务范围的常规招标，均不足。一个数量明确的新增空间飞行器是有别于小额合约选项的离散生产工作；对18颗基础分配无需等再增加到整批18颗才承认增量。
- C2 / SHORT / OUTER: SDA/USSF正式修改或终止Rocket Lab既有T2TL-Beta或TRKT3固定基础合同，明确将已签18颗中的一个或多个空间飞行器从Rocket Lab工作范围删去或转给其他供应商。
  - Reference: 当前两个直接基础范围均为18颗，尚无截至截止时点的政府合同修改将其缩减。未行使的TRKT3小额选项不属于18颗固定基础；AMDT3的36颗属于不同批次/变型，且在初始授标时即给了其他供应商。
  - Boundary: 合同修改或终止条款直接把一颗或更多已签空间飞行器从Rocket Lab基础工作移除，就足以降低其相对当前18颗工作范围的直接采购量；无需再等backlog或收入变化。发射时间重新排期、激励款未赚取、TRKT3选项未行使或不同变型另授他家都不满足此条件。
- C3 / SHORT / OUTER: SDA/USSF完成一项与Rocket Lab现有T2TL-Beta或Tracking Layer任务同用途、同类空间飞行器的后续竞争，并公开确认Rocket Lab曾提交同一工作范围的方案但未获选，整项有资金的卫星任务授给其他供应商。
  - Reference: 当前Rocket Lab在TRKT3 72颗中获得18颗；后续SDA任务预计仍是多家竞争，不能把潜在批次当成既定续单。2026年AMDT3新增36颗由两家供应商承接，但来源资料显示这些是不同的变型任务，且没有证据证明Rocket Lab投标同一工作或被拒，因此不构成该负向比较。
  - Boundary: 对于Rocket Lab实际竞争的一个有资金、功能可比的后续卫星任务，正式结果明确将同一合同任务授给竞争者并确认Rocket Lab未选，已经关闭这一次实际竞标机会；无需推断所有SDA工作份额都会消失。不同传感器变型的授标、未公开Rocket Lab是否投标的竞争者合同、只提高采购上限都不触发。

## 导弹感知与数据运输层的任务范围和轨道配置

国防用户改变防护对象、战区、时效和指挥链需求，会将未来采购在红外跟踪载荷、低轨数量、跨轨道链路和地面段之间重新分配。Rocket Lab目前的直接位置分别是T2TL-Beta 18颗数据运输卫星与TRKT3 18颗带导弹警戒/跟踪/防御任务的Tracking Layer卫星；2026年AMDT3再采购的36颗是另一个预警跟踪/导弹防御批次，且全部由L3Harris和Sierra Space获得。该分配显示空间感知网络的能力扩展既可能直接产生多家可竞标的后续卫星任务，也可能使感知数量增长却不增加Rocket Lab份额。若正式作战架构把天基传感器/低时延数据运输用于当前采购以外的新目标类别或作战区域，机会池会扩展；若正式阶段计划缩窄保护目标并将后续跟踪/运输交给既有地面能力或停止下一轮太空层扩张，未来替换采购会下降。仅有威胁增加不能确定采购设备种类或Rocket Lab获配。

- C1 / LONG / OUTER: DoD/USSF正式批准的作战要求或实施架构，将当前已采购的导弹预警/跟踪/防御目标之外增加一个可辨识的目标类别或作战区域，并明确由新增或扩展的天基红外感知、低轨/多轨道部署或低时延数据运输承担该任务。
  - Reference: 截至截止时点，SDA的TRKT3已覆盖传统及先进导弹威胁，并明确具备为导弹防御提供火控质量轨迹的能力；36颗AMDT3用于进一步的全球 missile warning/tracking 和 defense。T2TL-Beta的18颗运输卫星提供军用连接。已批准的主要星数和新AMDT3分配已分别有承包商，架构上的全球警戒/火控本身不是未来新增消息。
  - Boundary: 正式作战文件首次明确把一种当前合同范围外的目标任务/战区纳入部署方案，并指定卫星传感或数据运输为所需能力，已经修订未来空间层市场的使命边界，不必等待新卫星合同、Rocket Lab获选或财务确认。仅称对手威胁上升、重复T3既有导弹任务，或只讨论地面拦截能力，不满足。
- C2 / SHORT / OUTER: DoD/USSF正式批准的分阶段防御实施计划，明确将当前已签卫星批次之后的下一轮低轨导弹感知/数据运输扩展取消或从目标架构中排除，并把相同预警/覆盖需求交由地面传感器、既有系统或其他非新增太空层承担。
  - Reference: 截至cutoff，官方SDA公告仍把Tracking Layer作为导弹防御架构组成，AMDT3增加36颗以扩展全球coverage；Rocket Lab的18颗T2TL-Beta与18颗TRKT3已有固定工作，但之后是否滚动采购、新批次数量与资源组合均未锁定。CBO的1.2万亿美元是缺少公开objective architecture时建立的notional system估算，不是当前太空采购预算。
  - Boundary: 只有正式作战/采购路线将未来下一代或更新的天基跟踪/运输层明确取消、缩减或排除在已采纳架构之外，才足以降低当前已承包批次以外的重复卫星机会；若只是初期保护区域有限但保留全球感知/数据层，或部分层仍计划扩充，不触发。无需等现有18颗合约被取消。

## NITE-STAR 多奖方 IDIQ 转为 Rocket Lab 具名任务单

NITE-STAR 是 Space Force 的 National Space Test and Training Complex 创新技术与试验场能力开发合同，不是 NSSL 火箭发射合同。Space Force 披露 15 家公司（含 Rocket Lab）获得多奖方 IDIQ，两个五年期的共享合同 ceiling 为 9.81 亿美元；Rocket Lab 随后称已 onboarded 并可竞争任务订单，范围包括天基系统开发集成、地面系统部署、数字测试/训练环境和运行维护。因多家供应商共享上限，入池只打开竞标权，不能记成 Rocket Lab 收入、发射资格或 Neutron 订单。单项 funded task order 才表示采购者把某项明示系统/服务工作交给 Rocket Lab；它对工程、系统集成或运维业务的含义应按 scope/期间理解，不与 NSSL 运载器资格混算。

- C1 / LONG / MIDDLE: Space Force/SSC 将一项具体、有资金义务并界定交付范围/期间的 NITE-STAR task order 授予 Rocket Lab，或公开确认 Rocket Lab 是承担该项服务的合同团队成员。
  - Reference: SSC 于 2026-07-31 为 NITE-STAR Capability Development 签出多奖方 IDIQ，15 个 awardees 包括 Rocket Lab；共享上限 9.81 亿美元，跨两个五年期。Rocket Lab 于 2026-08-17 称已 onboarded、可竞标未来 orders；任务方向包括系统集成、地面部署、数字环境与运营支撑。至截止资料中只有资格/框架地位，未发现 Rocket Lab 已获该 IDIQ 下具名 funded task order。
  - Boundary: SSC 或可靠的公司/合同公告给出一项实际 task-order award，说明 Rocket Lab 被分配的具体工作、期间和资金义务，就把“可参与一项最高共享上限采购”转成直接订单，足以更新目标政府项目采用范围，不需等交付验收或收入；意向、RFP、入围/框架 onboarding、其他 awardee 的任务单或共享 ceiling 均不足。金额如披露应直接采用，不按 $981M 上限分摊。
- C2 / SHORT / MIDDLE: SSC 正式撤销、终止或修改仍有效的 NITE-STAR awardee 合同地位，使 Rocket Lab 不再能参加后续 task-order 竞争。
  - Reference: Rocket Lab 当前已列为 15 个 NITE-STAR awardee 之一，但没有保证订单、最低采购量或特定份额；合同 ceiling 是所有 awardees 共用的最高值。
  - Boundary: 对 Rocket Lab 有效 awardee 身份的正式撤销/终止，或有约束力的合同变更将其排除在仍有订单机会的任务范围之外，会关闭现存的竞标入口，降低其政府空间测试/训练能力选择权。单项 task order 给另一 awardee、某一 RFP 未中标或预算上限未用完，只要 Rocket Lab 仍在可竞争名单上，都不表示其整个 NITE-STAR 机会关闭。

## NSSL Phase 3 Lane 1 的 Neutron 任务竞标资格

Space Force 的 Lane 1 以商业式发射服务和较高风险容忍度承接一类任务；SSC 已公开说明，ID/IQ 在框架内授予并不等于型号能投每项发射任务，供方需先完成至少一次成功飞行才有资格竞标 Lane 1 任务，具体任务仍可另设适配与 mission-assurance 条件。Rocket Lab 于 2025 年进入 Lane 1 时获得的 500 万美元 firm-fixed-price 订单用于初始能力评估和定制任务保证，不是发射服务订单。2026 年 7 月框架扩至七家，说明供方入口增加而非七套成熟运力；Neutron 截至现有公司披露仍处于资格与首飞硬件阶段，目标为 2026Q4 到 Wallops 发射台、窗口收窄，尚无成功飞行或 Lane 1 任务竞标资格。达到公开的一次成功飞行门槛会把 Rocket Lab 从“已在 IDIQ 但尚不能竞标”改为“可提交单项任务方案”，本身只扩大可竞标集合，不代表中标、履约能力成熟或稳定份额；Lane 1 入口也不能外推到需完整 NSSL 认证的 Lane 2。

- C1 / LONG / MIDDLE: Space Force/SSC 公开确认 Rocket Lab 的 Neutron 已满足 NSSL Phase 3 Lane 1 的成功飞行资格门槛、可以参加具体 Lane 1 发射任务竞标；或发布的单项任务 solicitation 明确将 Neutron/Rocket Lab 纳入具备投标资格的供方。
  - Reference: 截至 2026-10-12，Rocket Lab 已于 2025-03-27 加入 Lane 1 IDIQ 并获得 500 万美元初始能力评估/定制任务保证订单，但该订单没有发射任务义务。SSC 2026-07-08 披露 Lane 1 共七家；SSC 对 2026-05-28 的 Blue Origin 任务授标说明，供方须先加入 IDIQ 且至少成功飞行一次方可竞标。Rocket Lab 2026-08-10 10-Q 和截至 2026-09-02 的事件记录仍显示 Neutron 未飞、到台目标为 Q4 2026；尚不能投 Lane 1 单项发射任务。
  - Boundary: SSC 确认一次成功 Neutron 飞行已经打开 Lane 1 竞标资格，或实际任务文件把它列为可投标供方，即从不可投转为可投，足以提高潜在任务集合的可达性；无需再等第二次飞行、复用、其他发射履历或首份中标订单。到台目标、热试车、资格部件完成、加入框架或新的 500 万美元评估订单均未跨过这一门槛；该条件只表示可竞标，不预设任务分配。
- C2 / SHORT / MIDDLE: SSC 正式提高或撤回 Neutron 的 Lane 1 任务竞标资格要求，使它在现行公开的一次成功飞行门槛之外还必须完成额外成功飞行/系统性审核，或在满足当前门槛后仍被排除于一类本来可竞标的 Lane 1 任务。
  - Reference: 当前公开门槛为：先进入 Lane 1 IDIQ，至少一次成功飞行后即可竞标；Rocket Lab 已在框架中，但 Neutron 尚未完成首次飞行。各任务可依其轨道与风险设定适配、定制 mission assurance，单项安全要求本身不等同全局资格变更。
  - Boundary: 正式规则/决定若把 Neutron 从“一次成功飞行后可投”的状态推迟到额外飞行、重新资格或明确排除适用任务类别，会收窄它可进入的采购集合，构成独立的资格恶化。只对一项任务普遍适用且 Neutron 仍可完成的普通接口或任务保证要求，或尚未改变资格的技术测试计划，不触发。

## NSSL Phase 3 Lane 1 发射服务的具体任务分配

对 Rocket Lab 的政府发射机会，真正的经济分配发生在框架内逐项竞争并下达 Launch Service Task Order 时：一个已资助、指明任务的发射订单把某项载荷运输义务给到供方，已明显超过只获得采购入口或能力评估。Lane 1 初始采购公告预计在 FY25–FY29 基础期竞争至少 30 项任务；2026 年 7 月把七家合同的合计 IDIQ ceiling 从 56 亿美元增加至 170 亿美元，是政府可下单的上限，不是 Rocket Lab 订单、拨款或均分份额。已公开的任务分配也展示竞争者的真实消化量：SSC 曾把一个 NRO Lane 1 任务授予 Blue Origin，另有两份 Space Based Sensing and Targeting 任务订单给 SpaceX、共 18 次发射；但这些在 Neutron 完成公开资格门槛前的对手授标不是 Rocket Lab 被击败或失单的证据。Neutron 合格之后，Rocket Lab 取得一项具名、有资金义务的发射任务是最早直接的客户选择；同一可投类别内的具名竞争者授标则会消耗一项现实任务机会。订单任务数量、轨道、窗口、金额及对手运力决定幅度，不能由总 ceiling 或单项中标推稳定份额、后续合同利润或已完成发射。

- C1 / LONG / MIDDLE: SSC/任务采购方授予 Rocket Lab 一项 firm、实际出资且针对具名 NSSL Phase 3 Lane 1 发射任务的 Launch Service Task Order，明确 Neutron/Rocket Lab 承担一个或多个载荷发射服务。
  - Reference: Rocket Lab 当前有 Lane 1 IDIQ 资格和 500 万美元初始能力评估订单；两者都不是发射服务合同。Neutron 尚未飞，也没有已披露的 Lane 1 launch task order。全 Lane 1 七家共享 170 亿美元上限，历史任务量、目前已公布给 SpaceX/Blue Origin 的订单和预计 30 项以上基础期竞争任务都不代表 Rocket Lab 的应得份额。
  - Boundary: 第一项有实际资金义务、指定具体政府任务与 launch service 的 Rocket Lab 订单就完成从资格选项到任务分配的转换；不必等待载荷交付、Neutron 飞行、开票或收入确认。仅发布 RFP、增加 framework ceiling、追加评估/mission-assurance 工作或 IDIQ 名册不触发；报道未披露金额时，以具名、实际 award 的飞行任务订单识别，不由上限反推合同值。
- C2 / SHORT / MIDDLE: 在 Neutron 已满足 Lane 1 一次成功飞行门槛后，SSC 将一项具名、有资金义务且公开属于可向所有合格 Lane 1 供方竞争的发射任务订单授予另一运载器，而非 Rocket Lab/Neutron。
  - Reference: 截至任务截止，Rocket Lab 尚未达到 Neutron 首飞门槛、没有可竞标的 Lane 1 发射任务；已有 Blue Origin 的 NRO 任务及 SpaceX 的 18 次发射订单均是在当前 Neutron 资格前授予，不能解释为 Rocket Lab 失标。合资格后，基线转为可以争取满足 Neutron 轨道/任务要求的后续 Lane 1 订单，而不是自动拥有份额。
  - Boundary: 门槛跨过之后，一项在公开规则下由 Neutron 可投的具名 launch-service mission 被 firm award 给替代供方，已将该任务的实际分配留给对手，是最早可观察的相对机会损失，不要求采购方公开未中标人的投标书，也不等 Rocket Lab 财报或该任务实际发射。框架内其他供应商无竞标资格的订单、Neutron 不具运力/窗口的任务、合同 ceiling 与合资格前的对手授标不触发；单一任务只代表本项分配，不据此外推全期份额。

## 政府合同基础任务与追加选项的实际资金承诺

Rocket Lab的政府采购链暴露具有规模，但不同合同的基础工作和或有工作不能等权外推。T2TL-Beta的18颗卫星基础合同约4.89亿美元、26百万美元上限混合激励与选项；TRKT3的18颗基础约8.06亿美元、约10百万美元选项仅约为基础的1.2%；RSLP则是12次基础亚轨道任务及最多6次追加任务，全部六次相对基础量增加50%。因此预算变化对短期新任务单与选项的影响，应按对应合同义务而非框架上限判断。签署并出资的RSLP全量选项会显著增加确定任务量；相反，明确因资金/优先级而减少至少一半的基础任务，直接削弱已分配采购机会。已完成部分与便利终止结算可能继续支付，不能将被取消任务数机械计作收入损失。

- C1 / LONG / MIDDLE: 国防采购机关通过公开合同修改或任务单，正式行使并为Rocket Lab RSLP合同最多六次的全部追加选项任务落实资金，使可执行任务从12次基础增至18次；只有上限、意向、未拨款的选项或新的不具名框架不满足。
  - Reference: D2记录的RSLP基础为12次任务、另有最多6次可选追加，当前没有把这6次当作已下达。相较之下，TRKT3选项约1,000万美元/8.06亿美元基础约1.2%，T2TL-Beta激励与选项合计约2,600万美元；不同合同的名义选项值不能按统一弹性比较。
  - Boundary: 六次全部由未确定变为有资金支持的任务，任务数量从12增至18，即在现有基础上增加50%，达到该合同最大公开选项量级，足以显著改写政府任务量和相关年度执行机会。单次较小追加、未行使选项或公司收入确认不必等候；但只写合同上限而未有可执行资金义务仍不足。
- C2 / SHORT / MIDDLE: 采购机关以公开合同修改、终止或资金通知明确因拨款不可用/重编程/项目优先级，取消或解除Rocket Lab RSLP原12次基础任务中的至少6次尚未履行任务；这必须减少原已签基础范围，而不是仅不行使最多6次选项或暂时推迟非取消任务。
  - Reference: RSLP的12次任务属于基础承诺，最多6次另属未行使选项。当前没有完整跨项目政府资金义务序列；付款、选项行使、合同修改和便利终止分别代表不同承诺状态，且已经履约的部分仍可能通过正常付款或终止结算收回。
  - Boundary: 取消至少6次基础任务等于减少原12次基础的一半，量级与该合同全部追加选项相同，说明已分配工作本身因资金/优先级而出现实质收缩；保留基础但不行使选项、CR仅短期延付或有资金支持的改期不构成同一负向信号。即使触发，也只下修未履行的后续任务机会，不将既有履约款视作损失。

## 国防卫星采购从年度拨款转为可执行的多年资金

政府及主承包/分包链约占Rocket Lab 2025年收入的47%，但该组合跨多个产品、合同和采购机关，不等于每个项目随国防总预算同比变化。现有政府合同有明确基础、选项和框架差异：Rocket Lab的TRKT3基础18颗约8.06亿美元而公司主文所述选项约1,000万美元；T2TL-Beta基础18颗约4.89亿美元、激励与选项合计上限2,600万美元；NSSL Lane 1联合IDIQ上限扩大不等于拨款或公司订单。对卫星采购而言，只有实际拨款用途、可用年度和批次排程落到SDA/PWSA导弹预警/跟踪生产，才直接增加可竞争的整星采购池。若资金改投载荷、地面或测试，短期卫星订购可能后移，但也可能解除网络共同瓶颈；因此须有正式的卫星生产排程推迟/撤销才形成负向边界。

- C1 / LONG / OUTER: 国会已颁布的DoD拨款法，或DoD/SDA正式预算执行文件，为一个具名的PWSA导弹预警/跟踪后续卫星生产批次提供在至少两个财政年度可用的实际采购资金或提前采购权限，且明确该资金用于新的生产采购（至少18颗卫星或一项完整的生产批次），而非仅研发、地面支持、规划或尚未批准的预算请求。
  - Reference: 当前工作基线为按年度释放资金、约每两年授出新批次；截至cutoff的材料没有一份完整的Rocket Lab政府项目义务/采购金额序列。2025年TRKT3及2026年AMDT3说明实际卫星批次已采购，但没有依据将广义联邦预算增减线性套入该公司或所有在手合同。
  - Boundary: 正式可用的跨两个或以上财政年度资金落到至少一个完整生产批次，减少了年度拨款不连续对该采购的约束，并使一项规模与Rocket Lab当前18颗TRKT3基础同量级的新卫星采购池可执行。已颁布资金权力和具体采购用途是关键新增；行政请求、单纯授权、框架上限、只拨研发/地面款或无批次用途的总额都不足以跨界，也不表示Rocket Lab赢标。
- C2 / SHORT / OUTER: 最终拨款/临时拨款执行、DoD/SDA重编程或正式采购排程明确撤回、冻结或转走具名PWSA导弹预警/跟踪卫星生产资金，并把一项此前排定的至少18颗卫星生产批次推迟至少一个完整财政年度，或在FY2028后仍无替代的获资生产日期；资金流向地面、载荷、范围或运行支持本身不是条件，只有同时挤出卫星采购批次才触发。
  - Reference: 现有批次按阶段持续授予，GAO描述的通常周期约两年；已签Rocket Lab T3基础工作仍独立于未获资金的后续批次。上游预算请求变化或临时拨款短期覆盖旧合同，不代表整个政府需求取消。地面、载荷和测试资金也可能解除系统瓶颈并提高后续卫星采购概率。
  - Boundary: 将一项完整卫星生产批次至少推后一个财政年度，约为正常两年节拍的一半，并且没有替代的获资日期，已经把后续采购机会移出一个可交易的预算/授标窗口。仅更改总预算、请求/授权下调、临时CR延迟数周，或把资金投入共同系统瓶颈而保留既定卫星日期，不足以下修；此条件也不推定已签基础合同被取消。

## SDA导弹预警与跟踪卫星的成熟度门槛及供应商分配

SDA的批次是竞争性采购，不是所有承包商随总需求按比例获单。Rocket Lab已经获得TRKT3的18颗卫星基础工作（约8.06亿美元），另有跨批设计评审进展，但截至截止点尚无该批在轨作战验证；此前TRKT3四家各获18颗，2026年的AMDT3另外36颗已授予L3Harris与Sierra Space。GAO指出的技术成熟度、用户协作、架构排程和成本资料缺口使下一轮规则可能重新排序供应商。新的正式门槛若使Rocket Lab满足并拿到一个完整18颗规模的后续生产配置，等同在当前捕获基础上再增加一批；若同用途整批采购由其他供应商完成且Rocket Lab没有分配，则丧失同等规模的增量机会。采购结果可在Rocket Lab现有合同或财报改变之前修订预期。设计审查、技术概念或对手单独获少量合同不能推论Rocket Lab资格变化或当前合同损失。

- C1 / LONG / MIDDLE: 在SDA/太空军正式招标或评估中新增作战用户验证、成熟度、跨批互操作或系统级交付门槛后，采购机关以有资金支持的最终授标向Rocket Lab分配至少18颗此前未签约的PWSA导弹预警/跟踪生产卫星；这必须是独立的后续基础采购，不是现有TRKT3的设计评审或合同选项。
  - Reference: Rocket Lab当前TRKT3基础为18颗。该公司2026年9月通过初步设计评审，但截至cutoff尚未对本批取得在轨作战验证。既往72颗TRKT3由四家分配，2026年AMDT3的36颗另由其他供方获得；现有证据不支持Rocket Lab自动续获下一批。
  - Boundary: 一项新授标至少新增与当前18颗相同的基础规模，令Rocket Lab在此采购路线的已获整星量增加约一倍，而不只是被列入竞标或达到设计节点。合同授标直接确认了新门槛下的采购资格与可捕获量，不必再等待收入确认；少于完整新基础批次的无资金意向不满足本边界。
- C2 / SHORT / MIDDLE: SDA/太空军完成下一项可比的PWSA导弹预警/跟踪卫星生产招标，正式授标文件显示该完整生产范围至少18颗全部分配给其他供方而Rocket Lab未获该批基础工作；同一采办文件将作战用户验证、技术成熟度、跨批互操作或系统交付门槛纳入此次选择。仅有一个竞争者获得部分卫星、未完成批次分配或选项未行使不构成此事件。
  - Reference: 截至2026-10-12，Rocket Lab有TRKT3 18颗已分配基础，但并无未来批次的既定续订单或保证份额；竞争采购包含多家供方，新增AMDT3的36颗已由别的两家承担。新标准也可能提高全部供应商门槛，不能把其存在本身理解为对Rocket Lab利空。
  - Boundary: 在新的正式门槛下，一项完整的至少18颗后续生产机会被其他供方拿走且不含Rocket Lab，规模已等于Rocket Lab目前该路线全部基础卫星配置，足以降低同类后续工作的可竞争捕获预期；它不取消既有TRKT3合同。单一竞争者部分得标、资格讨论、媒体重复报道及本次已知AMDT3分配不算新的边际损失。

## SDA导弹预警与跟踪批次的作战反馈及采购节奏

SDA按阶段采购PWSA导弹预警/跟踪能力，GAO记载其原计划约每两年授出一个新批次。2025年TRKT3共72颗由四家承接，Rocket Lab的基础份额为18颗、公司披露基础金额约8.06亿美元；2026年另有36颗AMDT3由L3Harris与Sierra Space获得，说明作战需求增加并不等于Rocket Lab续获订单。Rocket Lab于2026年9月通过TRKT3初步设计评审，但那是设计成熟度节点，不是该批卫星已经在轨运行或已取得作战用户验收。用户对已部署能力的反馈、成熟度和跨批互操作、系统级排期与生命周期成本可以先改变下一批是否启动、规模和时间，再改变竞争机会；若真实决策把采购移至地面、载荷或测试支持，也可能是解除系统瓶颈、稍后恢复卫星采购的前置投入。因此只把可执行的后续卫星采购加速/扩量或实际延期视作边界，不把GAO建议、评审、报告流程或笼统需求口号当成预算与订单。新增18颗相当于Rocket Lab现有单批数量，提前一个财政年度则约为既有两年周期的一半，均能实质改变前瞻机会；但扩量不等于Rocket Lab获配。

- C1 / LONG / OUTER: SDA或太空军发布正式采购计划、资金执行通知、招标或授标，明确由于已部署PWSA能力的作战用户反馈/验收而采取生产采购行动，并满足其一：把下一项导弹预警/跟踪卫星生产招标或授标较此前公开计划提前至少一个财政年度；或在当前已承诺批次之外，新增至少18颗卫星的有资金支持的生产采购。通知须是可执行的生产采购而非仅发布用户反馈、技术评估、GAO建议或原有日程重述。
  - Reference: 截至2026-10-12，D2与GAO材料给出的工作基线是批次约每两年授出；TRKT3于2025年授出，72颗中Rocket Lab获得18颗，2026年另有36颗AMDT3由其他两家承接。当前材料没有下一批的确切授标日期。Rocket Lab自己的TRKT3于2026-09-09通过初步设计评审，尚无本批在轨作战反馈。
  - Boundary: 提前一个完整财政年度相当于把既有约两年采购节拍压缩约一半；在原承诺之外再启动18颗生产量则等于Rocket Lab当前一个批次的整星数量级。任一有资金与正式生产采购依据的变化，已提高后续卫星采购机会/时间的前瞻，不需等Rocket Lab收入或取得该订单；例行评审、未资助计划、少量原型和维持原周期都不足以越界。
- C2 / SHORT / OUTER: SDA/太空军正式修订PWSA导弹预警/跟踪下一卫星生产批次的采办日程或预算执行计划，因作战用户确认的能力缺口、成熟度、跨批互操作或系统排期/成本治理问题，将该批授标至少推迟一个财政年度（若无可比先前日期，则正式移至FY2029或以后）或取消，并明确生产采购被暂停/移出当前周期，而不只是增加报告步骤。
  - Reference: 当前正常路径为持续批次竞争、约两年一次授标，TRKT3在2025年签约；当前D2未取得GAO建议均已实施或旧批全部失败的证据，也没有证明Rocket Lab现有TRKT3基础合同被削减。
  - Boundary: 相对约两年的既有批次节拍，正式增加至少一个财政年度的无新生产采购间隔已损失半个周期，影响的是下一轮卫星竞争而非已签18颗基础工作。需要官方采办/排程或资金决定将该机会延后或取消；报告措辞变严、技术复核或将资金短期投往地面/测试但同时保留原卫星采购日期，不单独构成下修。

## SBI竞争性演示与里程碑筛选对Rocket Lab的选择权

Space Force 的 Space-Based Interceptor（SBI）当前是竞争性原型采购，而不是已确定的重复制造订单：SSC披露2025年底至2026年初签出20项OTA、覆盖12家公司，合计潜在上限最多32亿美元，初始能力演示目标为2028年；Rocket Lab于2026年5月称其与Raytheon合作入选能力演示，且公司Q1披露称其发射与卫星能力均用于SBI，但未公开Rocket Lab独立授标额、团队份额或具体成本承担。7月SSC进一步说明，Johns Hopkins APL作为独立技术方向代理管理从火控、地面系统到太空拦截星座的接口一致性；企业先投入、再按开发里程碑竞争额外资金。因此评估不只看单项拦截器性能：方案必须能够融入完整防御架构，而整体资源可负担性会影响能否扩展；一次成功测试本身不等于团队保留或规模采购。若Raytheon–Rocket Lab团队被正式保留并进入后续有资金支持的里程碑，政府继续投入该方案的概率上升，Rocket Lab未来航天器/发射工作的选择权扩大，并可能部分降低后续开发的自筹压力；若团队被淘汰、失去经费或退出，相关选择权收缩，早期自投的回收风险上升。FY2025公司约47%的收入来自美国政府及其主承包商/分包链，说明该采购渠道有分量，但不是SBI收入占比，不能用32亿美元上限估计Rocket Lab订单或利润。

- C1 / LONG / MIDDLE: USSF/SSC或正式项目/合同方公开确认，Raytheon–Rocket Lab团队被保留、选入或获得当前能力演示阶段之后的下一项有资金支持的SBI开发里程碑；公告须确认Rocket Lab仍是该团队的参与者，而不是只有Raytheon单独获奖。
  - Reference: 截至本任务信息截止，USSF公开的起点是20项OTA、12家公司及最多32亿美元的合计潜在值，另以2028年为初始能力集成演示目标；Rocket Lab称其与Raytheon入选演示，Q1公司材料称其发射和卫星能力用于SBI。SSC公开材料未给出Rocket Lab独立合同金额、份额、量化测试排名或最终配置。7月31日SSC称APL将协调跨系统接口，并说明企业先投入、再竞争后续里程碑资金；故当前是有公司参与的原型选择权，不是已批准生产路线。
  - Boundary: 第一项官方、可公开识别的团队晋级事实已足够：USSF/SSC在评估后把该团队保留在下一有资助的开发阶段，或直接授予该团队额外里程碑资金。此类决定表明政府愿继续筛选并投入这一方案，Rocket Lab仍暴露于后续开发机会；无需另行取得完整演示评分、APL接口文件或团队分账，也不用等到2028年集成演示、重复制造、正式部署或新的目标公司订单。一般技术试验成功但没有政府接受/晋级信号，或只公布Raytheon获奖且未确认Rocket Lab仍在队内，不足以证明目标获益。晋级是选择权改善而非目标已获收入，潜在自筹成本仍未知。
- C2 / SHORT / MIDDLE: USSF/SSC明确宣布Raytheon–Rocket Lab团队未通过筛选、被排除在后续SBI里程碑资金竞争之外或终止其开发工作；或Rocket Lab明确退出并失去其已披露的SBI参与角色；也包括采购方正式取消后续原型与开发资金路径，使该团队不再有下一资助阶段。
  - Reference: 现有公开状态仍是Rocket Lab与Raytheon联合进入能力演示，且公司称其航天器和发射能力用于该方案；但参与仅处于竞争性原型阶段，企业需先行投入，额外资金取决于里程碑筛选。当前没有可据以估算的Rocket Lab SBI专属自筹金额、可收回成本、分包份额或生产承诺。
  - Boundary: 一旦政府或公司明确结束该团队的后续资助路径，或Rocket Lab退出/失去其现有SBI参与，即使还未到2028演示或规模部署，也足以削减该方案继续开发与未来重复制造/发射的选择权，并提高此前投入无法由后续项目回收的风险。若伙伴分工更新仅改变部分职责、但Rocket Lab仍在团队且未说明这项变化是实质性削减，份额未知不足以判断净影响。仅仅下调公司的阶段性自筹金额并不自动构成负向：它同时减少现金暴露，也可能是为退出作准备；只有它伴随团队淘汰、角色退出或资助路线终止时才越界。没有新授奖公告、付款时间延迟、竞争对手获奖但Rocket Lab团队仍保留，或32亿美元总上限的小幅变化本身均不等同于目标机会已丢失。

## 国防航天采购的材料来源追溯与合格来源接受

Rocket Lab的公共采购链暴露覆盖卫星、组件与任务系统，来源和资格规则可在不改变总任务需求时，离散地扩大或缩小产品进入特定项目生产线的范围。FY2025约47%的收入来自美国政府及其主承包/分包采购链，但这不是单一防务项目的份额，也不能推导出某一具体上游材料暴露。GAO在2025年指出，联邦采购记录对底层零部件和材料原产地的可见性有限；2026年9月GAO仍记录DOD在推进供应链信息政策，并指出特定国家来源的磁体/金属采购限制预计2027年1月生效、半导体限制预计2027年12月生效，实施需识别较深层供应链。现有DFARS来源识别条款可在符合条件的供货合同/招标中要求列出实际制造商或来源，但商业产品等有例外，来源身份也不等于原产国禁令。故政府要求记录来源本身主要是合规负担，不足以判断目标利害；真正改写价值的是某一资金落实的国防项目把目标实际供应路线接受/列为合格，或明确排除该路线并影响当前产线。Rocket Lab于2026年9月发布无锗IMM Apex并称其可替代旧产品、现可订购，但该公司公告不是政府采用/资格证据。项目采纳无锗来源可将其由替代路线转成可采购选择；若政府禁用或资格规则使目标实际供货路线无法接受，则可能影响项目资格或排期。两种情况都必须看到具名项目、实际来源和采购结果，不能把政府一般性供应链忧虑推作RKLB新禁令，也不能把新材料新闻推作新增订单。

- C1 / LONG / MIDDLE: 负责采购的政府机关或具名主承包商公开将Rocket Lab供应或生产的一项材料/组件替代路线列入某个已拨款/已授予国防空间项目的合格来源，并确认该来源已用于或被合同要求用于该项目的实际生产批次。
  - Reference: 截至2026-10-12，Rocket Lab的IMM Apex在2026-09-08以生产发布和可订购产品形式公开，官方公告称其不含锗、31.5%初始转换效率、比常规替代品轻40%，可作机械/电气drop-in替代；底层IMM技术有在轨履历，但公告未称IMM Apex已获任何具名国防项目采用或列入批准来源。GAO 2025报告提出测试如何用合同要求收集原产地信息；GAO 2026年9月报告更新特定磁体/金属及半导体限制的实施路径，但没有指出目标产品来源。
  - Boundary: 当一个具名、资金落实的国防卫星或空间系统生产项目将Rocket Lab的替代路线列为正式合格来源，并给出生产采购/批次采用事实时，首次跨过从商业可售/技术兼容到政府项目接受的边界，足以改善该产品进入相关采购的资格与可选择性。仅有产品发布、供应商资格申请、实验测试、技术可替换声明、普遍国内制造偏好或数据提交条款不够；无需等到完工交付或公司披露该项目净收入。
- C2 / SHORT / MIDDLE: 采购机关或具名主承包商公开宣布，一项来源追溯、原产地/控制权或合格来源规则适用于有资金且仍执行的国防航天生产项目，并确认Rocket Lab实际供应/制造的一项关键材料或组件因来源/资格不符被排除、暂停接受或必须重新资格验证，且现有批准替代路线尚未接替其功能。
  - Reference: 公开材料尚未识别Rocket Lab当前国防航天项目逐项使用的关键材料来源和原产地，D2只记录部分输入依赖单一/有限来源而未具名；GAO显示DOD底层供应商信息仍有限。DFARS 252.217-7026在适用的来源识别场景要求实际供应来源/制造商信息，但这不是普遍国家来源禁令。IMM Apex消除锗并公开可订购是潜在替代路线，不证明政府已接受或用于特定合同。
  - Boundary: 一项仍获资助的同用途生产线发生明确的来源资格拒绝、停止接受或由此导致的再资格/排期阻断，且采购机构/主承包商公开指出受影响的是Rocket Lab实际供应路线而非抽象行业风险，才足以改变该产品在该项目中的可竞争/可交付状态。单纯要求披露或追溯、政策宣布尚未明确适用产品/国家、未公开的潜在供应风险、或尚有已接受替代并能按当前计划供货，都不足以跨越SHORT边界。

## 国防卫星同用途竞标池的供给成熟与整合

国防采购者先按具体使命在合格承包商间分配星座工作，供方数量、可兑现产出与系统成熟度决定后续同用途采购的竞争密度。Rocket Lab在SDA Tracking Layer Tranche 3获18颗工作；Lockheed Martin、Northrop Grumman、L3Harris各获18颗，后续AMDT3另有36颗分给L3Harris与Sierra Space，显示行业需求增加并不等于Rocket Lab续获同等任务。FY2026.1 STRATFI选择11家公司，合计资金池5.625亿美元、其中2.45亿美元私人资本，但SpaceWERX说明后续尚须确定合同条款、完成里程碑并成熟技术以争取转移；单个被选企业的金额、任务用途与可交付能力均未由汇总数给出。因此资本支持、技术演示、具名生产承诺和实际合格交付是不同阶段。一个同用途供方形成与当前单家18颗相当的已资助生产责任，已足以新增一块有竞争意义的供给；相反，只有当原供方退出而采购者维持已资助的同等任务块时，退出才减少竞标压力。大型主承包商收购后若把能力放入自己同用途生产线，会形成更强整合竞争者，而不应被当作普通供方消失。整星/星座供给竞争在本规则内，子系统外部分包采用和具体招标份额另行判断。

- C1 / SHORT / MIDDLE: 政府项目办公室或采购主承包商公开确认，Rocket Lab以外的一家供方从原型/过渡阶段进入与Rocket Lab可竞争的同用途国防卫星项目，并获得有明确资金义务和交付排期的生产批次；该批次至少相当于一名现有TRKT3供方的18颗任务规模，或公告给出可比的单家任务系统生产责任。公告须说明技术资格/任务验证已达到项目要求或已进入合同规定的资格生产阶段。
  - Reference: 截至2026-10-12，Rocket Lab在TRKT3获18颗，另三家各18颗；AMDT3新增36颗分别由L3Harris和Sierra Space承担。SpaceWERX在2026-08公布11家STRATFI选择，5.625亿美元为项目级合计、2.45亿美元为私人配套；公告说明每家尚需确定合同条款、里程碑和潜在转移，并未指出这些获选者已取得与Rocket Lab同用途、同规模的飞行生产任务。18颗是现有供应商级工作块，不代表任意小型试验的统一门槛。
  - Boundary: 一份同用途、单一供方至少18颗或等效任务级系统的有资金义务生产合同/生产批次，并有可识别交付期或项目规定的资格生产安排，首次把供给从‘候选或原型’推至可参与下一轮分配的同类生产能力，足以增加一名同规模竞争者。单独获得STRATFI/SBIR资金、私人融资、工程演示、结构件完成或未说明任务数量的合作不够；无需再等完整星座验收或Rocket Lab因此失去合同。
- C2 / SHORT / MIDDLE: 已在相关任务池具备生产能力的主承包商公开完成对同用途卫星供应商/产线的收购，并说明被收购能力将并入其仍在执行或已获资助的同类任务生产，而非保留为独立的行业商用供方或仅持有股权。
  - Reference: 当前TRKT3已有Lockheed Martin、Northrop Grumman、L3Harris与Rocket Lab四家单家18颗分配。Lockheed Martin于2024年完成对Terran Orbital的收购，并称后者将继续作为面向行业的merchant supplier；因此‘收购完成’本身既未证明能力已内部化，也未证明产生新的同用途竞争生产。
  - Boundary: 仅当交易完成后，公告同时显示被收购的具名产线/能力实际整合进该主承包商的同用途且资金已落实的生产项目，新增或巩固至少一个可与现有单家18颗供应块相比的生产责任时，整合才足以强化竞争供给。只公布股权交易、收购价格、能力简介或继续向多家客户供货，不改变当前竞争容量锚。
- C3 / LONG / MIDDLE: 一名已在同用途国防卫星项目持有同级生产任务的非Rocket Lab供应商，因停产、财务退出或正式终止而被项目机构从仍在执行的供应池移除；采购机构同时公开保留原有资金与任务规模，并将至少一个原单家同级生产块重新开放给仍合格的供应商竞争，而未公告具备同等能力的新接替者。
  - Reference: 当前SDA相关供应池已有多家正式获授：TRKT3每家18颗；AMDT3在其他两家新增36颗。厂商融资困难或私募资金撤回并不自动转为Rocket Lab订单，因为采购者可能延后任务、缩小规模或改用新承包商；单个承包商退出只有在项目需求和资金仍在、同用途供方集合实际变小时才改善相对竞争条件。
  - Boundary: 一块原有18颗或等效单家生产规模的同用途任务仍留在已资助、时间仍有效的采购计划中，正式退出使其进入较小且明确的合格供应商池重新竞争，足以减少一个可用竞争来源。若合同只被取消/延迟、预算转投其他用途、需求缩小，或新整合主承包商承接并增强有效供给，则不构成LONG边界。

## 盟国航天架构与跨境产业采购入口

盟国决定采用单轨或多轨、政府自建或购买服务、以及本土控制与联合兼容采购，会改变卫星、运营、发射和组件的供应链分工。跨国标准/联合采购能扩大可参与的供应商池；主权运营、本地制造或国内主承包要求则可能把高价值集成和任务责任留在本地，外国厂商能否以主承包商、伙伴或部件/发射供应商进入要按具体工作范围判断。澳大利亚2023年曾将JP9102首选投标人定为Lockheed Martin Australia，2024年国防部长澄清项目并非取消，而是重设为更分散、具韧性的未来通信方案。日本Synspective于2026年9月选择MHI的H3在2027年发射两颗StriX至中倾角轨道并称其为战略自主路线；但其10月1日同时公布2028—2031年20次Electron专属发射合同，累计47次、尚有34次未飞，说明这一H3任务并不证明既有Electron分配被替代。JAXA基金公开名单将Synspective列在下一代地球观测市场扩张主题（该主题总额上限约100亿日元），并非单独披露H3发射补贴金额。Rocket Lab有跨国商业发射和航天器/组件供应能力，但未发现其获得澳大利亚重设项目或其他盟国特定公共系统的采购份额；美国政府采购链收入比率也不能外推为盟国订单。

- C1 / LONG / OUTER: 盟国或多国联合采购机关为一个具名卫星、通信/遥感系统、星座或发射/运输能力项目批准预算并发布正式竞争性招标或授标安排；项目要求与Rocket Lab可供给的航天器平台、组件、卫星生产或发射角色相符，且文件明确允许合格的非本国供应商直接竞标或作为本地伙伴承担具名工作包。
  - Reference: 目前跨国机会必须按国家和采购项目分别判断。澳大利亚JP9102原计划是主权控制通信体系：2023年澳方公布Lockheed Martin Australia为首选投标人；2024年11月国防部长说明不是取消整个项目，而是因技术演进重设为更分散、具韧性的未来通信方案。没有公开证据显示Rocket Lab进入澳方该项目。日本方面，Synspective与MHI签约两颗StriX于2027年以H3发射至中倾角轨道；2026年10月1日它又与Rocket Lab签20次Electron任务，安排在2028—2031年，合计47次且34次未飞。JAXA基金资料把Synspective列在地球观测市场扩张主题中（该主题约100亿日元上限），不证明H3合同由专门发射补贴资助。
  - Boundary: 获批预算下的正式招标/授标首次给非本国航天器、组件、发射商或本地合作伙伴一个明确、可竞逐的目标相关工作包，才从外交兼容或潜在架构走向实际可寻址采购机会。无需Rocket Lab中标，也不等待制造交付；只有共同标准、MOU、计划、预算增长或不含目标相符供应角色的招标不够。
- C2 / SHORT / OUTER: 盟国对一个具名、已预算的航天采购正式定标或修改资格规则，将目标相关的卫星平台/制造、系统集成、运营或发射工作包保留给国家控制的本地供应商，并明确排除非本国公司直接参与该工作包，且该批采购没有可承接同类目标产品的外国供应商/伙伴分包入口。
  - Reference: 当前案例展示本地路线存在，但并非所有本地选择都等于排挤Rocket Lab：澳方将JP9102由单一架构重设为分散、韧性通信项目，尚未公布Rocket Lab采购位置；Synspective的H3合同对应两颗2027年中倾角任务，而同一客户仍有2028—2031年20次Electron合同。Japan SSF名单提供对Synspective Earth-observation market development的公共支持证据，但未给出H3专属资助额或Electron合同取消。
  - Boundary: 正式规则或授标必须把目标可供给的那一类角色实质性锁定在本地，并关闭可行的外国直接/伙伴供应路线，才足以降低其同类跨境可寻址份额。单纯偏好本地、要求本地维护/合作但仍给外国厂商明确竞标或分包包件、国内火箭承担不同轨道或额外批次、或只公布本土航天预算，不越过SHORT边界；该条件不声称公司已有订单被取消。

## 国防商业数据使用权与可竞争航天能力采购

国防和情报机构既可自有传感器与卫星，也可购买商业影像、数据和分析服务；采购的数据权利决定谁能用于训练、作战及跨机构/伙伴共享。GAO-26-107959记载JCO在2023年1月至2025年9月通过Global Data Marketplace（GDM）支出7,680万美元，NRO与NGA也购买商业影像和分析；Space Force部分潜在用户因许可成本、感知到的使用限制和长期访问顾虑而犹豫。权利按许可而非所有权购买，扩大到更多人、组织或国家通常更贵；但部分政府目的权利允许全政府用于训练、运营等，且已购买并享有权利的数据据JCO说不会因GDM服务合同变化而失去访问。GAO所列支出只涵盖数据及相关服务，明确排除商业航天硬件、发射和卫星通信，不能当作Rocket Lab的可寻址收入。其同时记载GDM运营合同原到期日为2026-07-31、GSA在2026年4月表示计划延长并推进后续合同；报告没有确认该计划已在截止前完成。Rocket Lab约47%的FY2025收入来自美国政府及其主承包/分包采购链，但这不是商业数据收入或单一任务暴露；目标的传导要经过新采集能力、平台/组件/发射采购，以及该采购是否开放给市场。商用容量可能替代部分政府自有传感器，也可能让运营商扩大星座；反过来，政府自有系统若通过外部竞争采购，也能形成直接硬件机会。

- C1 / LONG / OUTER: 一个具名美国国防或情报任务的采购机关正式发布有已批准资金支持的竞争性采购，要求新增政府自有的卫星/传感器或任务平台，并在采购范围中列出可由商业承包商竞争的航天器、有效载荷集成、组件或发射工作；该工作是新采集能力，而非仅维持现有政府星座运行、分析既有档案或开展无资金的方案研究。
  - Reference: 截至2026-10-12，国防任务已并行使用政府自有能力与商业数据服务。GAO-26-107959报告JCO在2023-01至2025-09通过GDM购买7,680万美元数据及服务，并确认NRO/NGA另有商业影像/分析采购；该报告不包括商业硬件和发射，也未将这笔支出拆成可归于Rocket Lab的任务。Rocket Lab的美国政府/主承包商/分包商收入占比约47%（FY2025）是跨业务汇总，不代表某一情报项目或遥感星座。现有材料未显示本主题中一项新政府自有遥感能力已为目标预留供应位置。
  - Boundary: 具名项目的已资助采购文件首次把新增航天器/传感器容量及市场可竞争的硬件或发射工作落到可执行招标/授标范围，即从继续使用现有能力转为新的、可由外部供应商争取的设备需求，足以扩大目标可参与的机会；不必等待Rocket Lab中标、交付或披露收入。战略表态、未资助研究、仅续运现有卫星、框架总额或只加购数据许可均不越界。若新系统由政府内部提供或采购被明确限制为封闭渠道，也不符合本条件。
- C2 / LONG / OUTER: 一个具名美国国防/情报任务通过已资助的多年商业数据或服务合同，把作战和/或训练使用权授予明确用户群，并承诺超出既有档案或空余能力的新持续采集、专用容量或卫星/传感器扩建；同一采购安排公开了可由外部供应商竞争或承接的新航天器、有效载荷、组件或发射工作。
  - Reference: GAO所述当前方式是混合采购：数据通常按许可而非所有权购买，GDM权利层级按人员、组织或国家扩大且一般会提高价格；NRO与NGA也使用可在更广用户群间分享的终端用户许可。GAO记载部分Space Force用户担忧许可费用、限制和长期访问，但JCO表示持有相应权利者不会因平台合同变动而失去已购数据访问；GDM运营合同原到期日为2026-07-31，GSA在同年4月计划延长并准备后续服务，GAO没有确认延长已执行。2026-02 NRO宣布首批三项多模态遥感CSO奖项，表明商业采购已经存在，但没有公开证明这三项授予Rocket Lab或包含新增卫星/发射工作。
  - Boundary: 多年、已获资金的采购首次把广泛运行/训练权利与超出现有数据或容量的新采集承诺结合，并公开给出可竞争的新航天器/传感器/发射供给路径，代表商业服务从更多用户使用既有数据越过到需要额外空间能力、可传导至目标产品的资本需求。无需等新卫星在轨或目标获单；仅扩大许可、加入工作组、购买已收集影像、或没有新容量和供货路径的服务续约不够。
- C3 / SHORT / OUTER: 采购机关对一个具名任务正式取消或删除原已公开资助/招标的新卫星、传感器或商业新采集容量，明确改由现有政府资产或既有商业档案/空余容量满足同一任务，并且修订后的范围不再包含可竞争的外部航天器、组件或发射采购。
  - Reference: 当前政府商业数据购买和自有系统并行。GAO指出商业服务在某些低专业度需求中可避免动用政府专用卫星，但也指出具体使用受许可、预算和长期访问疑虑影响；部分已有政府目的权利的数据能跨机构用于训练和运营，JCO称已购数据的既有权利不会因GDM平台合同而自动消失。一项商业许可决定并不证明硬件市场被取消。目标可参与政府卫星及发射采购，但公开资料未把全部商业影像/分析计划与目标供应链相连。
  - Boundary: 同一具名任务原本有新造/新采集、对供应商开放的硬件或容量采购，后因正式重编范围而由现有数据或既有资产替代，并且该硬件/发射机会明确退出，才会削弱目标可寻址的新硬件需求。若商业合同要求新卫星/新容量、或政府以另一个开放的自有系统招标替换，不能视作SHORT；GAO报告、访问疑虑、一般性自建偏好、延期但仍保留采购、或既有数据共享本身也不触发。

## NASA科学新任务组合与小型运输、Photon平台采购入口

NASA科学账户先约束新任务可用资金，但具体科学目标排序、任务规模与项目级新开始决定资金进入新建航天器/独立飞行采购，还是继续观测运行、较大型任务或其他主承包链。只有新预算形成独立小型科学任务，并进一步产生单独的发射或航天器平台工作包，才增加Rocket Lab可竞争的Electron专属运输或Photon平台机会。NASA FY2026 Science已颁布预算为72.50亿美元；FY2027行政请求为38.939亿美元（低46.3%），而Exploration请求85.139亿美元、较FY2026的77.83亿美元高9.4%，两者只是请求而非最终拨款。截至cutoff，P.L.119-103以FY2026相关拨款水平为继续项目/活动提供临时经费至2026-12-11；众院委员会报告H.R.8845建议Science为60亿美元（比FY2026少12.5亿美元），并建议至少3000万美元用于大学小卫星任务，但这仍是委员会建议，且该小卫星条目不是专属发射采购。NASA在2026-06-25已于VADR选择Rocket Lab执行两次PolSIR专属Electron发射和一次TSIS-2 Electron发射；PolSIR是两颗16U CubeSat、观测轨道相隔3至9小时，生命周期成本上限3700万美元且不含发射，说明任务相位和独立小型任务可使专属运输有独立用途。VADR的10年300百万美元是多供应商共享框架上限，不是Rocket Lab订单。Photon平台是不同采购对象：NASA支持的LOXSAT安排中Eta Space负责载荷、Rocket Lab提供Photon与Electron，但资料只支持一次技术示范计划，不等于可重复的NASA科学任务采购。预算恢复本身、现有PolSIR/TSIS-2工作、ESCAPADE运行或NASA整体支出，都不证明新的目标订单；反之，科学资金偏紧也只有在新任务启动/独立采购池被正式收缩时才建立负向边界。

- C1 / LONG / OUTER: NASA正式选择或资助一项新的独立小型科学航天器任务（不含已选PolSIR、TSIS-2及既有ESCAPADE运行），并公布其独立运输采购要求及一项面向Rocket Lab可参与供应池的专属小型发射任务竞争，例如VADR/LSP任务订单；任务文件显示独立轨道、观测相位或时间要求，而非只把新载荷附带到大型任务或普通拼车。
  - Reference: 截至2026-10-12，NASA Science的FY2027行政请求为38.939亿美元、FY2026已颁布为72.50亿美元；FY2027全年度Science拨款尚未最终确定。P.L.119-103暂按FY2026拨款条件支持继续项目至12月11日；众院委员会报告建议Science为60亿美元，并列至少3000万美元大学小卫星任务，但均不能视为已实施的新任务采购。NASA在2026-06-25已选Rocket Lab承担两次PolSIR专属Electron任务和一次TSIS-2 Electron任务，形成三个已选择的现有任务。PolSIR的两颗16U CubeSat需相隔3至9小时轨道观测，任务生命周期成本上限3700万美元不含发射。NASA VADR允许独立任务选择专属或拼车服务，10年300百万美元为共享上限，不是目标订单。
  - Boundary: 第一次足以改变新任务池判断的事件，是一项额外于现有三次VADR任务的科学任务已获正式任务选择/资金，并且NASA公开其独立小型发射服务工作包及Rocket Lab可参与的竞争路径；任务轨道或时序需求使专属发射成为实际采购选项。无需该新闻同时给出Rocket Lab最终中标或订单收入。单纯提出预算请求、通过一般小卫星拨款、延续既有观测/运行或宣布新科学概念均不够，因为它们尚未转化为可竞争的独立发射采购。
- C2 / LONG / OUTER: NASA或其获资助的科学任务主承包方，正式选择并资助Rocket Lab的Photon平台/航天器工作包，用于一项新的独立科学任务；该工作超出LOXSAT一次性技术示范及已完成的ESCAPADE设计任务，并有明确的平台供货或任务支持范围。
  - Reference: 当前可确认的NASA科学相关Photon位置是LOXSAT：NASA通过Tipping Point支持Eta Space技术载荷，Rocket Lab提供Photon与Electron；截至本次材料，2026年发射仍是计划，未确认示范执行，也未建立其后重复平台采购。ESCAPADE是已经部署的既有航天器设计任务，不是新Photon订单。现有PolSIR、TSIS-2任务是Electron发射服务，不应当作Photon平台采购。
  - Boundary: 只有新科学任务的正式选择/资金决定同时指向Rocket Lab Photon的平台供货或可辨认的任务工作包时，平台采购路径才比一次示范更进一步；不要求已完成飞行或已确认收入。仅有NASA支持某个载荷、概念研究、通用商业平台采购或Photon既有示范计划，不足以形成新的目标平台捕获。
- C3 / SHORT / OUTER: 国会最终FY2027拨款与NASA正式任务配置/支出计划，或NASA正式的科学任务组合重排，取消或推迟至少一个完整预算周期内所有新的独立小型科学任务新开始及其专属小型运输/Photon平台采购，并明确资金留用于既有运行、少数大型任务/探索项目或其他既定主承包任务；或者NASA正式把该周期的新任务组合改为不再单独采购小型发射/平台的共享拼车架构，且没有同类替代新开始。
  - Reference: NASA FY2027行政请求提出Science 38.939亿美元，但FY2027全年度最终拨款尚未颁布；P.L.119-103仅将FY2026相关水平临时延长至2026-12-11。众院委员会报告的Science建议是60亿美元（较FY2026已颁布72.50亿美元低12.5亿美元），且建议至少3000万美元大学小卫星任务；这些分别反映收缩和保留小任务渠道的两种未定政策信号。现有三项Electron任务和ESCAPADE运行仍是既有活动，不代表未来新开始。
  - Boundary: 只有具备正式效力的全年拨款/支出计划或NASA项目组合决定，明确一个完整预算周期没有独立小型科学任务新开始及单独发射/平台采购，并显示资源向既有运行、大型任务或共享运输集中，才首次足以修订未来小任务机会。行政请求、委员会建议、临时CR、Science账户总额下降本身、单个仪器/发射日程延期或一个独立项目的常规优先级变化均不够；尤其不能把请求金额或NASA总预算按比例换算为Rocket Lab订单损失。

## EMSS固定价空口续约与新增服务收费边界

Iridium以政府专用网关提供EMSS空口服务；2019年七年期合同原定至2026年9月，最后年度固定费为每年1.105亿美元，不随订户或用量计费。2026Q2政府计费用户同比由12.8万降至11.8万，但合同收入仍按固定条款及合同年度阶梯定价变化，因此用户下降不是当期费率收入的同义指标。政府所有并运营的专用网关只兼容Iridium网络，增加切换、认证与连续服务摩擦，却不保证政府按旧价续约。当前最敏感的变量是新合同的固定年费、承诺期限及所含服务责任：年费变动10%即1,105万美元/年，相对原固定基座可直接重估持续服务收入。Certus等原本可另行收费，PNT尚无独立服务收入基线；确有额外付费的服务订单可增加基座，若新的服务责任被并入原固定包而不增加对价，则扩大义务却不增加收入。Iridium截至2026Q2仍预期2027年3月前签后续合同；旧合同六个月单方续期权和该管理层目标都不是已执行的新多年承诺。美国太空军另有面向COMSATCOM/EMSS的市场调查与规划通知，但这类采购信息本身不是已选替代供方、空口服务迁移或Iridium收入。所有变化先修订待交割Iridium的独立经营预期，交割前不算作Rocket Lab现有收入。

- C1 / LONG / MIDDLE: 美国政府正式授予或Iridium披露已签署EMSS空口后续合同/修订，且该合同为核心既有空口服务提供至少连续12个月的 firm/已承诺服务期，落在管理层2027年3月目标之后，年化固定费不少于1.105亿美元；或者合同至少12个月的年化固定费达到1.2155亿美元（旧费率上调10%），服务范围与原固定基座可比。确认的基础期限/最低承诺才计入，不把未行使选项、IDIQ上限或政府市场调查当成承诺。
  - Reference: 供给材料所载的2019年七年EMSS合同原期到2026年9月，最后年度固定费1.105亿美元，政府可单方按同价延长六个月；Iridium在2026Q2申报中称预计2027年3月前签新合同，但没有披露期限，管理层目标不是已签合同。截止输入未确认行使六个月选项或完成后续签约，日期经过本身不证明停服。既有同价短桥仍在已知过渡路径内；本条件只比较在目标之后新增的已承诺期限或明显更高费率。
  - Boundary: 至少12个月的固定价服务确定延续到2027年3月之后，按旧费率即锁定约1.105亿美元年化收入，超出已知六个月桥接安排；或至少一年的 firm 年费达到1.2155亿美元，较旧基准新增至少1,105万美元/年。仅确认六个月同价选项、只给出目标/谈判进度、或列示未行使选项及IDIQ总上限，都没有跨过这一承诺/年费边界。
- C2 / LONG / MIDDLE: 政府正式授予或签署独立于既有EMSS固定空口包的Certus、PNT或其他新增Iridium服务订单，并披露至少12个月的年化 firm/已承诺对价不低于1,105万美元；该金额是服务承诺而非未行使选项、市场调查中的潜在值或仅有终端兼容/试用。
  - Reference: EMSS固定年费为1.105亿美元且不按用户/用量计价；Iridium公开材料说明Certus等其他政府服务可通过单独安排另收费用，但截至截止输入没有建立独立PNT服务收入或已签新增订单的可比金额。新增付费订单因此是区别于旧不限量服务包的独立收入增量。
  - Boundary: 至少1,105万美元年化、持续至少12个月的firm服务费，相当于原EMSS年费的10%，构成足以改变政府服务收入基座的独立增量；仅框架上限、未行使选项、非付费试点、采购意向或订户增加不提供该固定新增金额，不能换算为收费增长。
- C3 / SHORT / MIDDLE: 美国政府正式宣布或签署的EMSS空口后续条款、价格修订、终止/替代采购，明确使Iridium既有核心空口服务的 firm 年化对价较1.105亿美元至少减少1,105万美元（新年费不高于9,945万美元，且适用于至少12个月）；若合同期限更短，则已明确移出的累计承诺金额须至少为1,105万美元。正式终止或替代授予若移走全部或上述等值的既有服务义务，也满足该条件；仅有竞争征询、客户订户减少或状态未披露不满足。
  - Reference: 当前合同的比较口径为政府专用网关上的既有固定费空口服务，年费1.105亿美元；费率不依订户/用量线性变化。虽然政府可采购其他商业卫星服务，已披露的市场调查只表明采购方在做市场研究，不等于已把Iridium用户/服务移出原合同。未确认是否行使选项、或没有看到新合同记录，并不能独立证明现有服务或收入中断。
  - Boundary: 同范围年化固定承诺降至9,945万美元或更低，即至少减少1,105万美元/年（旧基座10%）；若被移出的服务期不足一年，则仍要求合同明确减少至少1,105万美元累计承诺。该阈值直接落在价格/合同责任而不是用户数上。单纯公布通用市场调查、竞争者能力、短期程序延误或没有续约消息均不等于已实现费率/范围损失。
- C4 / SHORT / MIDDLE: 已签署的EMSS新合同或修订明确把至少一项此前可独立收费的完整服务类别（例如Certus空口，或带有新增可用性/运维责任的PNT服务）并入原固定包，且该类别没有单独收费/承诺对价，原固定年费仍为1.105亿美元或更低。仅列为兼容终端、服务测试或不增加客户责任的技术能力，不满足。
  - Reference: 原EMSS固定费为1.105亿美元/年，合同允许无限授权用户使用指定空口服务；公开年报说明Certus等其他服务此前可由政府按独立安排另行付费。PNT没有已披露的独立收入基线，故只有合同实际承担新增服务责任而未另收费用，才可直接比较收费边界，而不以技术发布推算成本或收入。
  - Boundary: 当新的付费服务类别及其明确服务/支持责任被纳入同一固定年费、而年费保持不变（或下降）时，原本独立收费的增量机会消失，单位服务责任增加而合同对价没有增量；这是最直接可识别的打包稀释。单纯续约同一范围、增加既有不限量用户，或分别签署有价服务订单，不是该负向边界。

## 工业设备配置与运营采用驱动的Iridium IoT付费连接

Iridium成熟SBD IoT的服务收入由付费设备线和渠道获取决定。2026Q2商业IoT收入为4,707.1万美元、期末计费用户209.1万、月ARPU 7.64美元；同比用户增长而ARPU从7.83美元降至7.64美元，说明设备/用户扩张并不自动带来同幅价值。若新客户以远程设备维护、异常诊断和停机响应为付费工作流程，新增计费连接可扩展现有IoT收入基础；在每线ARPU不变的静态算术下，10万新增季度平均付费用户约对应229.2万美元季度收入，约为当前IoT收入的4.9%及用户基数的4.8%，但这不是该类客户的预期价格或收入预测。HD Hyundai已选用Iridium连接Hi MATE远程设备管理，证明重型设备能进入实际服务配置；其用户量和付费规模未披露。SKYWAVE集成Iridium SBD进入其多网终端仍在进行，提供卫星、蜂窝与Wi-Fi选路并未证明已大规模量产。ORBCOMM于2026年4月宣布4.60亿美元再融资及未提取融资额度，可支持平台库存、软件和大客户部署的融资能力，但没有证据说明款项专用于Iridium产品；平台资本是部署约束，不是客户采用。设备所有者使用离网连接的回报受覆盖缺口、停机损失和数据工作流影响；本地仅上传异常或蜂窝优先可降低流量/成本，也可能促进更多设备采用。只有当月费、付费线路或实际合同价值受影响时，较低数据量才改变Iridium服务经济性。交易仍待交割，以上当前属于Iridium标的的运营暴露。

- C1 / LONG / MIDDLE: 工业设备OEM或资产运营商宣布已签约/开始生产级付费服务，把Iridium SBD连接用于真实的远程监测、诊断、预测维护或现场服务工作流；新增且明确归属于Iridium的付费连接达到约10万条，或披露同等规模的持续性连接服务收入承诺。
  - Reference: 截至cutoff，Iridium 2026Q2 IoT业务为209.1万期末计费用户、4,707.1万美元季度收入和7.64美元月ARPU；同比用户由192.4万增至209.1万，ARPU由7.83降至7.64美元。SKYWAVE与Iridium宣布合作，SBD仍处于嵌入SKYWAVE终端的集成阶段，支持重型设备诊断和维护但尚未披露生产客户、激活用户或费率。HD Hyundai于2025年已选择Iridium接入其Hi MATE远程机队管理，公告未披露规模和具体收费。
  - Boundary: 至少约10万新增、可计费且持续的Iridium连接，相当于现有2.091百万IoT基数约4.8%；按当前7.64美元ARPU作静态参照约为229.2万美元/季度、当前IoT季度收入约4.9%，并非未来单位价格预测。若连接服务采用合约而非订阅，只有披露了同等的经常性服务价值才可替代该线数门槛。消息还须将付款/服务责任归于设备OEM、方案商或运营客户，并确认产品已用于运营工作流；100万台兼容设备、试点、终端集成、未激活的标配选项或总设备出货量均不跨界。付费服务上线合同本身即足够，无需等待收入确认或卫星采购。
- C2 / SHORT / MIDDLE: 设备OEM或离网资产运营商取消、不续约或实质缩减一个已运行的付费Iridium连接项目，使约10万条已计费连接（或同等经常性服务价值）迁出Iridium或停止付费，而非仅降低单设备消息频率。
  - Reference: 当前成熟商业IoT有209.1万期末计费用户、4,707.1万美元2026Q2收入和7.64美元月ARPU；已知HD Hyundai选用Iridium的Hi MATE方案，但未披露其计费基数。SKYWAVE新集成仍未形成已知的大批量账单用户。接入费/订阅与按量收费对低数据量的敏感性不同，简单端侧处理本身不等于退订。
  - Boundary: 正式取消、非续约或转出至少约10万既有Iridium计费线，约等于当前IoT用户基数4.8%；也可以由公开的续约/合约金额减少证明约229.2万美元/季度当前ARPU参照的经常性收入价值损失。对按量收费客户，若线数保留则须披露价格/付费使用范围同步下降到等值规模，才足以跨界。设备仍连接但在边缘处理、减少传输、保留固定接入费，或客户改用驻地同步却没有取消Iridium账单，不足以支持该方向。

## NTN Direct移动运营商渠道的付费连接扩容与撤回

Iridium NTN Direct通过标准NB-IoT和现有运营商SIM/漫游入口，把Iridium覆盖带入无地面覆盖的设备连接；其首先改变的是可接入并愿付费的IoT设备与地域范围，不是Rocket Lab的新造星或发射订单。Iridium 2026Q2商业IoT已有209.1万期末计费用户、4,707.1万美元季度收入、7.64美元月ARPU，是成熟业务规模锚；这些不是NTN Direct用户、费率或预测。9月17日Deutsche Telekom称漫游集成完成，Iridium服务已向使用兼容NB-IoT设备的客户商业开放，但最初只由Nordic模块及最新版固件逐步向部分客户发布；其网络还整合Skylo、Sateliot和OQ Technology，故增加的兼容设备不等于Iridium获得全部流量。Vodafone于2025年公布合作并计划在集成和测试后于2026年作全球商业发布，是另一条仍待落地的渠道，不能视作DT服务已复制。未来若付费入口从部分已选设备扩展至广泛商业用户，服务可达市场和成为付费IoT用户的概率会提高；实际收入仍取决于激活、SBD迁移比例、批发结算、流量选路和使用频率，低功耗NB-IoT亦不等同高带宽需求。交易截至cutoff尚未交割，经营变化首先属于Iridium标的，未来才进入Rocket Lab合并业务。

- C1 / LONG / MIDDLE: 移动运营商将经Iridium网络路由的标准NB-IoT卫星服务，从选择性测试/初期设备群扩展为可向更广泛的商业IoT客户购买或激活的服务，并公开新增的设备类别或服务地域；仅固件兼容、技术演示或既有SBD用户一对一迁移不构成该事实。
  - Reference: 截至2026-10-12，DT于9月17日宣布其与Iridium的全球漫游集成已完成，服务已可供兼容设备客户商业使用，但首发为Nordic模块、最新版固件及逐步开放给部分客户；欧洲方案商在测试。Iridium 9月10日的Q4商业目标早于DT 9月17日公告，不能再当作尚未发生商业开放的唯一基线。Vodafone 2025年合作仍以完成集成/测试为商业发布前提，并计划2026年推出全球服务；与DT阶段不同。没有已披露的NTN Direct付费激活用户数、NTN批发价格或流量分配份额。
  - Boundary: 出现一个实际可购买/可激活的付费服务扩围，且可售设备群或地域超出DT当前Nordic模块、部分客户的选择性发布，覆盖新的广泛客户类别或新市场；公告须说明用户/客户可付费使用，不要求披露保密的批发单价或季度收入。仅复制既有SBD线、免费试验、兼容性扩大但仍只限选择客户，或只复述全球覆盖能力，尚未跨界。此边界已把一个潜在可接入市场变成更大范围的付费商业入口；多轨道选路仍使Iridium实际捕获份额未知。
- C2 / SHORT / MIDDLE: Deutsche Telekom公开终止或实质撤回已经完成的Iridium NTN Direct商用接入，或从其IoT漫游组合移除Iridium，令当前选择性商业服务不再可售；一般分批发布或单一模块固件延期不构成撤回。
  - Reference: DT的漫游协议和技术集成已经完成，兼容Nordic模块客户已进入商业开放/逐步发布；这是一条已完成集成且部分可售的渠道，不是全部设备均激活。多轨道组合中存在其他卫星伙伴，DT仍可提供其他连接路线。
  - Boundary: 只有服务被正式停止、Iridium从可售组合被移除，或商业资格被收缩到原商业客户不可再购买/使用，才足以向下修订当前已打开的接入渠道。个别固件版本延迟、选择客户阶段延长或未披露流量数字，均不证明收入流失；即使跨界，结论也限于该新增服务渠道的机会，不外推为全部Iridium IoT业务下降。
- C3 / SHORT / MIDDLE: Vodafone IoT公开取消Iridium NTN Direct集成/全球商业发布，或宣布因集成/产品障碍将原定2026年商业发布推迟至2027年，撤回这条已宣布的运营商服务路径。
  - Reference: Vodafone与Iridium于2025年11月宣布合作，面向其NB-IoT客户提供Iridium接入；该新闻将成功集成与测试列为前提，并称计划2026年商业发布。截止日没有可用的Vodafone NTN Direct商用服务或付费连接记录，因此它是前瞻渠道，不是当前收入基线；也不同于DT已完成漫游集成并向部分客户开放。
  - Boundary: 明确终止合作，或正式把原定2026年的全球发布目标移至2027年或以后，已经使未来一年内的全球服务路径落空，足以降低该渠道兑现概率与时点预期；不要求伙伴同时宣布Iridium收入损失。正常测试、未更新新闻、市场份额未知，或2026年内继续分批发布不构成边界；该负面限于未来渠道机会，不代表已有Iridium付费用户被取消。

## 多网络聚合与转售渠道的Iridium客户入口和价值分配

Iridium的商业连接主要经批发伙伴售给终端用户；服务提供商与VAR管理终端账单、客户关系和零售定价，Iridium则取得批发服务收入。多网络聚合商能够集中采购、选择默认路由并决定在产品中推广哪个网络，因此即使终端总联网量不变，Iridium获得的付费连接比例和新客户入口也会改变。2026-09-17 Deutsche Telekom宣布把Iridium加入其多轨道IoT漫游组合，但Iridium与Skylo、Sateliot、OQ Technology等仍是组合中的多个卫星伙伴；现阶段商业接入先面向兼容NB-IoT设备及部分客户，欧洲方案商仍在测试，公告没有披露自动选路份额、批发结算或已激活客户数。2025年年报将Marlink和Garmin列为最大两家商业分销商（合计约占当年总收入10%），前十大合计28%；同一年报还记载竞争者Inmarsat收购渠道后曾停止推广Iridium服务，说明渠道控制可先于行业连接需求改变客户接触和分配，但这只是历史先例，不代表本期发生新收购。批发折扣、低获客成本和替代网络可部分抵消份额变化，公开材料不能精确映射一条路由到收入或贡献利润。本Policy的暴露是潜在Iridium经营业务；截至截止日交易尚未交割。

- C1 / LONG / MIDDLE: 一个现有重要聚合商/MNO/转售商与Iridium发布已签署且进入商业执行的路由或分销安排，将Iridium从可选、多网络并列或仅试用位置提升为一个明确的广泛付费客户/设备类别的默认、首选或标准LEO连接，或为该类别签订实际推广Iridium服务的独家/优先渠道安排。
  - Reference: 截止2026-10-12，DT自2026-09-17起已把Iridium加入多轨道组合，协议及技术集成完成，兼容Nordic NB-IoT模块逐步向部分客户开放并有方案商测试；该组合仍有其他GEO/LEO伙伴，没有公开承诺Iridium独家或默认份额。Iridium的2025年年报显示批发分销和一年度自动续约为常态，最大两家商业分销商Marlink/Garmin合计约占2025年总收入10%，前十家约28%。当前未披露DT等渠道的激活数、路由分配及批发费率，因此不能把可用客户总数当Iridium收入。
  - Boundary: 充分边界是正式渠道公告/可信来源确认的有效商业选择改变，而不是仅列名：一个当前核心分销合同（例如两家最大分销伙伴之一）或规模相当的全球聚合平台把广泛、可识别的已售/付费服务群交由Iridium优先/默认服务，或者启动同等范围的标准化付费推广。协议须超出当前DT的非独家新增伙伴、兼容性开放及选择性测试，使Iridium获取常规路由/分销位置；不要求公开精确设备总数或等待下一季收入/用户确认，因为路由承诺本身改变未来接入机会。若同一公告同时披露足以抵消增量的批发折让或非付费安排，按该已公开条件重新定向，不把总联网设备量直接换算成收益。
- C2 / SHORT / MIDDLE: 一个现有重要Iridium分销商、MNO或聚合平台公布并实施/确定实施一项渠道控制或采购选择变化，使一个广泛的现有付费客户/设备类别不再通过Iridium正常销售或将Iridium从其首选/默认路由降为竞争网络，并明确转向、推广或采购替代网络。若由竞争者收购渠道引发，需同时有实际停止推广、终止/不续约或改配路由等经营变化；收购本身不够。
  - Reference: 同一渠道基线适用：DT于2026-09-17新增Iridium但保留多轨道、多供应商选择；Iridium也依赖年度自动续约的批发渠道，2025年年报披露Marlink与Garmin两大分销商合计约占公司总收入10%、前十大约28%，历史上收购后的竞争网络停止推广曾改变销售资源。任务截至日没有证据表明新的渠道收购或渠道退出已经发生。
  - Boundary: 一次公开、明确的重大渠道决定已经足够：例如上述核心分销商之一结束Iridium分销/推广，或一个规模相当的多网络运营商把广泛已付费类别的默认路由从Iridium移至竞争网络。必须能识别存量/新增服务入口及覆盖客户类别，且不是仅调整几个测试设备、短期营销或尚未生效的并购标题。渠道方本身控制客户、账单和路由，故该商业安排可在财报前修订Iridium新增客户和续费捕获；无需等客户总联网量或Iridium收入下跌才成立，但若伙伴仍同时销售并保留Iridium实际优先/备用路由，则没有足够负向新增。

## 商用语音与IoT存量服务的经常性资费和留存

Iridium的商业服务主要经由服务提供商和VAR批发销售，部分业务按订户收取月接入费并另计使用费；Iridium的批发费、折扣和促销影响其单位收入，渠道则负责终端零售价、账单及客户关系。2026Q2商业语音与数据收入为58.387百万美元（同比+3%），期末计费用户由415,000降至402,000，但ARPU由46美元升至49美元，公司称收入增长主要来自前一年实施的价格措施；同季IoT收入为47.071百万美元（同比+5%），用户由1,924,000增至2,091,000而ARPU由7.83美元降至7.64美元。用户总数或名义提价都不能单独代表净收益：批发费是否传递、促销期限、价格敏感用户的续费/降档、用途及支持成本共同改变收入和现金贡献。以Q2期末用户近似一个季度平均基数，每月语音费每用户变动1美元对应约1.206百万美元季度收入；IoT每用户每月0.10美元对应约0.627百万美元，均为固定用户组合的收入敏感度算术，不是毛利或自由现金流预测。商业订阅收入较为经常，但各产品单独毛利、费率表和价格弹性没有披露。该网络及其服务在截止日仍属于Iridium，尚非Rocket Lab已并表经营。

- C1 / LONG / MIDDLE: Iridium或其主要服务提供商/VAR公告并实施面向既有商业语音/数据或IoT付费账户的经常性月费上调，或有明确可分离价格的服务层续约上调；公告须表明新增月费实际归属于Iridium批发服务收入，或说明零售调价按合同传递至其批发收费，而非只改变渠道自身加价。
  - Reference: 截止2026-10-12，现有工作基线已包含2025年实施价格措施后的延续，并非以新一轮调价为零基线。2026Q2语音/数据收入58.387百万美元、期末计费用户402,000、ARPU49美元；IoT收入47.071百万美元、期末计费用户2,091,000、ARPU7.64美元。ARPU是混合服务的季度平均值而不是特定套餐价，任务材料没有公开各批发计划费率、现行套餐分布或留存弹性；比较时须以同一套餐当前/旧的披露费率和同一付费账户范围为锚。
  - Boundary: 最低充分线为有效费率变化带来的既有经常性季度收入增量约0.5百万美元（约各产品当前季度收入的1%）；按Q2期末用户作近似，适用于全体存量账户时约等于语音/数据每用户每月增加0.41美元，或IoT每用户每月增加0.08美元，较窄客户群按公告披露的账户数乘每月增量乘3个月比较。正式公告或可信报道给出存量适用范围及可比旧新费率即可命中，不等待后续ARPU或财报；若同一公告明确披露足以抵消该费率增量的折扣或账户迁移，应按其已披露金额净看。未知价格弹性不要求再追加全部客户留存证明，但本边界只支持经常性收入预期上修，不代表净利润/现金流已经兑现。
- C2 / SHORT / MIDDLE: Iridium或渠道续约/价格公告降低既有商业语音/数据或IoT付费账户的每月批发费、接入费或Iridium实际所得的经常性服务费，或将低于标准费率的促销折扣延长至存量续费期；服务/使用权范围须大体不变，且折价并非仅限一次性硬件补贴或仅减少渠道零售加价。
  - Reference: 比较锚与LONG侧相同：截止2026-10-12，2026Q2语音/数据ARPU为49美元、IoT ARPU为7.64美元，既有用户与收入基数分别为402,000人和58.387百万美元、2,091,000人和47.071百万美元。上一年已执行的价格措施及当前正常延续属于基线；须识别同一存量套餐在新续约/费率期的实际降幅，而不是把低ARPU新客或消费者零售促销自动解释为批发收入下降。
  - Boundary: 若同等服务范围的折价、费率下调或促销延长使存量经常性季度收入减少约0.5百万美元（约当前产品季度收入1%）即足够：全体Q2存量账户作近似时，语音/数据每月约降0.41美元，IoT每月约降0.08美元；较窄适用群以明确账户数×月费降幅×3个月计算。折价实际持续至少一个完整账单季度，或按续约合同持续的季度化差额达到上述门槛，即为充分偏离。无需等待公司公布实际净流失；若折价仅对应服务范围同步减少、渠道单独牺牲自身利润或新客短期硬件优惠，则不据此推断Iridium单位服务收益下修。
- C3 / SHORT / MIDDLE: 一个可信公开来源说明既有商业语音/数据或IoT付费账户在续约、促销到期或套餐调整后取消Iridium订阅，或转入较低经常性费率方案，并披露受影响账户/服务范围；一般客户对价格敏感的评论或未量化流失预测不构成该事实。
  - Reference: 当前季度基准仍为2026Q2语音/数据约402,000期末计费用户、月ARPU49美元及季度收入58.387百万美元；IoT约2,091,000用户、ARPU7.64美元及季度收入47.071百万美元。该用户数是期末而非季度平均，按现ARPU折算仅作数量级参考；D2基线明确语音用户曾下降而价格提升抵消部分损失、IoT扩户伴随ARPU下行，不能把所有流失或降档都视作同等金额。
  - Boundary: 单一披露的取消/降档造成其原有经常性季度收入损失达到该服务类别Q2收入约1%（约0.5百万美元）即足够；按当前平均收入粗算约为4,000名语音/数据用户或21,000名IoT用户，或任何规模等值、明确可比较的合同收入。若是降档，按旧新费率差计算而非把全部用户收入算作损失；若有同一披露的保留费或替代付费套餐，则用已披露的净经常性差额。此类可核实的续约/客户行动本身就是观察入口，不需等全公司下一季用户数，也不要求找出所有潜在流失。

## 消费终端卫星消息内含化与专业独立订阅选择

截至2026-10-12，Iridium商业语音与数据仍是待交割标的的独立业务：2026Q2收入58.387百万美元、期末计费用户402,000（上年同期415,000）、ARPU49美元/月（上年46美元）。以期末用户近似一个季度平均基数，ARPU每月变动1美元约对应1.206百万美元季度收入，是静态收入算术，不是毛利或自由现金流。Iridium主要通过批发渠道经营；终端用户偏好决定是否另购专业设备和卫星订阅，渠道与服务商决定网络实际被选用以及Iridium取得的批发收入。Apple支持的卫星SOS、位置与消息服务，以及T-Mobile/Starlink已商用的手机消息和部分应用连接，降低休闲用户使用卫星功能的硬件与购买摩擦，但覆盖地区、兼容手机、视野条件、速度和服务内容均有边界；电话内含功能并不等于全球专业语音服务。Amazon拟收购Globalstar并与Apple安排未来卫星功能，截止日仍待交割，不代表Amazon网络已全面接管现有功能或已普遍启用。反向一侧，Garmin inReach等专业户外设备须另有卫星服务订阅，其卫星覆盖包括Iridium并结合Skylo等网络；公开材料未披露具体产品/会话的网络分配。专用设备、户外安全与专业支持和电话内含消息不同。Garmin是Iridium重要分销渠道之一，但具体订户、批发价格与每项服务分成未披露。故手机服务扩张可先改变休闲和一般用途消费者对独立订阅的边际需要，不能由此推导专业安全、企业或全球语音业务归零；Iridium直接进入主流手机生态或专业设备订阅扩展则会增加其服务触达机会。

- C1 / LONG / MIDDLE: 具名移动运营商或手机/设备制造商签署并启动面向消费者的商业服务，使Iridium网络为现有消费者手机或无需独立卫星终端的主流个人设备提供卫星双向消息或语音；公开安排须识别兼容设备类别、商业服务范围及可售/明确上线时点，并确认Iridium是该消费服务的实际网络供给方。仅有IoT模块漫游、技术演示、功能兼容说明或未约定消费服务的合作标题不属于该事实。
  - Reference: Iridium目前有成熟商业语音/数据订阅，但主要经专用终端与批发伙伴销售；Deutsche Telekom的2026年合作为标准NB-IoT模块和选择性客户开放，不等于普通手机商用。竞争基线已包含Apple/Globalstar的部分iPhone卫星功能，以及T-Mobile/Starlink在美国商用的手机消息和扩展应用；Amazon/Globalstar收购及Apple后续网络安排尚未完成交割/全面部署。当前没有已确认的Iridium网络面向消费者普通手机的商用计划。
  - Boundary: 最低充分事实是一个具名主流运营商/设备平台将Iridium服务放入已签商业安排并向至少一个重要消费市场的既有设备用户公开提供（或给出明确上线时间和产品范围）；这一步本身改变了Iridium从专业终端进入消费者现有设备底座的可能性，不必等到Iridium披露用户数或财报收入。若只公布技术演示、IoT模块测试、尚无消费范围的标准化研发，或服务实际由其他网络承载，则未越界。商业承诺可能先于真实激活，仍不应据此量化收入。
- C2 / LONG / MIDDLE: Iridium主要分销伙伴或户外设备制造商将需要持续卫星服务订阅的消息/语音/安全产品从现有专业手持设备或小众型号，实际扩展到一个新的广泛个人设备类别或大范围产品系列，并明确该消费者服务在该类别中使用Iridium网络且已商业开放。
  - Reference: 专业户外独立订阅已经存在：Garmin inReach提供消息与SOS等功能，需有效卫星服务订阅，Garmin公开资料将Iridium列为其卫星覆盖网络之一；Iridium年报/季度材料将Garmin列为重要分销商，但未披露Garmin单独占比、此项产品用户数或其批发收益。当前已发布的inReach产品及功能、普通新型号迭代属于基线。
  - Boundary: 足够变化是订阅服务从既有专业手持设备范围进入一个新的、广泛销售的消费设备类别/产品系列，商业订阅条款可见且Iridium被明确列为该服务网络之一；新设备类别的上市和持续付费计划共同表明独立网络服务可达用户范围已扩大，无需再等下一期Iridium subscriber总数。若只是原有系列换代、加一款相近型号、仅功能宣传/免费试用，或多网络产品未说明实际使用Iridium的适用范围，不构成增量边界。
- C3 / SHORT / MIDDLE: 非Iridium的主要移动运营商、手机操作系统或设备制造商对消费者正式商用扩展卫星双向消息/语音或日常应用通信，利用消费者已经持有的兼容手机而无需另买专用卫星设备，并把服务开放给一个新增的广泛机型群或重要新市场；变化须超出截止日已存在的有限地区/机型和功能基线，而非仅紧急SOS概念或测试。
  - Reference: 截至cutoff，T-Mobile/Starlink已在美国以兼容手机提供消息与部分应用连接，最优套餐内含、其他用户可加购；Apple支持的部分iPhone卫星消息/SOS服务也已在若干地区提供。以上已是比较起点，T-Mobile服务扩展到应用、Amazon宣布拟收购Globalstar、Apple相关合作本身均不作为新的负向条件。普通用户的卫星消息和紧急联络开始不再要求专用终端；但设备覆盖、可视天空、地域、交互速度及安全等级仍不同于Iridium专业语音/户外服务。
  - Boundary: 最低充分偏离是一个新的广泛商用扩展：例如新增一个主要移动市场或主流手机产品代际，且普通消费者可在现有手机上使用超出紧急SOS的日常双向消息/应用通信。由于它降低休闲/一般用途用户的独立硬件和订阅需要，服务公开上线本身足以修订边际购买选择，不要求Iridium先报告取消订阅；也不将这一结果外推到具有不同地域覆盖、安全可靠性和设备要求的企业/专业客户。单纯交易完成、宣布未来网络蓝图、没有明确范围的功能演示或当前已存在的服务延续不算新变化。

## 远程运营船岸控制与状态链的独立卫星连接

MASS商业应用的新增连接责任来自岸基人员监控或操作船舶状态、远程控制模式和风险管理，不是船舶自动化标签本身。IMO在2026年5月通过的MASS Code于7月1日生效，但属非强制框架；其要求按船舶运行模式、风险、远程运营中心和人类监督处理安全，并不指定任何卫星供应商或强制采用Iridium。Iridium的全球L-band服务可成为低带宽控制、状态/心跳或备份路径的候选，但不是高吞吐视频/主数据替代；实际价值取决于远程操作是否需要一条与主宽带不同的船岸链、该链是否可付费且有责任/可靠性证明。现有宽带收入下行及Furuno GMDSS/SSAS/LRIT终端计划提供海事安全背景，却没有证据证明远程控制链已经用Iridium，或已有单船价格/独立服务收入。新链路的商业合同与投运可以在最终部署普及前改变市场可行性；规范出台、概念船演示、一般卫星覆盖声明、GMDSS设备和高带宽运营商选择均不能替代这一事件。反向若具体生产船队将控制/状态链完全指定给其他服务商，Iridium的新增用途空间缩小，但不因此消除既有安全/宽带账户。

- C1 / LONG / MIDDLE: 具名船东/船队运营者、船厂或远程运营服务商签订并进入商业部署的安排，明确由Iridium网络承载一条独立的船岸命令、遥测/状态或远程运营连续性服务，且该用途区别于主高吞吐宽带和单纯GMDSS遇险通信；公告须显示正常运营的船舶/船队或明确的付费持续服务，而非技术试验。
  - Reference: MASS Code非强制且技术中立，当前D2只支持远程/自主运行将提高连接和连续性要求的可能性，没有Iridium已进入遥控船队、独立状态链商业合同、服务价格或单船ARPU的证据。Furuno的SOLION-100是GMDSS/SSAS/LRIT安全终端，尚非远程控制服务合同；主数据流量也可以走高吞吐卫星网络。
  - Boundary: 最早充分边界是一份已签、实际投入正常商业运营的Iridium控制/状态链服务合同，适用范围为一个有识别度的运营船舶/远程船队项目，并明确Iridium路径承担独立控制、状态或连续性角色。该商业采购本身第一次把规范和技术可能转化成可付费服务需求；由于当前没有独立服务收入基线，不要求媒体额外披露精确每船费用或等待大规模装船。一次性演示、技术认证/兼容、未授予的采购意向、只提供遇险GMDSS或只承载高吞吐主数据，均不是该边界。
- C2 / SHORT / MIDDLE: 一个具名商业远程运营船队/新造船或改装项目正式采购并投运其独立控制/状态链时，采购结果明确把该功能授予非Iridium方案并排除或替代此前公开的Iridium方案/入围安排；或运营者正式取消该项Iridium远程控制服务计划，导致该生产部署不再使用Iridium。
  - Reference: 没有证据显示Iridium已获MASS/远程船舶控制市场份额，也没有实际Iridium独立控制链收入锚点。IMO的非强制规范本身不规定Iridium，Starlink/其他高吞吐网络当主宽带也不必然替代另一低带宽控制链。判断新机会被关闭，应以具体采购/系统设计为对象，而非从一般自动驾驶船试验中推断。
  - Boundary: 最低充分事实是具名、正式的商业船队/船舶系统决定，明确将独立命令/状态功能整体由另一运营商承担并不再需要Iridium，或取消已经公开的Iridium采购/集成计划。此事实关闭一项具体的新增付费服务路径；不要求因此推断全行业份额下降。若其他网络仅获主宽带、Iridium仍可作为独立控制备份，或者项目只做研究/单船演示/没有说明独立链供应商，则不足以支持SHORT。

## 船队安全终端配置与付费伴随服务价值

Iridium商业宽带服务在2026Q2收入11.674百万美元（上年同期12.724百万）、期末计费用户16,000（上年16,300）、ARPU243美元/月（上年260美元）；按期末用户近似平均基数，ARPU下降17美元约对应0.816百万美元季度收入，接近但不能精确分解实际收入下降。当前较合理的经营路径是高吞吐主链逐渐转向其他网络，而Iridium保留全球安全/备份与低速伴随角色；更多安装不自动恢复原宽带套餐价值。Furuno于2026-09-01公布SOLION-100，基于Iridium Certus 100，把GMDSS、船舶安全警报和LRIT整合到一台终端，计划于2026年末进入改装市场、2027年面向新造船；截止日尚非装船订单或部署数据。IMO已承认Iridium与Inmarsat为GMDSS卫星服务提供者，并未指定Iridium为唯一方案；Iridium公开说明GMDSS遇险服务不收费，普通商业语音/数据需另按商业套餐提供。因此安全终端进入标准配置可扩大服务入口，但只有随之形成持续付费的商业连接/附加服务，才直接支持Iridium经常性服务收入；船东可能只保留免费/最低安全链路。单船收入、设备补贴、装船量、套餐价格与续约期限均未由材料量化，不能从船舶数量或IMO规范单独推算价值。

- C1 / LONG / MIDDLE: 具名船东/船队运营者或船厂正式签署或实施一个船队新造船/批量改装服务安排，将Iridium Certus 100安全终端纳入标准配置，并明确为覆盖的船舶提供持续付费的Iridium商业语音/数据或其他商业连接服务；单纯售卖终端或仅使用GMDSS免费遇险服务不属于本条件。
  - Reference: 截止2026-10-12，Iridium商业宽带收入11.674百万美元/季、约16,000个期末计费用户、ARPU243美元/月；宽带收入和ARPU同比下降，已存在低价伴随套餐。SOLION-100是Furuno已公布产品计划，但改装预计2026年底、新造船预计2027年开放，未披露实际订单、装船数量、补贴或付费套餐。GMDSS本身可由多个获认可的卫星系统提供，Iridium遇险服务免费，不能将GMDSS terminal standard-fit直接当成付费宽带用户。
  - Boundary: 以当前商业宽带线的约1%季度收入作为最低可识别的服务增量，约为0.117百万美元/季；按2026Q2 ARPU静态换算约160个现有计费单位（16,000×1%），是账户等值而非船舶数量。足够事实是一个已签的多船标准安装/改装项目明确绑定至少该等值的重复付费商业服务，或直接披露等值合同收入/计费单位；只有船数时仅在来源说明每艘船与Iridium计费单位/服务合同的对应关系后才换算。至少达到一个完整季度的持续付费服务或明确跨年的服务承诺即可；不要求同时披露实际收入兑现或利润，但免费遇险服务、无付费计划的安全终端、单台样机和已公布的预期上市日期均不足。
- C2 / SHORT / MIDDLE: 具名船东、船队运营者或船厂签署并实施一项将高吞吐竞争网络指定为主链、同时把原有付费Iridium商业宽带/伴随服务降为仅安全或最低套餐、取消或不再续约的船队配置；公开披露须能识别受影响的既有付费服务范围，不能仅因新船装有竞争网络便推断Iridium退出。
  - Reference: 2026Q2 Iridium商业宽带收入11.674百万美元、16,000期末计费用户、ARPU243美元/月；商业基线已包含宽带向低价伴随套餐迁移和收入/ARPU下降。安全链路可以与其他宽带网络并存，因此只新增高吞吐主链、但保留原商业付费套餐/Iridium数据服务，不是已发生流失。
  - Boundary: 以被取消/降档的Iridium重复付费宽带服务净差额达到约0.117百万美元季度收入（商业宽带线约1%）为足够边界；按当前ARPU约相当于160个计费用户单位，部分降档按同一服务旧新套餐费差净算。迁移/降档须生效并持续至少一完整账单季度，或已由多年度船队合同明确锁定。船舶数必须由来源连到计费账户或服务收入；零售网络迁移、设备标准配置、免费GMDSS保留、尚未执行的换网意向及竞争网络的高速数据能力本身不证明付费Iridium服务减少。命中只修订宽带/付费伴随服务，不代表Iridium安全或其他行业业务归零。

## 独立PNT设计导入与替代源的付费价值分配

截至2026-10-12，Iridium仍是Rocket Lab拟收购但未交割的独立业务，PNT不是Rocket Lab现有合并收入。Iridium于2026-07-14宣布PNT ASIC商业可用：8毫米芯片通过Iridium单向加密信号提供位置和授时，降低终端集成负担；Solace的Vector组合多频GNSS与惯性数据、将Iridium用于可信度校验，Skyband则已宣布把ASIC集成至航空M100 LRU。关键基础设施会按失准/中断损失、允许误差和可接受保持时间承担备用责任；认证、终端设计定型及采购/保险条款决定责任是否转成实际预算。位置与授时不能用一个采用率外推：移动航空、无人系统需要满足其任务的可用性与连续性，Iridium的全球移动信号对这类用途有价值；固定电信、电网和金融设施可以用高稳定度时钟跨越外部时间源间隔，也能采用光纤传时。Xona在2026-10-09披露的计划发射六颗卫星，其中四颗将先在初始市场提供服务、约每12小时重访，日均八次、每次约25分钟的信号窗口，仍不是Iridium式连续全球供给；但对配有精密保持钟的固定授时客户，间歇校时可能已经可用。NIST IR 8323是自愿风险框架，NIST已有光纤时间服务也不等于所有运营商都已部署。Iridium在ASIC公告中提及的150家兴趣组织、产品集成及技术测试均不是付费用户数；Solace/ Skyband的合作阶段是基线，Xona既有计时合作与初步计划也已存在。Iridium没有单独披露PNT服务收入、付费设备/账户数或统一价格；Q2托管及其他数据收入16.571百万美元不能替代PNT规模。其商业模式可按区域、终端或服务打包，当前仍不适合用芯片数直接推算订阅/收入。真正改变RKLB潜在业务预期的是责任和供应路线落到标准采购、生产设备或实际运行服务；行业抗干扰预算增加仍可由Xona或光纤路线获益，未要求竞争者同时披露Iridium失单。

- C1 / LONG / OUTER: 有权采购/监管机构或承保方正式发布并开始执行一项适用于明确定义的关键基础设施或航空/无人系统类别的采购、准入或承保要求，将GNSS独立PNT的授时或位置校验从自愿风险管理变成实际备用责任；该要求同时明示Iridium PNT或其现有产品能满足的认证/性能架构可用于合规。仅提出指南、征求意见、风险提示或未说明适用对象的“提高韧性”声明不属于本事件。
  - Reference: Iridium PNT ASIC于2026年7月商业可用且有Solace、Skyband等集成路径，但没有证据显示关键基础设施普遍被强制采购Iridium或同类第二来源。NIST IR 8323 Rev.1是风险管理指南；其行政背景与光纤校时服务均不构成该行业的强制卫星采购。NIST对电信、金融、电力授时依赖的评估证明故障风险有业务含义，却不证明任何特定供应商已被选中。
  - Boundary: 最低充分边界是一项已生效、覆盖某个可识别的基础设施运行类或获准设备类别的采购/承保义务，规定必须有独立PNT授时/校验，并在资格条款中接受Iridium现有服务/兼容产品，而不是要求未来再证明行业普遍采用。NIST自愿框架、草案、调查、单次演练或只谈风险金额均未跨界。强制责任改变由谁承担备用费用并使当前可供给方案成为合规候选；不要求新闻同时披露具体Iridium订单，但若条款只认可光纤或其他路线则不支持LONG。
- C2 / LONG / MIDDLE: 具名电信、电网、金融或政府关键基础设施运营者，公开授予采购/服务合同或确认预算化部署，并将Iridium PNT时钟/时间服务列入其正在运行的网络或设施的生产同步架构，作为主授时源或实际工作的独立校验/备份源；仅采购芯片样品、认证测试或未采用的供应商试点不算。
  - Reference: 当前是ASIC商业可用、伙伴集成和专业设计导入阶段。Solace Vector把Iridium信号与GNSS/惯性数据组合，Skyband M100仍是集成计划；D2截至cutoff没有具名基础设施运营者的生产采购。NIST提供光纤时间，Xona已宣布计时合作但初期服务仍在部署准备中，故“独立授时需求”不等于Iridium独占。PNT收入及每设备价格/订阅数未单列。
  - Boundary: 一项明确进入运营网络/设施的合同或已批准项目，把Iridium信号放进生产时钟系统并承担采购费用，即从合作与兴趣跨到由用户选择的部署。一个实际网络功能段或运作设施的常规系统即可，不要求全公司/全国家覆盖、价格披露、收入确认或财报确认；若只是台架、实验、限时演示或独立芯片订货而未说明启用Iridium PNT服务，则不足。主源和交叉校验都可成立，但来源须说明部署角色，以免把低频校验误读成主授时规模。
- C3 / LONG / MIDDLE: 航空或无人系统OEM/系统集成商正式选定Iridium PNT ASIC/信号用于具名的量产型号或经批准的在役产品，并公开了最终设计定型、产品许可/适用认证或有约束力的生产计划；信号在产品中承担实际导航、授时或GNSS完整性校验职责，而非仅出现在验证试验中。
  - Reference: 2026-07 Iridium宣布商业ASIC并公布Skyband将集成至M100 LRU；Solace的Vector产品组合正在部署，但未有可从公开材料量化的航空/无人系统量产规模、付费服务基数或单位价格。设计集成与测试属于基线，不表示某OEM已经把Iridium列入生产标准。
  - Boundary: 一个具名OEM/终端系列完成正式生产选型并进入适用的批准/认证或量产销售，即足以显示高责任设备把Iridium纳入可交付产品，不必等到披露整机出货量、首次飞行或Iridium财报收入。纯合作公告、样机、试飞/抗扰测试以及现有Skyband集成承诺都比该边界弱。Iridium PNT可能作为校验而非主导航，若校验角色可进入产品的生产/商业服务包仍改变获益路径；不能将一台实验设备外推到所有机队。
- C4 / SHORT / MIDDLE: Xona Pulsar的计时合作方或具名关键基础设施用户公开确认，Pulsar信号已在电信、电网、金融或时间服务商的实际生产授时系统中投入常规运行，或该服务商已将其作为面向运营客户的商业授时产品交付；系统依靠精密时钟在卫星信号间歇期间保持时间。仅有MOU、试验接收、已签合作但尚未运行的客户、或计划中的首批星部署不属于本事件。
  - Reference: Xona于2025年宣布与Hoptroff、Fibrolan、Timebeat建立商业计时合作，并称真实场地部署计划在2026年末；2026-10-09公布六颗首批星，其中四颗拟先在初始市场提供服务、约12小时重访并日均八次发出约25分钟信号，明确由精密时钟跨越间隔。Furuno于2026年8月只报告接收和GNSS欺骗环境测试，Topcon先获早期访问；这些均不能视作固定基础设施已在生产中采用。
  - Boundary: 公开事实从计划/测试升到一个具名商业时间服务或关键设施的实际运行时间源，即足以证明间歇卫星校时可在固定授时场景兑现并竞争Iridium，不须等Xona完成250+星座、达到全球连续覆盖、公布Iridium失单或把全部网络预算转给Xona。固定保持钟允许不同于移动导航的断续更新；仅兑现已宣布的六星发射或首轮实验数据仍不足。
- C5 / SHORT / MIDDLE: Xona或另一独立PNT网络在具名商业服务区域公布已实际可用、对指定移动/航空/无人系统应用达到其公开的连续性与定位/授时性能要求的服务，并由OEM将该信号纳入具名量产/获批设备型号作为主源或运行中的完整性校验；单纯性能演示、授权、卫星发射或无设备采用的覆盖预测不算。
  - Reference: Iridium拥有当前已运行的全球移动网络，ASIC进入商用和伙伴集成。Xona截至2026-10-12计划的首批服务在初始市场约12小时重访，适合未来尝试间歇授时但不等于移动实时导航的连续供给；Furuno接收Pulsar信号/干扰测试和Topcon早期访问也未构成量产导航来源。
  - Boundary: 足以修订Iridium移动优势的最低状态，是一个具名服务区的实际覆盖/更新性能已由服务公告公开到能够完成某个移动应用所需的运行角色，同时对应OEM把竞争信号选入生产或批准产品。无需要求整颗竞争星座满额部署、全球全覆盖或竞争者直接报告赢得Iridium客户；然而在现有约12小时重访水平下的技术试验或固定钟保持用途不能被错认成移动连续导航竞争。
- C6 / SHORT / MIDDLE: 具名电信、电网、金融设施或授时服务商公开授予/实施一项在运行网络中采用商业光纤传时与精密本地时钟保持的架构，并明确光纤时间为该固定系统的常规外部参考、保持钟跨越链路中断；这是替代卫星授时输入的生产方案，而不是仅新增一条与Iridium并用的实验/校准路径。
  - Reference: NIST的风险指南及光纤授时服务已存在，NIST描述通过商业通信光纤传递UTC(NIST)；关键基础设施依赖GPS时间且时钟可按稳定度维持保持。cutoff未有证据表明该类技术已经在具名目标运营商的实际网络中广泛替代卫星时间源。光纤仅适用于可达的固定设施，不能替代船舶、飞机或离网移动设备所需的全球信号。
  - Boundary: 一个具名关键系统/运行网络正式把光纤时间加保持时钟列为其常规独立时间参考，并以此承担固定节点的同步职责，就足以削弱该节点对卫星授时的边际需求；不要求逐站清点、证明整个行业都已改造或该买方曾与Iridium签过合同。只有NIST服务选项、实验链路、通用披露光纤准确度或作为新增而非替换的第三条来源，不达到SHORT边界。

## 政府网关与混合网络工程支持责任配置

本Policy观察的是政府工程、地面集成及网关维护/改造任务的Iridium归属、可执行份额与期限，不是另一个EMSS空口固定费Policy。政府工程与支持在2026Q2占Iridium全部工程支持收入约96%（$41.453m/$43.142m），约占公司总收入18%；H1增量大部分来自SDA，说明采购任务在服务费合同不变时仍可独立改变该收入基座。GMI的$240m为Iridium披露的五年份额，SITH的$85.8m则是五年IDIQ最高值；前者是既有程序工作基线，后者是可下单框架而非已承诺年收入；USAspending截至截止日列出的五个SITH交付订单合计约$13.081m实际义务，分别涉及GWLS、网络基础设施技术刷新、消息处理系统、传送控制器替换及接入网络控制器，履行期延伸到2026年底至2027年。这个已下单额度证明具体工作存在，但不是IDIQ全部上限，也不是全部尚未确认的收入。新增或转移实际任务可先改变未来工作量、合同收入、人员配置和持续运营责任，无需等待财报确认。工程支持的成本随工程/运营人员、承包商、软件维护及产品支持变化；公司2025年工程与支持服务收入$156.592m、相关支持成本$110.1m，但这是跨项目聚合值而非SDA/SITH单合同毛利。2026H1 SEC披露SDA工作增加伴随相关成本上升。Iridium称工程支持通常按里程碑或进度开票，但未公开SITH/GMI具体验收付款节点、单合同利润率、全职/承包人员数量或可复用预配置资源。因此firm task value是衡量新增工作和回款路径的依据，不等于净利润或自由现金流，不能套用成熟空口利润率或把主承包商总额全算给Iridium。截止日Rocket Lab收购尚未交割，故这是潜在并表业务而非RKLB现有收入。

- C1 / LONG / MIDDLE: 美国政府/USSF/SDA或其主承包商（包括GD Mission Systems）正式授予并资助一项task order、合同修改、附加期，或同一公告/授标包内共同授予的多项新增task orders，令Iridium（若为分包则按公开披露的Iridium份额）承担高于当前已资助工作的新网关现代化、生命周期升级、安全/运维或GMI地面集成任务；订单必须说明自然工作范围、Iridium firm share及履行期，并达到至少$8.3m/合同年（按公开履行期折算的固定/保证总额，履行期不足一年则以其实际firm总额比较）。仅提高IDIQ最高额度、意向/征询、未行使选项、主承包商全额或既有工作在原scope内的常规进度不属于该事实。
  - Reference: 截至2026-10-12，Iridium仍是Rocket Lab拟收购但尚未交割的业务。Iridium 2026Q2政府工程与支持收入为$41.453m（2025Q2 $39.477m），占当季$43.142m工程与支持收入约96%；2026H1为$80.919m，较上年同期$75.305m增加$5.614m，10-Q称主要由政府项目、尤其SDA工作推动，并预期2026年工程与支持收入高于2025年。现有比较基准包含SDA Ground Management and Integration (GMI)：2024年$491.6m团队修改合同中披露Iridium份额$240m/五年；以及2025年获授的SITH五年IDIQ，价值“最高$85.8m”，覆盖政府EMSS服务中心、Technical Support Center和Defense Ground Station的更新、生命周期改造和安全增强。SITH上限不保证订购，且两项计划的工作不能重复计入增量。USAspending的SITH IDV子订单记录在截止时列出五个已授予交付订单，累计实际义务额$13.081m，履行期从2025-09至2026-12/2027-09：GWLS $1.570m、TPC替换/现代化$2.005m、IMPS $2.557m、NITR25 $2.757m、ANC $4.192m。它们证明存在具体已资助工作，但累计义务额不是未确认剩余收入，也不能与五年IDIQ上限等同。Q2同比政府工程支持增加约$1.976m/季度，另有已披露的2026年增长预期；这些既有任务与已资助责任是基线，不能将现有GMI份额或SITH最高额再次算作新增。Q2同比政府工程支持增加约$1.976m/季度，另有已披露的2026年增长预期；这些既有任务与已资助责任是基线，不能将现有GMI份额或SITH已授订单/最高额再次算作新增。
  - Boundary: 新增且可执行的Iridium firm/保证份额须达到$8.3m/每12个月（更长期合同按实际履行年数折算；五年期至少约$41.5m），且属于新scope或新增份额。该线约为$41.453m Q2政府工程支持年化run-rate的5%，相当于每季约$2.1m，接近当前Q2同比增加的$1.976m，足以改变政府工程增长基准；较小零散工作量不足以单独改变总业务判断。采用主承包商的Iridium分配后金额和已资助/保证部分，而不是框架上限、未来选择权或总项目金额；触发表示合同工作/收入路径扩大，不推断等额利润。
- C2 / SHORT / MIDDLE: 美国政府、USSF/SDA或主承包商正式终止、削减或重新分配Iridium当前firm-funded的网关维护/改造或GMI地面集成任务，或正式把一项正在执行的持续网关运营/工程支持责任转给政府自营、另一平台或其他承包商；必须明确旧任务不再由Iridium承担，而非只发布新招标、增加另一项目的竞争者或出现一般预算不确定。若不是完整移交当前核心操作责任，已移出的Iridium firm share须达到至少$8.3m/合同年，按披露履行期折算。
  - Reference: 截至2026-10-12，Iridium仍是Rocket Lab拟收购但尚未交割的业务。Iridium 2026Q2政府工程与支持收入为$41.453m（2025Q2 $39.477m），占当季$43.142m工程与支持收入约96%；2026H1为$80.919m，较上年同期$75.305m增加$5.614m，10-Q称主要由政府项目、尤其SDA工作推动，并预期2026年工程与支持收入高于2025年。现有比较基准包含SDA Ground Management and Integration (GMI)：2024年$491.6m团队修改合同中披露Iridium份额$240m/五年；以及2025年获授的SITH五年IDIQ，价值“最高$85.8m”，覆盖政府EMSS服务中心、Technical Support Center和Defense Ground Station的更新、生命周期改造和安全增强。SITH上限不保证订购，且两项计划的工作不能重复计入增量。USAspending的SITH IDV子订单记录在截止时列出五个已授予交付订单，累计实际义务额$13.081m，履行期从2025-09至2026-12/2027-09：GWLS $1.570m、TPC替换/现代化$2.005m、IMPS $2.557m、NITR25 $2.757m、ANC $4.192m。它们证明存在具体已资助工作，但累计义务额不是未确认剩余收入，也不能与五年IDIQ上限等同。政府可按联邦采购规则全部或部分终止合同；但该一般权利并非已发生的撤项。SITH/GMI等当前工作及H1政府工程支持增长构成当前任务基线。
  - Boundary: 短向边界为已资助、既有Iridium责任减少至少$8.3m/每12个月（长期合同依实际履行年数折算，五年约$41.5m），即当前政府工程支持年化run-rate约5%，或整项正在履行的专用网关维护/持续运营或GMI核心集成责任被至少12个月地正式移走。仅未动用IDIQ额度、无任务交付的竞争性征询、在另一个星座新增工作或尚未确认的预算削减不等于既有Iridium工作已流失；本边界判定的是合同份额与未来工作平台转移，不能假设成本完全不随收入下降。

## Aireon外部空管合同与航空数据产品分销范围

截至本任务信息截止，Iridium已于2026-07-02完成购买Aireon剩余60.5%权益，但Rocket Lab收购Iridium仍未交割；Aireon是RKLB潜在经营暴露，不是当前RKLB收入。Aireon利用Iridium星座上的ADS-B接收载荷，为远洋、极地及偏远地区提供地面雷达难覆盖的实时航班监视数据。NATS与NAV CANADA于2026-05将服务合同分别延至2037年及2035年中，出售Aireon股权与继续采购并存；此前Aireon还报告在特立尼达和多巴哥、佛得角等地签下ANSP合同。NATS委托研究称北大西洋运行中航空公司的安全与燃油收益显著，但客户收益不是Aireon取得的订阅额或利润。现有长约和运行业务是付费基线；固定范围/费用合同内飞行或数据量变大，不自动使Aireon收入同步增加。
商业数据分销是另一条价值路径：Airbus于2024年扩展多年数据分销合同，Cirium已有长期整合，ForeFlight于2025年把覆盖扩至商务与通用航空产品；GDM提供政府采购入口，AireonVECTOR及安全仪表盘拓展GPS干扰和风险分析用途。这些产品、伙伴和渠道已是当前背景，不是新订单本身；CAAP安全仪表盘合作公告是MOU，不等同付费采购。平台掌握终端客户关系与零售包装，Aireon可能只取得批发数据费；公开材料没有给出各平台费率份额、用户数或产品级毛利。新增合同/付费使用能改变外部收入范围，但支持和产品运营成本会影响净贡献，不能只按数据覆盖扩大推断利润。
Iridium与Aireon之间过去的托管、供电及数据传输收费属于集团内交易；全资后合并需抵销，不能在Aireon外部收入之外再加一次旧内部托管费。2026Q2 Iridium报表发生于取得剩余权益前，不能直接当作全资后分部的净收入或成本基线。

- C1 / LONG / MIDDLE: Aireon/Iridium或具名空管采购方披露：一名新的民航空管机构签署持续性付费ADS-B监视服务合同，或现有机构签署具有新增付款义务的合同变更，把服务带入一个此前未付费覆盖的国家、主要远洋/偏远运行区，或新增独立付费的安全数据用途。公告须能确认这是有偿服务采购/商业供数或新增收费范围，而非无偿试验；覆盖/用途可识别，合同金额与费率可以保密。客户股权变更、免费测试、MOU、一般技术合作、现有固定费用范围内的更多飞行/覆盖、旧范围例行续约不属于该事实。
  - Reference: NATS及NAV CANADA是Aireon的早期锚定ANSP客户；2026年5月公告分别把数据服务合同延至2037年和2035年中。Aireon还于2025年报告与特立尼达和多巴哥、佛得角等ANSP签约，但可得材料未披露各份合同金额、费率及收入份额。现有判断是既有空管客户续用和已签范围已在基线中，且全资并表后须消除Iridium旧内部托管/传输收费。
  - Boundary: 一份对新国家/主要远洋或偏远运行区真实生效的持续付费服务承诺，或对既有客户新设收费的额外用途，即已增加外部付费权利；不必等季度报表确认、数名新客户或披露合同金额。边界在于确有新增付费方/付费范围，而非仅更频繁使用旧固定费服务。
- C2 / LONG / MIDDLE: 航空数据分析、机队/飞行运行软件、OEM、航空公司、政府采购平台或类似分销方，签订新的商业数据馈送/使用许可，或扩展既有协议至一项新客户群的生产级航空效率、飞行跟踪、安全风险或GPS干扰产品，并明确这是新的商业供数/许可或具名客户采购，而不只是技术合作；不要求披露具体价格。只宣布新品、展示、无偿MOU、合作伙伴关系、数据目录上架或重复介绍既有Airbus/Cirium/ForeFlight接入不属于该事实。
  - Reference: Airbus已于2024年签订多年扩展分销安排，Cirium已有长期数据合作，ForeFlight于2025年扩展至商务与通用航空用户；GDM于2025年让经批准的政府买方能够采购Aireon数据。VECTOR于2025年推出，CAAP安全仪表盘合作为MOU。上述均为当前渠道/产品基础，不证明后续订单。各平台的数据批发价、客户数、分成及支持成本没有公开。
  - Boundary: 一项新或扩大的商业供数/使用许可，直接把数据放入可销售的客户产品或产生具名买方的付费使用，即足以证明渠道从可达性前进到新的有偿分销；无需知道零售售价、Aireon分成、客户总数或下一季利润。仅上架或发布产品尚未建立新增付款义务，因而不足。
- C3 / SHORT / MIDDLE: NATS、NAV CANADA或服务覆盖同等广阔地区的核心ANSP正式终止/提前退出Aireon ADS-B付费合同，或大幅削减/移出其主要国家、跨洋或偏远空域的合同化运行监视范围，使该区域不再按当前付费安排采购Aireon数据。出售股权但继续履行合同、新闻稿调整或不改变费用与付费范围的操作描述不属于该事实。
  - Reference: NATS和NAV CANADA于2026年5月续约，数据服务分别延续至2037年和2035年中；NAV CANADA覆盖加拿大国内与海洋空域，NATS等用户已将空间监视用于北大西洋运行。合同价格和可提前终止条款未公开，正常履约是当前基线。
  - Boundary: 一名上述锚定ANSP正式撤掉其广阔区域的持续付费监视服务，或合同明确把该核心区域移出付费范围，已足以削弱一条长期运行合同及区域采用基座；不需等另一家同时退出或等年度财报确认。单纯卖股、日常数据/飞行波动，或小幅服务描述变化而付费范围仍在，不跨越边界。
- C4 / SHORT / MIDDLE: Airbus、Cirium、ForeFlight等现有广覆盖分销伙伴正式终止其Aireon商业数据馈送/许可，并将Aireon数据从面向航空公司、机队/飞行运营或商务/通用航空客户的生产级产品中撤下，使该渠道失去持续付费供数或已实现的客户分发。单一功能改版、名称变化、产品宣传停止但付费feed仍在，或尚未形成收入的合作探讨，不属于该事实。
  - Reference: Airbus将Aireon全球数据用于飞行分析和Skywise数字产品，Cirium将其位置数据与航班、机队和时刻数据融合，ForeFlight已把高保真数据接入其客户生态。多年度协议/产品整合证明已有商业分销路径；但每条渠道向Aireon支付的费用、用户渗透和收入占比未知。
  - Boundary: 一个已运行的主要数据分销协议终止且其客户产品正式撤下Aireon供数，已移除一条跨客户群的商业分发和潜在批发收费路径；不要求另一个渠道同时退出或披露损失金额。仅停止一般合作宣传或缩减非核心单项功能而feed和付费关系继续，不足以判定。

## 空间VHF服务采购、监管准入与资本承担

空间VHF与既有ADS-B监视不是同一服务：ADS-B是飞机发出位置数据供卫星接收，空间VHF则让远洋/偏远区域飞机通过非地球同步卫星与空管进行VHF语音/数据通信，扩大传统地面VHF不能经济覆盖的空地通信范围。它可能改善海洋航路的直接通信、容量和操作连续性，但仍有HF、SATCOM等替代路线；现有ADS-B长约不等于空管已经购买VHF服务。
截至2026-10-12，Aireon/Iridium等伙伴已形成VHF联盟；2024年12月Aireon经加拿大ISED向ITU提交增强VHF/ADS-B载荷星座计划，NATS与NAV CANADA在2026年5月续约公告中仍称共同开发。ICAO在2026年4月称WRC-23已完成117.975–137 MHz频段空间VHF分配，但Annex 10的通信/频谱标准修订、区域与跨区域频率协调仍在推进；当时工作计划以2028年11月为标准适用目标。此为有真实客户和技术准备的开放机会，但不是现网已提供VHF通信、最终运营认证或服务采购。
决定服务价值的关键新变量是：谁承诺支付新增服务/载荷和运行责任，及频谱与航空安全程序何时使商业运营可行。对客户具有约束力的长期服务采购或共同投资可直接分担需求/资本风险；最终适用标准或特定空域的运行频率许可可显著改变可实现概率，不必等待后续收入。相反，主要锚定ANSP转向别的通信路线或监管正式排除拟议用途会关闭重要路径。尚无VHF专项资本预算、订单金额、运营成本、认证日期或收入拆分，故不把政府ADS-B合同、Iridium现有L-band网络、全资化或集团内造星/发射自动算作VHF收入、成本节省或现金回报。Aireon现属Iridium；Rocket Lab收购Iridium仍待交割，相关为潜在而非当前RKLB经营业务。

- C1 / LONG / MIDDLE: NATS、NAV CANADA或另一具名空管机构/联盟成员，与Aireon/Iridium签署具有约束力的空间VHF服务采购、区域部署承诺，或VHF专项共同投资/成本分担协议，并明确承担新的付款、预付款或资本义务，且指向可识别的远洋/偏远空域服务范围。单纯延长ADS-B合同、无付款的共同开发、技术演示、非约束MOU或公司仅宣布研究计划不属于该事实。
  - Reference: NATS、NAV CANADA及其他伙伴已有VHF联盟/共同开发背景；2026年5月NATS和NAV CANADA延长的是既有ADS-B服务合同，同时表示继续共同开发VHF。现行共识仍是频谱与方案准备，不存在已证明的VHF商业运营或付费采购。ADS-B长约延至2035/2037并非VHF承诺；项目付款比例、载荷预算和服务费均未披露。
  - Boundary: 一份面向已定义远洋/偏远运行区的约束性VHF服务采购/长期付款或客户共同投资，即把研究合作转化为承担实际需求或资本风险的经济承诺；金额可以保密，也不需等待首星、认证后的全面部署或财报收入。持续技术合作而无客户资金责任仍属于当前普通进度。
- C2 / LONG / OUTER: ICAO正式通过适用于空间VHF空地语音/数据运行的Annex 10标准及相应频率协调规则，或主管国家/区域正式为具名远洋/偏远空域授予商业运行所需的频率指配与空管使用许可，使空间VHF从申请/协调进入获认可的实际航空运行路径。WRC-23一般频段分配、ITU/ISED系统计划提交、标准修订草案、委员会进展报道或仅用于实验的试验安排不属于该事实。
  - Reference: WRC-23已将117.975–137 MHz分配给空间VHF用途；Aireon于2024年12月提交增强载荷星座计划。ICAO 2026年4月文件及7月会议回顾记录Annex 10 Volume III/V修订和区域/跨区域频率协调仍在推进，所列目标适用日期为2028年11月；本批材料没有确认2026年9月预审结果。既有一般频段分配和文件受理已在基线，当前资料没有证明最终Annex 10规则或特定商业运行许可已生效。
  - Boundary: 一项正式且适用于实际航空运行的全球标准/协调框架，或一个具名空域可执行的商业频率与运行许可，已清除安全通信从概念到部署的主要制度门槛，足以提高服务兑现概率；不用等全世界授权、订单交付或收入实现。仍在审查中的草案、会议议程及测试协调不会跨越边界。
- C3 / SHORT / MIDDLE: NATS、NAV CANADA或另一核心联盟ANSP正式停止空间VHF共同开发，或对某一主要远洋/偏远空域作出有约束力的通信方案选择、把原本拟采用的VHF用途分配给HF/SATCOM等替代路线且不再承诺VHF部署。仅保留ADS-B服务、一般测试延后或未公布采购金额不属于该事实。
  - Reference: 当前不是无需求的纯概念：NATS、NAV CANADA等共同参与VHF方案，2026年仍称继续开发；该客户关系是新通信服务最可信的早期需求入口。ADS-B运营及长约可以继续而VHF独立被取消/替代。替代通信和初期部署方式尚未最终确定。
  - Boundary: 一个锚定ANSP正式退出并为其指定的主要远洋/偏远运行需求选择其他通信路线，已失去该区域的客户支持和新服务范围，足以调低当前联盟主导的VHF机会；不需所有客户同时退出。普通会议参与减少、持续等待标准、ADS-B续约或未决采购不等同路线被替代。
- C4 / SHORT / OUTER: ICAO、ITU或实际负责该空域的国家/区域频谱与航空主管机关作出正式且适用于拟议商业运行的最终决定，拒绝空间VHF频率使用或禁止其在主要目标区域承担飞机—空管通信，或附加明确条件使既定VHF架构无法在该区域合法运营。征求意见、待补材料、普通协调延期或面向其他地区的局部频率冲突不属于该事实。
  - Reference: 频段已获一般分配但运营还取决于ICAO通信/频谱标准、区域协调及主管机关对航空安全使用的认可；ICAO 2026年工作文件显示协调程序仍待完善。具体VHF系统申请和各地区可用频率尚未被证明已获完整商业运行许可。
  - Boundary: 主管机关的最终否决或运行限制必须实际阻止拟议系统在主要目标空域提供空管通信；一项覆盖关键拟议区域的决定即可关闭已研究的服务路径。额外审查步骤或局部可协调频点不足不能等同于商业方案失效。

## 卫星服务共同依赖、恢复能力与韧性采购

Iridium 的专业服务价值部分来自在传统通信不可靠处继续连接、提供 PNT/航空数据并维持关键客户留存；2026Q2服务收入为1.613亿美元、占总收入约72%，但公司没有单列“韧性溢价”、按产品的留存率或安全事件支持成本，不能将该总额等同于本题可变收入。按2025年10-K，Iridium约66颗在运LEO卫星以星间链路将双向通信路由到TPN和地面网关；SNOC位于Leesburg，管理星座、路由和覆盖，Tempe是主要商业网关，俄罗斯网关仅服务俄境内流量，另有美国政府专用网关。多TPN、星间路由与星上处理支持改道和隔离，单星故障通常不会造成长期客户影响；但若Tempe主商业网关不可用，切至备份设施对多数服务预计需数小时、部分服务更久。因而一次路由/节点事件的结果取决于故障所在路径、地理和服务范围，不能外推为全网失效。通信是双向端到端链路；Iridium PNT以接收卫星广播为核心、与GNSS互补，不依赖相同的终端上行/商业网关路径，但仍共享部分卫星、管理和环境风险；Aireon ADS-B由星载接收载荷收集航空器广播，再经Iridium网络送往地面处理/分发，卫星接收段与客户交付段也应分开核实。外部蜂窝/光纤/电网失效后，若买方为Iridium建立与该特定失效模式独立的常态付费备份，可能扩大重复接入并增强留存；相反，内部共享节点长期受限，或买方因共同星座/控制/地面依赖而改选异源网络，会削弱可靠性溢价、续约位置并提高支持负担。NIST的PNT风险框架是自愿指南；Iridium相对GNSS的独立性不等于免疫空间天气、共享卫星/管理、供电或网络安全等所有共同风险。截止输入没有证明发生过共同失效、相关采购禁令或此类客户流失；Iridium收购仍待交割，所述经营影响是潜在RKLB暴露，不是RKLB当前并表收入。

- C1 / LONG / MIDDLE: 在一个真实影响服务的Iridium共享路由、TPN/网关、控制/安全节点或相关空间段事件后，Iridium或具名客户发布事件状态，点明受影响的节点、服务产品/地区及隔离或改道措施，并确认受影响的付费服务已恢复；PNT与Aireon数据交付是否受影响须按各自路径分别说明，不以未提及推定未受影响。
  - Reference: 截止2026-10-12的基线是：Iridium 2025年报称星间链路、多处TPN和网络控制设计可支持改配；个别卫星故障通常不会长期影响客户。该年报同时披露Tempe为主要商业网关，Tempe不可用时大多数服务切到备份设施预计需数小时，部分服务可能更久。D2/冻结材料未记录本轮发生共同失效或成功恢复事件。PNT与双向通信、Aireon星载接收及数据送达的路径不等同。
  - Boundary: 只有一次实际、服务相关的共享路径事件，被公开定位并证明已隔离/改道且付费服务在适用于该路径的公开恢复/备份窗口内恢复，才首次把“设计上有冗余”变成运行中验证的故障遏制能力，支持可靠性与留存预期。对Tempe商业流量，参照是公司披露的多数服务需数小时完成备份切换；其他网关、PNT或ADS-B必须依其各自披露的恢复窗口，不套用Tempe时限。一般产品介绍、仅有卫星故障而没有延迟客户使用、未给受影响服务/恢复状态的笼统“已修复”，以及例行维护均不足；该条件只支持已证实的受限路径，不代表其它产品或全网免疫。
- C2 / LONG / MIDDLE: 具名关键基础设施、通信运营商、政府或运输/航空运营者，在外部地面网络故障或正式依赖审查后，公开将Iridium识别为实际供给方，并把其卫星通信或PNT能力纳入某项关键业务/运营组合的常态付费备份、独立路径或标准配置。
  - Reference: 当前是Iridium专业服务与用户逐步增长的基线；已有D2资料显示通信、PNT及航空监视有各自的客户与使用场景，但没有披露单独的韧性订阅收入、客户故障时留存系数、或付费备份配置规模。产品演示、危机时临时流量和NIST自愿风险指导不等于采购。
  - Boundary: 一项已进入采购/正常运营的重复付费服务或标准业务配置，即足以将Iridium从临时应急选项变为某一可识别关键工作流/运营组合的持续备份供应方；公开消息需说明该路径区别于导致问题的外部地面网络，并覆盖一个实际业务项目、关键服务组合或运营资产群，而非孤立测试终端。持续接入权本身可改变服务机会与留存，不必等待使用量或财报收入确认，也不要求披露保密单价。免费试点、兼容性声明、未授予的采购意向、单次应急使用、服务实际由其他卫星网络承载，或备份仍依赖同一失效的地面链路，均未越界；该触发只针对对应失效模式，不代表Iridium对所有灾害/空间天气/网络风险独立。
- C3 / SHORT / MIDDLE: 经Iridium、主管机关或具名客户确认，一项实际故障、安全限制或路由事件使Iridium某项已付费的通信、PNT或Aireon数据服务在可识别的产品/地区/客户范围持续不可用或受限，且该限制超过该服务适用的公开备份/恢复窗口，或主管机关/运营方正式暂停该服务范围。
  - Reference: 公司已披露单颗卫星故障通常不会造成长期客户影响；Tempe主商业网关若不可用，多数服务的备份切换预计为数小时，部分更久。风险披露也承认超出连续性能力的服务中断会导致用户无法使用、损害声誉/收入并增加客户服务或修复工作。当前冻结输入没有显示该类共同服务中断已经发生。
  - Boundary: 边界是公开确认某一实际付费服务类别在其自身路径上越过已披露的连续性窗口仍受限，或存在正式持续的服务暂停；这是超出常态单星故障与已知备份切换的状态，足以使任务关键用户对可用性、留存和支持责任重新定价，无须先等季度订户或收入下降。商业Tempe服务只与其多数服务数小时备份基线比较；美国政府专用网关、PNT信号、Aireon星载采集/地面送达分别用自己的实际服务范围和恢复披露。局部网关事故只能影响已确认的链路，不能推断全网、PNT或ADS-B同时中断；在预期窗口内恢复的故障、无付费用户影响的单星异常或仅有一般网络风险公告不足。
- C4 / SHORT / MIDDLE: 具名政府买方、关键基础设施运营者、承运商或航空服务客户正式实施新的合同、授标或运营标准，因认定Iridium多产品共用的卫星/控制/地面路径不满足其指定的独立性要求，而取消、降级或排除Iridium在一项可识别的关键通信/PNT/ADS-B备份组合中的付费角色，并明确采用另一条不同失效域的路线。
  - Reference: 基线是Iridium的多产品服务依赖部分重合但并非同一条完整链路；单独增加品牌/卫星数量不自动形成独立冗余。NIST 2023 PNT Profile为自愿风险管理框架，不是采购禁令；冻结材料没有记录因共享依赖而实施的Iridium排除、主要客户撤单或普遍风险采购规则。
  - Boundary: 正式合同/授标或适用于具名运行组合的已生效架构标准，明确移走Iridium在一个关键、可识别的付费服务群或任务工作流中的主要/备份角色，已足以降低其未来新增和续约捕获，不必等财报确认流失。须能读出被移走的服务和买方选择的替代失效域；若采购者增加异源供应商但Iridium仍保留为付费路径，不满足。一般风险评估、RFI、标准草案、NIST指南、没有实际服务范围的供应商多元化声明，或因容量/价格而换路线但没有共同依赖依据，均不足以命中本共同风险条件。

## 终端模块供给资格与成本可达性限制新增服务安装

Iridium的卫星服务需经兼容终端才能新增或替换接入，有限制造商、单一来源组件及技术许可使换源同时涉及重新集成、资格和交付，不是采购部门可当季任意切换的零件。2025年报称贸易政策已提高设备成本并促使评估替代采购，但未证实截止日有断供；2026Q2设备收入为2,076.7万美元，设备成本为1,347.8万美元，同比成本增19%、收入增7%，公司将成本变化同时归因于销量和成本上升，H1成本增10%还受组件成本和产品组合影响，因此这些汇总数不能单独证明供应中断或单台毛利变化。9604于2026-06-23宣布模块及开发套件商业可用，集成的是Iridium SBD、LTE-M蜂窝和GNSS；标准NTN Direct则是基于3GPP NB-IoT、使用第三方芯片的不同路径。9604的现有上市不等于NTN芯片兼容，也不等于第二来源。设备收入低于服务收入，但缺货先限制新终端安装和新服务激活，通常不使既有订阅立即停止；供应改善也不意味着卫星采购增加。公司2026-06-30总库存6,347万美元（成品4,180.6万、原材料2,240.1万、扣除估值准备），并有1,150万美元Benchmark未来12个月库存采购义务，均未披露具体产品/模块或经销商分布，无法折算某一SKU的缓冲天数。

- C1 / LONG / MIDDLE: Iridium或其模块/终端供应商确认，现有受限的Iridium服务终端或其关键组件已经获得可用于正式生产的合格第二来源，或新的替代模块完成产品/服务兼容资格并开始接受生产订单，使一个明确的SBD/L-band或NTN Direct设备路径不再依赖原单一供货安排。
  - Reference: 2025年10-K披露Iridium依赖有限设备制造商及部分单一来源组件；即使找到替代供应商，重新开发和交付可能耗时、成本更高。2026Q2 10-Q将Benchmark列为大部分用户设备的制造商，披露未来12个月约1,150万美元不可取消的库存采购义务，但没有按SBD、L-band、9604或其他终端分拆库存与义务。9604模块和开发套件已于2026-06-23上市，适用SBD/LTE-M/GNSS；该现状不证明它可替换所有旧终端或标准NB-IoT NTN Direct。
  - Boundary: 适用于明确现用服务路线的替代来源/模块完成所需资格并可承接正式生产订单，已经缩短受限设备的资格/供应瓶颈；无需等下一份财报或新增用户激活来证明供货价值。只签评估协议、展示芯片、发布开发套件或没有生产可订购状态的‘兼容’公告仍未跨界；9604已公布的首发不重复作为新事件。命中仅涉及对应产品/路线，不外推全部Iridium设备或现有服务收入。
- C2 / SHORT / MIDDLE: 关键制造商/零部件供应商正式停产、限供或取消对Iridium某一现用终端/模块的交付，且Iridium、制造商或授权分销渠道确认该产品订单已出现无法按原期履约的缺货/延期，当前没有已资格化的替代供应来源。
  - Reference: 截止日公开事实是供应商集中与单一组件依赖、2025年贸易成本上升及评估替代采购；没有证据确认当时发生断供。公司层面库存总额及Benchmark采购义务不是某个终端SKU的可用缓冲，不能据此推定缺货或交付天数。设备供应影响新增终端安装，既有用户不因新品缺货自动停费。
  - Boundary: 确认到一个仍在销售/服务中的产品路线无法按原渠道满足订单，且无已合格的替代源，首次足以将该路线的新设备交付/安装时点向后修订；不要求等客户取消订阅或季度设备收入下降。一般性供应风险、组件延期但现有库存可正常交付、研发替代尚在评估、或单纯设备成本增速高于销售额，均不构成短缺边界。
- C3 / SHORT / MIDDLE: 对现用Iridium兼容终端/模块适用的新关税或供应商投入价格，已体现为该同型号持续销售的经销/终端报价上涨，或导致原有持续性硬件折扣、补贴被正式撤回，从而提高购买该设备的实际前置成本。
  - Reference: 2025年报称2025年美国贸易政策提高Iridium成本；2026Q2设备成本同比增长19%，但公司说明同时受设备销量增加和成本上升影响，H1亦受组件库存成本与产品组合影响。当前没有公开的9604或其他终端同型号零售/批发价目、优惠期限、终端单位成本、渠道库存或补贴回收期。
  - Boundary: 以同一可订购型号的既有公开报价与持续适用的新报价/折扣条款对照，价格上调或补贴撤回本身就是新增设备经济性变差的可观察边界，不要求终端新闻同时给出订阅留存或公司利润。只公布宏观关税、输入成本压力、季度汇总成本上升，或短期库存清仓价而未改变持续报价，不足以判断产品购买成本已变；影响限于对应新设备经济性，不推断存量订阅、客户使用量或净补贴回收。

## Certus航空驾驶舱安全通信从机型准入到付费机队采用

本观察范围是Iridium Certus AvSafety/AMS(R)S在驾驶舱与空管之间承载的安全数据链与安全语音，不是客舱Wi‑Fi。其采用链依次经过终端技术认可（TSO）、具体机型安装批准（STC）、指定空域/ANSP运行接受，再到航司或货运运营者安排改装与服务付费；这些环节扩大可服务飞机范围或提高采用概率，未必在当期产生收入。FAA网站托管的2026年5月Iridium项目演示称首个Certus终端于2025年12月取得TSO，但初始机型STC仍在FAA与英国CAA处理中，评估计划仍是草案，且首批参加者可获12个月免费服务。升级至RCP130/RSP160的地面、星上与固件改进又是独立于初始评估的后续技术步骤。

Iridium称其自2010年提供AMS(R)S，合作伙伴已在数千架飞机上装备相关系统，因此Certus可能替换或升级既有安全服务，也可能增加新机队/付费范围；仅发生迁移或沿用同一服务合同，不能等同新增订阅。机型STC可打开该机型的改装入口，但真实安装还受运营方安排和飞机维护/安装时段影响，不代表全机队同步改装。免费评估、讨论中的商务机会、已装终端均不等于持续付费使用。冻结材料没有该产品单列收入或定价，故技术接受可先改变实施概率，但不据此推算收入。Iridium在交易交割前仍是独立标的；对RKLB只是潜在并表业务的预期变化，不是当前RKLB收入。

- C1 / LONG / MIDDLE: FAA、英国CAA或其他适用主管机关批准首批货运评估机型之一（当前为Boeing 767F或777F）的Certus AvSafety/AMS(R)S飞机级STC，且批准范围允许该机型按获批构型安装安全通信终端。
  - Reference: 截至2026-10-12，首个Certus终端TSO已于2025年12月取得；冻结任务材料仍将初始飞机STC列为推进中。FAA托管的Iridium 2026年5月演示记载，STC当时正由FAA和英国CAA处理，首批货机为767F/777F、涉及7架以上飞机。既有AMS(R)S业务与装机基础已存在，所以新Certus可能是升级/迁移，也可能是增量用途。
  - Boundary: 第一项覆盖767F或777F初始评估机型的飞机级STC即可越界；不要求两种机型都获批、整支机队完成改装、评估完成或网络收入同时披露。它把已获TSO的终端推进到可按具体机型安装的实际认证入口，足以改变首批可服务机队的实现概率；但本身不代表装机或付费订阅。
- C2 / LONG / MIDDLE: Iridium、运营方及相关ANSP/监管方确认一架装有Certus AvSafety的飞机已在一个具名FIR投入安全通信运行或现场评估，并获该空域运行参与方接受；单纯计划、设备交付或地面模拟不算。
  - Reference: 2026年5月演示把北大西洋首架运行列为目标，并称南太平洋ISPACG空域的数据收集计划在2026年Q3/Q4启动；评估工作簿仍标为草案，设想至少75,000条数据消息和1,000次ATS安全语音呼叫。该等计划不是已运行证据。RCP130/RSP160性能改进另有地面、卫星和固件更新计划，首次搭载更新固件的飞机可能到2027年Q2，不能与初始评估状态混为一谈。
  - Boundary: 至少一架实际飞机在具名FIR按接受的运行安排使用安全链路，即由预期评估转为真实运行接受，足以提高该空域/机型继续部署的实现概率；不必等待75,000条消息或1,000次语音呼叫全数评估完成，也不要求免费试用同时转为付费。此条件只表示技术/运行采用，不认定经常性收入。
- C3 / LONG / MIDDLE: 航司、货运运营者或其航空通信服务伙伴公布一项评估期之后、覆盖明确多架飞机的Certus AvSafety付费经常性服务安排或付费扩展范围，而非仅免费评估、意向讨论或沿用同价同范围的既有合同。
  - Reference: 截至冻结时，Iridium演示称有航司讨论商务方案，并邀请运营方参加评估，提供最多12个月免费服务；材料没有确认评估后付费机队或Certus AvSafety单列收入。Iridium自2010年已有AMS(R)S服务和合作伙伴飞机装机，因此同一飞机由旧服务迁移到Certus可能只是保留/升级既有业务，而不构成新增订阅。
  - Boundary: 首个明确超出免费评估、具有持续付费服务义务且覆盖一个多机队列的新服务范围或付费扩展，即足以从技术试用跨入商业采用；不用等收入金额、全机队安装或多个航空公司重复签约。若只是既有服务合同下不加价迁移，按留存/升级理解，不当作新增付费用户或增量收入。
- C4 / SHORT / MIDDLE: 适用主管机关、ANSP、Iridium或初始参与运营者确认：首批767F/777F评估路径因安全/性能/认证问题被拒绝、暂停或撤回；或在仍未出现首架获接受运行时，整个初始货机评估队列的首个运行时点被正式推迟至2027年下半年或更晚，且没有获批的替代初始机型/空域安排。
  - Reference: 最新可用冻结状态是首个终端已获TSO、初始机型STC与运行评估仍在推进，而不是已全面通过。2026年5月项目演示把首批货机运行/数据收集放在2026年内（南太平洋为Q3/Q4目标）；其后RCP130/RSP160升级计划另指向2027年Q2首次可能搭载更新固件的飞机。早期目标日期已过或仍属目标，不单凭沉默推定失败。
  - Boundary: 项目被正式否决/暂停，或全部初始运行接受被移至2027年下半年及以后，才越过SHORT边界：这会把2026年内的初始采用窗口至少再推迟两个季度，或关闭首个机型/空域入口，实质降低近期安装及服务部署概率。仅有一次小幅日期调整、仍在原评估窗口内的阶段推进或缺少公开收入，均不足以单独支持SHORT。

## Iridium保留贷款的Rocket Lab担保与追索范围

9月15日修订规定Iridium贷款可在拟议交易后继续存续，Rocket Lab USA将在交割时为信用协议义务提供下游担保；截至本轮截止点交易尚未交割，该担保不是当前已经生效的Rocket Lab债务。6月底Term Loan本金约1,774.7百万美元，担保把贷款人追索范围从Iridium借款人扩展到Rocket Lab主要运营子公司，但并非新增一笔同额借款，也不意味着所有集团现金都已被冻结。此后担保解除、扩展到其他运营实体、增加担保资产或被实际执行，会改变集团承担债务压力的实体范围和可供经营/研发的资产；Iridium 2026Q2披露当时遵守契约且Term Loan没有财务维护契约，不等于未来不可能出现违约，也不支持假定当前已违约。

- C1 / LONG / MIDDLE: 交易交割后，贷款人签署并生效的豁免/修订解除Rocket Lab USA对仍存续Iridium定期贷款的担保，或将该担保责任实质降至较低的明确上限，且没有由另一Rocket Lab运营子公司或等值新增资产担保替代。
  - Reference: 9月15日公开的基线是Rocket Lab USA在交易交割时为信用协议义务提供担保；贷款仍由Iridium Satellite借入，约1,774.7百万美元为2026-06-30本金，实际交割本金会变化。交易本身及担保生效仍以交割为条件。
  - Boundary: 仅在贷款仍有至少约1,000百万美元未偿而担保被解除/封顶至不超过当期未偿本金的一半、且没有替代Rocket Lab担保或新增追索资产时，视为减少了大部分跨集团追索。若担保随贷款一并清偿，按债务偿还成本判断，不重复记为独立担保解除利好。
- C2 / SHORT / MIDDLE: 生效的贷款修订/担保文件将保留贷款的Rocket Lab追索范围从已公布的Rocket Lab USA担保扩展至另一个实质运营子公司，或新增一组重要运营资产/现金作为其担保或抵押。
  - Reference: 当前公开安排只明确Rocket Lab USA在交割时担保贷款义务；没有证据表明其他Rocket Lab运营公司或全部合并现金已被纳入该贷款担保。抵押/担保范围扩大改变可被贷款人追索的实体和资产，不增加同一1,774.7百万美元贷款的本金数。
  - Boundary: 须由有效合同或正式公司披露确认新增的是有实质运营现金流/资产的Rocket Lab主体或资产池，而非名义壳公司或重复列示的原保证人；触发含义是同一大额贷款现在能够追索更多集团经营资源，不把重复保证本金加倍计算。
- C3 / SHORT / MIDDLE: 贷款代理人/贷款人依据已发生的合同事件正式要求加速偿还、执行Rocket Lab担保、扫付或处置担保资产，并使Rocket Lab集团承担可量化现金付款或资产追索。
  - Reference: 本轮材料没有已发生违约、加速、担保索偿或全集团现金冻结的证据；2026Q2 Iridium披露符合当时契约，且Term Loan没有财务维护契约。贷款文件中的一般违约权利属于或有条款，不等于已调用。
  - Boundary: 只在正式救济已经被行使，且至少100百万美元现金被强制支付/扫付或同等规模运营资产进入执行范围时命中。一般违约风险、未量化的技术性契约违反、新闻推测或对全部现金的假设不构成边界。

## 跨平台研发组合与工程资源复用的费用及机会成本

Rocket Lab 的开发平台数量、各项目工作范围和工程人员配置共同决定公司高研发费用会持续多久，以及费用何时可能被更大毛利池吸收。2026Q2 净研发费用为 82.429 百万美元，同比增加 16.295 百万美元（25%）；公司将增量归因于 Neutron 开发进展、近期收购业务、招聘带来的人员费用，以及拓展航天器和组件组合的原型投入，不能把总额全归于 Neutron。公司披露研发成本包括人工、原型、专业服务、材料、设施和折旧；研发费用会随处在开发、验证或测试中的产品数量变化。因而一项完整新平台或新增再设计/验证周期，可能在已有高投入基座上继续增加多季度费用；真正完成一项实质工作流并把工程团队复用到既有项目，则可能避免重复原型和新增招聘。不过，人员换项目本身不等于集团费用下降，研发成本在转入商业生产后可能列为存货，销售时再进入营业成本；报表费用下降若只是分类移动，不是现金节约或合并成本消失。本轮可核验的 Neutron 基线来自 2026-08-10 SEC 10-Q：当时仍以 2026Q4 到台为目标、资格测试继续，且公司强调飞行后仍需形成可全规模生产和高频发射的系统。C1 未能确认截至 cutoff 的 10 月最新进展，因此不把该目标表述为 10 月已核实状态；但无论目标如何更新，到台、一次飞行或技术验证成功都不自动代表研发退出。反过来，为换取近端费用下降而撤掉整个有商业用途的平台，会同时削弱未来产品和合同机会，不能只计入节约。

- C1 / LONG / MIDDLE: 公司公开确认一项实质性产品平台或主要开发工作流已完成其主要原型/验证任务，并把相关工程人员转用于已在进行或已获资金支持的现有产品/生产工作；同时取消该工作流的后续原型、测试或招聘预算，而非把同一团队转入一个新的开发项目。该变化须保留已完成的产品能力，不是因退出一条核心商业平台而节省费用。
  - Reference: 截至 2026-10-12 cutoff，2026Q2 公司净研发费用为 82.429 百万美元（2025Q2 为 66.134 百万美元），但公开说明把费用增长分配到 Neutron、已收购业务、招聘/人员和航天器及组件原型等多项投入；项目级预算和人员分配未披露。公司 Q3 GAAP 经营费用指引为 143–149 百万美元，但未单列研发指引。年报说明内部产品研发成本在开发期间费用化，待项目转入商业生产后才可能列入存货。本轮冻结资料中未见公司确认跨平台团队转用或主要工作流退出；C1 也说明未取得 10 月 Neutron 完整运营更新，因此不从资料未记录推断项目没有变化。Neutron 的 Q4 到台目标仅是 8 月 10-Q 时点的基线。
  - Boundary: 最低充分边界为管理层公开给出至少 10 百万美元/季度的持续净研发运行成本下降（相当于当前Q2研发费用约12%、Q2营业亏损约17%），且将其归因于一项实质开发工作完成/停止、后续原型或新增用工减少，并说明释放的工程能力进入已有产品/生产工作。低于该幅度的单季变动不足以与项目组合和收购范围波动区分；若下降仅因研发成本转入存货或营业成本、或团队被新平台投入抵消，则不命中。
- C2 / SHORT / MIDDLE: 公司批准并投入一项超出当前已公开开发组合的独立重要产品/飞行平台，或为既有主要平台增加完整的重新设计、原型制造和验证周期，且公开确认需要专门工程资源和持续多季度工作；正常推进当前 Neutron 测试或已披露的航天器/组件开发不属于新增范围。
  - Reference: 公司已披露的当前投入组合包括 Neutron、近期收购业务、招聘及航天器/组件原型开发；2026Q2 净研发费用 82.429 百万美元，管理层称研发费用会随开发、验证或测试中的产品数量变化。Neutron 的 Q4 2026 到台目标及当时资格测试来自 2026-08-10 10-Q；公司另指出当时首飞窗口趋窄，且还需为飞行后全规模生产/高频服务作准备。C1 未取得截至 cutoff 的 10 月完整运营更新，故这些只作最近已核验的基线，不断言其在 10 月未变化。
  - Boundary: 新增一项独立主要平台，或因新发现/范围扩张而开启超出当前公开测试路线的完整重设计及多季度原型/验证周期，已足以延长现有高费用期；若公司披露金额，至少 10 百万美元/季度的增量研发预算也达到同一分量尺度。一个例行部件更新、既定测试、目标日期变化本身，或未增加工作量的团队重新命名，不足以命中。
- C3 / SHORT / MIDDLE: 公司正式取消、无限期搁置或从未来产品/服务路线中撤下一整项重要商业平台或完整产品能力，并因此不再交付其公开承诺的核心用途或依赖该能力的客户任务；仅缩减次要改型、一次测试失败或暂时延期不属于该事实。
  - Reference: 当前公开路径仍是多平台开发：Neutron 面向较大型商业及政府星座发射任务，Space Systems 继续扩展航天器、空间系统与组件产品。Neutron 在 2026-08-10 10-Q 时仍处在资格测试和发射准备中；截至 cutoff 的 10 月最新状态未在 C1 材料中核实。既有合同/任务与未来商业接受均不等于已实现收入，但这类平台保留未来产品和供应范围。当前资料没有显示公司撤掉整条开发平台或完整商业能力。
  - Boundary: 整项平台/产品能力退出，并使其预期交付范围或依赖该能力的已宣布客户项目不再可执行，第一次足以修订未来产品机会；无需等待季度收入损失确认。近端研发费用节约不能抵销该条件，因为它同时移除了公司未来可售能力；保留核心平台而取消一个非关键改型或测试方案则未达到边界。

## 已收购业务与区域组织的持续费用及整合执行

截至2026Q2，公司GAAP经营费用为每季142.090百万美元，研发82.429百万、SG&A 59.661百万；相较2025Q2合计增加36.063百万，其中研发增加16.295百万、SG&A增加19.768百万。公司把费用增加归因于Neutron研发、近期收购业务、招聘及员工相关支出、原型投入和并购交易活动；本批材料没有量化GEOST、Mynaric、Motiv的净后台协同。交易费只是部分且非经常负担，不能把它退出当作人员和组织成本退出；公司截至Q2仍有持续的购买会计无形资产摊销及正常股权激励。三项收购拥有不同的专业能力和客户接口：GEOST从事国家安全EO/IR有效载荷，Mynaric为激光光通信供应商并继续以慕尼黑为总部，Motiv带入约50名工程师和技术人员及帕萨迪纳制造设施。它们的研发、认证、客户信任、数据安全或地方经营要求不等同于重复后台。合并财务、采购或工程系统只有在确实取消了重复的持续支出、且留任、迁移、资格维持和所需地区/安全接口成本未抵消节约时，才会降低费用基座；反过来，整合若破坏关键团队或客户任务，短期费用压低也可能换来更低的履约能力。2026年8月Rocket Lab Germany GmbH的公告支持的是潜在未来德国制造扩张，尚不是有资金、工厂或已披露当地员工数的经营项目。未来Iridium服务整合不属于本观察范围。

- C1 / LONG / INNER: Rocket Lab公开宣布并已实施（或有明确实施日期和责任范围的正式批准）跨至少两个GEOST、Mynaric、Motiv业务的共享服务整合，实际集中至少一项核心非项目职能，如财务、采购或公司级IT/工程工具，并披露由此产生的年度化净经常性费用节约；金额明确扣除仍须保留的安全/地区团队、工具维护和必要迁移后的持续费用。
  - Reference: 2026Q2 GAAP经营费用142.090百万美元/季度，同比多36.063百万；公司说明并表及员工、研发和交易活动均增加费用，但没有给出净后台协同额。以Q2费用年化约568.36百万作为规模锚；交易费用、普通SBC和购买会计摊销并非可随一次整合自动退出的重复后台费用。
  - Boundary: 年度化净经常节约达到约36百万美元或以上，即Q2同比一个季度的经营费用增量规模、约为Q2年化费用基座的6.3%，且来自已识别的跨业务共享职能整合，已足以实质改变持续费用基座预期。一次性交易/重组费退出、未量化的协同目标、仅把研发费用转入存货或只宣布德国法人不满足边界；无需等待下一份财报才判断此结构性信息。
- C2 / SHORT / MIDDLE: Rocket Lab或相关客户/采购方公开将一项具名、已授予且仍在执行的重大多年度项目的取消、实质缩减或关键交付重新排期，明确归因于收购后组织整合破坏了必要的安全/数据接口、地区授权或关键专业团队能力。
  - Reference: 现有收购业务在Q2已贡献收入和费用，但公开材料尚未量化协同，也未证明存在可全球合并的重复团队。Mynaric保留慕尼黑总部并参与Rocket Lab的SDA卫星供应，Motiv带入50人专业工程团队及帕萨迪纳设施，GEOST面向国家安全项目；当前基线是持续整合负担，而非已证实的裁员协同。
  - Boundary: 一个具名的已资助重大项目因整合造成的人员、安全或地方运营能力缺口而丢失、缩量，或关键交付被客户正式改期，已足以证明费用节约可能以业务执行能力为代价。普通地区团队保留、单个管理层人事变动或德国扩张愿景本身不够；无需再等总研发下降或财报确认。
- C3 / SHORT / INNER: Rocket Lab公开确认，GEOST、Mynaric或Motiv某个收购后专业团队的整合/地区管理调整引发关键技术领导者及其专业团队离职，且公司为替代招聘、留任或返工追加持续资源，或将具名重大项目里程碑归因于该团队流失而延后。
  - Reference: 截至2026Q2没有公司按收购团队披露的离职率、留任费用或岗位空缺。Motiv官方收购公告明确带入50名工程师和技术人员；Mynaric继续以慕尼黑为总部并供货于政府及商业客户；GEOST面向国家安全有效载荷。专业人员并不等于一般可替换后台人员。
  - Boundary: 必须是因整合/地区组织决策而离职的关键技术负责人及成组专业能力，并有公司披露的持续替换/留任/返工投入或具名项目排期影响；此类事实已显示去重带来的短期费用下降可能被恢复能力的成本抵消。单一高管更替、未说明原因的自然流动或没有资源/里程碑后果的组织新闻不够。

## 模型化工程与数字测试流程对研发工时和验证负担的改变

Rocket Lab披露的研发费用随处于开发、验证或测试的产品数量变化，并包含工程劳务、原型、材料、设施等；2026Q2研发82.429百万美元，但无公司专属数字工具采用范围、节约工时或单位产出数据。GAO-26-107009记载国防测试现代化计划将数字工程工具和高技能人员纳入重点，同时指出多数主要采购路径的测试政策还没有充分落实迭代测试、数字孪生/线程等做法；GAO-26-108457则显示被调查项目使用成熟数字线程有限，且跨数字环境/涉密访问会妨碍实时共享。它们支持“模型可减少重复设计和测试准备”以及“系统互通、安全访问会增加实施和验证工作”的两种机制，不是Rocket Lab当前采用或节约的证明。若公司在核心项目把模型数据接入实际测试并复用设计反馈，可降低每个可信迭代的手工准备/返工或增加同一人力可完成的循环；若客户的分区、涉密或主权要求迫使多套模型环境并行，则工具维护、接口验证和数据重建会吞掉部分效率。数字模拟不等于取消必要的硬件、资格或物理测试，省下的工时也可能被更多研发工作吸收而非降低报表费用。

- C1 / LONG / INNER: Rocket Lab或该项目客户公开确认，数字模型/线程已用于一个核心、已资助的运载器、航天器或组件开发项目，并将模型数据与实际测试准备/反馈接入至少一个已完成的设计—验证迭代；该消息明确指出重复人工准备、设计返工或跨团队重复录入减少，或可在既有人力下更快完成下一轮设计/测试准备。
  - Reference: 截至cutoff，任务材料和2026Q2财报没有建立Rocket Lab具体项目的数字工程采用率或工程效率节约基线；研发仍以持续产品开发、验证和测试为基础。GAO的DOD样本仅说明行业采用与跨环境整合存在现实差异，不能代替公司采用证据。
  - Boundary: 在核心资助项目的实际设计/测试闭环中完成一次模型与测试数据的集成使用，并公开说明它减少重复准备/返工或加快循环，即首次跨过效率变化边界；普通模型展示、单纯签购工具、数字孪生计划或尚未进入工程工作的模型不够。此边界不要求研发总费用下降、多个项目重复使用或实物测试消失，因为新增研发范围可能吸收已释放工时。
- C2 / SHORT / MIDDLE: 具名政府/商业客户对Rocket Lab参与的一项重大在研项目发布新的模型或测试数据访问、主权/涉密隔离或跨环境互操作要求，并公开说明该要求迫使供应商维护彼此隔离的模型/测试线程、重复准备数据或为同一设计增加额外工程验证。
  - Reference: 数字线程的价值在于让设计者、测试方、客户和终端用户能共享实际迭代数据；GAO-26-108457记录的跨数字环境与涉密权限问题可阻断这种共享。Rocket Lab尚无公开公司级数字模型使用基线，不能把一般客户安全要求视为已新增成本。
  - Boundary: 一个重大资助项目出现新的程序级访问/互操作限制，并由客户或公司说明它实际造成并行模型环境、人工转录/重验或额外测试准备，足以修订每次工程迭代的工作量预期；既有安全规定没有工作流变化、仅称数据需保密或权限有标准分级都不够。无需再等待出现财报费用增加或最终项目延误。

## 工程人才获取与留任成本对有效开发能力的影响

Rocket Lab的研发费用包含劳务、原型、专业服务、材料、设施及折旧；2026Q2研发82.429百万美元、同比增加16.295百万，SG&A 59.661百万、同比增加19.768百万，公司将其中的费用增长部分归因于招聘和员工相关支出。其研发/SG&A总额不是全体工程师薪酬：缺少公司专属的岗位工资、空缺、离职率、招聘周期和单位工程产出数据，不能把同行工资变化直接乘到全部研发费用。关键岗位空缺会让一美元当季人工费用减少却延长设计、测试准备或返工周期；更高现金薪酬或股权留任奖励能保住能力，但也提高持续投入；按现有成本培训/留任稀缺技能并缩短空缺则可能提高同等费用可承担的工作量。Rocket Lab的股权激励计划明示吸引和留任员工的目的，2026上半年披露的一次性CEO RSU取消不代表全体员工正常激励退出。GAO对国防测试现代化的材料支持高技能人员和迭代开发之间的机制，不证明Rocket Lab当前存在工资冲击或已实现节约。

- C1 / LONG / INNER: Rocket Lab公开说明，针对具名重大开发项目或一整类关键技术岗位实施了培训、内部培养或留任安排，并确认由此填补了此前限制任务的工程/技师职位或保住团队，令原本受人员瓶颈影响的工作范围或里程碑得以推进，同时避免了一个已公开的高价外聘/持续薪酬上调计划。
  - Reference: 截至2026Q2，公司研发投入和员工相关支出均上升，研发费用82.429百万美元/季度；尚无公司专属工资、招聘周期、空缺率或按工程人员计的产出基线。2026上半年披露的11.180百万美元CEO RSU取消是一次性事项；普通股权报酬仍是吸引/留任成本的一部分。
  - Boundary: 公开证据需涉及一个核心在研项目的关键工程/技师群体或一类稀缺岗位，并把内部培养/留任与填补瓶颈、避免已公开的外聘溢价或维持里程碑直接相连；一个这样的业务群即可改变有效能力成本判断，不要求整个公司研发费用先下降。泛泛招聘、一次高管奖励/取消奖励或只提出培训计划但没有人员/项目结果不够。
- C2 / SHORT / INNER: Rocket Lab或具名收购业务公开确认，某重大开发项目/专业工程团队因持续岗位空缺、离职或与同行竞争而不得不提高现金薪酬、签约奖励或股权留任成本，同时关键岗位仍未填满或公司明确说明相关人员短缺推迟了设计、验证准备或交付里程碑。
  - Reference: 2026Q2公司说明招聘和员工相关开支是研发及管理费用增量原因之一，但未报告工程岗位工资上调或离职冲击；全体研发开支中还含原型、材料、设施、专业服务和折旧。当前预期保留高投入而不认定已发生工资阶梯。
  - Boundary: 一次公开披露若把持续薪酬/留任上调与多名关键岗位人员或一个重大项目仍存在的人员瓶颈、返工或时间后移相连，即已显示单位有效工程能力成本走高；单一高管离职、普通奖金、同业独自招募、一般性职位发布或一次性RSU取消均未越界，也不对全部研发费套行业涨幅。

## 客户批次验收与供应商结算周期

履约投入先可能留在库存或未开票合同资产，合同约定的客户验收/运行移交再产生开票权，应收款仍须在到期日实际支付才成为现金。2026-06-30 合同资产为 94.245 百万美元、应收账款为 112.889 百万美元；H1 经营现金桥显示库存、应收和合同资产分别占用 73.3、63.0、30.1 百万美元，而合同负债贡献 78.8 百万美元，余额还含收购带入部分。因而，验收只把合同资产换成应收不等于现金回收；只有可开票权更早且到期清楚，或逾期款真实收回，才重估供应商垫资时间。标准平台按批次重复验收可能令后续项目更快开票，但新项目同时开工可重新吸收旧款释放；这影响现金转换节奏，不必等到 Rocket Lab 合并 CFO 同步披露。技术成功、发射或运营新闻若不产生合同接受/付款权，不自行触发。

- C1 / LONG / MIDDLE: 客户或主承包商对具名 Rocket Lab 项目正式接受某批次/移交运行，或签订新的分批验收条款；公开的合同或验收通知同时使至少 10 百万美元已履约价值成为无条件可开票款，并约定在 90 天内支付，且比原本的全系统/后端验收付款计划至少提前 90 天。只有飞行、技术验收或合同资产转列应收而没有付款权及到期安排，不构成该事实。
  - Reference: 截至 2026-06-30，合同资产 94.245 百万美元、应收 112.889 百万美元，H1 合同资产现金占用约 30.1 百万美元。当前单位级资料说明按里程碑开票，并有部分后端验收/长期客户融资情形，但未提供逐客户旧新付款期限、应收账龄或可适用于所有项目的标准验收日期；因此不把正常交付进度视为意外现金改善。
  - Boundary: 同一项目有至少 10 百万美元的已履约余额成为确定的可开票债权，且金额在一个季度内到期、相对原合同付款里程碑至少提前 90 天。该边界表示从未开票资产向短期现金权利实质推进；如果消息只称验收完成而无应付金额/日期，或仅资产科目换位，不足以支持 LONG。
- C2 / LONG / MIDDLE: 客户、主承包商或 Rocket Lab 对外确认，已实际收到一笔至少 10 百万美元、原已逾期或曾因项目验收/账期争议重订期限的 Rocket Lab 合同付款；该收款不是新授标预付款，也不只是开票、账面合同资产减少或对旧收款的重复报道。
  - Reference: 目前披露的经营现金压力主要来自库存、应收及合同资产净占用，而非已知的单项坏账。合同到期收款通常属于计划内兑现；当前无公开材料显示 Rocket Lab 有某笔具名商业项目逾期款已被市场当作无法回收，也不能用一次收款推断全集团现金流转正。
  - Boundary: 现金须已到账而非只获客户签收/付款承诺；金额至少 10 百万美元，且此前的公开合同/客户通知显示该款已经逾期至少 90 天或已被正式展期/争议。此状态解决了明确现金悬置，较单纯应收转列更早且足够；未逾期的正常分期收款仍属普通进展。
- C3 / SHORT / MIDDLE: 客户或主承包商正式拒绝/推迟具名批次验收，或修订 Rocket Lab 合同，把至少 10 百万美元已发生履约/持续生产所对应的付款从现行里程碑推至全系统后端验收或更晚的账期；新增延迟至少 90 天，且 Rocket Lab 仍须继续投入而没有相同范围的停工/取消对冲。仅尚未到约定验收日、技术进度变化但未改变付款条件，或应收资产在科目间转列不构成命中。
  - Reference: Rocket Lab H1 经营资产负债占用约 135.9 百万美元，合并收款周期受开票、验收、客户账期和预付款分别影响。当前合同具体接受标准及日期未按客户公开；在既有合同到期前，普通生产或技术工作继续本身不是付款延后证据。
  - Boundary: 已发生/仍须继续垫资的金额至少 10 百万美元，并且相对已签或已公开的原里程碑推迟至少一个季度（90 天），或正式把该批款项改为后端系统验收后才可开票/付款。若投入同步停下、客户取消新项目且不再产生该笔履约成本，净峰值占款未因此增加，不越过边界。

## 商业客户项目资金来源与供应商垫资责任

Rocket Lab 的现金变化取决于项目资金何时、以何种追索条件穿过运营者、主承包商和分包链，而不是客户资产负债表上的融资总额。2026-06-30 的客户融资应收为 32.150 百万美元（2025 年底 22.888 百万美元）；部分商业发射客户融资在发射后分 12 个季度收回。H1 经营资产负债占用约 135.9 百万美元，说明预付材料、履约、开票和回款时序可以主导现金桥。Globalstar 展示了资金链：SEC 披露服务客户为 Globalstar SPE 提供 20% 股权、服务预付款及项目建设资金，预付款用于卫星、地面网络及发射成本；但 Globalstar 以 MDA 为卫星主承包商、SpaceX 为运输方，Rocket Lab 的平台供应角色并不等于它直接收到客户投入。Globalstar 的服务预付款还对应未来服务与抵销/偿付义务，不是无条件赠款。只有新资金在合同中被明确用于向 Rocket Lab（或其承包商链）支付具名供应商里程碑、且其追索/担保没有回转到 Rocket Lab，才降低本公司的垫资风险。强买方可能降低违约概率，也可能把付款后移至验收；外部融资还可能催生更早备料，使先期现金支出抵消部分好处。客户融资与批次验收是不同观察对象，项目资金到位不自动改变验收或账期。

- C1 / LONG / MIDDLE: 针对仍在履行的具名商业航天器或发射项目，客户/运营者/资金方与主承包商公布一项新、已承诺且可动用的项目预付款、专属融资或权益资金安排，并披露该资金按合同在交付/发射前至少形成 10 百万美元对 Rocket Lab 或其供应链中向 Rocket Lab 应付的付款；同时明确 Rocket Lab 不为该笔资金提供新增本金担保或追索，且该付款比原合同的验收/发射后收款时点至少提前一个季度。仅有客户融资总额或资金进入运营者/SPE 不构成命中。
  - Reference: 截至 2026-06-30，Rocket Lab 已有 32.150 百万美元客户融资应收；部分商业发射融资按发射后 12 个季度偿付，显示本公司承接过资金桥，但并非所有客户账期都是该安排。Globalstar 10-Q 披露，客户对其 SPE 的 400 百万美元投资代表 20% 权益（其中 176 百万美元现金、224 百万美元实物投入），并披露累计收到 813.4 百万美元基础设施预付款；资金用于 Globalstar 网络资产，不能据此认为 Rocket Lab 收到同额款项。当前没有可用的客户级付款流向、RKLB 保证或同一合同上的供应商现金回收表。
  - Boundary: 至少 10 百万美元成为可识别、不可撤销且在未来 12 个月内按具名合同向 Rocket Lab/其应付链条付款的资金，并比原合同早至少 90 天到达；不得只按融资公告的总额或客户信用评级判断。10 百万美元是明确现金时点变化，约为 H1 经营资产负债现金占用的 7.4%，已足以改变一个季度现金需求；如新融资同时给 Rocket Lab 增加同额提前备料/供应商付款义务，则净提前现金不足 10 百万美元不越界。
- C2 / SHORT / MIDDLE: 具名客户项目的既有外部预付、SPV/权益融资或银行项目融资被撤回、冻结或重组，且正式合同/付款通知显示由此至少 10 百万美元的 Rocket Lab 供应商应付款或融资应收被推迟至少一个季度、延长到发射后 12 个季度以外，或转为 Rocket Lab 新增追索/保证；同时相关履约或已备料仍需继续，因而不是项目投入同步停止所形成的自然现金对冲。单纯客户更换股东、融资谈判或信用评级变化不构成命中。
  - Reference: 当前客户融资应收 32.150 百万美元、部分回款期跨发射后 12 季度；Globalstar 上述安排则由客户预付款、SPE 权益和后续服务义务组合支撑，不能把资金方变强等同于 Rocket Lab 无风险收款。现有材料没有证明某个客户已拖欠 Rocket Lab，也没有公布可归属于 Rocket Lab 的客户融资回收率或全部保证条款。
  - Boundary: 只在可指认的 Rocket Lab 合同金额达到至少 10 百万美元，且现金到达时点至少后移 90 天、超过现有 12 季度回收路径，或新增至少 10 百万美元由 Rocket Lab 担保/垫付时成立。若只是融资渠道被撤但客户仍按原期支付，或生产随资金取消而停下且不再产生垫资，不达到这一边界。

## 政府合同进度融资与主承包付款流转

政府融资改变的是项目资金的到达时点，不是订单规模或最终合同收入。FAR 52.232-16 在合同实际采用进度付款条款时，以成本进度为基础，标准大企业率为 80%；合格申请通常按月处理，标准请求通常在 30 天节点支付，但审查及具体合同条款可能改变时点。FAR 32.504 允许符合条件、已到期并通常在主承包请求后 30 天内支付的分包款纳入进度付款基础，却不保证政府把钱自动传给每一供应商。DoD 小企业加速付款条款也不应套用到 Rocket Lab：FAR 52.232-40 要求在收到政府加速款后 15 天内向小企业分包商付款，而 Rocket Lab 的大型企业供应商身份和具体合同条款必须实际核实。GAO 记录 DoD 在 COVID 期把大企业进度付款率从 80% 提到 90%，后又回到 80%；GAO 还指出大企业多收的资金向下传递有限、政府对分包付款缺乏充分可见性。Rocket Lab H1 合同负债经营现金贡献 78.8 百万美元，但客户构成未知，不能当作政府预付款或现金结余；本轮也没有证据证明公司已经逾期或政府正在拖欠。若 Rocket Lab 是主承包，新增入账仍可能被其向供应商加速支付吸收；若为分包商，主承包收到款并不保证 Rocket Lab 同步收款。只有适用合同、付款率/验收条件和实际流转对公司已形成明确净时点差时才改变现金判断。

- C1 / LONG / OUTER: 采购机构/合同官对一项已授予且仍执行的 Rocket Lab 直接主承包合同发布并执行新的融资规则或合同修改，明确把至少 10 百万美元新增合同现金提前至交付/政府验收前、按已发生合格成本支付给 Rocket Lab；适用条款、申请依据和应付时点均可从正式文件/合同公告判定，而非仅发布一般试点或预算授权。
  - Reference: FAR 52.232-16 的标准大企业成本进度付款率为 80%，但只有实际包含该条款的合同适用；政府还可协商绩效付款或其他条件。GAO 记载 COVID 期间大企业率曾临时升至 90%、之后回到 80%。Rocket Lab 当前合同是否包含进度付款、实际基数或申请余额并未按项目公开；H1 的 78.8 百万美元合同负债不能分解成政府现金。
  - Boundary: 正式文件必须显示至少 10 百万美元在原付款时点前、且在交付/接受前成为 Rocket Lab 可申请并到期的现金。作为可直接检验的费率等价，若合同原为 80%，提高至少 10 个百分点并覆盖至少 100 百万美元的剩余合格成本，相当于约 10 百万美元更早融资；合同有付款额度但无可动用时点不够。
- C2 / LONG / MIDDLE: 一名政府主承包商就具名 Rocket Lab 分包/供应合同公布或签署付款流转修改，明确将至少 10 百万美元政府进度或绩效融资传给 Rocket Lab，并使款项在 Rocket Lab 交付/客户验收前至少提前一个季度、且在有效付款请求后 30 天内到期；扣除 Rocket Lab 按同一安排必须更快支付自身供应商的新增金额后，净提前现金仍不少于 10 百万美元。仅主承包商获得较高融资率、收到政府款或一般表态支持供应链不构成该事件。
  - Reference: 政府与主承包商直接签约，政府对分包付款条款和实际到账的可见度有限。FAR 32.504 允许符合条件的分包融资款纳入主承包进度付款请求并要求符合分包条款，但具体支付仍须在适用分包合同内建立。GAO-22-105007 与 GAO-24-106850 说明政府增加主承包融资未必改善供应商现金流。Rocket Lab 可能在不同任务担任主承包或供应商，公开资料未给出本任务所有项目的付款率/分包条款。
  - Boundary: 至少 10 百万美元明确在 Rocket Lab 付款链上提前到期，并比旧分包日程早至少 90 天；任何被要求加速付给 Rocket Lab 自身供应商的金额必须先净额抵消。没有具体 Rocket Lab 付款、合同适用和可用现金路径，即使政府宣布提高通用率也不越界。
- C3 / SHORT / OUTER: 政府采购机构对仍在履行的 Rocket Lab 直接主承包合同，正式减少/暂停原有成本进度融资，或将至少 10 百万美元原可在交付前申请的款项改为交付/最终验收后支付或推迟一个季度以上；同一公告/合同仍显示工作、备料或支出义务继续，没有对应停止工作或取消订单来抵消垫资。单纯 CR 延迟未启动的新任务或一般预算未增加不构成命中。
  - Reference: 对适用 FAR 52.232-16 的大企业合同，80% 是标准成本进度率；超出、低于或不采用该条款需看实际合同。Rocket Lab H1 经营资产负债净占用约 135.9 百万美元，但政府客户份额未知；没有证据显示当前政府对 Rocket Lab 的付款已逾期。
  - Boundary: 适用合同的既定融资被实际削减至少 10 百万美元，或其至少 10 百万美元付款从已授权执行中的成本/里程碑节点延到原付款日期之后至少 90 天，同时继续发生 Rocket Lab 资金支出。费率上，若原合同为 90%，回落至少 10 个百分点并覆盖至少 100 百万美元剩余合格成本可形成约 10 百万美元融资缺口；不能把普通 80% 适用率当作新利空。
- C4 / SHORT / MIDDLE: 政府主承包商在取得/可申请政府进度融资后，正式修订与 Rocket Lab 的具名分包付款条件，继续要求 Rocket Lab 为已授权项目采购或生产，却将至少 10 百万美元应付给 Rocket Lab 的金额保留至后端系统验收或推迟至少 90 天；或公开确认政府进度资金虽已到账但至少 10 百万美元不流向 Rocket Lab 且供应商继续垫付。新安排没有相同规模停工或其他提前付款抵消。
  - Reference: 政府融资到达 prime 不等于下游收到融资。FAR 52.232-40 的 15 天加速支付条款针对小企业分包商，不自动为 Rocket Lab 创造同一权利；FAR 32.504 的适用融资分包条款也需结合具体合同。当前并无已知 Rocket Lab 政府合同欠款事件，亦未披露统一的 prime-to-RKLB 付款时滞。
  - Boundary: 至少 10 百万美元的具名 Rocket Lab 应收/履约资金，相对已签付款条件后移至少 90 天或被推至系统验收后，且相关生产支出仍继续，即足够显示政府融资没有传到供应商。仅主承包收到融资、付款流水不可见或预算时点不明仍是相关而未触发。

## 供应锁料与跨项目库存复用改变集团现金底座

Rocket Lab的库存现金底座由两类不同资金共同组成：履约中的原料/在制品，以及为单一或有限来源、长交期输入维持的供应保障库存。公司2025年10-K明确称其对单一来源输入以增加缓冲库存管理风险，尤其是长交期项目；这使最低采购量、不可取消条款和交期变化能够在客户里程碑回款前改变现金需求。2026年上半年库存现金流出为73.331百万美元；6月30日库存账面余额266.931百万美元，其中原材料119.662百万、在制品129.529百万、成品17.740百万。余额还受并购带入和经营增长影响，并非全部安全库存；原材料与在制品也不是同一资金阶段。若相同的持续生产计划可通过已合格的替代来源降低缓冲/锁料，或已有库存经批准在另一个当前项目使用并实际替代新采购，避免的采购现金近似按成本一比一释放（仍需扣资格、转换和替代项目补购）；10百万美元净减少约相当于当前半年库存现金使用的14%，足以改变近期现金占用判断。反之，新增不可取消的材料最低采购或提前付款会扩大已投入但尚未收到客户现金的底座；客户改型使已购专用料无法退回或转用，则已垫现金无法按原路径随履约回收，且替代采购可能追加占用。Rocket Lab在2026年2月收购PCL并称其精密加工基地将服务航天器、Electron和Neutron，提供了真实的跨业务协调节点，但没有证明料件可互换、供应商锁料减少或库存现金已节约；自制产能可能改变采购地点，也可能仅把瓶颈转到共享排产。2026年上半年10-Q还列示5.802百万美元库存成本调整作为经营现金流调节中的非现金项目；账面库存因减值下降本身不是现金回收。

- C1 / LONG / MIDDLE: Rocket Lab或其供应商披露，一项当前用于持续客户生产、受单一/有限来源或长交期约束的关键输入，已完成可重复交付的替代来源资格并转入常规采购；同时新供货安排明确缩短交期、降低最低采购/预付锁定，或使公司能在同一生产承诺下减少安全库存，而非仅完成样件或技术资格测试。
  - Reference: 公司2025年10-K的当前供应策略是单一来源/长交期输入维持较高缓冲库存；截至2026-06-30库存为266.931百万美元，上半年库存现金占用73.331百万美元。按当前材料，没有披露哪类物料的实际安全库存、最低采购量、供应商交期或替代资格转换成本，故这些不假定为零。
  - Boundary: 已合格替代来源进入连续生产的消息，只有在同样的既有客户生产计划下，可核验地降低至少10百万美元的公司净现金锁料/缓冲需求（约为上半年库存现金使用的14%），扣除一次性资格、转换和必需的并行备货后，才足以支持LONG。仅多一个获批供应商而仍保持原MOQ、交期和库存目标，或PCL提供新机床而无采购/库存变化，尚不足。
- C2 / LONG / MIDDLE: Rocket Lab披露某一已购或在制的合格组件/材料，被正式接受用于另一项当前客户项目，并因此取消或减少原本要向供应商下达的等效新采购；不是只在项目间调拨后由原项目补买，也不是把库存重新分类。
  - Reference: Rocket Lab跨发射与航天器业务经营，PCL基地被规划为服务航天器客户、Electron和Neutron的共享精密加工能力；但设计、公差、认证和客户验收可能使料件不能跨项目复用。现有半年库存现金占用为73.331百万美元，资料未给出可跨项目使用的料件金额。
  - Boundary: 一项公开、可辨认的复用/订单变更实际避免至少10百万美元的公司净新采购或预付款，且受让项目已接受该料件、供料项目无需等额补购，扣除再资格、改制和调度成本后仍达到该金额，即已足以降低资金底座。仅共用机床、工程人员或仓库，或只把库存占用从一个项目挪到另一个项目，不跨越边界。
- C3 / SHORT / OUTER: 关键供应商或 Rocket Lab 对一项单一/有限来源、长交期的持续生产输入，新增或提高非取消最低采购量、不可撤销的长期采购承诺、预付款，或延长交付期，以致公司必须在相应客户里程碑收款前锁定更多材料现金。
  - Reference: 目前公司已披露单一来源和长交期项目需要额外缓冲库存；2026年上半年库存项目占用73.331百万美元现金、期末库存266.931百万美元。现有材料没有给出供应商逐项合同、未来MOQ或未履行采购义务金额，因此不能把当前库存余额当成已经锁定的供应商债务。
  - Boundary: 新条款/承诺相对原安排净增加至少10百万美元、必须由 Rocket Lab 提前支付或以不可取消库存形式承担的材料资金（约为已发生半年库存现金使用的14%），且超出当前已承诺生产批次所需的普通交付在制品、未被客户预付或供应商账期抵消，已足以支持SHORT。只有较长合同期限但没有增量最低购买/提前现金义务、或与同步新增的客户预付款完全匹配，不够。
- C4 / SHORT / OUTER: 客户改型、取消或变更合同接口/批次，使 Rocket Lab 已经购买或正在加工的一类专用材料/组件对原项目失去用途；公司或供应链公开说明该库存不能退货、获得供应商信用，也未获准跨项目复用，持续合同工作仍须另行采购替代料或原持有资金无法回收。
  - Reference: 期末库存由原材料、在制品和成品构成，分别为119.662、129.529和17.740百万美元；集团库存既含履约投入也含供应缓冲。2026年上半年10-Q列有5.802百万美元库存成本/市价调整，属于现金流桥中的非现金调节，说明账面下降不能作为现金释放证据。当前没有已确认的项目级过时库存金额。
  - Boundary: 新设计/合同事实已使当前成本至少10百万美元的已购库存永久不能用于现有客户项目、不能退回/获贷/跨项目批准复用（约为半年库存现金占用的14%），即足以改写现金回收基线；无需等下一季报才判断。库存减值本身不是新的现金流出或现金释放，但超过此量级的不可回收库存意味着此前垫付现金失去预期履约回收路径，若替代采购另行发生则只会扩大占用。

## Iridium自身国家合法服务范围

物理全球覆盖与分销账单地址不等最终用户本地合法性。UAE既有PTT只授当地实体特定获批客户/适用设备，不扩成全NTN/SBD；历史俄罗斯约2%不当当前实际地域。有效许可本身改变可售法律入口，不等订单/激活，部分权利恢复/失去也可有意义；并购控制审批与终端供给不同。

- C1 / LONG / OUTER: 一国主管机构发布并生效的商业卫星服务许可、终端型式/频率批准或当地经营渠道授权，使Iridium或具名当地持牌伙伴能够在此前未获准或受限的国家/服务类型/兼容终端上合法销售或运营。
  - Reference: 截至2026-10-12，Iridium具有全球网络和广泛分销伙伴，但各国许可按服务与当地经营实体限定。UAE的2024年许可证授予当地Iridium实体，特定为PTT服务，经授权网络向获批准客户提供，并要求适用的型式及频谱授权；TDRA说明即使漫游方式提供公共电信服务也受本地许可监管。该许可证不证明9604、所有语音/SBD产品或NTN Direct均获准在UAE销售。2025年报国家收入按经销商账单地址归属、实际用户地理位置未知。
  - Boundary: 一个最终生效的许可如果把明确产品/客户类别从不能合法经营变成当地可售或可用，已移除市场进入的法律约束，可独立改变可寻址机会和上市时间，不必等首批收入或激活用户。仅原则性政策、咨询、许可申请受理、已有范围的重述、全球覆盖或不含适用终端/服务的牌照不跨界；该变化只计入被许可国家和服务，不将俄罗斯约2%或其他国家比例外推为全球收入。
- C2 / SHORT / OUTER: 一国主管机构对Iridium当前已获准经营的特定服务/终端作出最终撤销、暂停或实质收窄决定，或实施即刻生效的外国卫星、终端进口/型式、数据路由/本地渠道要求，使现有当地持牌渠道不能按原有合法条件继续销售/提供该服务。
  - Reference: 最新10-K记录俄罗斯在制裁下调整后的本地运营、授权服务商和专用网关；2023—2025年俄罗斯服务收入约占总收入2%，截止材料未确认新发生全部停业。公司称经销商账单地址不等于最终用户所在地，无法把一般监管规则换算为准确国家业务收入。UAE牌照针对PTT和获批客户，并非任何设备/用途的无条件许可。
  - Boundary: 最终行政决定或生效规则必须适用于一个有现行Iridium许可/已公开本地服务渠道的具体国家和产品，并实际使该路径暂停、停售、不能合法使用或必须转入新的本地许可/数据路径，才首次足以修订该区域的可售市场与合规负担；不需要公司披露收入损失。对外一般制裁讨论、草案、投诉或与Iridium服务无关的网络规则不命中；即使命中也只限该地区，不外推全球服务归零。 重要部分权利丧失即可，不等全国家所有产品停用；已获合法替代实际保住同用途则据实抵销，同一终端/经营授权不跨稿重复。

## 重合移动用途竞争网络的国家合法资格

美国/英国既有SCS/D2D批准必须排旧。新有效许可在实际设备、用户功能和地区重叠时，可提前改变Iridium相对选择；撤回原真实资格则相反，不等同报目标失单/新订阅。不能外推专业安全、PNT、政府专网或全球所有工业SBD。

- C3 / SHORT / OUTER: 主管机关向竞争卫星运营商与具名移动运营商授予新的最终频谱/市场准入权，使其可以在一个此前未覆盖或显著扩大覆盖的国家/地区，利用地面MNO频谱向现有兼容手机或相关移动设备提供D2D连接，且许可新增的用途与Iridium在该地可提供的移动消息/IoT服务实际重叠。
  - Reference: 美国已存在FCC的SCS监管框架；截止日美国有SpaceX/T-Mobile及AST与AT&T/Verizon等特定频谱和地域授权，英国Ofcom已批准Telefonica UK与VodafoneThree在特定移动频段提供卫星D2D所需的牌照变更/豁免。这些决定是已知监管基线，不证明许可伙伴已获得消费者使用量，也不触发重复报道。SCS依赖MNO频谱租赁和地理范围；Iridium 9604的SBD/LTE-M/GNSS及标准NB-IoT NTN Direct使用路径、终端兼容与服务形态不同，只有设备和用途真实重叠时才影响竞争。
  - Boundary: 超出现有美国/英国授权基线的新的最终国家许可，或一项实质扩大现有许可的主要MNO覆盖区域/兼容设备范围的频谱决定，足以降低竞争者进入重叠移动消息/低速连接用途的法律门槛；许可本身可改变可选服务/议价机会，不必等对手披露用户增长或Iridium确认流失。一般卫星宽带牌照、频谱咨询、临时灾害试用、重复确认既有授权，以及与Iridium服务不相容的D2D许可均不跨界；不外推至Iridium的PNT、政府专网、专业安全语音或所有工业SBD。
- C4 / LONG / OUTER: 主管机关最终撤销、暂停或实质削减竞争卫星运营商与当地移动运营商已获准使用的D2D频谱/地理权利，使其在与Iridium服务重叠的既有市场不能再按此前许可扩大或提供相关移动连接。
  - Reference: 美国和英国已有范围明确的MNO-卫星D2D频谱准入决定；相关服务仍需遵守具体频段、干扰保护、设备及地域条件。授权带来竞争选项但不等于已经获取付费用户。Iridium的全球卫星覆盖、传统移动卫星频谱和当地持牌渠道与这些MNO频谱许可不是同一种权利。
  - Boundary: 仅对已经取得且可用于重叠设备/用途的竞争授权，发生正式撤销、暂停或显著地理/频段收缩才足以降低竞争者在对应市场的合法可服务机会；拒绝未来未获准、未形成当前竞争参照的陌生申请不自动构成利好。无需等Iridium新增订阅，但结论只限被撤销或收窄的地区/设备类型，不表述为所有竞争消失。

## 纳税人实际研发方法选择的现金税权

研发扣除只在同纳税人同年度有真实正联邦税基/已建立现金税路径、且可依法利用时节税。RKLB现联邦零税及DTA全备抵不产生现金退款；报税/方法选择通常不公开，不能由程序到期推已选。$2.5m只强尺度，不用全辖区<10m指引或历史2.190m联邦数据设新年统一底线。

- C1 / LONG / INNER: 一项实际、有约束力的美国联邦研发税务方法/选择被公开确认为已作出并适用于 Rocket Lab 或已依法确定的相关纳税人，包括 2025 年后国内 §174A 扣除/资本化方法，或 2022–2024 年未摊销国内研发余额的过渡回收选择；该选择相对现行/原有可用方法，足以减少该纳税人可预期的联邦现金税。
  - Reference: 截至 2026-10-12，2025 年后国内 R&E 可依 §174A 当期扣除，也可按允许方式资本化；国外研究仍依 §174 摊销。2022–2024 年历史国内余额可在 2025 年一次回收或于 2025–2026 年两年回收；合格小企业追溯选项的三年平均收入门槛为 31 百万美元，Rocket Lab 2022–2024 年收入约为 211、245、436 百万美元，不符合该门槛。IRS Rev. Proc. 2026-32 更新会计方法变更程序，但程序本身不证明纳税人作出选择。Rocket Lab 2025 年联邦现金税为零，美国 DTA 全额估值备抵、资本化研究相关 DTA 为 82.234 百万美元；联邦 NOL 为 840.916 百万美元。2026 上半年税前亏损 90.745 百万美元，披露现金税 0.464 百万美元为全辖区口径。联邦报税及附随选择通常不是公开材料；截至截止时点没有证据表明某项选择已提交或已公开确认。
  - Boundary: 有约束方法选择与同一纳税人、同年正联邦税基/可用盾相连，重要部分现金税降低即有意义，不仅$2.5m或较低基线全部归零。已有公开主体、法定范围和税负可组合，无需同篇全私有余额；80%NOL、SRLY、§382及实际扣除资格不可省。决定性主体/税基未知则保个案gap，当前联邦零税只增NOL不LONG。

## 交易公司层面纳税组与可用税盾

§368股东待遇不证明公司纳税组。Iridium正税负仍是独立主体且交易未交割；只有binding主体/属性安排与同年度实际税负相连，才可在交割/报表前修订现金税。正向包括重要可用盾改善，负向必须新增/提前税或真实已建盾损害，不把消除正税负误作利空。

- C2 / LONG / MIDDLE: 公开且有约束力的交易税务安排、交易税务意见或正式裁定明确了 Rocket Lab–Iridium 交割后的美国联邦申报主体/纳税组，并确认一项可依法使用的 Rocket Lab 国内研发扣除或 NOL 能抵减合并组内已存在的 Iridium 正税基，使未来联邦现金税低于 Iridium 独立纳税路径。
  - Reference: 截至 2026-10-12，交易尚未交割；Iridium 股东于 2026-09-24 批准交易，仍待监管等条件且预期 2027 年年中完成。Iridium 2025 年美国税前收入为 143.779 百万美元，联邦现金税为 2.190 百万美元、全辖区现金税为 7.007 百万美元；2026 上半年税前收入为 45.467 百万美元，税费 11.952 百万美元、现金税 4.904 百万美元（全辖区），管理层指引 2026–2027 年现金税每年低于 10 百万美元。Rocket Lab 2025 年后 NOL 中 2017 年后部分通常最多抵减 80% 应税收入，另有 SRLY、§382 和合并申报限制。当前并无证据确认交割后集团申报或 Rocket Lab 税务属性可被 Iridium 利润利用。已签合并协议 §368 相关的 40% 股票对价门槛是股东层面的重组/股票出售税务处理，不是公司合并纳税组、NOL 可抵扣或现金节税结论；公开文件也未显示 IRS 裁定。
  - Boundary: 公司纳税主体及实际可用属性被binding文件确定，并能结合该同年度真实联邦税负说明有意义部分节税即可；不等$2.5m、全低基线归零、交割或季报。遵守80%、SRLY、§382及主体连接，无连接不编税盾，私有全税基不用同报。
- C4 / SHORT / MIDDLE: 交易特定的有约束力文件、正式税务意见、官方裁定或法院行动公开显示 Rocket Lab–Iridium 公司层面的申报/税务安排新增联邦现金税，或使一项此前已公开建立且可使用的联邦现金税盾权利失效/显著缩减。
  - Reference: Iridium 独立经营时的公开基线为 2025 年联邦现金税 2.190 百万美元、全辖区现金税 7.007 百万美元，管理层预期 2026–2027 年现金税每年低于 10 百万美元、长期税率至 2029 年更接近法定税率。交易未交割，公开协议的 §368 股票对价条件说明的是持有人税务待遇；它不是公司联邦纳税组或 Iridium/ Rocket Lab 损失可互抵的公开结论。Rocket Lab 尚未建立一项已可抵减 Iridium 税款的税盾。
  - Boundary: 真实新增/提前联邦税，或此前已建立可利用扣除权的重要部分被损害即可，不等$2.5m或全权利消失。恢复正向必须相对真实先前损害；尚未可用NOL未兑现、仅§368股东待遇/DTA改变不是SHORT。按同主体同年度公开税负/法定资格比较，关键未知留gap。

## 一般正式研发规则的实际现金税影响

一般适用最终规则可在公司检查/税实缴前改变真实纳税权，但必须适配公开研发类别、主体及同年度可利用性。binding已定未来适用期可以先改预期，不等相关年度报表；草案/程序重述不够。RKLB当前联邦零税，Iridium全辖区数据不代未来联邦基线。

- C3 / SHORT / OUTER: 最终正式且有约束、具有明确当前或未来适用期的法律/权威规则，缩减或后移公开适用研发扣除/回收权，使同主体同年度真实正联邦税基/已建现金税路径新增或提前税负，或损害已有可利用盾。
  - Reference: 当前基础为 2025 年后符合资格的国内 R&E 可依 §174A 当期扣除，国外研发仍按 §174 摊销，历史国内余额有特定过渡回收路径。Rev. Proc. 2026-32 是方法变更程序更新，不等于已经削减上述实质权利。Rocket Lab 当前 2025 年联邦现金税为零且美国 DTA 全额估值备抵，故一个尚未兑现/未建立的税盾损失本身不是现金税利空；Iridium 有实际联邦税款与未来现金税路径，但仍是独立纳税人。
  - Boundary: 重要部分真实税负/可用盾损害即可，$2.5m只是强例；消除正现金税基线是减税，不写成负向。一般规则不需点名目标/IRS公司检查，也不需同篇全私表；无真实正税基或只潜在盾更难兑现不SHORT。
- C5 / LONG / OUTER: 最终正式有约束且明确适用期的研发规则/解释，扩大、恢复或前移该相关纳税人依法可用扣除/回收，并降低其同年度已有正联邦税负，或恢复真实此前受损的可用盾。
  - Reference: 现行 §174A 已恢复符合资格的 2025 年后国内 R&E 当期扣除；国外研发仍受 §174 摊销，2022–2024 年国内历史余额已有全额/两年回收选择。通常方法变更程序并不自动扩大可扣除额或把 DTA 变成退款。Rocket Lab 目前联邦现金税为零且全额估值备抵；Iridium 独立纳税人的实际联邦现金税/未来税负是现实税务暴露，但不能单独证明其拥有 Rocket Lab 国内研发扣除或纳税组权益。
  - Boundary: 有意义部分改善可先成立，不只$2.5m或全基线归零。公开实体与法定资格可关联既有税负，不省80%等限制；未来正式适用可先改变预期，不等实缴。无可用主体连接/NOL潜在价值不冒现金。

## 收购整合中的卫星服务合同与运营责任

截至2026-10-12，Rocket Lab提出把发射、航天器与Iridium网络能力组合成端到端服务，但交易虽已获Iridium股东批准仍未交割，目标为2027年中且尚需监管及其他条件。Iridium 2026Q2服务收入为1.61328亿美元，占当季总收入约72%，说明经常服务是大块业务；该季度仍是Rocket Lab未并表且Aireon全资收购前口径，不能当作整合后新收入基线。Iridium通过约120家服务提供商、320家增值转售商和100家增值制造商进入客户工作流，客户合同与支持责任由谁承担会影响持续连接能否保留、扩用。SEC交易文件指出，Rocket Lab的项目型发射/航天器业务与Iridium的订阅型服务节奏不同，整合卫星运行、地面系统、客户和供应商关系可能复杂并干扰持续经营；其合并备考也未计入预期协同、收入增量或实现成本。因而真正的服务上行入口是外部客户对跨业务持续服务承担新付费义务；真正的下行入口是实际合同或持续运营支持因整合转出、收窄或终止。完成收购、品牌合并、内部收费抵销、降低后台费用或一次性发射/硬件订单均不能替代外部服务合同证据。没有客户级收入、套餐价格或责任成本拆分，无法将单项合同换算为统一美元阈值或利润率。

- C1 / LONG / MIDDLE: 具名外部客户签署可执行持续付费安排，把Iridium通信/PNT/数据与Rocket Lab任务/卫星/地面持续服务相连，真实新增有偿工作、产品位置或收费权；仅两旧已付合同联名、更名或原价新增无偿职责不构成新增收入。
  - Reference: 截至2026-10-12，6月28日签署的并购协议已于9月24日获Iridium股东批准，但交易仍待监管及其他交割条件，预计2027年中完成；经营上Iridium仍是独立服务业务。Rocket Lab与Iridium公开宣示垂直整合和服务扩展方向，但材料没有显示已签成由合并团队共同承担的外部持续服务合同。Iridium的Q2服务收入1.61328亿美元和500余家服务生态伙伴仅是当前经营尺度；没有具体客户、渠道的服务费、份额或支持成本分布。
  - Boundary: 新binding付费责任可在投运/季报前改变捕获，金额未知不强制全私有成本。交割后生效亦须真实可执行客户承诺，新增免费负担另解释；集团内收费/组织节省不是外部销售。
- C2 / SHORT / MIDDLE: 有权客户/合同方正式撤销、实质缩减或转出此前已绑定的可分新跨业务共同持续服务重要有偿职责/产品位置，使其实际权益减少。
  - Reference: 当前服务仍由Iridium按既有网络、客户和伙伴体系运营；Q2 2026服务收入为1.61328亿美元，服务伙伴多而客户/伙伴级份额未披露。交易文件把客户、供应商与持续运营关系留存列为整合风险，但这是风险提示，不是已发生的流失；截至信息截止日，映射材料没有记录由Rocket Lab整合引发的具体客户合同退出或服务责任转移。
  - Boundary: 重要部分新共同角色损失即可，不等全业务停止；整合原因不是旧EMSS/NTN/Aireon/网关同合同退出之外第二个事件，专属旧角色只原范围承接。补偿/同等付费替代保全尊重，当前无共同新合同不造丢单。

## Iridium控制许可与核心取得范围

FCC最终有效同意解除一项关键法定门槛，不等其他清关/交割；HSR、股东与初审旧结果不重复。必要监管最终拒绝或核心隔离实质损害拟取得经营控制，属于执行机会损失，不天然证明集团净损失：撤回对价、借款/担保不进入、已成ATM稀释和附条件费用须共同解释，留存现金也不天然LONG。无法比较终止净交易取舍部分仍gap。

- C1 / LONG / OUTER: FCC对Iridium卫星、地面站及通信授权的拟议控制权转让作出最终有效同意，且批准不要求交易特定的核心资产处置、保持独立或实质限制Rocket Lab控制相关网络运营、客户服务及其数据/现金。一般许可合规或技术性条件不排除该事件。
  - Reference: 截至cutoff，Iridium股东于2026-09-24批准交易，Rocket Lab于2026-09-15完成ATM融资，HSR等待期于2026-08-12届满；但FCC及其他若干必要监管/交易条件尚未满足，Iridium仍独立。FCC于2026-09-15发布DA 26-985：申请经初步审查可受理并开始征求意见，评论/申请异议截止10-15、回应截止10-30、回复截止11-09；该公告没有实质批准或决定日期。公司公布的2027年中只是有条件交割目标。
  - Boundary: 一项最终且有效的FCC转让控制权同意，若允许交易保持对成熟卫星网络及运营的拟议控制范围，就足以消除当前一个主要许可障碍并上调该业务进入Rocket Lab控制范围的可执行性；无需再等交割或财报才判定。初审受理、程序截止、意见数量或一般合规条件尚不足；批准仍不代表其他审批和交割条件已完成。
- C2 / SHORT / OUTER: FCC或另一项必要监管机关作出有约束力的拒绝/禁止决定，或批准只在交易特定的核心卫星/地面资产处置、保持独立、运营隔离或关键数据/现金控制限制下有效，实质阻止Rocket Lab取得拟议的网络控制与整合范围。
  - Reference: 当前交易仍待必要监管批准，2026-09-15的FCC通知只是受理和公众意见程序。合并协议允许当事方在特定条件下尝试解决异议，但公开文件说明Rocket Lab不必接受某些处置或类似补救；因此普通审查、意见或技术性许可约束并不等于范围被缩减。
  - Boundary: 有约束必要监管拒绝/重大核心限制或明确监管原因终止，已损害取得原经营范围，不等最后EndDate或财报。一般合规/第三方未采纳异议不足。该方向仅承接真实执行/经营机会损失，撤回付款、未进入债务担保、既成稀释/实际终止费及替代用途据实解释，不从终止本身推整个集团净SHORT，未知交易取舍保gap。
- C4 / SHORT / MIDDLE: 当事方以正式有约束力的交易终止决定确认无法取得必要监管条件，实际撤回原核心网络经营取得安排；不以谈判传闻、条件性End Date或普通窗口后移代替终止。
  - Reference: 截至2026-10-12交易未交割、尚待必要批准；合同有条件性终止安排，但当前不存在已终止结果。
  - Boundary: 仅承接正式监管原因终止造成的执行/经营机会损失；若同一最终监管拒绝已由C2承接，不再次把该同一不可取得结果记一次。撤回付款、未进入集团的债务/保证、已完成ATM稀释、真实附条件终止费用和未绑定替代用途共同解释，终止不天然证明集团净SHORT或留现现金天然LONG；净交易取舍无法比较留gap。

## Iridium非FCC必要清关的独立解除

澳/新/英明列必要外资批准及依法确有交割前要求的外国通信许可，各可独立消除门槛。DCSA先正式提出FOCI要求后有效接受/协议承诺才有安全清关信息，不造当前要求。可接受binding交割时生效承诺不需等全部清关；初审、无反对报道、旧HSR/股东不是新结果。

- C1 / LONG / OUTER: 一项在合并协议/S-4中明确列为必要的非FCC外国投资或通信授权批准，由相应主管机关就本次Rocket Lab–Iridium交易作出最终书面同意或确认；若批准附有约束性条件，当事方公开接受可执行的条件并确认该法定交割门槛已满足。澳大利亚、新西兰、英国的必要外国投资审批属于明列范围；其他境外通信授权只有在适用法律或主管机关确认交割前须获准时计入。
  - Reference: 截至2026-10-12，Iridium股东已批准，HSR等待期已于2026-08-12届满，融资已完成；交易仍待FCC及其他必要监管/交割条件，目标年中交割未实现也未被撤销。S-4明确把澳大利亚、新西兰、英国外国投资审批列作必要批准；特定外国通信授权是否必须在交割前同意则依适用法律/主管机关确认。当前输入未记录这些外国批准的最终结果，不能按未记载视为未申报或被拒。
  - Boundary: 主管机关作出对本交易有效的最终许可，且批准本身或当事方正式披露确认已满足该项必要条件；可接受的、以交割为生效条件的明确承诺/缓解安排可满足边界，不要求等到FCC、其他辖区或最后交割全部完成。它消除一个独立法定门槛并提高交割按现有范围实现的可能性；初审、材料齐备通知、征求意见、无反对报道或非约束承诺不够。批准并不等于所有许可都完成，也不自动证明并购净值、协同或交易后自由现金流。
- C2 / LONG / OUTER: 如果DCSA就并购后设施安全要求正式要求FOCI缓解，当事方披露DCSA已书面确认接受Rocket Lab提出的缓解计划，或已按该要求签署并交付承诺通知/承诺函，且明确满足协议中的相应交割条件。
  - Reference: 截至cutoff，SEC代理材料称相关公司/子公司持有受NISPOM约束的设施安全许可；只有DCSA要求FOCI缓解时，交易才须满足其书面接受计划或收到所要求承诺函的路径。当前冻结输入没有显示DCSA已提出该要求或已作决定。
  - Boundary: 正式书面接受或提交协议约定的承诺函，是把一个已被DCSA正式提出的安全清关条件转成可交割状态的可披露、可约束事项，足以独立降低交易执行风险；不要求再等到并购完成、后续财报或新的政府授标。一般安全审查、潜在转介、未指明的“正在沟通”或第三方意见均不足；缓解计划本身也不证明任何特定合同收入、所有设施许可或无限制经营权。

## Iridium实际取得经营范围的交割窗口

公开预计2027年中不是6月28日精确许诺。6/28、9/28、12/28为有条件EndDate，合同自动延长非新预计；不将任何Q3目标或跨一季标签自动算重大延期。真正原重要窗口持续错失/经营取得时点实质后移可修订执行时间，但交易付款亦后移，成熟现金未并入及贷款/担保路径同时改变，小幅净方向未校准保gap。

- C3 / SHORT / MIDDLE: 交易方正式修订或明确持续无法达到真实原公开预计交割窗口，关联事实足以说明取得经营控制的重要时点实质后移；不只从“年中”改Q3或条件EndDate推延迟。
  - Reference: 截至cutoff，双方公开目标为2027年中；合并协议的初始End Date是2027-06-28，只有特定监管条件尚未满足且其他条件已满足或可满足时，才自动延至2027-09-28及随后2027-12-28。日历经过或合同自动延长本身不是交易失败，也不意味着已变更公司的预期目标。
  - Boundary: 以真正旧公开窗口及实际经营取得时间影响比较，不造年中精确日，不设12/28或两个季度唯一最低，也不用更小硬日历替代。普通程序/自动延长不够，小幅相邻窗口净方向未知留gap；同监管终止归核心取得范围，不再本条件重复。

## Iridium交割与等待期现金用途对可用成长资金的占用

交易融资已落实只说明公司认为预计现金用途可筹足，不代表并表后仍留下相同规模的成长现金。2026-09-15 ATM为19.44亿美元毛额并发行2,930万股，毛额不是净款；原36亿美元过桥承诺已取消，Iridium的17.75亿美元定期贷款获准在交割后保留并由Rocket Lab USA提供担保，不应再算成一笔需现金偿还的交割用途。与此同时，2026-08-26交易文件的6月底pro forma明确排除Iridium于7月2日完成的Aireon收购：新增1.834亿美元一年期无息卖方贷款，以及Aireon原有定期贷款在收购日1.547亿美元余额；剩余Aireon债务计划在Rocket Lab交割时偿还。文件另列约2.292亿美元交割交易费用估计及现金结算的Iridium CSAR奖励。故每一笔债务、费用、现金奖励或等待期新承诺都需与更新的来源用途逐项调节；1.834亿美元整笔卖方贷款与上半年1.875亿美元简单自由现金流消耗提供强尺度，非所有责任首次重要改约最低额；已建立重要债权或关键付款窗口的变化可先成立，但需解释真实抵销与获得资源，不从毛占款推净损失。6月底现金与9月毛ATM不能相加为cutoff可用余额，目标现金只计入一次，也不机械年化半年现金流。 卖方贷款尺度非全部责任变化最低；公开债务/付款权改约可早于结算或财报。延期不抹债务，外部新现金和新业务价值不能忽略，只有已知可比责任变化才有方向。

- C1 / LONG / MIDDLE: 生效债務豁免、到期/费用/奖励改约或binding结算安排，使交割及后12个月的一项重要已承诺现金义务实际减少或后移；公开对应责任/付款窗口可比较，不仅完整未来来源用途表。
  - Reference: 截至2026-10-12，2026-08-26 S-4的六月底pro forma未反映7月2日Aireon收购；该交易增加1.834亿美元一年期无息卖方贷款及收购日余额1.547亿美元的Aireon定期贷款，文件称剩余Aireon债务预计由Rocket Lab在交割时偿还。S-4另估交割交易费用2.292亿美元，列出现金结算CSAR奖励估值约544万美元。2026-09-15公告其ATM净款、Iridium定期贷款及其他可用现金足以覆盖现金对价、某些非保留债务与费用；并未给出截至cutoff的完整现金来源用途或并表后现金缓冲。
  - Boundary: 183.4m卖方贷款是强尺度，重要整笔债权/阶段付款改约可更早有意义。延期非债务消失；已知同额替代义务/费用/挪用资源抵销须扣，不强制全部私余额同时公开。总对价同一改约只由价格范围承接，历史现金/毛融资不拼cutoff余额。
- C2 / SHORT / MIDDLE: 正式更新使现有预计用途外的重要债務、奖励、费用或等待期binding付款义务净增/前移至交割后12个月内，实际对原可用现金路径更不利；不是单已知用途重述或新有价值投资仅毛额支出。
  - Reference: 9月15日融资公告称ATM净款、保留的Iridium定期贷款及其他非受限现金足以支付预计现金对价、某些其他债务与相关费用，但没有披露交割后自由现金保证。六月底pro forma又明确不含7月Aireon新增债务。故需以9月15日预计用途为更新比较点，并将Aireon卖方贷款、既有Aireon借款、预计交割费用和CSAR现金结算逐笔与后续来源用途调节；不得再把已取消的36亿美元过桥或已纳入用途的债务全额重复加算。
  - Boundary: 183.4m只强例，重要实际责任/窗口改约即可。以9/15更新责任逐笔比较Aireon/卖贷/费用，六月proforma漏Aireon不证9月融资漏列。新增资源/业务能力与已确定现金融资抵销须解释，投资净价值缺比较不自动SHORT；不能要求一篇全私来源用途。对价改约只价格稿一次。

## 其他公司级融资的固定优先责任

公司级融资换回资金/资产，同时改变先于普通股的利息、强制偿还、优先分派和集团追索。新增资金解除实际约束或取得有价值能力，与固定责任必须共同比较；有外部项目回款也不消除集团担保。扩大本金或追索不是自动否定全部交换，重要的是真实旧新资金、责任和期限的净取舍。2026H1简单FCF -$187.519m只提供资金约束背景，不能年化为将来缺口；Q3 $21m净利息收入是计划。已完成9月ATM毛额$1.944bn、29.3m股及已取消过桥均不是新事件，融资毛额不能加历史现金构造截止日可用款。

- C1 / LONG / MIDDLE: 公司与资金提供者公开签署有约束力的新融资或改约，实质改善其他公司级融资先于普通股的固定现金或偿还责任；绑定的未来生效条款可先成立。
  - Reference: 截止日没有闭合的交易后自由现金/全部公司债务模型；已签Iridium条款不是本范围新融资。其他未来融资须以具体有效合同建立基线。
  - Boundary: 相对同一责任、同一期间的有效旧安排，净减少重要固定支出或解除实际融资/到期压力；计入新增费用、旧债替代、额外本金/担保和可用资源。$17.75m/年仅为已披露Iridium本金100bp强尺度，不是其他融资首次重要边界；依据具名实际责任的重要部分和公开资金窗口，短于一年也不一律排除。纯票面利率下降但净代价抵销、意向或普通利率波动不足。若新增资产/资金收益与责任交换的主导净意义尚不能比较，保留个案gap，不推定所有加本金/担保交换均无效。
- C2 / SHORT / MIDDLE: 公司签署新的或修订的公司级融资，实质加重先于普通股的固定现金/偿还或集团追索责任，且已知取得的资金、资产和被替代责任不足以补偿该不利变化。
  - Reference: 现行基线已包括9月交易融资的 $1.775bn Iridium 贷款及其条件性担保，不将其再次当成新增融资；其余完整债务和交割后可自由使用现金尚未闭合。公司上半年简单 FCF 为 -$187.519m，但该数不含并购支出，不能机械年化为未来现金需求。
  - Boundary: 对同一期间真实旧新条款比较净新增的重要责任，不以$17.75m/年为必需最低额。纳入净可用资金、实际约束解除、旧债清偿、费用、期限及集团追索；有明确项目回款不能自动排除公司保证。一般用途、融资毛额或支出增加本身不证明净SHORT，若用途收益/权利未知会翻转判断则留gap，而非把未知当零。

## 新增普通股和转换融资的残余权利代价

普通股/转换证券扩大残余索取权，同时为公司带来资金、资产或解除实际资金约束；股数增加本身不能决定净负向。需比较实际新增权益价格及条款与换回的可用资源、旧融资条件和保留权益，避免把负盈利期EPS变化当增厚。已完成ATM29.3m股是旧基线；641m为含约41m参与型优先股的Q3基本加权指引，非期末普通股，不能据此精算稀释。

- C3 / SHORT / MIDDLE: 公司公开签署有约束力的普通股或可转换融资，新增普通股等价索取权或不利转换/优先权利，且对真实换回资金、资产及已有效融资条款作比较后成立实质不利的残余权利交换。
  - Reference: 9月 ATM 已发行 29.3m 股，已是现实股本基线而非未来催化；Q3 管理层 641m 基本加权股数指引含约41m参与型优先股，且是否包括9月发行不清楚。该加权口径不是当前期末普通股数。未来融资尚无已确认发行。
  - Boundary: 29.3m已完成ATM仅强规模参照，不是最早最低股数；不因一般用途或股数变大直接SHORT。依据公开净到款、真实资金约束解除/资产收益及发行价格、转换/优先条款，识别重要的不利交换或既有残余权利实质损害；不要求未来同报全私有估值，但缺乏足以判断补偿是否相当的资源/权利基线时保留gap，不用毛融资額、加权股数或假定资金无收益填补。

## Iridium保留定期贷款的利率保护与净融资成本

Iridium Satellite是Term Loan借款人，2026-06-30未偿本金约1,774.7百万美元，合同到期日为2030年9月。2026-09-15贷款人同意贷款在拟议交易后保留；交割后才适用的利差按S&P/Moody’s贷款评级分档：两者均BB-/Ba3或更好为SOFR+2.50%，一者达标而另一者为B+/B1或更差为+2.75%，两者均更差为+3.00%；无Term B-4评级时参考S&P发行人评级和Moody’s公司家庭评级，二者皆无则默认最高的Level III。合同利差随评级机构宣布评级变化立即生效。此前公开利差为SOFR+2.25%（SOFR下限0.75%）。现有10亿美元cap以1.436%的一月SOFR为赔付阈值、固定年保费0.31%，只保护到2026年11月；2026Q2 SOFR高于阈值，cap当季减少利息费用5.6百万美元、对应保费0.8百万。按6月底本金减去cap名义额，约775百万美元仍未覆盖，每25bp SOFR变动约1.9百万美元年敏感度；cap到期且不续的情景下，全部本金每100bp约17.75百万美元年毛敏感度。第四次修订还规定：交割后前六个月的重定价交易对受影响贷款收取1%费用，六个月后该重定价费用为0；自愿提前还款在交割周年日以前没有此项溢价，周年日后对预付本金收取1% exit fee。贷款利差改变直接改变债务成本；普遍SOFR下降还会削弱交割后现金资产利息收入，不能单凭基准利率下行判定集团净融资收益改善。再融资和提前清偿必须把具体费用及被挪用现金的机会成本一并计算。

- C1 / LONG / MIDDLE: 借款人/贷款人签署绑定的利差、利率保护、再融资或自愿还款安排，或评级变化使合同档位立即生效，实质降低保留贷款的同口径净融资成本或上行敏感度。
  - Reference: 截至2026-10-12，6月底本金约1,774.7百万美元，现行利差为SOFR+2.25%、SOFR下限0.75%；9月修订的交割后贷款利差是评级阶梯：Level I（S&P BB-且Moody’s Ba3或更好）2.50%，Level II（一家评级达该门槛、另一家为B+/B1或更差）2.75%，Level III（两家均低于BB-/Ba3）3.00%。若贷款本身无评级，取发行人评级/公司家庭评级；两者均缺失时合同默认Level III，且评级变化即日调整利差。1,000百万美元cap至2026年11月、阈值1.436%、年保费0.31%，续期尚无证据。新信息应与当时适用的评级层级和保护安排比较，不把已公开的交割利差重置或已知cap到期当作新增利好。 修订在交割生效；重定价在第四次修订生效后前六个月收1%、之后0%；自愿提前还款在第一周年日以前及当日无该溢价，第一周年日之后收1%。9/15的0.50%同意费已知，不重复当新费用。
  - Boundary: 按同一本金、实际有效期间和SOFR情景比较净成本/保护；全额本金一级25bp约$4.44m/年仅强尺度，不与其他融资100bp门槛相交，也不要求所有保护满12个月。重要较短期间保护或有据条款改善可在绑定时成立；固定本金纯利差变化不要求另一个完整集团现金模型。保费、重定价费、周年后的1%自愿还款费及被挪用现金收益均计入；年度敏感度与实际期间总节约不混同。若相邻期限或资金权利不足以比较主导意义，保留该分量gap，不把未知收益当零。
- C2 / SHORT / MIDDLE: 新的绑定贷款/保护/再融资或自愿还款条款，或已生效评级档变化，实质增加保留贷款净融资成本或上行风险；一般SOFR变化不替代新权利事件。
  - Reference: 截至2026-10-12，6月底本金约1,774.7百万美元，现行利差为SOFR+2.25%、SOFR下限0.75%；9月修订的交割后贷款利差是评级阶梯：Level I（S&P BB-且Moody’s Ba3或更好）2.50%，Level II（一家评级达该门槛、另一家为B+/B1或更差）2.75%，Level III（两家均低于BB-/Ba3）3.00%。若贷款本身无评级，取发行人评级/公司家庭评级；两者均缺失时合同默认Level III，且评级变化即日调整利差。1,000百万美元cap至2026年11月、阈值1.436%、年保费0.31%，续期尚无证据。新信息应与当时适用的评级层级和保护安排比较，不把已公开的交割利差重置或已知cap到期当作新增利好。 修订在交割生效；重定价在第四次修订生效后前六个月收1%、之后0%；自愿提前还款在第一周年日以前及当日无该溢价，第一周年日之后收1%。9/15的0.50%同意费已知，不重复当新费用。
  - Boundary: 同一本金/期间/情景比较新的净不利变化，$4.4m年成本为25bp强尺度而非任意最早硬门槛，实际重要责任/保护损害须有基线。计入相应保费、前六个月重定价费、周年后1%自愿还款费、清偿资金机会成本及被替代保护。已知cap到期、未续期沉默或未生效评级意见不触发；真实新绑定条款可先于实施，不能因未来生效或短于12个月一概漏掉。

## 项目共同出资的真实风险承担与保留权益

共同出资可以把具名开发/建设阶段的资金和风险转给伙伴，但优先款、追索、补缴、控制及经济权利决定公司留得多少能力与剩余。多数权益不是净正向充分条件，少于多数也不天然负向；比较外部实际承担与公司获得/保留价值。当前没有确认已签项目伙伴，项目私人IRR/现金瀑布未知，不虚构已有角色。H1负FCF和ATM用途仅背景，不证明未来项目亏损。

- C1 / LONG / MIDDLE: 公司与外部伙伴就明确项目或具名开发阶段签署绑定共资协议，伙伴实质承担原需公司承担的资金/风险，公司保留有价值的能力和经济权益。
  - Reference: 供给的截止材料没有确认任何已经签署的 Rocket Lab 项目股权伙伴协议，也没有可用的项目级回报率或未来现金流预测。2026上半年简单 FCF 为 -$187.519m，9月已完成 ATM 的净款拟付 Iridium 现金对价，不能把该融资当作项目伙伴或运营增长现金。
  - Boundary: 相对真实项目阶段与旧承诺比较，纳入可用伙伴出资、优先款、集团追索/保证、补缴及保留能力/收益。$100m、超过50%权益/控制仅强情景，不是全部最早边界；较早重要具名工作包可成立，不等全项目建成。无集团追索且保留多数不是一律必要，但不得把有追索等同风险已全转移。公开绑定条款可支持净意义，不要求未来披露全私有IRR；决定性权利/风险交换未知则留gap。
- C2 / SHORT / MIDDLE: 公司签署实质不利的项目出资/权益分配或改约，或已真实承诺的共担被撤回、公司保留经济权利重要部分下降，且替代资源/权利不足以补偿。
  - Reference: 当前资料仅把项目权益伙伴列为未来可能的资金来源；没有已知协议、项目特定的利润基线或可用于抵销融资成本的客户现金流。现有公司级负 FCF 仅提供资金约束背景，不证明任一未来项目必然亏损。
  - Boundary: 依据真实旧新资金、风险、优先顺位、追加义务与公司保留能力比较。初签时伙伴多数且公司出至少一半/集团保证是强不对称场景，不以$100m或多数阈值作唯一门槛；未来已建立伙伴出资撤回、可用窗口丧失或保留收益实质缩减有独立不利意义。少数权益本身、无已存在角色的假想撤回或普通客户订单丢失不足；未知初签净交换保留gap，不假定所有项目融资净方向已确定。

## 具名设施同用途的净固定责任

PCL于2026年2月并入；Mahia机库和Auckland任务控制设施有公开用途，但没有完整项目预算。H1现金capex $53.112m为历史，未来12个月最低租赁付款$23.6m、总最低付款$178.5m为全公司而非具名项目预算。设施共建/共享/租赁需同时看实际使用权、可用能力及非取消付款、匹配、保证；同用途责任下降或上升改变可用于其他成长投入的资源。付款延期和成本下降不同，能力变多也不是原目的成本上修。

- C1 / LONG / MIDDLE: 公司/设施伙伴就此前公开由公司承担的具名设施阶段签署绑定安排，保留可比有效用途/使用权并实质减少公司净固定投入责任。
  - Reference: 截至2026-10-12，PCL 已于2026年2月并入并定位为高精度/高批量生产节点；Mahia LC-1 机库扩建和 Auckland 卫星任务控制设施已公开。公司未披露这些项目各自完整预算、剩余现金支出或所有固定维护现金流。2026H1现金资本支出$53.112m是已发生半年支出，不是未来预算。2026-06-30已披露租赁最低付款总额$178.5m，其中未来十二个月$23.6m；新租约/保底付款必须计入公司固定责任。
  - Boundary: 同一目的、实际阶段和有效使用窗口比较真实旧新现金/固定责任；$25m是约H1 capex47%的强尺度，不是首次重要最低额。包括租赁全不可取消期间已知固定款、保证、匹配与外部承担；公开重要工作包/付款责任减少即可比较，不要求所有寿命私有预算同报。较长租期只降低近端峰值而全期成本相同/更高，不作净成本节约；少建少用或权利缩减须纳入可用能力，未知决定性替代成本留gap。
- C2 / SHORT / MIDDLE: 公司正式绑定同一具名设施目的的重要额外自有投入或固定责任，实际取得的能力/外部承担不足以补偿该上修。
  - Reference: 当前没有 PCL、Mahia 或 Auckland 设施的分项目预算或剩余成本基线，不能把$53.112m H1 capex当作余下预算，也不能仅凭公司总体capex上修推断某个设施超支。现有租赁最低付款总额$178.5m及未来十二个月$23.6m表明租金与资本开支并存，付款日期变晚不等于总成本降低。
  - Boundary: 对同一真实阶段、目的和时窗比较净固定责任，计租赁、最低款、可追索保证并扣除同窗可用绑定出资。$25m仅强尺度；重要责任上修不要求同时延期或用途缩小，已建立较小关键工作包可有意义，不编任意低数字。新增能力取得及不同用途投资不因支出变多就SHORT，净交换无法比较留gap。纯用途/窗口丧失由独立用途条件承接，不能再当虚构成本增加。

## 具名设施付款峰值的独立时间价值

绑定安排可能用较长租期换回较低近端现金峰值，且全期固定成本不降。这不是免费节约；只有真实重要融资/付款压力得到缓解、可用能力保留且已知后续负担可承受的交换，才有独立资金时间价值。未披露具名资金压力或后续责任主导意义不明时不假定净利好。

- C1 / LONG / MIDDLE: 公司签署具名设施付款/融资安排，保留重要使用权和可用窗口，实质降低已公开关键付款期的自有现金峰值，即使以较长不可取消期交换而非全期成本节约。
  - Reference: 截至2026-10-12，PCL 已于2026年2月并入并定位为高精度/高批量生产节点；Mahia LC-1 机库扩建和 Auckland 卫星任务控制设施已公开。公司未披露这些项目各自完整预算、剩余现金支出或所有固定维护现金流。2026H1现金资本支出$53.112m是已发生半年支出，不是未来预算。2026-06-30已披露租赁最低付款总额$178.5m，其中未来十二个月$23.6m；新租约/保底付款必须计入公司固定责任。
  - Boundary: 比较同一真实付款窗口和实际融资约束；重要具名阶段峰值改善可先于付款，$25m非必需。须解释已知长期租金/保证/费用和取得能力，只有足以确认缓解真实关键约束的独立时间价值才LONG，不要求全私人预算齐备。全期成本下降已由净成本条件承接则不重复；纯移账、未知可用现金当零或未知未来负担当无均不足，交换主导意义未知留gap。

## 承诺设施用途或可用窗口丧失且固定责任持续

设施价值取决于实际目的/可用窗口；既有固定付款仍在时，重要用途丧失或实际延期本身可削弱已承诺资本的生产价值，无须同时成本上修。场地法律入口和一般工程吞吐不代替具体制造设施的资本用途。现有项目私人预算和固定责任对应仍不完整，不能由总体capex外推。

- C1 / SHORT / MIDDLE: 有权合同方正式变更/撤回或确认无法兑现已承诺设施的重要用途、有效使用权或关键可用窗口，而对应公司既有不可取消固定责任仍在且无相当有效替代。
  - Reference: 当前没有 PCL、Mahia 或 Auckland 设施的分项目预算或剩余成本基线，不能把$53.112m H1 capex当作余下预算，也不能仅凭公司总体capex上修推断某个设施超支。现有租赁最低付款总额$178.5m及未来十二个月$23.6m表明租金与资本开支并存，付款日期变晚不等于总成本降低。
  - Boundary: 以真实旧用途/窗口和已建立固定责任比较重要部分损失，不要求全部设施停止或另有$25m成本上修。实际能力、付款撤销/赔偿和同窗替代可用性须解释；普通排期小变、计划未承诺、固定责任已相当解除不自动SHORT。尚无足以建立具体责任/用途连接的材料时保留gap，不虚构既存租约。

## 地区具名项目实际资本与可用窗口

绑定地区资金改变项目可用资源、风险及自有现金压力，赠款、可提款贷款/保证和权益资本并不同义。贷款本金不能先全额扣净使所有融资价值归零，也不能面额天然LONG；比较可提款窗口、期限成本、追索、匹配和保留权利。2026-08-10仅宣布Germany实体及寻找制造机会，尚无具名资金/厂址预算；历史CHIPS最高$23.9m非全实收。Space TechEU经银行提供信用/保证、拟动员约€1.4bn非给目标直接赠款；项目权益分配仍单独处理。

- C1 / LONG / MIDDLE: 机构/融资方签署或正式授予适用于公司真实地区制造用途的绑定资金或可提款安排，实际提供重要阶段资源/风险承担或降低原资本约束；不等全部实收。
  - Reference: 截至2026-10-12，Rocket Lab Germany GmbH已成立，Rocket Lab公开表述为寻求未来在德国扩大卫星、载荷与组件制造；尚无目标地区项目的已证实预算、具体授资、可用贷款或公司自有出资额。历史材料中的美国CHIPS奖项只表述为“最高$23.9m”，不能视作全额实收。EIB Space TechEU公布的是拟向商业银行伙伴提供信用额度和保证、预计动员约€1.4bn，并重点支持SME及mid-cap；它不是Rocket Lab直接获授的赠款。EDF是合作性防务研发资助，具备联盟、欧盟实体/管理和第三国控制限制，注册当地法人本身不决定资格。
  - Boundary: 以真实项目阶段、付款窗口和有效条件比较可用资源/责任，$20m仅强尺度不是最早底线。非任意撤回且客观可执行里程碑下的承诺可先于到账；面额须区分不合格成本/匹配、利息费用、期限、还款、保证及权利交换，贷款偿还责任单独比较而非从首期资源全扣本金。公开实体/控制结构、用途和具名资金窗口可建立适用，不要求下次公告全私人净表；未知关键金额/权利净意义留gap，不假定Germany已有获奖。
- C2 / SHORT / MIDDLE: 机构/融资方正式减少、取消已有绑定项目资金/提款权，或将可用时间移到原重要付款窗口之后，实际损害已建立阶段资金条件。
  - Reference: 截至cutoff，没有证据显示 Rocket Lab Germany 已有已授资金或明确获资格的德国项目；不能从没有授奖、尚未申请或公司没有公布资金来源推出“失去既有资助”。2024年CHIPS最高$23.9m仍只是历史授奖上限，不能推断已全额入账或当前正在被取消。若后续出现有效签约项目，其已公布金额、可用时点和范围才形成未来可比较状态。
  - Boundary: 比较同一已有资金、阶段与可用窗口，扣除同窗有效替代，并解释范围/能力后移、自有补资或集团追索变化。$20m仅强尺度，已承诺关键阶段的重要部分撤回可成立，不须公司同报全额自筹。未获奖申请落选、旧最高上限、未建立角色或资金沉默不当旧承诺损失。因替代资源/责任解除导致净意义未定的部分留gap。

## 地区制造资金的正式可申请资格

正式资金规则可以在授奖之前改变真实实体/用途的可申请机会。Germany受美国母公司控制，德国注册不自动满足EDF多国联盟、欧盟管理和第三国控制限制，经批准保证例外须实际适用；Space TechEU银行信用/保证及SME/midcap范围不是EDF赠款。规则适用可由公开实体结构和法定项目范围证明，不要求公告专门点名公司，但未知具体资格不能当已经开放。

- C3 / LONG / OUTER: 机构公布已定有约束力的资格规则/征集或有效资格决定，使目标真实实体及已公开制造用途首次可实际申请具名开放资金窗口。
  - Reference: Rocket Lab 于2026年8月10日宣布设立 Rocket Lab Germany，称正寻求未来德国卫星、载荷和组件制造机会，但未宣布具体厂址、预算、申请、已获资金或可竞争的项目角色。EDF现行说明要求多国合作；受资者及分包方须在欧盟且具欧盟执行管理，非关联第三国控制原则上不符合，只有经批准保证等例外。公司德国法人受美国母公司控制，故德国注册不能单独视为EDF资助资格。Space TechEU则为通过商业银行提供信用额度/保证的融资计划、侧重SME/mid-cap，非同一笔EDF赠款。
  - Boundary: 按真实控制/管理、项目用途和具体条件确认可获资而非仅无资合作；不要求规则必须点名Rocket Lab。$20m为强规模参照，不是有意义具名阶段资格最低额，也不以全部基金替代目标机会；公开规则和工作包足以建立实质可达机会即可在授奖前成立。已定未来适用期可先改预期，草案/一般倡议不足；未确认符合的控制例外或工作包连接明确留gap。
- C4 / SHORT / OUTER: 新的有效规则/资格决定关闭此前正式建立的目标实体/制造用途可获资通道，而相应资金窗口仍有真实可竞争机会。
  - Reference: 截至2026-10-12没有已证实的 Rocket Lab 德国地区授资或特定可获资资格，因此现有EDF的第三国控制条件本身是已知的准入背景，不是新的“被拒资金”事实；当前也不应虚构一项旧拨款或已经参加的竞标。未来若公开规则曾明确打开目标实体的具体参赛资金通道，该状态才形成规则关闭的比较起点。
  - Boundary: 以真实曾开放的资格与新规则比较重要部分丧失；$20m非必需，不能拿旧EDF第三国控制限制重新当拒绝，也不虚构旧项目资格。已建立入口的重要适用范围被关闭可先于获奖或收款；没有真实先前资格/具体用途连接留gap，普通未获选非资格关闭。

## 同产品地区竞争产线获得真实融资

具名竞争者的已落实资金支持同市场可竞争产线，可在投产/目标丢单之前改变供给预期。需真实产品与客户功能重叠，资金对应可商业使用能力；Cailabs€37m贷款/€57m包支持光学地面站、最多50站/年，不是Mynaric飞行终端。EIF给Join Fund III€50m、25家计划没有具名受益者，非已发生同产品竞争融资。

- C5 / SHORT / MIDDLE: 具名同产品竞争者取得绑定资金/可提款融资，用于实质扩大欧洲同市场卫星飞行光通信终端或组件可商业供应产线。
  - Reference: Rocket Lab在2026年8月披露其欧洲制造立足点包括已收购并继续在慕尼黑生产光学通信终端的Mynaric；Rocket Lab Germany的卫星/载荷/组件制造进一步扩张仍是潜在未来用途。欧洲资金承诺必须有具名受资者和所资助的同类产品/地区产线才能作为竞争者供给的先行证据。截止前的Cailabs例子是法国光学地面站与激光地面网络：EIB项目簿显示对Cailabs的€37m融资是已签长期贷款、支持其工业设施/R&D；Cailabs则称€57m融资将扩至每年最多50个光学地面站。地面站并非Mynaric的星载/机载飞行终端，故该案说明欧洲融资工具和产品边界，但不等于同产品竞争者扩产。EIF另向Join Capital Fund III承诺€50m，该基金计划投资25家早期深科技公司，未给出具体受益公司，不能当作某终端厂商获资。
  - Boundary: 资金须直接落实到具名主体、对应真实同产品可竞争工作包/能力；$20m仅强参照，不以模糊等金额产能替代判断。重要较早阶段资金可成立，不等全部投产或目标丢单；贷款/保证按可用性期限成本追索解释非赠款。相邻不同功能产品、无具名企业基金总额、未确定可竞争用途不足，真正产品/阶段连接未明留gap。

## Iridium收购对价条款与机械换股结果

已签交易约定每股 Iridium 普通股取得 $27 现金加 Rocket Lab 普通股：约定十个连续交易日 VWAP 不高于 $67.50 时换股比率为0.4000，处于 $67.50–$112.50 内时为 $27/VWAP（四位小数），不低于 $112.50 时为0.2400。中间区间每股股票部分约值 $27，故通常总对价为名义 $54；在上下限外，固定换股比率使股票价值随 Rocket Lab 价格变化。公告的最终 VWAP 和发行股数仍可更新实际股本稀释，但在现有公式内是已知合同的机械结果，不是新经济条款；单看比率变大/变小还会把 RKLB 股价变化与对价变化混在一起。代理材料按2026-06-30 Iridium 105.956m 股和0.3894示例比率估算约41.259m股，明确不是最终交割股数。只有双方签署的条款修订实际改变同一资产/债务范围下的总对价，才直接改变 RKLB 交付的现金和普通股索取权。 $100m是强支出尺度不是最早价格边界。绑定修订可先改变路径，但必要贷款人/监管同意仍如实说明；签署不等全部许可已经取得。真实资产/责任或现金补偿必须同时尊重，不要求未来全私人净值披露。

- C1 / LONG / MIDDLE: 双方公开签署绑定交易价格/对价权利修订，在同一收购范围及可比责任下，实质降低真实总支付且无相当现金补回、资产缩减或新增责任抵销。
  - Reference: 2026-06-28协议、2026-08-26最终代理/招股材料和2026-09-24股东批准披露的基线是每股 $27 现金加按0.2400–0.4000公式计算的股份；预计2027年中交割但仍有监管及其他条件。SEC代理材料以2026-06-30的105,956,272股 Iridium 普通股、2026-08-07十日VWAP $69.33和0.3894比率，示例估算41,259,372股 RKLB 对价股；这不是最终股份数。
  - Boundary: 同一合同比较VWAP、同一目标股/奖励数及同一资产债务保证范围计现金和股票；$100m强尺度非最早最低额，重要真实价格/权利改约可据公开旧新条款先成立。实际补偿和新增/缩减范围解释，不能把组合变化当总价下降；必要监管/贷款人同意的条件保留，不把签署说成已交割。决定性净补偿未知留gap，非要求所有私人未来净值。
- C2 / SHORT / MIDDLE: 双方公开签署绑定总对价上调/支付权利改约，对同一股份和收购范围形成实质增加且无相当资产/现金或责任解除补偿。
  - Reference: 现行合同已批准但未交割：每股 $27现金加公式化 RKLB 股份；ATM 的 $1.944bn 是9月募集毛额，已发行29.3m股且款项拟用于交易现金对价，并不代表后续可自由使用资金。Iridium $1.775bn既有贷款可在交易后保留，Rocket Lab USA 交割时提供担保。
  - Boundary: 同一比较VWAP、目标股/奖励和资产/负债范围比较，$100m或每股约$0.94为强情景而非唯一最早边界。重要绑定实际价格变更可在必要同意尚待完成时改变条件路径，但须说明可执行性。原公式内VWAP/最终股份机械变化、旧ATM加权不是新经济条款；新增资产/责任补偿不能忽略，未知净方向留gap不以普通股数增加填补。

## 关键执行领导的授权接续与能力连续性

2025年10-K明确公司对Beck创意与执行能力的关键依赖；截至2026Q2 Beck仍任President/CEO/Chair，代理文件的接班审视不证明当前有空档或内部无计划。重要执行能力真正新增、关键单点责任被有权且具相符能力的人有效分担，或先前真实能力缺口被接续，可在客户/项目/财报之前改善连续性。有效Beck被另一有效CEO正常替代，不因头衔和通用高层履历自动增加能力。反向亦不以Beck离任本身自动负向：真实职责、权限、相关能力及执行机制决定能力是否保全，董事会保留权限可以有有效机制。CFO Adam Spice仍在任，2026-06-03 CAO职责交予Agostino Ricupati是旧会计职责交接不是CFO空档；Frank Klein为COO。没有公开逐人客户关系/技术归属，不据此揣测项目受损。

- C1 / LONG / INNER: 公司/董事会批准并公开具有明确职责、权限及生效安排的执行授权：在Beck仍有效执行时真实新增相关能力/分散重要单点决策职责；或具相符能力的有权负责人接续此前公开的重要执行/能力缺口，包括CEO、CFO、COO及公司指定平台/项目负责人范围。
  - Reference: 截至 2026-10-12，2025 年 10-K 明确披露公司对 Beck 的关键执行依赖；2026-04-06 代理文件只称公司审视关键高管接班风险，并未公开具名 CEO 继任者或授予其经营权，这不代表内部没有计划。2026-08-10 的 2026Q2 10-Q 仍列 Beck 为 President、CEO 与 Chairman。没有可用的卖方接班概率共识；比较锚是公开的现行执行责任由 Beck 承担，不是推断市场必然预期其长期在任。
  - Boundary: 比较公开原重大职责和真实授权/能力范围。新增承担者须有与具体任务相符的能力依据，不以通用高层履历证明增量；在Beck仍任职时须实际分担重要依赖而非同一有效岗位简单换人。真实先前重要缺口被有效接续亦LONG，不要求客户/项目结果。已经批准、有约束且明确未来生效的授权可先建立有条件改善路径，说明仍待实施；未批候选或一般未来意向不足。正常连续交接无有据风险/能力增量可中性；特定权限已交接而能力保全研究不足处留具体gap，不造当前空档。
- C2 / SHORT / INNER: Beck停止关键执行职责或实质撤出重要能力后，公开职务/权限及具体相关能力事实显示公司原重要执行依赖未被有效保全；即使有临时CEO也不以名字或通用履历否定真实缺口。
  - Reference: 截至 cutoff，Beck 仍是 President/CEO/Chair；2025 年 10-K 称其为许多乃至大多数公司创意与执行的来源，且指出失去其服务可能对运营有重大不利影响。代理文件所称例行接班审视不证明现有执行空档。公司未披露客户关系或技术决定逐项归属，故比较范围是公开列出的公司级或重大项目执行责任，而非私下客户依赖。
  - Boundary: 根据10-K已列关键依赖、公开重大职责、新承担者实际权限/相关能力及执行机制，确认有据重要损失；不须公司逐项承认无人接手或客户/项目已经受损。仅资料沉默或Beck离任不足；董事会代管须看实际能力和执行机制，不一概视为空档。有权且相符能力者连续保全普通交接不SHORT；某项特定能力未公开到足以判断的分量留gap，不能假设私下技术/客户归属。
- C3 / SHORT / INNER: 公司列名CFO、COO或公司明确指定重要平台/项目负责人的离任/职责撤出，导致其已公开重要财务、运营或项目能力/权限未被有效保全。
  - Reference: 2026-04-06 代理文件将 Adam Spice 列为 CFO、Frank Klein 列为 COO，并列出公司关键平台执行风险；2026-06-03 的披露将 Chief Accounting Officer 职责交予 Agostino Ricupati，而 Spice 仍任 CFO，因此这只是会计职责交接，不是当前 CFO 空缺。公司没有公开技术负责人到客户/项目的逐人分工。
  - Boundary: 实际职责、接续权限、相符能力和执行机制支持重要缺口即可，不强制公司明确说无人接手。名义代理或宽泛头衔不证明原关键能力被保全，董事会有实际有效机制也不天然空档。不等收入/项目损失，不要求永久任命；普通有据连续交接可中性。当前无CFO空档，未知特定能力接续不能当不存在；后续真实缺口恢复由C1同一范围承接。

## Iridium贷款契约下的集团现金调度权限

Iridium是贷款借款人，成熟卫星服务所留现金只有在贷款与实体规则允许时才可向Rocket Lab集团其他实体使用。Iridium截至2026-06-30披露现金及现金等价物约1.842亿美元，但这是数月前的合并余额，不是cutoff或交割日可调度净余额；Iridium于2026-07-01另提取1亿美元循环贷款用于Aireon收购，不能将这项借款当作新增闲置现金。2026-09-15第四次修订的贷款人控制权同意当日生效；信用协议修订条款本身则以收购交割为生效条件。修订明确把Rocket Lab USA、Rocket Lab Corp.列为Parent Company，并扩大特定跨实体投资及Parent费用支付篮子；原有向Parent普通股派息条款被删除并标为reserved，修订没有给予对全部Iridium现金作任何集团用途的无限权限。因而，贷款人签署且无后续酌情批准的现金调度承诺，可在实际划款前降低未来资金被锁在借款人/标的实体内的风险；但一个只扩大纸面篮子、没有真实可用现金或用途仍限于交易费的安排，不产生同等资金价值。跨实体转账本身不增加合并现金；若以清偿贷款换取解限，须同时计入现金减少、债务与利息下降及契约释放，不把一次还款多次计入方向。 新增一般用途权利须对应公开可支持的正常经营资金及真实先前受限责任，但未知事件日实体余额不等于零；不要求新闻给全私有净划款表。历史$184.2m、合同$44.3m及$100m只提供强尺度，不是全部权限最早最低额。扫付/清偿还会减少债务、利息和风险，现金可用额下降本身不证明集团净损失；一次清偿的现金、债务、担保解限共同理解，不重复方向。

- C1 / LONG / MIDDLE: 借款人及所需贷款人签署有约束力改约/豁免，相对既有有限用途条款新增真实一般集团用途调度或解除先前有价值用途限制；可即时生效或待交割条件自动生效，后者无需再逐笔酌情批准。
  - Reference: 现有基线为2026-09-15签署的Consent and Amendment No. 4：控制权同意于Consent Effective Date生效，Article II对信用协议的修订则待收购交割且满足列明条件时生效。该修订把Parent Company定义扩至Rocket Lab USA/Rocket Lab Corp.，并把若干有限用途的跨实体投资/Parent费用篮子调高至至少1.772亿美元或LTM EBITDA的40%；原Parent普通股派息条款在修订中被删除并标为reserved，且这几项篮子均有特定用途或适用实体限制；故它没有建立对全部Iridium自由现金的普遍集团使用权。Iridium在2026-06-30曾报告约1.842亿美元合并现金及现金等价物，但当前实体分配、可用净额及交易后留存金额未公开；2026-07-01提取的1亿美元循环贷款用于Aireon收购，不应再作为可用经营现金计算。 ECF按50%/25%/0%及净额超过$44.3m或LTM EBITDA10%较高值的合同计算，非对全部现金扫付、非财务维护契约；当前净可调度量未建立。
  - Boundary: 权利覆盖公开已存在或正常经营可合理支持的资金，实质打开重要先前受限的集团经营/研发/投资用途；$44.3m与$100m均强尺度非最严交集或统一最低额。较小有意义资金权按真实责任、用途及资金生成支持比较，不要求事件日全部实体余额/全集团机会成本同报。纯纸面无资金支持、有限交易费篮子扩大或旧ECF例行算术不足。绑定未来路径有条件价值但不表示交割前RKLB已经支配标的现金；同一签署权利的生效/划款不再触发。解限涉及清偿须解释本金/利息/费用和资源交换，净意义未明留gap。
- C2 / SHORT / MIDDLE: 新的有约束力贷款改约、豁免条件或正式执行限制，损害此前有价值且有现实资金支持的一般用途调度权，或以真实不利费用/追索交换实质缩减该权利。
  - Reference: 现有基线为2026-09-15签署的Consent and Amendment No. 4：控制权同意于Consent Effective Date生效，Article II对信用协议的修订则待收购交割且满足列明条件时生效。该修订把Parent Company定义扩至Rocket Lab USA/Rocket Lab Corp.，并把若干有限用途的跨实体投资/Parent费用篮子调高至至少1.772亿美元或LTM EBITDA的40%；原Parent普通股派息条款在修订中被删除并标为reserved，且这几项篮子均有特定用途或适用实体限制；故它没有建立对全部Iridium自由现金的普遍集团使用权。Iridium在2026-06-30曾报告约1.842亿美元合并现金及现金等价物，但当前实体分配、可用净额及交易后留存金额未公开；2026-07-01提取的1亿美元循环贷款用于Aireon收购，不应再作为可用经营现金计算。 ECF按50%/25%/0%及净额超过$44.3m或LTM EBITDA10%较高值的合同计算，非对全部现金扫付、非财务维护契约；当前净可调度量未建立。
  - Boundary: 即时/未来自动生效都可先改变权利，不等实际扫款；按真实用途/重要受限责任而非$44.3m/$100m硬最低比较。仅可用现金减少不足：扫付同时减少债务、利息/风险，须比较实际权限损失、费用和资源取舍，净交换无法判断留gap。旧公式例行计算、无改变权限、技术风险、没有旧一般用途权利/资金支持不足；同一清偿不与贷款成本/保证解除重复。当前实体资金及较小责任净量仍未知，不把余额当零。

## 重要持有人实际持股与公开转让的供求变化

持有人实际增减 RKLB 已发行普通股，会改变特定投资者的配置和当前股权集中度；一项有明确规模、可执行的公开二级出售，还会在成交前改变可预期进入市场的现有股份供给。两者属于投资者持仓/股票供求事件，不是 Rocket Lab 新订单、盈利或一级融资；公司新发股、NDX 目标篮子强制调整和并购换股分别由一级融资、指数配置及交易本身的路径解释。按已知 cutoff 基线，2026-06-30 普通股约 5.982 亿股，9 月 ATM 再发行 2,930 万股，故截至 2026-10-09 可核实普通股基数至少约 6.275 亿股，未核实的自由流通股数不以该数替代；20 个交易日平均每日成交量约 2,144 万股。冻结 E32 记录 ARK 8 月末至 9 月初实际购入超过 70.5 万股，约为上述普通股基数的 0.11%、20 日 ADV 的 3.3%；现有 ARKQ/ARKK/ARKX 合计约持有 322 万股。这个事件支持一个主动管理人自身配置及持有人集中度已发生可见变化，但不证明价格冲击或长期锁定。ARK 每日公开 ETF 持仓，而 ETF 可经授权参与人以大额单位申购/赎回；所以同一基金持仓股数的变化也可能来自基金份额流量或经理在旗下基金间转仓，持仓市值和百分比还会随股价、公司发行分母变化。2026-10-09 归档表所示单日减少约 84.9 万股不能单独认定为卖出。政策只在公开信息可确认实际净交易/净持股变化时判断；若已有披露可校正流量或内部转仓，应做同管理人合并，不能要求未来新闻交付不可公开的完整 AP 申赎账，亦不能把无法归因的持仓差当作买卖。按 RKLB 的已知市场尺度，约 0.1% 普通股、且约 3% 的 20 日 ADV（当前约 0.63–0.64 百万股）可作为跨管理人而非“占自身持仓 20%”的净重配参考；它约等于历史 E32 规模。公开、明确并有约束力的卖出安排可以早于成交改变近端供应预期：当前约 0.5% 普通股/15% ADV 是约 3.2 百万股，接近现 ARK 全部持仓规模，足以构成可识别的大宗供给，但不保证股价方向。SEC 的 5% 13D/G 申报线是法律披露门槛，不是经济重要性的下限；13G 的无控制目的证明不等于指数机械持有，但首次申报本身也不证明当期新资金。Form 13F 是季末持仓快照且通常季末后 45 日内申报，披露日不能当成交易日；Form 144 是拟议出售通知，SEC 工作人员明确指出未成交时无需提交未成交的修订。因此判断需要核对持有人类型、股份数量、时点、实际活动/委托状态和是否已在公开预期中，而不是从法律表格名或申报百分比推断资金方向。 重要新主动集中持有/资金承诺与日常市场重配是不同维度：超过5%的真实新集中度可独立有意义，不必宣称治理目的，但首次静态法定申报并不证明新增投资。ARK自身20%/10日及>5%卖方20%为高关注强例，不推广任何小基金；新市场参照也不与原比例取最严交集。同一买入/出售同时改变集中度和供给只按一项信息，承诺、成交、快照不重复，实际超出承诺的新量可另比较。

- C1 / LONG / MIDDLE: 具名主动管理人/投资者披露可归因的RKLB普通股实际净买入/净增持，相关账户/基金归并后形成重要主动重配；不以静态首次申报代替新增。
  - Reference: 截至 2026-10-09 的归档日持仓显示 ARKQ/ARKK/ARKX 合计约 3,219,746 股；归档来源同时列示单日股数变化 -848,859，但这只是账户持仓差，无法据此确认实际卖出。冻结 E32 记录 2026-08-31 至 09-09 期间 ARK 合计购入超过 705,000 股，其中 09-08 ARKX 另买 2,341 股。基于 10 月 9 日价格 68.21 美元及 20 个交易日成交量，20 日 ADV 约 21,441,516 股；公司已知普通股基数至少约 627,480,438 股。ARK 当前汇总持仓约为该股数基数 0.51%，E32 买入约为 0.11% 和 3.3% ADV。
  - Boundary: ARK高关注强例为10交易日内实际净增至少上一同口径持仓20%（10/9基线约644,000股）；其他管理人采用RKLB市场参照max（事件时已发行普通股约0.1%，20日ADV约3%），当前约643,000股，不把小基金自身20%泛化，也不将两条参照取交集。同口径市场/账户归并、实际交易证据足以归因即可，不强求完整私有AP申赎账；未能排除机械流量的日差不足。E32旧买入不再次触发，价格效果非保证。
- C2 / LONG / MIDDLE: 非指数机械持有的主动/战略投资者，公开可验证实际新买入、累积或绑定资金承诺，形成此前未有的重要RKLB普通股集中持有角色。
  - Reference: SEC 对 Section 13(d)/(g) 的披露框架以超过 5% 的某类已登记权益证券为重要实益持有披露门槛。当前已知普通股基数至少约 627.5 百万股，5% 约为 31.4 百万股，按近期正常成交约等于 1.46 个 20 日 ADV。ARK 截止时聚合约 3.22 百万股，远低于此法律持股门槛，故 ARK 日常调仓与新 5% 持有人应分开。
  - Boundary: 超过5%的真实新增实益持有/绑定取得承诺，是独立集中度强入口，按事件时同口径股数而非自由流通股估计；须有实际新增取得或承诺支持，首次法定申报/披露日/旧静态持仓本身不足。主动13G无控制目的不等指数，也不须同时宣称战略/治理目的；发行分母变化不作买入。若同一次买入也符合C1只一次；较小角色重要性或披露滞后、资金意图尚不足留具体gap，不以统一市场阈值取消重要集中持有观察。
- C3 / SHORT / MIDDLE: 具名主动管理人/投资者披露可归因的RKLB普通股实际净出售/净减持，相关基金/账户归并形成重要主动退出/重配。
  - Reference: 截至 2026-10-09，ARKQ/ARKK/ARKX 合计约持有 3,219,746 股；同一归档表记录 -848,859 股日差，但没有说明它是主动出售，故不能作为已确认抛售。公司股数以 6 月 30 日 5.982 亿股普通股流通和 9 月 ATM 2,930 万股发行构成至少约 6.275 亿股的已知基数；20 日 ADV 约 2,144 万股。
  - Boundary: ARK10交易日内实际净减20%（约644,000股）保留高关注强例，其他主动管理人用max（已发行普通股约0.1%，20日ADV约3%）市场参照；两条不是必须共同满足。排除机械赎回、内部转仓、价格/发行分母因素，但已有足够公开交易归因不要求完整私人流水。10/9 -848,859股日差不可单独推主动卖出；小持有人的任意20%不自动足够。已绑定出售随后落仓由C4同一事实承接不重复，较小持有人分量未建立留gap。
- C4 / SHORT / MIDDLE: 现有持有人/关联卖方公开新签数量明确、有约束力且面向近期公开市场分销的二级出售/大宗配售；可低于5%持股，不是可撤销意向/一般登记。
  - Reference: 超过 5% 是 Section 13(d)/(g) 的公开实益持有重要门槛。以当前已知至少 6.275 亿股普通股为基数，5% 约 3,140 万股，约 1.46 个 20 日 ADV；它远大于 ARK 10 月 9 日合计约 322 万股。可执行 block/出售计划直接改变市场可预期供给，即使尚未成交，也不同于一般日持仓波动。
  - Boundary: >5%重要持有人出售其头寸20%是已研究强例；其他卖方公开分销用max（已发行普通股约0.5%，20日ADV约15%）当前约3.2m股的具体市场参照，不与>5%/20%取最严交集。数量/近期公开供给须绑定，普通注册、Form144、旧10b5-1上限和长期锁定战略买方不足。同一承诺、成交/持仓快照一次；只有超出原已吸收承诺的实际新增量另比较。新一级融资、指数机械供给、治理权变化各按其实际信息，不从供给保证价格必跌。

## 工程技术信息安全事件与承包授权恢复

Rocket Lab 2025 年约 47% 营收来自美国政府及其主承包商/分包链；截至 2026-06-30 的 backlog 为 23.559 亿美元，其中 Space Systems 14.158 亿、Launch Services 9.402 亿。公开资料没有把这些收入或 backlog 按涉密等级、具体项目或受安全授权约束的范围拆分，因此只能说明国防/政府承包是实质业务接口，不能把任何一份合同金额当作潜在损失。10-K 称公司过去不时遭受攻击尝试、截至 2025 年末尚无重大不利影响；同时指出公司、客户和供应商的受控/涉密技术信息与工程系统若被未经授权访问、泄露或篡改，可导致 IP 损失、运营/验证中断、客户信任下降，甚至影响安全许可、政府合同、涉密访问、出口资格或承包资格。故重点不是面向用户的卫星通信是否仍在运行，而是设计、制造、测试和任务验证能否继续处理受控资料并完成安全任务；一个受控设计资料的真实失窃，或一项有规模的政府项目被正式安全停工/撤权，可在全部经济损失确定前修订竞争和 backlog 转化预期。相反，安全限制解除能恢复该项目的执行/投标能力，但不能撤回已泄露的数据，也不自动证明排期、成本和收入完全恢复。影响应限于被证实涉及的系统、设施、数据和合同：供应商标准采购条款要求发现 Rocket Lab 信息遭 compromise 后立即调查/遏制并在 24 小时内通知，模板把相关调查/补救成本分配给供应商，但实际合同和剩余项目损失仍需分别判断。 真实资料受侵、关键工作系统停用和正式安全权限改变是不同事实：同一公告完整披露的重合损害/恢复不重复，但后来独立权限变动/关键能力变化可有新增信息。资料访问本身即有风险，无须竞争者已经利用；正式授权解除可以早于全部流程、成本或排期恢复。自有系统事实为INNER，真实履约供应链接口为MIDDLE，不依攻击者或发布者位置划层。

- C1 / SHORT / INNER: 可靠信息确认未经授权者实际访问、外传、公开、篡改或破坏Rocket Lab自身工程/履约系统中的现行任务受控技术资料或重大设计、源代码、制造/验证文件。
  - Reference: 2025-12-31 的 10-K 已把攻击者尝试描述为不时发生，但称截至该时点未产生重大不利影响，并称当时没有已识别、已重大影响或合理可能重大影响公司业务/财务/经营的网络风险（含既往事件）。同一 10-K 明确涉密/受控技术信息事件可能引发安全许可、政府合同、涉密访问、出口资格或承包资格损失。2026-06-29 并购协议又含自 2023-01-01 起不存在达到 Company Material Adverse Effect 门槛的安全事件/通知的陈述，该陈述受重大不利影响例外限定；它不是“没有任何攻击或事件”的证明。2026-06-30 backlog 23.559 亿美元、Space Systems 占 14.158 亿美元，2025 年政府/主承包商/分包收入占比约 47%，但安全项目/涉密收入没有单列。
  - Boundary: 至少一项现行重要任务的真实受控/关键工程资料受侵即越过攻击尝试基线；不等竞争者利用、罚款/合同取消。只有尝试、未证实勒索/资料包、漏洞、确认工程数据无损或纯PII不足。事实按真实资料范围，不要求私人全部补救净表，也不推全集团风险；同一损害已经完整被系统停用/权限事实吸收不重复，独立泄露/完整性损害仍保。
- C2 / SHORT / MIDDLE: 主管机关/政府客户/主承包商正式因安全事件暂停或实质限制现行目标任务的资料访问、设施/安全/出口授权或履约资格，实际阻断重要仍须履约能力。
  - Reference: 当前披露的总业务规模为 2026-06-30 backlog 23.559 亿美元；2025 年约 47% 收入来自美国政府及主/分包链，但合同分类、单项安全授权和涉密营收没有公开分拆。故限制的经济意义取决于被阻断的仍有效制造/任务范围，而不是把任何一般网络故障扩展到全公司。
  - Boundary: 单一关键任务或重要实际授权范围已足够，不以$100m base/多项目设施为必需门槛；这些仅强暴露参照，名义总授标不是剩余风险损失。非保密概述足以识别重要仍须工作及权限阻断，无需私有全部backlog/修复预算。正式限制不等实际工程系统损坏；仅警告、审查或不影响任务的隔离不足。当前各项目安全权限范围未公开，较小授权具体分量未知留gap，不由总政府收入造适用范围。
- C3 / LONG / MIDDLE: 此前公开重要安全权限受限后，有权机关/客户/主承包商正式有效解除相应限制，恢复同一任务/设施实际资料访问、履约或资格。
  - Reference: 2025 年 10-K 所述的一般攻击尝试尚未形成重大不利影响，且截至2026-10-12的公开资料中没有可据以假定全公司安全授权已停的事实；因此，若未来先发生一项正式停工/访问禁令，须以该项目被阻断的基线读取。与此相对，2026-06-30 backlog 为 23.559 亿美元、2025 年政府/主承包商/分包收入约占 47%，说明安全授权复位可保护重要但未按涉密分拆的未来履约入口。
  - Boundary: 重要已受限权限的有效恢复足够，可早于全部流程复工/成本结清/排期追回；不要求$100m或全设施。基线是真实此前授权限制，不须先系统命中某条件。不得推已泄露资料收回、全公司风险消失或全部工作已恢复；技术系统修复不代替尚存正式禁令。仅普通续证/无先前限制声明不足，恢复只计真实新权限范围。
- C4 / SHORT / MIDDLE: 可靠信息确认Rocket Lab真实履约供应商/客户或主承包商接口系统中，承载现行目标任务的受控技术资料/重大工程文件被实际未经授权访问、外传、公开或破坏。
  - Reference: 2025-12-31 的 10-K 已把攻击者尝试描述为不时发生，但称截至该时点未产生重大不利影响，并称当时没有已识别、已重大影响或合理可能重大影响公司业务/财务/经营的网络风险（含既往事件）。同一 10-K 明确涉密/受控技术信息事件可能引发安全许可、政府合同、涉密访问、出口资格或承包资格损失。2026-06-29 并购协议又含自 2023-01-01 起不存在达到 Company Material Adverse Effect 门槛的安全事件/通知的陈述，该陈述受重大不利影响例外限定；它不是“没有任何攻击或事件”的证明。2026-06-30 backlog 23.559 亿美元、Space Systems 占 14.158 亿美元，2025 年政府/主承包商/分包收入占比约 47%，但安全项目/涉密收入没有单列。
  - Boundary: 真实目标资料/当前履约连接及实际受侵足以成立，不等目标系统也受侵或供应商事件造成全部收入损失。无目标工程资料/任务连接的供方事件、纯PII、未遂和未经证实勒索不足；同一目标资料损害不能按供方/公司分别披露重复计算。未知接口角色不虚构，正式授权和操作性功能的后来独立变化保留。

## 自有工程系统的关键功能中断与工作恢复

Rocket Lab 的航天器、组件和运载器依赖设计、生产、集成、测试与验证系统把在研任务转成可交付硬件。公司 2025 年 10-K 指出，IT/通信系统停机可能中断运营、制造和服务，造成延迟、额外成本或收入/利润损失；也披露曾不时遇到攻击尝试，且截至 2025-12-31 未认定网络威胁已重大影响公司。该文件还称其没有备用制造设施或运营，但这不等于每个数字系统都没有替代流程。公司 2025 年约 47% 收入来自美国政府、其主承包商/机构及分包链，且美国政府合同为固定价格；2026-06-30 剩余 backlog 为 23.55949 亿美元，定义为仍需履行的可执行客户义务的估计交易价，其中约 45% 预计在 12 个月内确认。这些数字说明履约时点和工程执行是重要接口，但没有把任何金额分配到安全项目或受网络影响的具体系统。若网络事件或遏制/恢复本身使某项在履行的任务无法继续一个关键设计、制造或验证工作流，单一任务的关键路径停滞就能改变交付时点、完成概率或固定价履约成本预期；不需要等正式安全授权 hold、取消合同或公布私有修复预算。重要性根据真实关键履约路径判断，无固定合同金额门槛；不能以合同名义授标额或未行使选项冒充剩余义务。关键工程系统恢复并让受影响工作流复工，可降低这一项操作性履约约束；它不消除另有证据的资料失窃、知识产权风险或政府授权限制。用户卫星网络是否继续服务是另一层业务，不足以反证工程、制造或验证系统确曾停用。

- C1 / SHORT / INNER: 可靠信息确认Rocket Lab自身现行任务的设计/制造/集成/验证系统因安全事件或必要遏制失去关键功能，实际阻断重要工作流、迫使重复验证或变更已公开关键节点。
  - Reference: 公司 2025-12-31 10-K 的特定基线是：此前攻击尝试截至当时未造成重大不利影响；同一申报称重大 IT/通信系统中断可能影响制造与服务，且列出安全事件影响工程/制造、客户与知识产权的风险。2026-06-30 10-Q 将 backlog 定义为仍待履约的可执行义务估计交易价，并记载总剩余 backlog 2,355.949 百万美元，其中约 45% 预计在 12 个月内确认；没有公开把该数或 2025 年政府链收入比例逐项映射到易受影响系统/合同。 当前未建立公开重大工程停用事实，不等于截至截止日从无事件；具体关键路径和备用流程按实际公开状态比较。
  - Boundary: 单一任务真实关键履约路径实际受阻即可，不等security hold、$100m、全设施、全部取证/费用。合格备用流程保持关键工作则不足，仅预防隔离或威胁无实际功能损失不成立。正式权限导致停工不自动再记系统损坏；同一公告已完整披露重合损害一次，后来新关键功能丧失可独立比较。
- C2 / LONG / INNER: 此前公开受阻的同一关键系统/流程重新可用，并使实际现行任务的重要工程、制造或验证工作有效复工。
  - Reference: 未来恢复以真实此前公开关键工作受阻及备用能力状态比较；当前没有可据以假定所有系统已经停用的事实。
  - Boundary: 真实此前受阻工作是起点，不要求先命中过某Policy。重要受阻工作已复工即可，无须全部数据追回、所有系统无风险、费用结清/原排期全部追回。补丁、外围登录/调查结束但关键工作未开不足；未解除正式授权若仍阻断工作，技术可用不等有效复工。真实流程恢复与授权后来独立解除保留，公告完整重合恢复只一次。

## 履约外部工程接口的关键功能中断与恢复

Rocket Lab 的航天器、组件和运载器依赖设计、生产、集成、测试与验证系统把在研任务转成可交付硬件。公司 2025 年 10-K 指出，IT/通信系统停机可能中断运营、制造和服务，造成延迟、额外成本或收入/利润损失；也披露曾不时遇到攻击尝试，且截至 2025-12-31 未认定网络威胁已重大影响公司。该文件还称其没有备用制造设施或运营，但这不等于每个数字系统都没有替代流程。公司 2025 年约 47% 收入来自美国政府、其主承包商/机构及分包链，且美国政府合同为固定价格；2026-06-30 剩余 backlog 为 23.55949 亿美元，定义为仍需履行的可执行客户义务的估计交易价，其中约 45% 预计在 12 个月内确认。这些数字说明履约时点和工程执行是重要接口，但没有把任何金额分配到安全项目或受网络影响的具体系统。若网络事件或遏制/恢复本身使某项在履行的任务无法继续一个关键设计、制造或验证工作流，单一任务的关键路径停滞就能改变交付时点、完成概率或固定价履约成本预期；不需要等正式安全授权 hold、取消合同或公布私有修复预算。重要性根据真实关键履约路径判断，无固定合同金额门槛；不能以合同名义授标额或未行使选项冒充剩余义务。关键工程系统恢复并让受影响工作流复工，可降低这一项操作性履约约束；它不消除另有证据的资料失窃、知识产权风险或政府授权限制。用户卫星网络是否继续服务是另一层业务，不足以反证工程、制造或验证系统确曾停用。

- C1 / SHORT / MIDDLE: 可靠信息确认真实目标履约供应商/主承包商工程接口因安全事件/遏制失去关键功能，实际使目标现行任务的重要设计、制造或验证工作停滞、重做或改变已公开关键节点。
  - Reference: 公司 2025-12-31 10-K 的特定基线是：此前攻击尝试截至当时未造成重大不利影响；同一申报称重大 IT/通信系统中断可能影响制造与服务，且列出安全事件影响工程/制造、客户与知识产权的风险。2026-06-30 10-Q 将 backlog 定义为仍待履约的可执行义务估计交易价，并记载总剩余 backlog 2,355.949 百万美元，其中约 45% 预计在 12 个月内确认；没有公开把该数或 2025 年政府链收入比例逐项映射到易受影响系统/合同。 当前未建立公开重大工程停用事实，不等于截至截止日从无事件；具体关键路径和备用流程按实际公开状态比较。
  - Boundary: 单一任务真实关键履约路径实际受阻即可，不等security hold、$100m、全设施、全部取证/费用。合格备用流程保持关键工作则不足，仅预防隔离或威胁无实际功能损失不成立。正式权限导致停工不自动再记系统损坏；同一公告已完整披露重合损害一次，后来新关键功能丧失可独立比较。
- C2 / LONG / MIDDLE: 此前公开受阻的同一外部工程接口重新有效支持目标任务，受影响的重要履约工作已实际恢复。
  - Reference: 未来恢复以真实此前公开关键工作受阻及备用能力状态比较；当前没有可据以假定所有系统已经停用的事实。
  - Boundary: 真实此前受阻工作是起点，不要求先命中过某Policy。重要受阻工作已复工即可，无须全部数据追回、所有系统无风险、费用结清/原排期全部追回。补丁、外围登录/调查结束但关键工作未开不足；未解除正式授权若仍阻断工作，技术可用不等有效复工。真实流程恢复与授权后来独立解除保留，公告完整重合恢复只一次。

## 具体国防采购和分包的数据系统资格与协作路径

2025年约47%收入来自政府及主/分包链，仅说明实质采购暴露，非CMMC适用收入。公司参考CMMC框架不证明具体系统合格。冻结基线为2026-07-13暂停Phase II、9/3采购偏离落实，Phase I Level1/2自评仍在；Level1针对FCI的15项FAR52.204-21，Level2针对CUI的110项NIST SP800-171 Rev2，DFARS252.204-7012保护义务未撤。合同/招标等级对应用于履约且处理FCI/CUI的系统，授标前SPRS当前状态/年度affirmation及系统UID核验，沿数据流向必需分包；COTS-only例外和采购活动选定等级不能忽略。具体短期FCI任务、新竞争采购/协作入口可先于订单或旧合同失去改变机会，不仅多年CUI。较低要求也扩大对手进入，较高要求也可能使已合格目标获相对优势；须读目标真实资格、机会和实际评估/隔离成本的主导作用，不按等级升降机械方向。现有公开输入未映射目标法人/系统状态、合同等级或FCI/CUI流转，SPRS私有状态未知不为零，不能把一般制度变动自动写为目标得失。

- C1 / LONG / MIDDLE: 具体有效招标/合同或必要分包条款、权威资格决定实际打开目标可竞争/履约的重要FCI或CUI工作/数据协作路径，或解除原真实独立评估/隔离限制，目标有公开可信的适用资格/能力连接。
  - Reference: 截至2026-10-12暂停后的Phase I及底层信息保护义务是基线，非11月普遍C3PAO升级。当前目标具体合同/法人/系统认证及FCI/CUI流转未公开映射；新竞争采购所列等级并不证明目标目前合格或不合格。
  - Boundary: 有意义具体工作/采购范围的实际可用入口可先于订单或收入成立，不限定多年任务/CUI，也不要求公开保密系统名、分包名和公司承认少建隔离区的共同包。公开非保密任务范围、真实目标角色/资格依据足以建立主导机会改善；评价底层控制和新增竞争，放宽等级本身不天然LONG。未有目标可达资格/机会连接的普通招标或旧暂停重述不足，不能让未来消息替代本次缺失的全部比较基线；现有映射及相邻竞争净作用未建立部分留gap，非要求私有全整改预算/竞争排名。
- C2 / SHORT / MIDDLE: 具约束力具体招标/合同/分包系统要求，新增实际独立评估、隔离或资格限制，实质阻断目标已建立的重要采购/履约协作路径或加重有据必要合规责任。
  - Reference: 截至2026-10-12暂停后的Phase I及底层信息保护义务是基线，非11月普遍C3PAO升级。当前目标具体合同/法人/系统认证及FCI/CUI流转未公开映射；新竞争采购所列等级并不证明目标目前合格或不合格。
  - Boundary: 依据真实当前适用资格、重要工作/数据流及新条款建立阻断/成本主导作用，不强迫目标/prime同时承认不合格，不须多年任务/保密系统名或订单取消。短期重要FCI或新可竞争采购的资格损失亦可成立。评级门槛升高但目标已满足、且限制对手可能相对有利时不得自动SHORT；未知证书不是不合格。确需新评估/隔离的有据范围可先于安全事故/收入成立；目标现行状态与具体路径未映射留gap，不凭47%总政府收入扩展。

## 正式CMMC通用规则的可参与采购与协作范围

2025年约47%收入来自政府及主/分包链，仅说明实质采购暴露，非CMMC适用收入。公司参考CMMC框架不证明具体系统合格。冻结基线为2026-07-13暂停Phase II、9/3采购偏离落实，Phase I Level1/2自评仍在；Level1针对FCI的15项FAR52.204-21，Level2针对CUI的110项NIST SP800-171 Rev2，DFARS252.204-7012保护义务未撤。合同/招标等级对应用于履约且处理FCI/CUI的系统，授标前SPRS当前状态/年度affirmation及系统UID核验，沿数据流向必需分包；COTS-only例外和采购活动选定等级不能忽略。具体短期FCI任务、新竞争采购/协作入口可先于订单或旧合同失去改变机会，不仅多年CUI。较低要求也扩大对手进入，较高要求也可能使已合格目标获相对优势；须读目标真实资格、机会和实际评估/隔离成本的主导作用，不按等级升降机械方向。现有公开输入未映射目标法人/系统状态、合同等级或FCI/CUI流转，SPRS私有状态未知不为零，不能把一般制度变动自动写为目标得失。

- C1 / LONG / OUTER: 正式通用采购/资格规则的约束变更，使公开可识别目标业务/系统类别的重要工作机会或数据协作入口实质扩大，且真实适用资格及竞争/自身成本作用支持目标主导改善。
  - Reference: 截至2026-10-12暂停后的Phase I及底层信息保护义务是基线，非11月普遍C3PAO升级。当前目标具体合同/法人/系统认证及FCI/CUI流转未公开映射；新竞争采购所列等级并不证明目标目前合格或不合格。
  - Boundary: 正式规则已定及适用期明确可先改预期，不必须等单个旧合同改约/订单。规则无需点名公司/保密系统，但必须与已公开真实目标用途/资格连接；FCI短任务、新竞争招标和CUI路径均保留。既有框架采用或总政府收入不是资格依据；门槛降低也引入对手，不能只凭放宽方向LONG。当前逐系统状态/任务等级仍未映射，未能建立真实目标适用及主导作用的类别保留最终gap，不编资格或强迫未来公告给私人全排名。
- C2 / SHORT / OUTER: 新的正式通用门槛/评估或信息协作规则，实质损害公开已建立目标资格/重要工作入口，或增加有据必需独立评估/隔离责任，且已知竞争作用不抵销主导不利变化。
  - Reference: 截至2026-10-12暂停后的Phase I及底层信息保护义务是基线，非11月普遍C3PAO升级。当前目标具体合同/法人/系统认证及FCI/CUI流转未公开映射；新竞争采购所列等级并不证明目标目前合格或不合格。
  - Boundary: 正式约束适用及真实目标路径比较，不等已有订单取消/安全事故，也不限多年CUI。更高门槛若目标已达到且限制对手，不能机械SHORT；未知证书不得当零。保留已生效独立评估/隔离和权限范围重要变化，但普通建议/旧11月日历/未定改革不足。当前缺目标公开CMMC状态、任务级数据流和适用等级，相关类别净方向尚未完成，不能声称已修复全部早期接口；无需全部私有整改预算。

## 董事会独立监督与战略权利配置

董事会监督与特别资本权会改变谁能审视 Rocket Lab 的跨平台资源、重大项目与融资安排。2026-04-06 代理文件的基线不是零监督：七名董事中六名被认定独立；独立首席董事主持独立董事例会并作为董事长与独立董事的联络人，独立董事定期开无管理层参与的会议，审计、薪酬及提名/治理委员会满足独立性要求。Nasdaq 规则要求独立董事多数及定期独立执行会议。故独立主席仅换头衔并不必然新增治理能力；其必须获得相对现任 lead/委员会确实新增的董事会议程、召集或独立信息监督权限。实际在任、享表决/监督权的董事多数与 Series A 按授权董事席位计算的特别席位公式是两种不同分母。现有 Series A 一席及自身类别权利不代表公司普遍否决权，但对单个公司命名的多年核心项目或公司级资本配置拥有可执行阻断/转向权，即使未控董事会多数也可能改变决策路径。评估这类安排时须比较公开披露的权利范围与同一交易所带来的绑定资本或能力：限制于其实际出资项目/期限的保护权不等于一般公司控制，超出投入保护范围、可影响其他项目或普通融资的权利才是独立的治理风险。

- C1 / LONG / INNER: 董事会将 CEO 与董事长职务分开，并由符合 Nasdaq 独立性要求的非管理层董事担任独立董事长；正式治理指南、章程或董事会决议同时把至少一项目前未授予 lead independent director 的实质全董事会议程/监督权交给该主席，例如无需 CEO 同意即可决定或增加董事会会议议题、召集全体董事/独立董事会议，或独立取得重大项目与资本决策所需管理层信息。CEO 经营执行权由另一名具名负责人承担，且实际在任独立董事仍为多数、审计/薪酬/提名治理委员会仍保持独立。只有董事长称谓变化、原有独立会议主持/联络职责重命名、无新增议程或信息权限的非执行主席，或同时失去独立多数/委员会监督，不符合。
  - Reference: 2026-04-06 代理文件显示 Beck 同时为 CEO 与董事长；董事会可按需要决定合并/分开职务。七名在任董事中 Beck 是唯一非独立董事，另有独立 lead director Saintil 主持独立董事执行会议并联络董事长，独立董事亦定期开无管理层会议；审计、薪酬、提名/治理委员会均独立。现行治理已有实质制衡，lead 可由董事会另行委派职责，但公开文件没有披露他已取得独立决定全董事会议程的权利。
  - Boundary: 只有独立非执行董事获得新的、可在治理文件中核实的董事会议程或独立监督权限，并实际主持董事会，而不是单换 CEO/Chair 标签，才比现有 lead/委员会安排多出治理制衡。新的议程控制或独立召集权本身即可改变管理层与董事会的监督关系；不要求等预算表现或项目结果。若独立多数、独立委员会或原有独立会议权同时消失，则不能用这项单向 LONG 抵销。
- C2 / SHORT / INNER: 公司新代理文件、董事会/股东披露、章程修订或 Nasdaq 状态正式确认以下任一有效变化：实际在任且有表决权董事中的独立董事已不再占多数；审计、薪酬或提名/治理核心委员会不再达到适用独立性要求；或治理文件实质取消独立董事召开/主持独立执行会议、取得重要经营信息或对重大议题独立设定议程的现存权利，且没有同时交给其他独立董事或独立机构的等效实权。只增加授权席位但席位空缺、或正常换届后独立实际在任者仍为多数且委员会/监督权完整，不符合。
  - Reference: 2026-04-06 代理文件列出七名在任董事、其中六名独立；独立首席董事及无管理层参与的定期执行会议已经运作，审计、薪酬、提名/治理委员会成员均被认定独立。Nasdaq Rule 5605 要求董事会独立董事占多数并举行定期独立董事会议。比较董事多数时按有效任职且具投票/监督权的董事计算，而非只按经授权的总席位；Series A 特别席位的授权公式另算。
  - Boundary: 实际独立董事从多数变为非多数，核心委员会丧失适用独立性，或全体独立董事失去当前实质会议/议程/信息权且无替代，任何一项在生效时已削弱独立监督，不需等待董事会实际作出有害资本决定、Nasdaq 补救期限届满或财报确认损失。单一独立董事空缺只在它确实使实际在任董事不再独立多数/破坏关键委员会时才跨界；授权扩张、空缺名额或名义职位变化不够。
- C3 / SHORT / INNER: 公司提交生效章程、Series A 指定证书、股东批准文件或具约束力投资/融资协议，使单一持有人、其关联方或资方取得超出现有一席特别董事及优先股自身保护权的新增审批、同意、否决或指令权；该权利能阻止或转向一个公司公开列明的多年核心项目/重大资本预算，或普通公司层面的融资、股权发行与资本配置，而且适用范围超出该持有人在同一文件中新增承诺的特定出资/技术资源及相应项目期间。此等项目权利可在未取得董事会多数或普遍公司事项否决前成立；只有咨询权、普通董事提名、一席席位、对自身证券条款的类别保护，或被限定于同一已承诺出资用途与期限的投资者保护权不符合。
  - Reference: 2025 10-K、2026 代理文件和 2026Q2 10-Q 记载 Series A 可作为单独类别选出至少一名董事；代理文件时为七席董事会中的一席，授权董事超过十席时另按约 10% 的授权席位公式配置。Series A 按一比一转换普通股与普通股共同投票，对特别类别权利的同意权限于保护其自身条款，并无普通资本决策的普遍否决权。该授权席位公式使用授权席数，不是判断实际在任董事多数的分母。
  - Boundary: 最早有意义的 SHORT 边界不是取得全董事会多数或对所有事务的普遍否决，而是首次出现可执行的单方权力，能拦截或重定向一个 Rocket Lab 已公开列明的重大多年项目资本安排，或公司的普通融资/权益发行，并可作用于新出资/技术能力包以外的公司资源。该权利已限制董事会原有资本配置自由，不必等项目停摆。若权利仅约束资方明确提供的新增资本/能力在指定项目、金额或期限内怎样使用，且独立董事仍可控制其他公司项目及融资，资金与能力贡献可能抵销集中权风险；此种受限权利不自动支持 SHORT。普通减持、Series A 一比一转换、董事授权席位公式或持有人股数变化本身均不越界。
- C4 / LONG / INNER: 在公司已公开披露独立董事实际任职多数、核心委员会独立性或独立董事会议/议程/信息权限受损后，董事会、股东或公司治理文件正式任命/恢复独立成员或修订权限，使该项已披露的监督缺口重新由实际在任独立董事多数、符合独立性的相关委员会，或有同等独立召集及议程/信息权限的结构承担。新安排须已生效，且仅以普通授权空位、新任命意向或重新使用 lead/chair 职称但未恢复权力不符合。
  - Reference: 当前公开比较起点为 2026-04-06 代理文件所列七名在任董事中六名独立、独立首席董事主持独立会议、核心委员会独立，Nasdaq 要求独立董事多数及定期独立执行会议。未来只有先出现有文件支持的监督缺口，才按那一缺口的新现实判断恢复；当前不存在可据此虚构的失效状态。
  - Boundary: 一项正式且立即生效的任命或权力恢复，只要消除此前公开确认的独立监督缺口（例如独立董事重新占实际任职多数、失去独立资格的关键委员会恢复，或独立董事重新取得已撤销的召集/议程/信息权），就首次带来可核验的监督恢复；不要求董事会回到精确六席或等到资金分配表现证明监督有效。若只填补一个授权空位但未恢复实际独立多数/失去的权力，尚不足。

## Nasdaq-100 成分、目标权重与计入股数变化

NDX 对 Rocket Lab 的直接联系是基准跟踪产品的目标配置，不是订单、经营收入或主动持有人观点。最终篮子增配会提高复制该目标时对 RKLB 的预期配置；最终减配或删除会降低该目标配置。2026 年 5 月 1 日起的方法把 Full Market Capitalization 用于成员资格/排序，把 Modified Market Capitalization 用于权重；权重只计入符合条件的上市类别，低流通股证券用于加权的 TSO 受三倍自由流通股数限制，季度审议还会更新股份与低流通调整。故股票价格涨跌可改变屏幕上的权重、市值和美元敞口，却不单独证明 index shares 或目标篮子有净增减；普通增发、回购、拆股、float/TSO 更新也须先剔除公司行动与单位口径的机械变化。比较时优先用公开的最终 index-share 目标；如仅有完整前后权重表，则从每个篮子各自的权重/参考价格恢复相对股份向量，在同一参考价格向量重估旧、新篮子，再把两篮子归一到同一总规模，得到 RKLB 的净目标权重变化 Δw*。同一规模 A 下的目标资金差为 A×Δw*，等价目标股数为 A×Δw*/共同参考价格；这剔除股价与指数分母漂移，但只估算目标敞口，不是实际买卖、净流入或价格冲击。Nasdaq 所称 200 多种跟踪产品、全球 AUM 超过 8000 亿美元只给 gross scale；基金/衍生品复制、抽样、AUM 变化、预先交易和分批执行使实际成交可显著不同。若 Nasdaq 已正式宣布具有确定生效日的 RKLB 目标变化，可在公告时判断预期配置变化，不必等生效开盘或基金实际成交；生效和执行是后续实现，不自动构成第二次催化。更广方法变更只有在终局规则与公开输入已能机械算出达到本 Policy 边界的 RKLB 目标变化时，才有同一早期路径；泛泛咨询或方法讨论本身没有独立目标效应。

- C1 / LONG / MIDDLE: Nasdaq 对 RKLB 公布已最终确定且有确定生效日的 NDX 目标 index shares、权重或成员结果上修；也包括已终局的 NDX 方法改约在具体篮子实施前，已能由正式规则与可公开输入机械确定该上修。该事实必须表示正式目标篮子变化，而不是 RKLB 股票价格上涨、rank 推测、公司发行股数或未最终通过的方案。
  - Reference: RKLB 自 2026-06-22 起为 NDX 成分。已接纳的 0055 基线记录 10-09 前后 NDX 可见权重约 0.18%、QQQ 单一基金约 0.17%/约 1,248 万股；单一 QQQ 不代表所有指数目标股数。Nasdaq 10-01 表示全球 200 多种跟踪产品、AUM 超过 8000 亿美元。Nasdaq 公共 Global Index Policies 页可取得一份 NDX 完整成分/权重快照，日期为 2026-08-03，其中 RKLB 为 0.18%、WBD 为 0.29%，权重只四舍五入至 0.01 个百分点；它是 8 月快照而非 10-09 的后事件篮子。Nasdaq NDX Weighting 页面提示完整数据需要登录，页面所述日度 pro forma 是给指数客户的 T+5 投影。截止时免费来源没有提供可核验的完整 NDX index-share 表；5 月方法已生效且 6-22 首次相关审议已属基线。
  - Boundary: 把最终新目标与此前最后一个可公开重建的有效篮子按同一参考价格、同一总组合规模比较；优先使用正式公开 index shares，或对完整旧/新权重向量分别按各自参考价还原相对股数、再以共同价格向量重估并归一到同一规模。若可公开的精确目标数据显示 RKLB 净权重上升至少 0.01 个百分点（1bp），即为最低有意义增加；若只得到 Nasdaq 免费公布的 0.01pp 四舍五入权重，须在上述同价计算后至少净升 0.02pp，避免把两端舍入误差当方向。以 Nasdaq 所称 8000 亿美元作粗略 gross reference，精确 0.01pp 约为 8000 万美元，按 2026-10-09 的 68.21 美元约 117 万股/20 日 ADV 的 5.5%；公开 rounded-data 的 0.02pp 约为 1.6 亿美元、235 万股/约 11% ADV。旧政策的 0.05pp/约 586 万股是更强量级而非最低界线。8000 亿美元不等于可买入的实物跟踪资产，所有折股量仅为目标尺度，不保证实际买入或价格上涨。若找不到前一可比公开篮子，则不能要求新新闻同时重复整套旧数据，也不能以陈旧 0.18% 或原始权重差补算；除非正式最终名单本身明确使 RKLB 从零进入并有公开目标份额，否则将精确净变化记为不可判，而非零。
- C2 / SHORT / MIDDLE: Nasdaq 对 RKLB 公布已最终确定且有确定生效日的 NDX 目标 index shares、权重或成员结果下修/删除；也包括已终局的 NDX 方法改约在具体篮子实施前，已能由正式规则与可公开输入机械确定该下修。须是 Nasdaq 的目标篮子变化，不是单靠价格下跌、rank 推测、公司增发或未通过提案。
  - Reference: 沿用 C1 的同一现实：RKLB 自 2026-06-22 起属于 NDX；截至截止时可见权重约 0.18%，当前 exact full index shares 未由免费资料完整披露；单只 QQQ 持仓不是全体目标。2026 方法的 Full/Modified 市值、低流通股数更新及季度规则已生效，普通公司行动调整不等于主动/独立观点。Nasdaq 公开 2026-08-03 完整权重快照为两位小数，并早于 10-01 Moderna/WBD 置换；10-01 官方新闻只公布替换对象与 10-09 生效日，没有给出 RKLB 权重/index shares。
  - Boundary: 按 C1 同一价格向量、同一总规模和同一公司行动调整口径比较新旧目标篮子。可公开精确目标数据下，RKLB 净权重降低至少 0.01pp 即为最低有意义减配；仅有免费 0.01pp 四舍五入权重时，需同价重估后净降至少 0.02pp，并使舍入/归一误差不能改变符号。由 10-09 前约 0.18% 的已知成分被 Nasdaq 正式宣布完整删除，直接归零本身已远过边界，无需等待基金实际抛售；在 8000 亿美元 gross reference 下约是 14.4 亿美元或按 68.21 美元折算约 2,111 万股（约 0.98 个 20 日 ADV）的目标敞口减少，而非保证的卖单。一般季度 TSO/float 调整、ATM、拆股、类别转换或数据页权重变化，只有在拆股/公司行动口径校正后仍使同价同规模的净目标权重减少达到上述界线才成立；如仅使股数单位变化而经济目标权重不变，不命中。公告的最终目标可先于实施判断；后续实际持仓/成交只有在相对已公告目标出现新的实质偏离时才是新信息。正式方法改约亦须按 C1 的公开、直接、达到规模的适用性门槛；宽泛制度讨论、现行五月方法、普通 rank 及价格变化没有独立下修触发。

## 卖方对Rocket Lab经营前景与风险的独立新判断

Rocket Lab截至2026Q2的收入增长尚未解决盈利与现金兑现：Q2收入2.34066亿美元，但上半年CFO减capex的简单FCF为-1.87519亿美元；管理层Q3收入指引为2.50亿—2.65亿美元，同时指引调整后EBITDA亏损1,700万—2,300万美元。Neutron仍在资格测试与发射台准备阶段，Iridium交易仍以2027年年中为有条件交割目标，故未来商业化时点、服务现金并表、整合与融资风险会改变远期价值分布，而非当前已实现经营结果。

卖方研究把对这些公开业务路径的概率、时点或经济性判断转化为投资意见；新研究即使不伴随Rocket Lab订单或指引变化，也能提供新的独立市场观点。2026-09-11 Raymond James首度覆盖并给出Outperform与80美元目标价；The Fly可检索摘要将其投资理由联系到Neutron、Iridium/Mynaric、执行及整合风险，并称其判断2027/28年有正EBITDA/FCF路径。原研报与完整模型未取得，这只证明有一项具名独立观点，不证明公司预测、当前共识或其模型已经兑现。公司分析师名单页面也明确分析师意见、估计与预测仅属分析师自身，并非公司预测或背书。

截至cutoff，C5只有10月9日收盘价68.21美元，缺少可核验的同日完整EV、净债务、稀释股数、卖方预测序列与一致预期；C1记载的盈利及管理层基线不能代填卖方预测。因而一名具名分析师的明确首次推荐、升级/降级或有方向的新概率/时点判断，可以是独立观点信息，但不等于市场共识或经营事实；没有资料证明实际投资者如何吸收此判断，也不据此计算股价影响。单纯目标价跟随现价、重复已知报告或已披露公司事实，不构成新观点。纯同业比较方法变化由另一条Peer Policy承接；同一报告同时改变经营假设与倍数时，应以报告明确表达的整体结论或主导变化定方向，不能将互相抵销的子项机械拆成相反催化。

- C1 / LONG / OUTER: 具名卖方机构首次公开给出明确偏正面的Rocket Lab推荐/独立基准，或明确上调其自身既有推荐，或在研报/有出处摘要中提出一项新的有利公司特定概率、时点或价值判断；首次推荐或明确评级上调本身可承载新的独立观点，单纯目标价变化则须能识别新的业务/风险依据，而非只随现价机械调整。
  - Reference: 截至2026-10-12，最近可核验的示例是Raymond James于2026-09-11首次覆盖并给出Outperform、80美元目标价。The Fly摘要将其正面观点联系到Neutron及Iridium/Mynaric机会、执行/整合/利润率风险，并称2027/28年存在正EBITDA/FCF路径；未取得原研报的完整模型或同分析师更早预测。Rocket Lab Q2实际、Q3指引与Neutron/Iridium状态见C1及Future Nodes；卖方共识与同时点估值分母在C5仍未建立。
  - Boundary: 一次公开、可归属到具名分析师/机构、方向明确的新独立观点即可跨界：新覆盖不需要该机构不存在的旧模型作比较；首次明确的Buy/Outperform等积极推荐或既有明确升级本身足以记录一个新卖方意见，即使摘要没有可量化的年度现金模型。非评级式的概率/时点/风险判断，或只有目标价变化的报告，则须提供足够公开理由把新结论连到RKLB业务/风险，而非只随现价机械调整。无需完整盈利桥、第二家跟随或公司经营兑现。重复引用2026-09-11的RJ判断也只是已知基线。若同篇对经营路径与peer估值方法给出相反变化，只在其总体推荐/估值结论或明确主导的新判断仍偏正面时命中；净方向不清时不由下游拼模型，C1不成立。
- C2 / SHORT / OUTER: 具名卖方机构首次公开给出明确偏负面的Rocket Lab推荐/独立基准，或明确下调其自身既有推荐，或在研报/有出处摘要中提出一项新的不利公司特定概率、时点或价值判断；首次推荐或明确评级下调本身可承载新的独立观点，单纯目标价变化则须能识别新的业务/风险依据，而非只随现价机械调整。
  - Reference: 截至2026-10-12，最近可核验的卖方示例仍是Raymond James于2026-09-11给出的首次Outperform推荐；该摘要同时承认Neutron执行、Iridium整合和利润率风险。C1披露收入与调整后EBITDA路径并非同向，Neutron未进入常态商业运营、Iridium尚未并表；没有可核验卖方一致预期或该机构完整前后预测序列，不能把管理层指引冒充市场基准。
  - Boundary: 一次公开、可归属到具名分析师/机构、方向明确的新不利观点即可跨界：新覆盖首次给出明确偏负的建议，或既有机构明确降级，本身是新的卖方意见，不要求完整年度现金模型；也可由公开的新判断显示推迟重要现金/商业化时点或降低关键路径实现概率。无需出现公司丢单、实际财务下修或其他分析师跟随。单纯无新依据的PT变化、重复报道、评级保持或仅因股价移动而改目标价不足；非评级式的风险/价值判断必须有可识别的业务理由。若报告中的一项假设变差但其整体结论因其他变化转为更有利，不机械认定SHORT；如经营和peer估值子项方向冲突且报告未表达主导/净结论，则本Condition也不命中。

## 同业比较框架与Rocket Lab相对估值的独立变化

投资者会参照公开上市航天同业的经营组合、盈利质量与估值方法，判断Rocket Lab应获得何种相对倍数；卖方改变peer集合、权重或适用指标时，即使Rocket Lab当期经营没有新变化，也可能改写其估值观点。该比较必须反映业务与资本口径差异，而不是把同业市值、增长率或backlog直接移植到Rocket Lab。

截止日Firefly与Voyager都已上市并有2026Q2公开财务数据，故未来不必等待新的IPO或首次完整年报才能发生有意义的比较方法变化。Firefly Q2收入1.17683亿美元，Launch为940万美元、Spacecraft Solutions为1.08283亿美元（包含并购业务及任务进度）；Voyager Q2收入5,274.6万美元，报告口径为Defense and Space Technologies且Starlab仍处发展阶段；Rocket Lab同期收入2.34066亿美元，其中Space Systems约1.895亿美元、Launch约4,460万美元。业务组合、并表时点、分部报告及合同/backlog口径不一致，使单季增速或单项倍数不是可直接比较的结论；另一方面，这些公开同行已足以为分析师重新判断比较集合与估值方法提供新锚点。

C5没有可复核的同日Rocket Lab完整市值/净债务/摊薄股数/前瞻分母，也没有同口径卖方估值序列。这一限制不表示卖方无人研究，也不妨碍识别某份公开报告将哪类上市同行或估值指标用于Rocket Lab、以及其自身结论朝何方向变化。本Policy监测分析师对Rocket Lab估值参照的选择/方法及其方向，不交易Firefly、Voyager等同业的财报或IPO本身；不要求正常摘要泄露分析师全部私人模型、每个分部拆分或完整EV—权益价值桥，但至少需公开可识别的方法依据和该方法对Rocket Lab总体价值判断的方向。

- C1 / LONG / OUTER: 一份具名卖方研究首次建立Rocket Lab的上市同业估值基准，或明确改变其对Rocket Lab所用同业、估值倍数/指标、权重或对照期间；报告说明可识别的比较依据，并呈现因该peer方法而来的有利Rocket Lab整体估值判断。首次独立研究以其明确的正面估值/投资结论为方向；既有覆盖则须显示相对其原框架的有利变化。
  - Reference: 截至2026-10-12，Firefly和Voyager分别已于2025年上市，且均公开2026Q2财务；其上市或该季业绩已是可用背景，而非新的Rocket Lab事件。Firefly的航天器解决方案含收购贡献且公司分部披露有限；Voyager将业务报为Defense and Space Technologies，并合并Starlab等发展中项目；Rocket Lab的Launch/Space Systems结构和backlog定义不同。C5未闭合同日RKLB EV、净债务、完全摊薄股数、远期分母或卖方共识，旧政策也未找到可比的卖方估值序列。
  - Boundary: 首次估值可以没有同一分析师的旧模型：只要一份可归属报告/摘要明确建立一个用于Rocket Lab的公开peer/估值方法（至少可识别选取的同行或同行类别，以及使用的倍数/财务指标、对应期间或资本口径），并以明确的正面估值/投资结论表明该peer方法支持有利的RKLB观点，就有了新独立估值意见；无需凭目标价与现价的简单差值推断方向。既有覆盖则须显示相对其原peer框架或估值结论的有利变化。已上市同行重新分组/加权或改用新的公开经营质量比较同样可以；无需等待新IPO/下一份同业年报，也不要求每份正常摘要同时披露完整EBITDA/FCF模型、EV至权益桥、净债务、摊薄股数或全部有机/并购分部调节。只有同业高倍数/好业绩、未经说明把同业市值套给RKLB，或单独目标价上调而未表明peer方法有变化，均不足。方法变化与RKLB价值结果若相反，按报告明确的整体结论/主导peer影响定向；没有可识别净方向就不触发LONG。
- C2 / SHORT / OUTER: 一份具名卖方研究首次建立Rocket Lab的上市同业估值基准，或明确改变其对Rocket Lab所用同业、估值倍数/指标、权重或对照期间；报告说明可识别的比较依据，并呈现因该peer方法而来的不利Rocket Lab整体估值判断。首次独立研究以其明确的谨慎/负面估值或投资结论为方向；既有覆盖则须显示相对其原框架的不利变化。
  - Reference: 同C1：截至2026-10-12，已上市同业与其2026Q2经营数据属于背景；Firefly、Voyager与Rocket Lab的业务分部、并购构成、项目/服务组合和订单口径并不一致。缺少同日完整市值—资本结构—摊薄股数桥及可比卖方估值时间序列，只能将分析师公开的方法与RKLB结论作为观点变化，不自行反推出当前合理倍数。
  - Boundary: 首次估值可以没有同一分析师的旧模型：一份可归属报告/摘要若明确建立用于RKLB的上市peer方法（可识别同行/类别、估值指标或倍数、对应期间或资本口径），并以明确的谨慎/负面估值或投资结论表示该方法支持不利的RKLB观点，即足以形成新独立peer判断；不凭目标价与现价的简单差值判负。既有覆盖则须显示相对其原peer框架或估值结论的不利变化。peer不必是新上市公司，数据也不必是该peer首次披露；不要求未来新闻提供完整新旧模型、全资本结构或收购/有机分部桥。单独同业财报、市场市值或交易倍数下滑不是RKLB的Short；不变的peer方法下目标价跟随RKLB股价调整也不是新方法。若经营预测改善而倍数收缩，应按分析师对整体RKLB价值/推荐的明确主导结论处理，不把两项拆成相反方向；结论未显示净方向时不命中本Condition。

