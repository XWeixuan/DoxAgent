"""Packaged CDECR prompts."""
