"""Application ports used by CDECR business code."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal, Protocol

from pydantic import Field, field_validator

from cdecr.contracts import (
    AtomicEvent,
    EventMention,
    EventPackage,
    ExternalEventRelation,
    PackageExternalRelation,
    PackageMembership,
    PackageMembershipDecision,
    SourceMessage,
    StrictModel,
)
from cdecr.field_coreference_contracts import (
    CanonicalFieldLink,
    CanonicalFieldRegistryEntry,
    FieldNamespace,
)
from cdecr.model_boundary import (
    normalize_json_prompt,
    normalize_temporal_values,
    relax_temporal_schema,
)
from cdecr.single_document_contracts import (
    DreamCandidate,
    GrounderOutput,
    JudgeDecisionRecord,
    NormalizationDecision,
    PreprocessedDocument,
    PreprocessingResult,
    SingleDocumentResult,
)

if TYPE_CHECKING:
    from cdecr.cross_document_contracts import (
        AtomicAssignmentRecord,
        CrossDocumentResult,
        PackageAssignmentRecord,
    )


class SourceQuery(StrictModel):
    market: str = Field(min_length=1)
    ticker: str = Field(min_length=1)
    start_at: datetime
    end_at: datetime
    limit: int = Field(ge=1, le=1000)
    min_text_chars: int = Field(default=1, ge=1)


class RejectedSource(StrictModel):
    source_row_id: str
    reason_codes: list[str]


class SourceRecord(StrictModel):
    source_row_id: str
    market: str
    ticker: str
    document_fingerprint: str
    message: SourceMessage


class SourceReadBatch(StrictModel):
    query: SourceQuery
    accepted: list[SourceRecord]
    rejected: list[RejectedSource]
    raw_count: int


class EmbeddingResult(StrictModel):
    model: str
    dimensions: int
    vectors: list[list[float]]
    input_tokens: int | None = None
    latency_ms: int = Field(ge=0)
    request_id: str | None = None


class StructuredModelRequest(StrictModel):
    system_prompt: str
    user_prompt: str
    json_schema: dict[str, object]
    output_mode: Literal["json_object", "json_schema"] = "json_object"
    schema_name: str = "cdecr_response"
    strict: bool = False
    reasoning_effort: Literal["none", "low", "high", "max"] = "none"
    previous_response_id: str | None = None
    session_cache: bool = True
    metadata: dict[str, object] = Field(default_factory=dict)

    @field_validator("user_prompt")
    @classmethod
    def normalize_model_time_input(cls, value: str) -> str:
        return normalize_json_prompt(value)

    @field_validator("json_schema", mode="before")
    @classmethod
    def relax_model_time_schema(cls, value: object) -> object:
        return relax_temporal_schema(value)


class ResponsesModelRequest(StrictModel):
    """A typed Responses request that can continue one provider response."""

    input: list[dict[str, Any]] = Field(min_length=1)
    json_schema: dict[str, object]
    output_mode: Literal["json_object", "json_schema"] = "json_object"
    schema_name: str = "cdecr_response"
    strict: bool = False
    previous_response_id: str | None = None
    reasoning_effort: Literal["none", "low", "high", "max"] = "none"
    session_cache: bool = True
    metadata: dict[str, object] = Field(default_factory=dict)

    @field_validator("json_schema", mode="before")
    @classmethod
    def relax_model_time_schema(cls, value: object) -> object:
        return relax_temporal_schema(value)


class StructuredModelResult(StrictModel):
    model: str
    payload: dict[str, object]
    input_tokens: int | None = None
    output_tokens: int | None = None
    reasoning_tokens: int | None = None
    text_tokens: int | None = None
    cached_input_tokens: int | None = None
    latency_ms: int = Field(ge=0)
    request_id: str | None = None
    response_id: str | None = None
    transport: Literal[
        "chat_json_object",
        "chat_json_schema",
        "responses_json_object",
        "responses_json_schema",
    ] | None = None
    output_mode: Literal["json_object", "json_schema"] | None = None
    effective_reasoning_effort: Literal["none", "low", "high", "max"] | None = None
    provider_key_fingerprint: str | None = None
    provider_status: str | None = None
    incomplete_details: dict[str, object] = Field(default_factory=dict)
    finish_reason: str | None = None
    parse_diagnostics: dict[str, object] = Field(default_factory=dict)

    @field_validator("payload", mode="before")
    @classmethod
    def normalize_model_time_output(cls, value: object) -> object:
        return normalize_temporal_values(value)


class DecisionAuditRecord(StrictModel):
    audit_id: str
    run_id: str | None = None
    decision_type: str
    subject_id: str
    payload: dict[str, Any]


class SourceMessageReader(Protocol):
    def read(self, query: SourceQuery) -> SourceReadBatch: ...


class EmbeddingClient(Protocol):
    def embed(self, texts: Sequence[str]) -> EmbeddingResult: ...


class StructuredModelClient(Protocol):
    def complete(self, request: StructuredModelRequest) -> StructuredModelResult: ...


class ResponsesModelClient(Protocol):
    def complete_response(self, request: ResponsesModelRequest) -> StructuredModelResult: ...


class EntityNormalizer(Protocol):
    def normalize_entity(
        self, surface: str, *, ticker_hints: Sequence[str], mention_id: str, field_path: str
    ) -> tuple[str | None, NormalizationDecision]: ...


class TimePeriodNormalizer(Protocol):
    def normalize_period(
        self, raw_period: str | None, *, company_id: str | None, mention_id: str, field_path: str
    ) -> tuple[str | None, NormalizationDecision | None]: ...


class MetricNormalizer(Protocol):
    def normalize_metric(
        self, raw_metric: str | None, *, mention_id: str, field_path: str
    ) -> tuple[str, NormalizationDecision]: ...


class QuantityNormalizer(Protocol):
    def normalize_quantity(
        self, raw_text: str, value: int | float, unit: str, *, mention_id: str, field_path: str
    ) -> tuple[int | float, str, NormalizationDecision]: ...


class CDECRRegistry(Protocol):
    def initialize(self) -> None: ...

    def start_bulk_epoch(
        self,
        *,
        epoch_id: str,
        manifest_hash: str,
        orchestrator_version: str,
        message_ids: Sequence[str],
    ) -> dict[str, Any]: ...

    def get_bulk_epoch(self, epoch_id: str) -> dict[str, Any] | None: ...

    def update_bulk_epoch(
        self,
        epoch_id: str,
        *,
        status: str,
        current_stage: str,
        result: dict[str, Any] | None = None,
    ) -> None: ...

    def upsert_bulk_epoch_item(
        self,
        *,
        epoch_id: str,
        stage: str,
        item_id: str,
        status: str,
        input_hash: str,
        snapshot_hash: str | None = None,
        expected_versions_hash: str | None = None,
        result_ref: dict[str, Any] | None = None,
        error_code: str | None = None,
    ) -> None: ...

    def list_bulk_epoch_items(
        self, epoch_id: str, *, stage: str | None = None
    ) -> list[dict[str, Any]]: ...

    def upsert_bulk_epoch_task(
        self,
        *,
        epoch_id: str,
        stage: str,
        task_id: str,
        input_hash: str,
        snapshot_hash: str,
        status: str,
        component_id: str | None = None,
        decision_ref: dict[str, Any] | None = None,
        error_code: str | None = None,
    ) -> None: ...

    def upsert_bulk_epoch_tasks(
        self, records: Sequence[dict[str, Any]], *, chunk_size: int = 512
    ) -> dict[str, int]: ...

    def list_bulk_epoch_tasks(
        self, epoch_id: str, *, stage: str | None = None
    ) -> list[dict[str, Any]]: ...

    def save_parent_occurrence_proposals(
        self, *, run_id: str, records: Sequence[dict[str, Any]]
    ) -> dict[str, int]: ...

    def list_parent_occurrence_proposals(
        self, *, run_id: str | None = None
    ) -> list[dict[str, Any]]: ...

    def upsert_package_parent_occurrences_v3(
        self, *, registry_scope_id: str, records: Sequence[dict[str, Any]]
    ) -> list[dict[str, Any]]: ...

    def list_package_parent_occurrences_v3(
        self, *, registry_scope_id: str
    ) -> list[dict[str, Any]]: ...

    def get_package_registry_v3(
        self, *, registry_scope_id: str
    ) -> dict[str, Any] | None: ...

    def allocate_package_mcp_ids_v3(
        self, *, registry_scope_id: str, count: int
    ) -> list[str]: ...

    def get_package_registry_batch_v3(
        self, *, registry_scope_id: str, batch_id: str
    ) -> dict[str, Any] | None: ...

    def save_package_registry_batch_v3(
        self,
        *,
        registry_scope_id: str,
        batch_id: str,
        base_registry_version: int,
        input_hash: str,
        status: str,
        response_a_payload: dict[str, Any] | None = None,
        staged_changes: dict[str, Any] | None = None,
        affected_mcp_ids: Sequence[str] = (),
        error_code: str | None = None,
    ) -> None: ...

    def save_package_registry_description_task_v3(
        self,
        *,
        registry_scope_id: str,
        batch_id: str,
        mcp_id: str,
        input_hash: str,
        status: str,
        payload: dict[str, Any] | None = None,
        error_code: str | None = None,
    ) -> None: ...

    def save_package_registry_description_tasks_v3(
        self, records: Sequence[dict[str, Any]], *, chunk_size: int = 256
    ) -> dict[str, int]: ...

    def list_package_registry_description_tasks_v3(
        self, *, registry_scope_id: str, batch_id: str
    ) -> list[dict[str, Any]]: ...

    def finalize_package_registry_batch_v3(
        self,
        *,
        registry_scope_id: str,
        batch_id: str,
        expected_base_version: int,
        expected_base_hash: str,
        registry_version: int,
        registry_hash: str,
        snapshot: dict[str, Any],
    ) -> bool: ...

    def save_parent_occurrence_partition(
        self,
        *,
        run_id: str,
        partition_hash: str,
        snapshot_hash: str,
        status: str,
        payload: dict[str, Any],
    ) -> bool: ...

    def get_parent_occurrence_partition_for_snapshot(
        self, *, run_id: str, snapshot_hash: str
    ) -> dict[str, Any] | None: ...

    def save_parent_occurrence_checkpoints(
        self, *, run_id: str, records: Sequence[dict[str, Any]]
    ) -> dict[str, int]: ...

    def list_parent_occurrence_checkpoints(
        self, *, run_id: str, stage: str
    ) -> list[dict[str, Any]]: ...

    def save_bulk_epoch_artifact(
        self,
        *,
        epoch_id: str,
        artifact_kind: str,
        artifact_hash: str,
        upstream_hash: str,
        payload: dict[str, Any],
    ) -> None: ...

    def get_bulk_epoch_artifact(
        self, epoch_id: str, artifact_kind: str
    ) -> dict[str, Any] | None: ...

    def save_source(self, source: SourceMessage, *, fingerprint: str) -> bool: ...

    def get_source(self, message_id: str) -> SourceMessage | None: ...

    def list_all_sources(self, *, limit: int = 10000) -> list[SourceMessage]: ...

    def get_source_fingerprint(self, message_id: str) -> str | None: ...

    def has_source_fingerprint(self, fingerprint: str) -> bool: ...

    def save_mention(self, mention: EventMention) -> bool: ...

    def get_mention(self, mention_id: str) -> EventMention | None: ...

    def list_all_mentions(self, *, limit: int = 100000) -> list[EventMention]: ...

    def list_mentions_for_message(self, message_id: str) -> list[EventMention]: ...

    def save_atomic_event(self, event: AtomicEvent) -> bool: ...

    def save_package(self, package: EventPackage) -> bool: ...

    def save_membership(self, membership: PackageMembership) -> bool: ...

    def save_membership_decision(self, decision: PackageMembershipDecision) -> bool: ...

    def save_external_relation(self, relation: ExternalEventRelation) -> bool: ...

    def list_external_relations(self) -> list[ExternalEventRelation]: ...

    def save_package_external_relation(self, relation: PackageExternalRelation) -> bool: ...

    def list_package_external_relations(
        self, *, source_event_id: str | None = None
    ) -> list[PackageExternalRelation]: ...

    def list_current_atomic_events(self, *, limit: int = 1000) -> list[AtomicEvent]: ...

    def get_current_atomic_event(self, event_id: str) -> AtomicEvent | None: ...

    def get_atomic_event_for_mention(self, mention_id: str) -> AtomicEvent | None: ...

    def get_current_package(self, package_id: str) -> EventPackage | None: ...

    def resolve_package_root(self, package_id: str, *, max_depth: int = 32) -> str | None: ...

    def list_current_packages(self, *, limit: int = 1000) -> list[EventPackage]: ...

    def list_packages_for_event(self, event_id: str) -> list[EventPackage]: ...

    def list_memberships_for_package(self, package_id: str) -> list[PackageMembership]: ...

    def list_membership_decisions(
        self, *, event_id: str | None = None
    ) -> list[PackageMembershipDecision]: ...

    def recall_atomic_event_ids(
        self,
        *,
        entity_ids: Sequence[str],
        event_family: str,
        normalized_predicate: str,
        schema_type: str,
        reference_period_id: str | None,
        event_start: str | None,
        event_end: str | None,
        source_fingerprint: str | None,
        field_ids: Sequence[tuple[FieldNamespace, str]] = (),
        per_route_limit: int = 20,
    ) -> dict[str, set[str]]: ...

    def list_sources(
        self,
        *,
        market: str | None = None,
        ticker: str | None = None,
        start_at: datetime | None = None,
        end_at: datetime | None = None,
        limit: int = 100,
    ) -> list[SourceMessage]: ...

    def list_preprocessed_documents(
        self, *, exclude_message_id: str | None = None
    ) -> list[PreprocessedDocument]: ...

    def get_completed_document_result(self, processing_key: str) -> SingleDocumentResult | None: ...

    def get_latest_completed_document_result_for_message(
        self, message_id: str
    ) -> SingleDocumentResult | None: ...

    def start_document_run(
        self,
        *,
        run_id: str,
        processing_key: str,
        message_id: str,
        pipeline_version: str,
        prompt_version: str,
        catalog_version: str,
        model_config: dict[str, Any],
    ) -> bool: ...

    def save_preprocessing_result(self, run_id: str, result: PreprocessingResult) -> bool: ...

    def save_dream_candidates(self, run_id: str, candidates: Sequence[DreamCandidate]) -> int: ...

    def get_latest_dream_candidates_for_processing_key(
        self, processing_key: str
    ) -> list[DreamCandidate]: ...

    def save_grounder_batch(
        self,
        *,
        run_id: str,
        processing_key: str,
        batch_key: str,
        output: GrounderOutput,
    ) -> bool: ...

    def get_grounder_batch(
        self, *, processing_key: str, batch_key: str
    ) -> GrounderOutput | None: ...

    def save_judge_decisions(
        self, run_id: str, decisions: Sequence[JudgeDecisionRecord]
    ) -> int: ...

    def save_normalization_decisions(
        self, run_id: str, decisions: Sequence[NormalizationDecision]
    ) -> int: ...

    def save_embedding(
        self,
        *,
        owner_kind: str,
        owner_id: str,
        model: str,
        input_hash: str,
        vector: Sequence[float],
        embedding_id: str | None = None,
    ) -> bool: ...

    def save_embeddings(
        self, records: Sequence[dict[str, Any]], *, chunk_size: int = 256
    ) -> int: ...

    def list_latest_embeddings(
        self, *, owner_kind: str, model: str, limit: int = 10000
    ) -> list[Any]: ...

    def get_embedding(
        self, *, owner_kind: str, owner_id: str, model: str, input_hash: str
    ) -> Any | None: ...

    def create_field_registry_entry(self, entry: CanonicalFieldRegistryEntry) -> bool: ...

    def get_field_registry_entry(self, registry_id: str) -> CanonicalFieldRegistryEntry | None: ...

    def list_field_registry_entries(
        self, *, namespace: FieldNamespace | None = None, limit: int = 10000
    ) -> list[CanonicalFieldRegistryEntry]: ...

    def find_field_registry_by_external_id(
        self, *, namespace: FieldNamespace, external_id: str
    ) -> CanonicalFieldRegistryEntry | None: ...

    def update_field_registry_aliases(self, registry_id: str, aliases: Sequence[str]) -> bool: ...

    def set_field_registry_external_id(self, registry_id: str, external_id: str) -> bool: ...

    def save_field_redirect(self, source_id: str, target_id: str) -> bool: ...

    def resolve_field_registry_entry(
        self, registry_id: str, *, max_depth: int = 16
    ) -> CanonicalFieldRegistryEntry | None: ...

    def save_field_link(self, link: CanonicalFieldLink) -> bool: ...

    def get_field_link(self, mention_id: str, field_path: str) -> CanonicalFieldLink | None: ...

    def list_field_links_for_mention(self, mention_id: str) -> list[CanonicalFieldLink]: ...

    def list_all_field_links(self, *, limit: int = 1000000) -> list[CanonicalFieldLink]: ...

    def get_field_links_for_mentions(
        self, mention_ids: Sequence[str]
    ) -> dict[str, list[CanonicalFieldLink]]: ...

    def list_packages_for_events(self, event_ids: Sequence[str]) -> dict[str, list[str]]: ...

    def start_cross_document_run(
        self,
        *,
        run_id: str,
        processing_key: str,
        message_id: str,
        engine_version: str,
        prompt_version: str,
        model_config: dict[str, Any],
    ) -> bool: ...

    def start_cross_document_trace(
        self,
        *,
        trace_id: str,
        message_id: str,
        engine_version: str,
        prompt_version: str,
        model_config: dict[str, Any],
    ) -> bool: ...

    def finish_cross_document_trace(
        self, trace_id: str, *, status: Literal["REUSED", "FAILED", "PARTIAL"]
    ) -> None: ...

    def get_completed_cross_document_result(
        self, processing_key: str
    ) -> CrossDocumentResult | None: ...

    def complete_cross_document_run(self, result: CrossDocumentResult) -> bool: ...

    def fail_cross_document_run(self, run_id: str, *, error_code: str) -> None: ...

    def save_atomic_assignment(self, record: AtomicAssignmentRecord) -> bool: ...

    def get_latest_atomic_assignment_for_mention(
        self, mention_id: str
    ) -> AtomicAssignmentRecord | None: ...

    def save_package_assignment(self, record: PackageAssignmentRecord) -> bool: ...

    def get_latest_package_assignment_for_event(
        self, event_id: str
    ) -> PackageAssignmentRecord | None: ...

    def save_atomic_redirect(
        self, *, source_event_id: str, target_event_id: str, run_id: str, reason: str
    ) -> bool: ...

    def resolve_atomic_event_root(self, event_id: str, *, max_depth: int = 32) -> str: ...

    def save_package_redirect(
        self, *, source_package_id: str, target_package_id: str, run_id: str, reason: str
    ) -> bool: ...

    def record_model_call(
        self,
        *,
        model_call_id: str,
        run_id: str | None,
        tier: str,
        model: str,
        status: Literal["SUCCEEDED", "FAILED"],
        input_tokens: int | None,
        output_tokens: int | None,
        latency_ms: int,
        error_code: str | None,
        metadata: dict[str, Any],
        stage: str | None = None,
        prompt_version: str | None = None,
        schema_hash: str | None = None,
        input_hash: str | None = None,
    ) -> bool: ...

    def append_decision_audit(self, record: DecisionAuditRecord) -> bool: ...

    def append_decision_audits(
        self, records: Sequence[DecisionAuditRecord], *, chunk_size: int = 512
    ) -> dict[str, int]: ...

    def save_atomic_stage_batch(
        self, records: Sequence[dict[str, Any]], *, chunk_size: int = 64
    ) -> dict[str, int]: ...

    def save_package_stage_batch(
        self, records: Sequence[dict[str, Any]], *, chunk_size: int = 64
    ) -> dict[str, int]: ...

    def activate_package_partition_v3(
        self,
        *,
        packages: Sequence[EventPackage],
        memberships: Sequence[PackageMembership],
        assignments: Sequence[Any],
        external_relations: Sequence[PackageExternalRelation],
        redirects: Sequence[tuple[str, str]],
        run_id: str,
    ) -> dict[str, int]: ...

    def rebuild_derived_state(self) -> dict[str, int]: ...

    def complete_document_run(self, result: SingleDocumentResult) -> int: ...

    def fail_document_run(self, run_id: str, *, error_code: str) -> None: ...
