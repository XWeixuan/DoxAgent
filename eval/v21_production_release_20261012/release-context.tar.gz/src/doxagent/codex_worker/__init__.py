"""Independent Codex worker service."""
