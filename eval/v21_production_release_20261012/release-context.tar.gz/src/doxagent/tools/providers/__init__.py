"""Real tool provider implementations."""
