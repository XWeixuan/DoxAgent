"""Bus-side daily source sweep ownership, sharing the Runtime durable journal."""

from __future__ import annotations

import asyncio
import logging
from datetime import timedelta
from typing import Any

from doxagent.message_bus_v2.schema import AcquisitionMode, SourceDefinition, TickerSourceBinding
from doxagent.semantic_clock import boundary, semantic_day

from .calendar import MarketCalendar
from .journal import RuntimeJournal, is_sqlite_contention


class BusOrchestration:
    def __init__(self, journal: RuntimeJournal) -> None:
        self.journal = journal
        self.calendar = MarketCalendar(journal)
        self._inflight: dict[str, asyncio.Task[Any]] = {}

    async def run_once(self, scheduler: Any) -> list[Any]:
        now = self.journal.clock()
        eligible = scheduler._eligible_bindings(now)
        scheduler._initialize_due_slots(eligible, now)
        scheduler._update_capacity_alerts(eligible)
        results = []
        for key, running in list(self._inflight.items()):
            if running.done():
                try:
                    result = running.result()
                    if result is not None and key != "distribution-worker":
                        results.append(result)
                except Exception as exc:
                    logging.getLogger(__name__).warning(
                        "bus task failed key=%s error=%s", key, type(exc).__name__
                    )
                    try:
                        await self._journal_call(
                            self.journal.gap,
                            "source:" + key,
                            "",
                            type(exc).__name__,
                            type(exc).__name__,
                        )
                    except Exception as gap_exc:
                        logging.getLogger(__name__).warning(
                            "bus gap persistence failed key=%s error=%s",
                            key,
                            type(gap_exc).__name__,
                        )
                        if not is_sqlite_contention(gap_exc):
                            raise
                finally:
                    del self._inflight[key]
        roster_eligible = scheduler._eligible_bindings(now, include_inactive_hours=True)
        shared_realtime: dict[str, tuple[SourceDefinition, list[TickerSourceBinding]]] = {}
        # All bindings use the same semantic day. Do not perform two synchronous
        # calendar/SQLite lookups per binding on the network event loop.
        calendar_error = None
        try:
            day = semantic_day(now)
            realtime_mode = await self._journal_call(self.calendar.is_session, day)
            if not await self._journal_call(
                self.calendar.is_session, day - timedelta(days=1)
            ) and now < boundary(day, minute=1):
                realtime_mode = False
        except Exception as exc:
            realtime_mode = None
            calendar_error = str(exc)
        calendar_failed_tickers: set[str] = set()
        sweep_distribution_sources: set[str] = set()
        for sweep in sorted(
            self.journal.tasks(kind="SWEEP"), key=lambda item: item["inputs"]["cutoff"]
        ):
            if sweep["status"] in {"SUCCEEDED", "FAILED"}:
                continue
            if self.journal.get("pause", sweep["ticker"]) == "all":
                continue
            roster = self.journal.get("sweep_roster", sweep["id"])
            if roster is None:
                identities = []
                for source, binding in roster_eligible:
                    if binding.ticker != sweep["ticker"]:
                        continue
                    identity = f"{sweep['id']}:source:{binding.binding_id}"
                    await self._journal_call(
                        self.journal.put_task,
                        identity,
                        binding.ticker,
                        "SOURCE_SWEEP",
                        {
                            "source": source.model_dump(mode="json"),
                            "binding": binding.model_dump(mode="json"),
                            "cutoff": sweep["inputs"]["cutoff"],
                            "window_start": sweep["inputs"].get("window_start"),
                            "sweep_id": sweep["id"],
                        },
                    )
                    identities.append(identity)
                roster = {"source_tasks": identities, "frozen_at": now.isoformat()}
                await self._journal_call(self.journal.set, "sweep_roster", sweep["id"], roster)
            for identity in roster["source_tasks"]:
                pending = self.journal.get_task(identity)
                assert pending is not None
                key = pending["inputs"]["binding"]["binding_id"]
                shared_key = f"shared:{pending['inputs']['source']['source_id']}"
                if key in self._inflight or shared_key in self._inflight:
                    continue
                task = await self._journal_call(self.journal.claim, identity, seconds=1800)
                if task:
                    if (
                        task["inputs"]["source"]["acquisition_mode"]
                        == AcquisitionMode.BY_DISTRIBUTION
                    ):
                        sweep_distribution_sources.add(task["inputs"]["source"]["source_id"])
                    self._inflight[key] = asyncio.create_task(self._source(scheduler, task))
        for source, binding in eligible:
            if self.journal.get("pause", binding.ticker) == "all":
                continue
            if realtime_mode is None:
                if binding.ticker not in calendar_failed_tickers:
                    await self._journal_call(
                        self.journal.gap,
                        f"bus-calendar:{binding.ticker}",
                        binding.ticker,
                        "CALENDAR_UNAVAILABLE",
                        calendar_error or "calendar unavailable",
                    )
                    calendar_failed_tickers.add(binding.ticker)
                realtime = (
                    self.journal.get("schedule", binding.ticker, {}).get("mode") == "REALTIME"
                )
            else:
                realtime = realtime_mode
            if realtime:
                from doxagent.source_maintenance.settings import enabled as maintenance_enabled
                from doxagent.source_maintenance.signals import scheduler as maintenance_scheduler

                if maintenance_enabled():
                    maintenance_scheduler(
                        binding,
                        scheduler.repository.get_poll_state(binding),
                        now,
                        binding.binding_id in self._inflight,
                    )
                if source.acquisition_mode is AcquisitionMode.BY_DISTRIBUTION:
                    if source.source_id in sweep_distribution_sources or any(
                        key.endswith(":" + source.source_id) for key in self._inflight
                    ):
                        continue
                    shared_realtime.setdefault(source.source_id, (source, []))[1].append(binding)
                    continue
                state = scheduler.repository.get_poll_state(binding)
                if state.next_dispatch_at is None or state.next_dispatch_at <= now:
                    if binding.binding_id not in self._inflight:
                        self._inflight[binding.binding_id] = asyncio.create_task(
                            asyncio.wait_for(scheduler._poll(source, binding, now), timeout=600)
                        )
        for source, bindings in shared_realtime.values():
            key = f"shared:{source.source_id}"
            if key not in self._inflight and scheduler.distribution_due(bindings, now):
                self._inflight[key] = asyncio.create_task(
                    asyncio.wait_for(
                        scheduler._poll_distribution(source, bindings, now), timeout=600
                    )
                )
        # Let newly scheduled I/O start, without waiting for a source or model.
        if (
            scheduler.distribution_worker is not None
            and "distribution-worker" not in self._inflight
        ):
            self._inflight["distribution-worker"] = asyncio.create_task(
                scheduler.distribution_worker.run_once()
            )
        await asyncio.sleep(0)
        return results

    async def _journal_call(self, operation: Any, *args: Any, **kwargs: Any) -> Any:
        # Each entire transaction owns its connection inside the thread.
        for attempt in range(3):
            try:
                return await asyncio.to_thread(operation, *args, **kwargs)
            except Exception as exc:
                if not is_sqlite_contention(exc) or attempt == 2:
                    raise
                await asyncio.sleep(0.1 * (attempt + 1))

    def _yield_source(self, task: dict[str, Any]) -> None:
        from datetime import timedelta

        with self.journal.transaction() as db:
            self.journal.fence(db, task)
            db.execute(
                "UPDATE runtime_tasks SET status='PENDING',due_at=? WHERE id=?",
                ((self.journal.clock() + timedelta(seconds=5)).isoformat(), task["id"]),
            )

    async def _source(self, scheduler: Any, task: dict[str, Any]) -> Any:
        from datetime import datetime, timedelta

        try:
            binding = TickerSourceBinding.model_validate(task["inputs"]["binding"])
            source = SourceDefinition.model_validate(task["inputs"]["source"])
            if source.acquisition_mode is AcquisitionMode.BY_DISTRIBUTION:
                return await self._distribution_source(scheduler, task, source, binding)
            cursor_key = f"{binding.binding_id}:{source.version}:{binding.version}"
            receipt = task["receipt"]
            cutoff = datetime.fromisoformat(task["inputs"]["cutoff"])
            if "window_start" not in receipt:
                from doxagent.message_bus_v2.search_plan import build_query_plan
                from doxagent.semantic_clock import boundary

                start = (
                    task["inputs"].get("window_start")
                    or boundary(semantic_day(cutoff) - timedelta(days=1)).isoformat()
                )
                found = (
                    scheduler.terms.get(binding.ticker)
                    if source.acquisition_mode is AcquisitionMode.BY_SEARCH
                    else None
                )
                frozen_query_plan = (
                    build_query_plan(source, found[1], found[0]).model_dump(mode="json")
                    if found is not None
                    else None
                )
                await self._journal_call(
                    self.journal.checkpoint,
                    task,
                    window_start=start,
                    cutoff=cutoff.isoformat(),
                    page_cursor={},
                    job_ids=[],
                    page_coverages=[],
                    poll_done=False,
                    query_plan=frozen_query_plan,
                )
            receipt = task["receipt"]
            result = None
            if not receipt["poll_done"]:
                from doxagent.message_bus_v2.admission import AdmissionContext
                from doxagent.semantic_clock import boundary

                safe_start = datetime.fromisoformat(
                    task["inputs"].get("window_start")
                    or boundary(semantic_day(cutoff) - timedelta(days=1)).isoformat()
                )
                context = AdmissionContext(
                    mode="CLOSED_SWEEP",
                    sweep_id=task["inputs"].get("sweep_id", task["id"]),
                    source_task_id=task["id"],
                    window_start=safe_start,
                    cutoff=cutoff,
                )
                result = await asyncio.wait_for(
                    scheduler._poll(
                        source,
                        binding,
                        self.journal.clock(),
                        window_start=datetime.fromisoformat(receipt["window_start"]),
                        window_cutoff=cutoff,
                        checkpoint=receipt["page_cursor"],
                        admission_context=context,
                        query_plan_override=receipt.get("query_plan"),
                        freeze_query_plan=True,
                    ),
                    timeout=600,
                )
                if result.error_code:
                    raise RuntimeError(result.error_code)
                # A replay may re-read this page after a crash. Intake identity deduplication
                # returns the same live job IDs; completed provider payloads are also deduped.
                await self._journal_call(
                    self.journal.checkpoint,
                    task,
                    job_ids=sorted(set(receipt["job_ids"]) | set(result.enrichment_job_ids)),
                    page_cursor=result.next_checkpoint,
                    page_coverages=[*receipt["page_coverages"], result.window_coverage],
                    poll_done=result.window_done,
                )
                if not result.window_done:
                    await self._journal_call(self._yield_source, task)
                    return result
            receipt = task["receipt"]
            pending = scheduler.repository.pending_enrichment_ids(receipt["job_ids"])
            if pending:
                await self._journal_call(
                    self.journal.checkpoint, task, pending_job_count=len(pending)
                )
                await self._journal_call(self._yield_source, task)
                return result
            scheduler.service.flush_binding(binding.binding_id, force=True)
            coverage = (
                "COMPLETE"
                if all(v == "COMPLETE" for v in receipt["page_coverages"])
                else "PARTIAL"
                if "PARTIAL" in receipt["page_coverages"]
                else "UNKNOWN"
            )
            if coverage != "PARTIAL":
                await self._journal_call(
                    self.journal.set,
                    "source_sweep_cursor",
                    cursor_key,
                    {"cutoff": cutoff.isoformat(), "source_task": task["id"], "coverage": coverage},
                )
            await self._journal_call(
                self.journal.finish,
                task,
                pending_job_count=0,
                coverage=coverage,
                settlement="INTAKE_TERMINAL",
                attempted_cutoff=cutoff.isoformat(),
                stream_highwater=scheduler.repository.latest_stream_offset(task["ticker"]),
            )
            return result
        except Exception as exc:
            if is_sqlite_contention(exc):
                raise
            if task.get("failures", 0) + 1 >= task.get("max_failures", 3) and task["receipt"].get(
                "job_ids"
            ):
                await self._journal_call(
                    self.journal.gap,
                    "coverage:" + task["id"],
                    task["ticker"],
                    "SOURCE_WINDOW_PARTIAL",
                    type(exc).__name__,
                )
                await self._journal_call(
                    self.journal.checkpoint,
                    task,
                    poll_done=True,
                    page_coverages=[*task["receipt"].get("page_coverages", []), "PARTIAL"],
                    poll_error=type(exc).__name__,
                )
                await self._journal_call(self._yield_source, task)
            else:
                await self._journal_call(self.journal.fail, task, exc)
            return None

    async def _distribution_source(
        self,
        scheduler: Any,
        task: dict[str, Any],
        source: SourceDefinition,
        binding: TickerSourceBinding,
    ) -> Any:
        from datetime import datetime, timedelta

        from doxagent.message_bus_v2.admission import AdmissionContext
        from doxagent.semantic_clock import boundary

        cutoff = datetime.fromisoformat(task["inputs"]["cutoff"])
        start = datetime.fromisoformat(
            task["inputs"].get("window_start")
            or boundary(semantic_day(cutoff) - timedelta(days=1)).isoformat()
        )
        context = AdmissionContext(
            mode="CLOSED_SWEEP",
            sweep_id=task["inputs"].get("sweep_id", task["id"]),
            source_task_id=task["id"],
            window_start=start,
            cutoff=cutoff,
        )
        receipt = task["receipt"]
        if not receipt.get("poll_done"):
            result = await asyncio.wait_for(
                scheduler._poll_distribution(
                    source,
                    [binding],
                    self.journal.clock(),
                    window_start=start,
                    window_cutoff=cutoff,
                    admission_context=context,
                ),
                timeout=600,
            )
            if result.error_code:
                await self._journal_call(
                    self.journal.gap,
                    "coverage:" + task["id"],
                    binding.ticker,
                    "SOURCE_WINDOW_PARTIAL",
                    result.error_code,
                )
            await self._journal_call(
                self.journal.checkpoint,
                task,
                distribution_run_id=result.poll_run_id,
                pending_distribution_delivery_ids=[],
                poll_done=result.window_done or bool(result.error_code),
                coverage="PARTIAL" if result.error_code else result.window_coverage,
            )
            if not result.window_done and not result.error_code:
                await self._journal_call(self._yield_source, task)
                return result
        else:
            result = None
        run_id = task["receipt"].get("distribution_run_id")
        pending = scheduler.distribution.pending_for_run(run_id, binding.ticker) if run_id else []
        if pending:
            await self._journal_call(
                self.journal.checkpoint, task, pending_distribution_delivery_ids=pending
            )
            await self._journal_call(self._yield_source, task)
            return result
        failures = scheduler.distribution.failures_for_run(run_id, binding.ticker) if run_id else []
        coverage = task["receipt"].get("coverage", "UNKNOWN")
        if failures:
            coverage = "PARTIAL"
            await self._journal_call(
                self.journal.gap,
                "distribution:" + task["id"],
                binding.ticker,
                "DISTRIBUTION_DELIVERY_FAILED",
                f"{len(failures)} terminal delivery failures",
            )
        scheduler.service.flush_binding(binding.binding_id, force=True)
        await self._journal_call(
            self.journal.finish,
            task,
            pending_distribution_delivery_ids=[],
            coverage=coverage,
            settlement="INTAKE_TERMINAL",
            attempted_cutoff=cutoff.isoformat(),
            stream_highwater=scheduler.repository.latest_stream_offset(task["ticker"]),
        )
        return result
