"""DoxAgent V2 Persistent Runtime.

This package is intentionally isolated from :mod:`doxagent.persistent_runtime`.
The legacy package and its W1/W2/A2/O3 semantics are not imported here.
"""

from .schema import (
    RuntimeCase,
    RuntimeCaseStatus,
    RuntimeFactCandidate,
    RuntimePrimaryRoute,
    SourceMessageEnvelope,
    SourceMessageSnapshot,
    W1FactExtractionResult,
    W1NoveltyResult,
    W1Round1Result,
    W2PolicyResult,
    W2Round1RecallResult,
    W3CaseResult,
    W3Mode,
    W3RouteCase,
)

__all__ = [
    "RuntimeCase",
    "RuntimeCaseStatus",
    "RuntimeFactCandidate",
    "RuntimePrimaryRoute",
    "SourceMessageEnvelope",
    "SourceMessageSnapshot",
    "W1FactExtractionResult",
    "W1NoveltyResult",
    "W1Round1Result",
    "W2PolicyResult",
    "W2Round1RecallResult",
    "W3CaseResult",
    "W3Mode",
    "W3RouteCase",
]
